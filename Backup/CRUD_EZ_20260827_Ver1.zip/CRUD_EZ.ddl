BEGIN;

CREATE TABLE IF NOT EXISTS CRUD_ONLINE_EZ1 (
    id              BIGSERIAL PRIMARY KEY,
    system_name     VARCHAR(100)  NOT NULL,
    base_date       VARCHAR(20),
    url_message_id  VARCHAR(400),
    adapter         VARCHAR(1000) NOT NULL,
    screen_name     VARCHAR(1000),
    jsp_name        VARCHAR(1000)
);

CREATE INDEX IF NOT EXISTS idx_crud_online_ez1_system_adapter
    ON CRUD_ONLINE_EZ1 (system_name, adapter);

CREATE INDEX IF NOT EXISTS idx_crud_online_ez1_url_message_id
    ON CRUD_ONLINE_EZ1 (url_message_id);

CREATE TABLE IF NOT EXISTS CRUD_ONLINE_EZ2 (
    id           BIGSERIAL PRIMARY KEY,
    system_name  VARCHAR(100)  NOT NULL,
    adapter      VARCHAR(1000) NOT NULL,
    table_name   VARCHAR(500)  NOT NULL,
    create_flag  BOOLEAN       NOT NULL,
    read_flag    BOOLEAN       NOT NULL,
    update_flag  BOOLEAN       NOT NULL,
    delete_flag  BOOLEAN       NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_crud_online_ez2_system_adapter
    ON CRUD_ONLINE_EZ2 (system_name, adapter);

CREATE INDEX IF NOT EXISTS idx_crud_online_ez2_table_name
    ON CRUD_ONLINE_EZ2 (table_name);

COMMIT;
