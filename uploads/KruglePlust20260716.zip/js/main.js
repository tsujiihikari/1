"use strict";

// Servlet APIへ接続する。Tomcat側は krugleapi.war -> /krugleapi 固定。
// index.html を file:// で直接開く検証のため、APIはTomcatの絶対URLに固定する。
const USE_SAMPLE_DATA = false;
const KRUGLE_CONTEXT_PATH = "/krugleapi";
const KRUGLE_API_ABSOLUTE_BASE = "http://10.205.7.19:8080/krugleapi/";
const API_BASE = window.KRUGLE_API_BASE || KRUGLE_API_ABSOLUTE_BASE;

const FILE_HISTORY_STORAGE_KEY = "krugle.history.files";
const FILE_HISTORY_INITIALIZED_VERSION_KEY = "krugle.history.files.initialized.version";
const FILE_HISTORY_INITIAL_VERSION = "20260708_home_history_seed_width_fix2";
const FILE_HISTORY_INITIAL_SEED_MARKER = "INITIAL_FILE_STORAGE_VALUES_20260708_home_history_seed_width_fix2";
const INITIAL_FILE_STORAGE_VALUES = [
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzNys_java.jar/jp/co/fnt/stp1/app/apptier/back/az/nys/model/KyakJkyKjnHjnSyutkTask.java,2026/07/01_12:30:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtt_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctt/model/KjoYmdSyutkTask.java,2026/07/01_12:20:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtt_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctt/model/KjoYmdUpdTask.java,2026/07/01_12:10:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjEdd_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/edd/model/KjEddHojnJohoTask.java,2026/07/01_12:00:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjEdd_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/edd/model/KjEddKabunusiYakuinTorkTask.java,2026/07/01_11:50:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzKzt_java.jar/jp/co/fnt/stp1/app/apptier/back/az/kzt/model/SaknRyuhoGKjo1K2KMainTask.java,2026/07/01_11:40:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjUhk_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/uhk/model/KjUhkDelTask.java,2026/07/01_11:30:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjUhk_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/uhk/model/KjUhkJohoSearchTask.java,2026/07/01_11:20:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtc_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctc/model/KysJohoKjnSyutkTask.java,2026/07/01_11:10:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzJky_java.jar/jp/co/fnt/stp1/app/apptier/back/az/jky/model/SaknRyuhoGKjoInqTask.java,2026/07/01_11:00:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzJky_java.jar/jp/co/fnt/stp1/app/apptier/back/az/jky/model/SaknRyuhoGKjoTask.java,2026/07/01_10:50:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYK5470_upd.sql,2026/07/01_12:30:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF9800_Ikan.sql,2026/07/01_12:20:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF6510_INS.sql,2026/07/01_12:10:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4410_spool.sql,2026/07/01_12:00:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF3030upd_From_CC.sql,2026/07/01_11:50:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISD0607_KYK5300_02_SPOOL.sql,2026/07/01_11:40:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF3030spool_To_CC.sql,2026/07/01_11:30:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4400_BZN_spool.sql,2026/07/01_11:20:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISALTD218.sql,2026/07/01_11:10:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4301_PL_SEL.sql,2026/07/01_11:00:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISALTD078.sql,2026/07/01_10:50:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/meigara/MeigaraIchiran.java,2026/07/01_12:30:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiApplication.java,2026/07/01_12:20:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiApplicationCommand.java,2026/07/01_12:10:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiBbApplication.java,2026/07/01_12:00:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiBbApplicationCommand.java,2026/07/01_11:50:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiPoApplication.java,2026/07/01_11:40:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_po/meigara/MeigaraIchiran.java,2026/07/01_11:30:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_po/sinkoku_jyokyo/KbSnkokMeisaiBbPOApplication.java,2026/07/01_11:20:00"
];
const sampleFiles = INITIAL_FILE_STORAGE_VALUES;
const RECENT_TAB_STORE_LIMIT = 100;
const RECENT_TAB_VISIBLE_LIMIT = 21;
const RECENT_TAB_MIN_COUNT = 0;
const FILE_HISTORY_HOME_DISPLAY_LIMIT = 300;
const FILE_HISTORY_MINI_DISPLAY_LIMIT = 20;
const INITIAL_HISTORY_SAMPLE_COUNT = 20;
const HISTORY_PLACEHOLDER_VALUE = "-";
const INITIAL_RESULT_PLACEHOLDER_COUNT = 30;
let recentWindowStart = 0;
let activeRecentTabKey = "";
let manualRecentWindowShift = false;


function splitHistoryStorageValue(value) {
  if (value && typeof value === "object") {
    const path = String(value.path || value.fullPath || value.filePath || value.filePathName || value.file || value.name || "").trim();
    const openedAt = value.openedAt || value.time || value.updateTime || value.dateTime || value.timestamp || "";
    const fileName = value.fileName || value.file || value.name || "";
    const group = value.group || value.migrationGroup || value.ikogroup || value.ikoGroup || value.projectGroup || "";
    const directoryGroup = value.directoryGroup || value.dirGroup || value.directory || value.dir || value.project || "";
    return {
      path,
      openedAtRaw: String(openedAt || "").trim(),
      fileName: String(fileName || "").trim(),
      group: String(group || "").trim(),
      directoryGroup: String(directoryGroup || "").trim(),
      initialSeed: value.__initialFileHistorySeed === true || value.initialSeed === true,
      seedMarker: String(value.__initialFileHistorySeedMarker || value.seedMarker || "").trim(),
      raw: value
    };
  }

  const text = String(value || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) {
    return { path: text, openedAtRaw: "", fileName: "", group: "", directoryGroup: "", initialSeed: false, seedMarker: "", raw: text };
  }

  const commaIndex = text.lastIndexOf(",");
  if (commaIndex > 0) {
    return {
      path: text.substring(0, commaIndex).trim(),
      openedAtRaw: text.substring(commaIndex + 1).trim(),
      fileName: "",
      group: "",
      directoryGroup: "",
      initialSeed: false,
      seedMarker: "",
      raw: text
    };
  }

  return { path: text, openedAtRaw: "", fileName: "", group: "", directoryGroup: "", initialSeed: false, seedMarker: "", raw: text };
}

function parseHistoryOpenedAt(value, fallbackDate) {
  const raw = String(value || "").trim();
  const fallback = fallbackDate ? toSafeDate(fallbackDate) : new Date();
  if (!raw) return fallback.toISOString();

  const normalized = raw
    .replace(/_/g, "T")
    .replace(/\//g, "-")
    .replace(/\s+/g, "T");
  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? fallback.toISOString() : date.toISOString();
}

function formatHistoryStorageDate(value) {
  const date = toSafeDate(value || new Date());
  const pad = number => String(number).padStart(2, "0");
  return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())}_${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function createHistoryStorageValue(path, openedAt, meta = {}) {
  const fullPath = getHistoryEntryPath(path);
  if (!fullPath || isPlaceholderHistoryValue(fullPath)) return fullPath;

  const result = {
    path: fullPath,
    openedAt: formatHistoryStorageDate(openedAt || new Date())
  };

  const fileName = String(meta.fileName || meta.file || meta.name || "").trim();
  const group = normalizeMigrationGroupName(meta.group || meta.migrationGroup || meta.ikogroup || meta.ikoGroup || "");
  const directoryGroup = cleanDirectoryGroupName(meta.directoryGroup || meta.dirGroup || meta.directory || meta.project || "");
  const initialSeed = meta.initialSeed === true || meta.__initialFileHistorySeed === true;
  const seedMarker = String(meta.seedMarker || meta.__initialFileHistorySeedMarker || (initialSeed ? FILE_HISTORY_INITIAL_SEED_MARKER : "")).trim();

  if (fileName) result.fileName = fileName;
  if (group) result.group = group;
  if (directoryGroup) result.directoryGroup = directoryGroup;
  if (initialSeed) {
    result.__initialFileHistorySeed = true;
    result.__initialFileHistorySeedMarker = seedMarker || FILE_HISTORY_INITIAL_SEED_MARKER;
  }
  return result;
}

function getHistoryEntryPath(value) {
  return splitHistoryStorageValue(value).path;
}

function getHistoryEntryOpenedAt(value, fallbackDate) {
  const entry = splitHistoryStorageValue(value);
  return parseHistoryOpenedAt(entry.openedAtRaw, fallbackDate);
}

function buildRecentTabFromHistoryValue(value, fallbackDate) {
  const path = getHistoryEntryPath(value);
  if (!path || isPlaceholderHistoryValue(path)) return null;
  return {
    path,
    openedAt: getHistoryEntryOpenedAt(value, fallbackDate)
  };
}


function readStoredArray(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) ? value : [];
  } catch (e) {
    return [];
  }
}

function createInitialFileHistorySeedValues() {
  return normalizeFileHistoryValues((Array.isArray(INITIAL_FILE_STORAGE_VALUES) ? INITIAL_FILE_STORAGE_VALUES : [])
    .map((value, index) => {
      const entry = splitHistoryStorageValue(value);
      const path = entry.path;
      if (!isValidFileHistoryPath(path)) return null;
      const openedAt = parseHistoryOpenedAt(entry.openedAtRaw, new Date(Date.now() - index * 60 * 1000));
      return createHistoryStorageValue(path, openedAt, {
        fileName: entry.fileName,
        group: entry.group,
        directoryGroup: entry.directoryGroup,
        initialSeed: true,
        seedMarker: FILE_HISTORY_INITIAL_SEED_MARKER
      });
    })
    .filter(Boolean));
}

function isCurrentInitialFileHistorySeed(value) {
  const entry = splitHistoryStorageValue(value);
  return entry.initialSeed === true && entry.seedMarker === FILE_HISTORY_INITIAL_SEED_MARKER;
}

function isAnyInitialFileHistorySeed(value) {
  const entry = splitHistoryStorageValue(value);
  return entry.initialSeed === true || Boolean(entry.seedMarker);
}

function createInitialFileHistoryCompareSet(seedValues) {
  return new Set((Array.isArray(seedValues) ? seedValues : [])
    .map(stringifyHistoryValueForCompare)
    .filter(Boolean));
}

function initializeFileHistoryStorageIfNeeded() {
  if (USE_SAMPLE_DATA) return;
  try {
    const seedValues = createInitialFileHistorySeedValues();
    const seedCompareSet = createInitialFileHistoryCompareSet(seedValues);
    const storedValues = readStoredArray(FILE_HISTORY_STORAGE_KEY);
    const hasCurrentSeed = storedValues.some(isCurrentInitialFileHistorySeed);

    // INITIAL_FILE_STORAGE_VALUES 由来の旧データだけを先にクリーンする。
    // ただし、現在のマーカー付き seed は残し、ユーザーが実際に開いた同一ファイルの別日時履歴は消さない。
    const cleanedValues = storedValues.filter(value => {
      if (isCurrentInitialFileHistorySeed(value)) return true;
      if (isAnyInitialFileHistorySeed(value)) return false;
      return !seedCompareSet.has(stringifyHistoryValueForCompare(value));
    });

    const nextValues = hasCurrentSeed
      ? normalizeFileHistoryValues(cleanedValues)
      : normalizeFileHistoryValues(seedValues.concat(cleanedValues));

    const before = storedValues.map(stringifyHistoryValueForCompare).join("\u0001");
    const after = nextValues.map(stringifyHistoryValueForCompare).join("\u0001");
    if (before !== after || !hasCurrentSeed) {
      saveArray(FILE_HISTORY_STORAGE_KEY, nextValues);
    }
    localStorage.setItem(FILE_HISTORY_INITIALIZED_VERSION_KEY, FILE_HISTORY_INITIAL_VERSION);
  } catch (e) {
    console.warn("file history storage initialize failed", e);
  }
}

function readFileHistoryValues() {
  const fallback = createInitialFileHistorySeedValues();
  if (USE_SAMPLE_DATA) return normalizeFileHistoryValues(fallback);
  initializeFileHistoryStorageIfNeeded();
  const values = readArray(FILE_HISTORY_STORAGE_KEY, fallback);
  return seedFileHistoryStorage(FILE_HISTORY_STORAGE_KEY, values, fallback);
}

function buildSampleRecentTabs() {
  // 時間タブも、ホーム履歴・右側履歴と同じ「フルパス,日時」の元データから作る。
  const result = [];
  const base = new Date("2026-07-07T10:01:04");
  sampleFiles.forEach((value, index) => {
    const fallback = new Date(base.getTime() - (index * 60 * 1000));
    const item = buildRecentTabFromHistoryValue(value, fallback);
    if (item) result.push(item);
  });
  return result;
}

const sampleRecentTabs = buildSampleRecentTabs();
let sessionRecentTabs = null;

const sampleSearchWords = [
  "TableAccessor | ALL | ALL",
  "CUSTOMER_ID | nkCCIS | java",
  "Command Task Accessor | BPNet | Java",
  "MST_CUSTOMER | SMBC | SQL",
  "QueryAccessor | fast2024 | XML",
  "AccountUpdate | nikkoEZ | ALL",
  "KYF1940 | ALL | java",
  "8jjj8jjeJEjee | nkCCIS | Java",
  "TableAccessor009 | BPNet | SQL",
  "CUSTOMER_ID010 | SMBC | XML",
  "Command Task Accessor011 | fast2024 | ALL",
  "MST_CUSTOMER012 | nikkoEZ | java",
  "QueryAccessor013 | ALL | Java",
  "AccountUpdate014 | nkCCIS | SQL",
  "KYF1940015 | BPNet | XML",
  "8jjj8jjeJEjee016 | SMBC | ALL",
  "TableAccessor017 | fast2024 | java",
  "CUSTOMER_ID018 | nikkoEZ | Java",
  "Command Task Accessor019 | ALL | SQL",
  "MST_CUSTOMER020 | nkCCIS | XML",
  "QueryAccessor021 | BPNet | ALL",
  "AccountUpdate022 | SMBC | java",
  "KYF1940023 | fast2024 | Java",
  "8jjj8jjeJEjee024 | nikkoEZ | SQL",
  "TableAccessor025 | ALL | XML",
  "CUSTOMER_ID026 | nkCCIS | ALL",
  "Command Task Accessor027 | BPNet | java",
  "MST_CUSTOMER028 | SMBC | Java",
  "QueryAccessor029 | fast2024 | SQL",
  "AccountUpdate030 | nikkoEZ | XML",
  "KYF1940031 | ALL | ALL",
  "8jjj8jjeJEjee032 | nkCCIS | java",
  "TableAccessor033 | BPNet | Java",
  "CUSTOMER_ID034 | SMBC | SQL",
  "Command Task Accessor035 | fast2024 | XML",
  "MST_CUSTOMER036 | nikkoEZ | ALL",
  "QueryAccessor037 | ALL | java",
  "AccountUpdate038 | nkCCIS | Java",
  "KYF1940039 | BPNet | SQL",
  "8jjj8jjeJEjee040 | SMBC | XML",
  "TableAccessor041 | fast2024 | ALL",
  "CUSTOMER_ID042 | nikkoEZ | java",
  "Command Task Accessor043 | ALL | Java",
  "MST_CUSTOMER044 | nkCCIS | SQL",
  "QueryAccessor045 | BPNet | XML",
  "AccountUpdate046 | SMBC | ALL",
  "KYF1940047 | fast2024 | java",
  "8jjj8jjeJEjee048 | nikkoEZ | Java",
  "TableAccessor049 | ALL | SQL",
  "CUSTOMER_ID050 | nkCCIS | XML",
  "Command Task Accessor051 | BPNet | ALL",
  "MST_CUSTOMER052 | SMBC | java",
  "QueryAccessor053 | fast2024 | Java",
  "AccountUpdate054 | nikkoEZ | SQL",
  "KYF1940055 | ALL | XML",
  "8jjj8jjeJEjee056 | nkCCIS | ALL",
  "TableAccessor057 | BPNet | java",
  "CUSTOMER_ID058 | SMBC | Java",
  "Command Task Accessor059 | fast2024 | SQL",
  "MST_CUSTOMER060 | nikkoEZ | XML",
  "QueryAccessor061 | ALL | ALL",
  "AccountUpdate062 | nkCCIS | java",
  "KYF1940063 | BPNet | Java",
  "8jjj8jjeJEjee064 | SMBC | SQL",
  "TableAccessor065 | fast2024 | XML",
  "CUSTOMER_ID066 | nikkoEZ | ALL",
  "Command Task Accessor067 | ALL | java",
  "MST_CUSTOMER068 | nkCCIS | Java",
  "QueryAccessor069 | BPNet | SQL",
  "AccountUpdate070 | SMBC | XML",
  "KYF1940071 | fast2024 | ALL",
  "8jjj8jjeJEjee072 | nikkoEZ | java",
  "TableAccessor073 | ALL | Java",
  "CUSTOMER_ID074 | nkCCIS | SQL",
  "Command Task Accessor075 | BPNet | XML",
  "MST_CUSTOMER076 | SMBC | ALL",
  "QueryAccessor077 | fast2024 | java",
  "AccountUpdate078 | nikkoEZ | Java",
  "KYF1940079 | ALL | SQL",
  "8jjj8jjeJEjee080 | nkCCIS | XML"
];

const sampleResults = [
  { file: "KYF1940TableAccessor.java", line: 128, project: "NewNikko", group: "nkCCIS", path: "kayk.online/lib/KjCTMYYYYYY.jar/jp/com/xxx/xxx/xxx/KYF1940TableAccessor.java" },
  { file: "KYF1950TableAccessor.java", line: 82, project: "NewNikko", group: "nkCCIS", path: "kayk.online/lib/KjCTMYYYYYY.jar/jp/com/xxx/xxx/xxx/KYF1950TableAccessor.java" },
  { file: "KjCustomerSearchCommand.java", line: 45, project: "NewNikko", group: "nkCCIS", path: "business-java/lib/KjCommand.jar/jp/com/xxx/command/KjCustomerSearchCommand.java" },
  { file: "KjCustomerSearchTask.java", line: 211, project: "NewNikko", group: "nkCCIS", path: "business-java/lib/KjTask.jar/jp/com/xxx/task/KjCustomerSearchTask.java" },
  { file: "ORD0100QueryAccessor.java", line: 67, project: "BPNet", group: "BPNet", path: "bpnet_dbac/lib/OrderDbac.jar/jp/com/xxx/dbac/ORD0100QueryAccessor.java" },
  { file: "AccountUpdateTableAccessor.java", line: 159, project: "SMBC", group: "SMBC", path: "smbc_dbac/lib/AccountDbac.jar/jp/com/xxx/dbac/AccountUpdateTableAccessor.java" },
  { file: "customer-search.sql", line: 14, project: "fast2024", group: "fast2024", path: "fast/sql/customer/customer-search.sql" },
  { file: "application-context.xml", line: 33, project: "nikkoEZ", group: "nikkoEZ", path: "ez/config/application-context.xml" } ];

const sampleCode = `NIKKO.nkCCIS/efront.online.jar/lib/ApFrKjFtf_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ftf/model/KyakRiskKakzJohoSyutkTask.java


package jp.co.fnt.stp1.app.apptier.front.kj.ftf.model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.fnt.stp1.app.apptier.com.cm.com.exception.SoteiGaSQLException;
import jp.co.fnt.stp1.app.apptier.com.cm.com.task.Task;
import jp.co.fnt.stp1.app.apptier.com.cm.com.task.TaskResult;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.constants.KjFtfAppSymbols;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.constants.KjFtfGyomConst;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.ctrl.param.KakudukeJoho;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.ctrl.param.RiskItem;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1940TableAccessor;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1940TableRecord;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1950TableAccessor;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1950TableRecord;
import jp.co.fnt.stp1.appfw.basefw.APBFWException;
import jp.co.fnt.stp1.appfw.basefw.CommandContext;
import jp.co.fnt.stp1.appfw.basefw.CommandException;
import jp.co.fnt.stp1.appfw.basefw.MsgInfo;

/**
 * <strong>格付算出情報取得タスク</strong>
 * <BR>
 * @author ACC
**/

public class KyakRiskKakzJohoSyutkTask implements Task{
	public static final Map<String,String> KAKUDUKE_KBN_MAP = new HashMap<>();
	static{
		KAKUDUKE_KBN_MAP.put("EH", "00");
		KAKUDUKE_KBN_MAP.put("H", "00");
		KAKUDUKE_KBN_MAP.put("M", "01");
		KAKUDUKE_KBN_MAP.put("L-", "02");
		KAKUDUKE_KBN_MAP.put("L", "02");
	}

    /**
    *  <B>格付算出情報取得する </B>
    * @param CommandContext                コマンドコンテキスト
    * @param kyakCifC                      顧客CIFコード
    * @param coHyjunC                     会社標準コード
    * @exception CommandException          アプリケーションが送出する例外の抽象クラス
    * @exception APBFWException            APBFWが送出する例外の抽象クラス
    **/

    public static TaskResult getKakzJoho(CommandContext context, 
            String kyakCifC, String coHyjunC) throws CommandException, APBFWException {
        // タスクリザルト
        TaskResult taskResult = new TaskResult();

        // 結果格納
		ArrayList<KakudukeJoho> kakudukeJohoList = new ArrayList<KakudukeJoho>();
		String expertJudgement = "";
		String total = "";
		String kakuduke = "";
		String kakudukeKbn = "";

		// DB Accessor
        Kyf1940TableAccessor kyf1940Accessor = new Kyf1940TableAccessor();
        Kyf1950TableAccessor kyf1950Accessor = new Kyf1950TableAccessor();
    	
        Kyf1940TableRecord kyf1940Record = new Kyf1940TableRecord();
        Kyf1950TableRecord kyf1950Record = new Kyf1950TableRecord();
		
        try{
        	// 格付算出根拠情報を取得する
        	kyf1940Accessor.executeQueryKyakRiskKakzJoho(
        			context.getConnectionManager().getConnection(), 
        			coHyjunC, 
        			kyakCifC, 
        			KjFtfGyomConst.RONR_MASY_K_0);
        	
        	// 格付項目名情報を取得する
        	kyf1950Accessor.executeQueryKyakRiskKakzKomkNmJoho(
        			context.getConnectionManager().getConnection(), 
        			coHyjunC, 
        			KjFtfGyomConst.RONR_MASY_K_0);
			
			if ((kyf1940Record = kyf1940Accessor.nextRecord()) != null) {
				// 顧客リスク格付項目名情報
				kyf1950Record = kyf1950Accessor.nextRecord();
				
				// 格付情報_基本項目
				KakudukeJoho basicJoho = editKakudukeJoho(kyf1940Record,kyf1950Record,1,4,"基本項目","10");
				kakudukeJohoList.add(basicJoho);
				
				// 格付情報_加点項目
				KakudukeJoho addJoho = editKakudukeJoho(kyf1940Record,kyf1950Record,5,15,"加点項目","11");
				kakudukeJohoList.add(addJoho);
				
				expertJudgement = kyf1940Record.getExpJuge();
				total = kyf1940Record.getRiskScoreGokei();
				kakuduke = kyf1940Record.getRiskKakzCnd();
				kakudukeKbn = KAKUDUKE_KBN_MAP.get(kakuduke);
				
			} else {
				// データ存在しない場合
				taskResult.setMsgInfo(new MsgInfo("AFKJFTF112001"));
			}
        } catch(SQLException e){
            throw new SoteiGaSQLException(e.getMessage(), e);
        } catch(APBFWException e) {
            throw e;
        } finally{
        		try {
        			kyf1940Accessor.closeStatement();
        			kyf1950Accessor.closeStatement();
    			} catch( SQLException e) {
    				throw new SoteiGaSQLException(e.getMessage(), e);
    			}
        }
        // タスク結果設定
		// 格付情報リストをタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE_LIST, kakudukeJohoList);
		// ExpertJudgementをタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.EXPERT_JUDGEMENT, expertJudgement);
		// 合計をタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.TOTAL, total);
		// 顧客リスク格付をタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE, kakuduke);
		// 顧客リスク格付区分をタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE_KBN, kakudukeKbn);
		
		// タスクリザルト
        taskResult.setEndJtai(TaskResult.OK);
        return taskResult;
    }
    
    /**
     * 格付情報作成
     * @param kyf1940Record KYF1940から取得した情報
     * @param kyf1950Record　KYF1950から取得した情報
     * @param start 情報取得開始位置
     * @param end　情報取得終了位置
     * @param riskNm　リスク要素名
     * @param riskKbn　リスク要素区分
     */
	private static KakudukeJoho editKakudukeJoho(
			Kyf1940TableRecord kyf1940Record, Kyf1950TableRecord kyf1950Record,
			int start, int end, String riskNm, String riskKbn) {
		// リスク格付け情報
		KakudukeJoho joho = new KakudukeJoho();
		// リスク内容リスト
		List<RiskItem> riskItems = new ArrayList<>();
		
		for(int i = start; i <= end; i++){
			RiskItem item = new RiskItem();
			if(kyf1950Record!=null){
				item.setLabel(getItemValue(kyf1950Record,"getKyakAtr"+ String.format("%02d", i)+"nm"));
			}else{
				item.setLabel("");
			}
			item.setPoint(getItemValue(kyf1940Record,"getKyakAtr"+ String.format("%02d", i)+"Pt"));
			riskItems.add(item);
		}
		
		joho.setRiskElementKbn(riskKbn);
		joho.setRiskElementNm(riskNm);
		joho.setRiskItems(riskItems);
		return joho;
	}
	
	/**
     * 項目名によりレコードから項目値を取得
     */
    public static String getItemValue(Object ob, String getName) {
    	String rt = "";
    	try {
    		rt = (String)ob.getClass().getDeclaredMethod(getName).invoke(ob);
    	} catch (Exception e){}
    	return rt;
    }
}`;

const sampleAiCode = `// AIによる解説コード
// このAccessorは、CUSTOMER_IDを条件にMST_CUSTOMERを検索するサンプルです。
// SQL_SELECTで取得項目を定義し、PreparedStatementでバインド変数を設定します。
// ResultSetを1行ずつDTOへ詰め替えて、呼び出し元へListで返却します。

public List<CustomerDto> selectCustomer(Connection con, String customerId) throws Exception {
    // 1. 戻り値用のリストを作成
    List<CustomerDto> result = new ArrayList<CustomerDto>();

    // 2. CUSTOMER_IDを条件に検索
    try (PreparedStatement ps = con.prepareStatement(SQL_SELECT)) {
        ps.setString(1, customerId);

        // 3. 検索結果をDTOへ変換
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                CustomerDto dto = new CustomerDto();
                dto.setCustomerId(rs.getString("CUSTOMER_ID"));
                dto.setCustomerName(rs.getString("CUSTOMER_NAME"));
                dto.setStatus(rs.getString("STATUS"));
                result.add(dto);
            }
        }
    }
    return result;
}`;

const sampleSummaryText = `要約説明

・MST_CUSTOMERを検索するTableAccessorです。
・CUSTOMER_IDを検索条件としてPreparedStatementに設定します。
・取得したCUSTOMER_ID、CUSTOMER_NAME、STATUSをCustomerDtoへ詰め替えます。
・検索結果はList<CustomerDto>として返却します。`;

let currentView = "home";
let currentCodePath = USE_SAMPLE_DATA ? sampleFiles[1] : "";
let codeFontSize = 14;
const CODE_FONT_MIN = 9;
const CODE_FONT_MAX = 24;
const CODE_FONT_STEP = 1;
let activeCodePanel = "source";
let lastSearchParams = null;
let lastSearchMode = "prefix";
let lastSearchResults = [];
let currentCodeMeta = null;
let currentSourceText = "";
let currentSourceLanguage = "java";
let currentTableNames = [];
let currentTableNameSet = new Set();

function $(id) {
  return document.getElementById(id);
}

function formatDateTime(value) {
  const date = toSafeDate(value);
  const pad = value => String(value).padStart(2, "0");
  const week = ["日", "月", "火", "水", "木", "金", "土"][date.getDay()];
  return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())}(${week}) ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function formatSummaryDateTimeValue(value, fallbackDate) {
  const text = String(value == null ? "" : value).trim();
  if (text && text !== "-") {
    if (/^\d{4}\/\d{2}\/\d{2}\([日月火水木金土]\)\s+\d{2}:\d{2}:\d{2}$/.test(text)) {
      return text;
    }
    return formatDateTime(text);
  }
  return fallbackDate ? formatDateTime(fallbackDate) : "-";
}


function apiPath(path) {
  const cleanPath = String(path || "").replace(/^\/+/, "");
  const base = String(API_BASE || "").trim();
  if (base) {
    if (/^https?:\/\//i.test(base)) {
      const normalizedBase = base.endsWith("/") ? base : `${base}/`;
      return new URL(cleanPath, normalizedBase).toString();
    }
    const normalizedBase = base.endsWith("/") ? base.slice(0, -1) : base;
    return `${normalizedBase}/${cleanPath}`;
  }
  // 念のためフォールバック。通常は /krugleapi/search の絶対パスになる。
  return `${KRUGLE_CONTEXT_PATH}/${cleanPath}`;
}

function formBody(params) {
  const body = new URLSearchParams();
  Object.keys(params || {}).forEach(key => {
    const value = params[key];
    if (value !== undefined && value !== null) body.append(key, String(value));
  });
  return body;
}

function buildQueryString(params) {
  return formBody(params).toString();
}

async function fetchJson(path, params = {}, options = {}) {
  const method = String(options.method || "POST").toUpperCase();
  let url = apiPath(path);

  const requestOptions = {
    method,
    headers: {
      "Accept": "application/json"
    },
    cache: "no-store",
    mode: "cors",
    credentials: "omit"
  };

  if (method === "GET") {
    const query = buildQueryString(params);
    if (query) url += (url.indexOf("?") >= 0 ? "&" : "?") + query;
  } else {
    // file:// から呼ぶため、不要なプリフライトを増やさない。
    // charset 付き Content-Type は避け、単純な x-www-form-urlencoded にする。
    requestOptions.headers["Content-Type"] = "application/x-www-form-urlencoded";
    requestOptions.body = formBody(params);
  }

  let response;
  try {
    response = await fetch(url, requestOptions);
  } catch (e) {
    throw new Error(`通信失敗: ${e.message}
URL: ${url}
※ file:// から呼ぶ場合、Servlet側のCORSヘッダが必要です。`);
  }

  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (e) {
      throw new Error(`JSON解析失敗 HTTP ${response.status}: ${text.substring(0, 300)}
URL: ${url}`);
    }
  } else {
    data = {};
  }

  if (!response.ok) {
    throw new Error((data && data.error) ? `${data.error}
URL: ${url}` : `HTTP ${response.status}
URL: ${url}`);
  }
  return data;
}

function submitDownload(path, params = {}) {
  const form = document.createElement("form");
  form.method = "POST";
  form.action = apiPath(path);
  form.style.display = "none";

  Object.keys(params || {}).forEach(key => {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = key;
    input.value = params[key] == null ? "" : String(params[key]);
    form.appendChild(input);
  });

  document.body.appendChild(form);
  form.submit();
  setTimeout(() => form.remove(), 1000);
}

function optionText(selectElement) {
  if (!selectElement) return "";
  const option = selectElement.options[selectElement.selectedIndex];
  return option ? option.textContent.trim() : "";
}

function normalizeKeywordForMode(rawKeyword, mode) {
  const base = String(rawKeyword || "").trim().replace(/^\*+/, "").replace(/\*+$/, "");
  if (mode === "fuzzy") return `*${base}*`;
  return `${base}*`;
}

function buildSearchParams(mode = "prefix") {
  const keywordInput = $("keywordInput");
  const projectSelect = $("groupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  const rawKeyword = keywordInput ? keywordInput.value.trim() : "";
  // 0行目相当の「選択なし」は、検索条件としては全件扱いにする。
  const project = projectSelect && projectSelect.value ? projectSelect.value : "ALL";
  const language = languageSelect && languageSelect.value ? languageSelect.value : "ALL";
  const languageForApi = language === "ALL" ? "ALL" : String(language).toLowerCase();
  const projectText = optionText(projectSelect) || (project === "ALL" ? "すべて" : project);
  const languageText = optionText(languageSelect) || (language === "ALL" ? "すべて" : language);

  return {
    rawKeyword,
    keyword: normalizeKeywordForMode(rawKeyword, mode),
    project,
    projectText,
    language,
    languageText,
    languageForApi,
    findin: "ALL",
    clone: cloneCheck && cloneCheck.checked ? "NO" : "YES",
    source_disp: "NO"
  };
}

function normalizeSearchRow(row, index = 0) {
  const source = row || {};
  const fileName = source.fileName || source.file || source.name || "";
  const path = getHistoryEntryPath(source.path || source.fullPath || source.filePath || fileName);
  const project = source.project || source.projectName || source.group || "";
  const projectParts = String(project).split(".");
  const rawGroup = source.group || source.migrationGroup || source.ikogroup || source.ikoGroup || extractMigrationGroupFromPath(path) || (projectParts.length > 1 ? projectParts[1] : projectParts[0]) || "";
  const group = normalizeMigrationGroupName(rawGroup);
  const directoryGroup = cleanDirectoryGroupName(source.directoryGroup || source.dirGroup || source.directory || extractDirectoryGroupFromPath(path));

  return {
    no: source.no || String(index + 1),
    fileName,
    lineNo: source.lineNo || source.line || "",
    project,
    group,
    directoryGroup,
    path,
    href: source.href || "",
    sourceUrl: source.sourceUrl || "",
    preview: source.preview || "",
    language: source.language || inferLanguageFromPath(path, "java")
  };
}


function normalizeCloneDisplayValue(value, params) {
  const raw = value == null ? "" : String(value).trim();
  if (raw === "YES") return "表示";
  if (raw === "NO") return "非表示";
  if (raw) return raw;
  return params && params.clone === "YES" ? "表示" : "非表示";
}

function setText(id, value) {
  const element = $(id);
  if (element) element.textContent = value == null ? "" : String(value);
}

function setSummaryFromParams(params, startedAt, endedAt, hitCount) {
  setText("summaryCount", hitCount == null ? "-" : hitCount);
  setText("summaryKeyword", params ? params.rawKeyword : "");
  setText("summaryProject", params ? (params.projectText || params.project) : "");
  setText("summaryLanguage", params ? (params.languageText || params.language) : "");
  setText("summaryStart", startedAt ? formatDateTime(startedAt) : "-");
  setText("summaryEnd", endedAt ? formatDateTime(endedAt) : "-");
  setText("summaryClone", params && params.clone === "YES" ? "表示" : "非表示");
}

function setSummaryFromServer(summary, params, startedAt, endedAt, fallbackCount) {
  const source = summary || {};
  setText("summaryCount", source.hitCount || source.count || fallbackCount || 0);
  setText("summaryKeyword", source.keyword || (params ? params.rawKeyword : ""));
  setText("summaryProject", source.project || (params ? (params.projectText || params.project) : ""));
  setText("summaryLanguage", source.language || (params ? (params.languageText || params.language) : ""));
  setText("summaryStart", formatSummaryDateTimeValue(source.startTime, startedAt));
  setText("summaryEnd", formatSummaryDateTimeValue(source.endTime, endedAt));
  setText("summaryClone", normalizeCloneDisplayValue(source.clone, params));
}

function buildInitialResultPlaceholderRows(count = INITIAL_RESULT_PLACEHOLDER_COUNT) {
  return Array.from({ length: count }, (_, index) => ({
    no: String(index + 1),
    fileName: HISTORY_PLACEHOLDER_VALUE,
    group: HISTORY_PLACEHOLDER_VALUE,
    directoryGroup: HISTORY_PLACEHOLDER_VALUE,
    path: HISTORY_PLACEHOLDER_VALUE,
    placeholder: true
  }));
}

function renderInitialResultPlaceholders() {
  renderSearchInitialEmptyState();
}

function renderSearchInitialEmptyState() {
  const body = $("resultBody");
  if (!body) return;
  const card = document.querySelector("#searchView .resultCard");
  if (card) {
    card.classList.add("isInitialEmptyResultCard");
    card.classList.remove("hasSearchResultRows");
  }
  body.innerHTML = `
    <tr class="resultEmptyStateRow">
      <td colspan="5">
        <div class="resultEmptyStateMessage">検索結果がここに表示されます</div>
      </td>
    </tr>
  `;
}

function resetInitialSearchSummary() {
  setText("summaryCount", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryKeyword", "");
  setText("summaryProject", "ALL");
  setText("summaryLanguage", "ALL");
  setText("summaryStart", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryEnd", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryClone", "非表示");
}

function bindResultRowEvents(body, normalizedRows = []) {
  if (!body) return;
  body.querySelectorAll("tr[data-index]").forEach(rowElement => {
    rowElement.addEventListener("click", () => {
      const index = Number(rowElement.dataset.index);
      const row = normalizedRows[index] || normalizeSearchRow({
        no: rowElement.dataset.no || String(index + 1),
        fileName: rowElement.dataset.fileName || "",
        project: rowElement.dataset.project || "",
        group: rowElement.dataset.group || "",
        directoryGroup: rowElement.dataset.directoryGroup || "",
        path: rowElement.dataset.path || "",
        href: rowElement.dataset.href || "",
        sourceUrl: rowElement.dataset.sourceUrl || "",
        preview: rowElement.getAttribute("title") || "",
        language: rowElement.dataset.language || ""
      }, index);
      if (row && !row.placeholder) openCode(row.path, { row });
    });
  });
}

function setResultCardState(rowCount) {
  const card = document.querySelector("#searchView .resultCard");
  if (card) {
    card.classList.remove("isInitialEmptyResultCard");
    card.classList.toggle("hasSearchResultRows", Number(rowCount || 0) > 0);
  }
}

function renderSearchHtml(resultHtml, rows = []) {
  const body = $("resultBody");
  if (!body) return;

  const normalizedRows = Array.isArray(rows) ? rows.map(normalizeSearchRow) : [];
  setResultCardState(normalizedRows.length);
  body.innerHTML = resultHtml || `
    <tr class="resultNoDataRow">
      <td colspan="5">検索結果がありません</td>
    </tr>
  `;
  bindResultRowEvents(body, normalizedRows);
}

function renderSearchRows(rows, options = {}) {
  const body = $("resultBody");
  if (!body) return;

  const isPlaceholderMode = options && options.placeholder === true;
  const normalizedRows = Array.isArray(rows) ? (isPlaceholderMode ? rows : rows.map(normalizeSearchRow)) : [];
  setResultCardState(normalizedRows.length);
  if (!normalizedRows.length) {
    body.innerHTML = `
      <tr class="resultNoDataRow">
        <td colspan="5">検索結果がありません</td>
      </tr>
    `;
    return;
  }

  body.innerHTML = normalizedRows.map((row, index) => `
    <tr class="${row.placeholder ? "isPlaceholderResultRow" : ""}" data-index="${index}" title="${escapeHtml(row.placeholder ? "" : (row.preview || row.path))}">
      <td>${escapeHtml(row.no || String(index + 1))}</td>
      <td>${escapeHtml(row.fileName || row.path)}</td>
      <td>${escapeHtml(row.group || row.project)}</td>
      <td>${escapeHtml(row.directoryGroup || "")}</td>
      <td>${escapeHtml(row.path || "")}</td>
    </tr>
  `).join("");

  bindResultRowEvents(body, normalizedRows);
}

function inferLanguageFromPath(path, fallback = "plaintext") {
  const value = String(path || "").toLowerCase();
  if (value.endsWith(".java")) return "java";
  if (value.endsWith(".sql")) return "sql";
  if (value.endsWith(".xml")) return "xml";
  if (value.endsWith(".jsp")) return "xml";
  if (value.endsWith(".html") || value.endsWith(".htm")) return "xml";
  if (value.endsWith(".js")) return "javascript";
  if (value.endsWith(".css")) return "css";
  if (value.endsWith(".sh")) return "bash";
  return fallback;
}

const GROUP_SELECT_SECTIONS = [
  {
    key: "NIKKO",
    label: "NIKKO",
    match: value => /^(newnikko|nikko|nk)/i.test(value)
  },
  {
    key: "BPS",
    label: "BPS",
    match: value => /^(bpnet|bps)/i.test(value)
  },
  {
    key: "SY",
    label: "→ SYはじまり",
    match: value => /^sy/i.test(value)
  },
  {
    key: "RPS",
    label: "RPS",
    match: value => /^rps/i.test(value)
  },
  {
    key: "OTHER",
    label: "その他",
    match: () => true
  }
];

function normalizeGroupProjectOption(project) {
  const source = project || {};
  const value = typeof project === "string" ? project : (source.value || source.text || "");
  const text = typeof project === "string" ? project : (source.text || source.value || "");
  const normalized = {
    value: String(value == null ? "" : value).trim(),
    text: String(text == null ? "" : text).trim(),
    selected: Boolean(source && source.selected)
  };
  if (!normalized.value && !normalized.text) return null;
  if (!normalized.text) normalized.text = normalized.value;
  if (!normalized.value) normalized.value = normalized.text;
  return normalized;
}

function isAllProjectOption(option) {
  const value = String(option && option.value || "").trim().toLowerCase();
  const text = String(option && option.text || "").trim().toLowerCase();
  return value === "all" || text === "all" || text === "すべて";
}

function groupProjectClassifierValue(option) {
  return `${option.value || ""} ${option.text || ""}`.replace(/\s+/g, "").trim();
}

function groupProjectDisplayText(option) {
  const rawText = String((option && (option.text || option.value)) || "").trim();
  if (!rawText) return "";

  // Select の value は API から来た値をそのまま保持する。
  // 画面に出す文字だけ、NIKKO. / BPS. / RPS. / SY. などのカテゴリ接頭詞を外す。
  const stripped = rawText.replace(/^(?:NewNikko|NIKKO|BPS|RPS|SY)[._-](?=.)/i, "");
  return stripped || rawText;
}

function findGroupProjectSection(option) {
  const value = groupProjectClassifierValue(option);
  return GROUP_SELECT_SECTIONS.find(section => section.match(value)) || GROUP_SELECT_SECTIONS[GROUP_SELECT_SECTIONS.length - 1];
}

function buildGroupedProjectOptionsHtml(projects) {
  const normalized = (Array.isArray(projects) ? projects : [])
    .map(normalizeGroupProjectOption)
    .filter(Boolean);

  const seen = new Set(["all"]);
  const buckets = GROUP_SELECT_SECTIONS.reduce((acc, section) => {
    acc[section.key] = [];
    return acc;
  }, {});

  normalized.forEach(option => {
    if (isAllProjectOption(option)) return;
    const seenKey = String(option.value || option.text || "").trim().toLowerCase();
    if (!seenKey || seen.has(seenKey)) return;
    seen.add(seenKey);
    const section = findGroupProjectSection(option);
    buckets[section.key].push(option);
  });

  const html = [`<option value="ALL" class="groupSelectAll">すべて</option>`];
  GROUP_SELECT_SECTIONS.forEach(section => {
    const items = buckets[section.key] || [];
    if (!items.length) return;
    html.push(`<optgroup label="${escapeHtml(section.label)}">`);
    items.forEach(item => {
      const displayText = groupProjectDisplayText(item);
      const selected = item.selected ? " selected" : "";
      html.push(`<option value="${escapeHtml(item.value)}"${selected}>${escapeHtml(displayText)}</option>`);
    });
    html.push(`</optgroup>`);
  });
  return html.join("");
}

function setGroupSelectValue(select, currentValue) {
  if (!select) return;
  const target = currentValue || "ALL";
  const hasTarget = Array.from(select.options).some(option => !option.disabled && option.value === target);
  select.value = hasTarget ? target : "ALL";
}


function groupComboOptionMatches(option, query) {
  if (!query) return true;
  const text = String(option && option.textContent || "").toLowerCase();
  const value = String(option && option.value || "").toLowerCase();
  return text.includes(query) || value.includes(query);
}

function getGroupComboElements() {
  return {
    select: $("groupSelect"),
    combo: $("groupCombo"),
    button: $("groupComboButton"),
    search: $("groupComboSearch"),
    list: $("groupComboList")
  };
}

function ensureGroupComboDom() {
  const select = $("groupSelect");
  if (!select) return null;

  const field = select.closest ? select.closest(".field") : null;
  if (field) field.classList.add("fieldGroup");

  let combo = $("groupCombo");
  if (!combo) {
    combo = document.createElement("div");
    combo.id = "groupCombo";
    combo.className = "groupCombo";
    combo.innerHTML = `
      <div id="groupComboButton" class="groupComboButton" role="combobox" aria-haspopup="listbox" aria-expanded="false" aria-controls="groupComboMenu">
        <input id="groupComboSearch" class="groupComboSearch" type="text" autocomplete="off" spellcheck="false" aria-label="移行グループ検索" value="すべて">
        <span class="groupComboArrow" aria-hidden="true"></span>
      </div>
      <div id="groupComboMenu" class="groupComboMenu" role="listbox" aria-label="移行グループ選択">
        <div id="groupComboList" class="groupComboList"></div>
      </div>
    `;
    select.insertAdjacentElement("afterend", combo);
  }

  select.classList.add("nativeGroupSelect");
  if (field) field.classList.add("isComboReady");

  const elements = getGroupComboElements();
  if (!combo.dataset.bound) {
    combo.dataset.bound = "1";
    combo.dataset.searching = "0";

    const openFromDisplay = () => {
      openGroupCombo();
    };

    elements.button.addEventListener("click", event => {
      event.preventDefault();
      openFromDisplay();
    });

    elements.search.addEventListener("focus", () => {
      openFromDisplay();
      // 現在選択中の表示文字は初期表示として残す。
      // そのまま入力すると置き換えられるように全選択する。
      setTimeout(() => elements.search.select(), 0);
    });

    elements.search.addEventListener("input", () => {
      combo.dataset.searching = "1";
      openGroupCombo({ skipSelect: true });
      refreshGroupCombo({ keepOpen: true });
    });

    elements.search.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        event.preventDefault();
        closeGroupCombo();
        elements.search.focus({ preventScroll: true });
        return;
      }
      if (event.key === "Enter") {
        const firstItem = elements.list.querySelector(".groupComboItem");
        if (firstItem) {
          event.preventDefault();
          selectGroupComboValue(firstItem.dataset.value);
        }
        return;
      }
      if (event.key === "ArrowDown") {
        const firstItem = elements.list.querySelector(".groupComboItem");
        if (firstItem) {
          event.preventDefault();
          firstItem.focus({ preventScroll: true });
        }
      }
    });

    elements.list.addEventListener("click", event => {
      const item = event.target.closest ? event.target.closest(".groupComboItem") : null;
      if (!item) return;
      event.preventDefault();
      selectGroupComboValue(item.dataset.value);
    });

    elements.list.addEventListener("keydown", event => {
      const current = event.target.closest ? event.target.closest(".groupComboItem") : null;
      if (!current) return;
      const items = Array.from(elements.list.querySelectorAll(".groupComboItem"));
      const index = items.indexOf(current);
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectGroupComboValue(current.dataset.value);
        return;
      }
      if (event.key === "Escape") {
        event.preventDefault();
        closeGroupCombo();
        elements.search.focus({ preventScroll: true });
        return;
      }
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        const nextIndex = event.key === "ArrowDown" ? Math.min(items.length - 1, index + 1) : Math.max(0, index - 1);
        if (items[nextIndex]) items[nextIndex].focus({ preventScroll: true });
      }
    });

    elements.list.addEventListener("wheel", event => {
      // ドロップダウン内では、ページ側ではなくリスト側を優先して縦スクロールさせる。
      const list = elements.list;
      const maxScrollTop = list.scrollHeight - list.clientHeight;
      const goingUp = event.deltaY < 0;
      const goingDown = event.deltaY > 0;
      const canScrollUp = list.scrollTop > 0;
      const canScrollDown = list.scrollTop < maxScrollTop - 1;
      if ((goingUp && canScrollUp) || (goingDown && canScrollDown)) {
        event.stopPropagation();
      }
    }, { passive: true });

    document.addEventListener("click", event => {
      if (!combo.contains(event.target)) closeGroupCombo();
    });
  }

  refreshGroupCombo({ resetFilter: true, keepOpen: combo.classList.contains("isOpen") });
  return elements;
}

function openGroupCombo(options = {}) {
  const elements = getGroupComboElements();
  if (!elements.combo || !elements.button || !elements.search) return;
  elements.combo.classList.add("isOpen");
  elements.button.setAttribute("aria-expanded", "true");
  refreshGroupCombo({ keepOpen: true });
  if (!options.skipSelect) {
    setTimeout(() => {
      elements.search.focus({ preventScroll: true });
      if (elements.combo.dataset.searching !== "1") elements.search.select();
    }, 0);
  }
}

function closeGroupCombo() {
  const elements = getGroupComboElements();
  if (!elements.combo || !elements.button || !elements.search) return;
  elements.combo.classList.remove("isOpen");
  elements.button.setAttribute("aria-expanded", "false");
  elements.combo.dataset.searching = "0";
  elements.search.value = getSelectedGroupComboLabel(elements.select);
}

function selectGroupComboValue(value) {
  const elements = getGroupComboElements();
  if (!elements.select) return;
  const target = String(value || "ALL");
  const option = Array.from(elements.select.options).find(item => !item.disabled && item.value === target);
  elements.select.value = option ? option.value : "ALL";
  elements.select.dispatchEvent(new Event("change", { bubbles: true }));
  if (elements.combo) elements.combo.dataset.searching = "0";
  if (elements.search) elements.search.value = getSelectedGroupComboLabel(elements.select);
  refreshGroupCombo({ resetFilter: true });
  closeGroupCombo();
  if (elements.search) elements.search.focus({ preventScroll: true });
}

function getSelectedGroupComboLabel(select) {
  if (!select) return "すべて";
  const selected = select.options[select.selectedIndex];
  if (!selected || selected.disabled) return "すべて";
  return String(selected.textContent || selected.value || "すべて").trim() || "すべて";
}

function appendGroupComboItem(fragment, option, className = "") {
  const item = document.createElement("button");
  item.type = "button";
  item.className = `groupComboItem ${className}`.trim();
  item.setAttribute("role", "option");
  item.dataset.value = option.value || "ALL";
  item.textContent = String(option.textContent || option.value || "").trim();
  item.title = option.value || item.textContent;
  item.tabIndex = -1;
  fragment.appendChild(item);
  return item;
}

function refreshGroupCombo(options = {}) {
  const elements = getGroupComboElements();
  const { select, combo, search, list } = elements;
  if (!select || !combo || !search || !list) return;

  if (options.resetFilter) {
    combo.dataset.searching = "0";
    search.value = getSelectedGroupComboLabel(select);
  }

  const query = combo.dataset.searching === "1" ? String(search.value || "").trim().toLowerCase() : "";

  const fragment = document.createDocumentFragment();
  const allOptions = [];
  const sections = [];
  let currentSection = null;

  Array.from(select.options).forEach(option => {
    if (option.disabled && option.classList.contains("groupSelectHeader")) {
      currentSection = { label: String(option.textContent || "").trim(), items: [] };
      sections.push(currentSection);
      return;
    }

    if (option.value === "ALL" || option.classList.contains("groupSelectAll")) {
      allOptions.push(option);
      return;
    }

    if (!currentSection) {
      currentSection = { label: "その他", items: [] };
      sections.push(currentSection);
    }
    currentSection.items.push(option);
  });

  allOptions.forEach(option => {
    if (!query || groupComboOptionMatches(option, query)) {
      const item = appendGroupComboItem(fragment, option, "groupComboAll");
      item.setAttribute("aria-selected", select.value === option.value ? "true" : "false");
      item.classList.toggle("isSelected", select.value === option.value);
    }
  });

  let visibleDataCount = 0;
  sections.forEach(section => {
    const matchedItems = section.items.filter(option => groupComboOptionMatches(option, query));
    if (!matchedItems.length) return;

    const header = document.createElement("div");
    header.className = "groupComboHeader";
    header.textContent = section.label;
    fragment.appendChild(header);

    matchedItems.forEach(option => {
      const item = appendGroupComboItem(fragment, option, "groupComboData");
      const selected = select.value === option.value;
      item.setAttribute("aria-selected", selected ? "true" : "false");
      item.classList.toggle("isSelected", selected);
      visibleDataCount += 1;
    });
  });

  if (!fragment.childNodes.length || (query && visibleDataCount === 0 && !allOptions.some(option => groupComboOptionMatches(option, query)))) {
    const empty = document.createElement("div");
    empty.className = "groupComboEmpty";
    empty.textContent = "該当なし";
    fragment.appendChild(empty);
  }

  const previousScrollTop = list.scrollTop;
  list.innerHTML = "";
  list.appendChild(fragment);
  if (options.keepOpen) list.scrollTop = Math.min(previousScrollTop, Math.max(0, list.scrollHeight - list.clientHeight));
}

async function loadInitialData() {
  if (USE_SAMPLE_DATA) return;

  try {
    const data = await fetchJson("/init", {}, { method: "GET" });
    const projects = Array.isArray(data.projects) ? data.projects : [];
    const select = $("groupSelect");
    if (!select || !projects.length) return;

    const current = select.value || "ALL";
    select.innerHTML = buildGroupedProjectOptionsHtml(projects);
    setGroupSelectValue(select, current);
    refreshGroupCombo({ resetFilter: true });
  } catch (e) {
    console.error(e);
    showCopyFeedback("/init 接続失敗");
  }
}

function readArray(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) && value.length > 0 ? value : fallback;
  } catch (e) {
    return fallback;
  }
}

function saveArray(key, value) {
  localStorage.setItem(key, JSON.stringify(value.slice(0, key === FILE_HISTORY_STORAGE_KEY ? 300 : 100))); }

function isAutoFilledRecentTab(item) {
  return Boolean(item && (item.autoFilled === true || item.__autoFilled === true));
}

function createAutoFilledRecentTab(path, openedAt) {
  return {
    path: getHistoryEntryPath(path || currentCodePath || sampleFiles[0]),
    openedAt: toSafeDate(openedAt).toISOString(),
    autoFilled: true
  };
}

function ensureMinimumRecentTabs(tabs) {
  const base = (Array.isArray(tabs) ? tabs : [])
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (base.length === 0) {
    base.push(createAutoFilledRecentTab(currentCodePath || sampleFiles[0], new Date()));
  }

  // 実履歴が35件未満の場合は、画面右端にある最後の時刻から1分ずつ戻して35件まで補完する。
  // 補完行は localStorage へ保存しない。実際に閲覧された履歴と混ざらないよう autoFilled を付ける。
  let cursor = toSafeDate(base[base.length - 1].openedAt);
  const fillerPath = base[base.length - 1].path || currentCodePath || sampleFiles[0];
  while (base.length < RECENT_TAB_MIN_COUNT) {
    cursor = new Date(cursor.getTime() - 60 * 1000);
    base.push(createAutoFilledRecentTab(fillerPath, cursor));
  }

  return base.slice(0, RECENT_TAB_STORE_LIMIT);
}

function readRecentTabs() {
  // ①ホーム履歴、②上段時刻タブ、③ソース右側履歴は同じ元データから作る。
  // 時刻タブは fileStorage に入っているファイル履歴分をそのまま使う。
  // ただし件数が多すぎる場合は、並び順上位100件までに制限する。
  const historyValues = readFileHistoryValues();
  const tabs = normalizeFileHistoryValues(historyValues)
    .map((value, index) => buildRecentTabFromHistoryValue(value, new Date(Date.now() - index * 60 * 1000)))
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  return tabs.map((item, index) => normalizeRecentTab(item, index));
}

function saveRecentTabs(value) {
  // 互換用。時間タブ専用のlocalStorageは使わず、krugle.history.filesを正とする。
}

function recentTabKey(item) {
  if (!item) return "";
  return `${item.openedAt || ""}::${item.path || ""}`;
}

function ensureActiveRecentVisible(tabs) {
  if (!Array.isArray(tabs) || !tabs.length) {
    recentWindowStart = 0;
    return;
  }

  const activeIndex = tabs.findIndex(item => recentTabKey(item) === activeRecentTabKey);
  if (activeIndex < 0) {
    recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
    return;
  }

  if (activeIndex < recentWindowStart) {
    recentWindowStart = activeIndex;
  } else if (activeIndex >= recentWindowStart + RECENT_TAB_VISIBLE_LIMIT) {
    recentWindowStart = activeIndex - RECENT_TAB_VISIBLE_LIMIT + 1;
  }

  recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
}

function addRecentTab(path, meta = {}) {
  const fullPath = getHistoryEntryPath(path);
  if (!fullPath) return null;
  const openedAt = new Date();
  const item = { path: fullPath, openedAt: openedAt.toISOString() };
  addHistory(FILE_HISTORY_STORAGE_KEY, createHistoryStorageValue(fullPath, openedAt, meta), []);
  activeRecentTabKey = recentTabKey(item);
  recentWindowStart = 0;
  renderRecentTabs();
  return item;
}

function toSafeDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? new Date() : date;
}

function normalizeRecentTab(item, index) {
  const fallback = sampleRecentTabs[index % sampleRecentTabs.length] || sampleRecentTabs[0];
  const path = getHistoryEntryPath(item && item.path ? item.path : (fallback ? fallback.path : sampleFiles[0]));
  const openedAtValue = item && item.openedAt ? item.openedAt : (fallback ? fallback.openedAt : new Date().toISOString());
  const openedAt = toSafeDate(openedAtValue).toISOString();
  return { path, openedAt, autoFilled: isAutoFilledRecentTab(item) };
}

function formatTabDate(isoText) {
  const date = toSafeDate(isoText);
  const week = ["日", "月", "火", "水", "木", "金", "土"][date.getDay()];
  const pad = value => String(value).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())}(${week})`;
}

function formatTabTime(isoText) {
  const date = toSafeDate(isoText);
  const pad = value => String(value).padStart(2, "0");
  return `${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function dateKey(isoText) {
  const date = toSafeDate(isoText);
  const pad = value => String(value).padStart(2, "0");
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}`;
}

function shiftRecentWindow(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!tabs.length) return;

  const maxStart = Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT);
  recentWindowStart = Math.max(0, Math.min(maxStart, recentWindowStart + offset));
  manualRecentWindowShift = true;
  renderRecentTabs();
}

function renderRecentTabs() {
  const area = $("recentTabArea");
  if (!area) return;

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!activeRecentTabKey && tabs.length) {
    const fallbackActive = tabs.find(item => item.path === currentCodePath) || tabs[0];
    activeRecentTabKey = recentTabKey(fallbackActive);
  }

  if (manualRecentWindowShift) {
    recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
    manualRecentWindowShift = false;
  } else {
    ensureActiveRecentVisible(tabs);
  }

  area.classList.toggle("hasMoreLeft", recentWindowStart > 0);
  area.classList.toggle("hasMoreRight", recentWindowStart + RECENT_TAB_VISIBLE_LIMIT < tabs.length);

  const visibleTabs = tabs.slice(recentWindowStart, recentWindowStart + RECENT_TAB_VISIBLE_LIMIT);
  const groups = [];
  visibleTabs.forEach(item => {
    const key = dateKey(item.openedAt);
    const last = groups[groups.length - 1];
    if (!last || last.key !== key) {
      groups.push({ key, label: formatTabDate(item.openedAt), count: 1 });
    } else {
      last.count += 1;
    }
  });

  area.innerHTML = `
    <button class="recentNavArrow recentNavArrowLeft" type="button" aria-label="左のタブへ移動" title="左のタブへ移動">
      <svg class="recentNavIconSvg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M14.2 4.8L8.3 12l5.9 7.2" />
      </svg>
    </button>
    <div class="recentDateRow">
      ${groups.map((group, index) => {
        const prevGroup = groups[index - 1];
        const afterNarrowDateGroup = !!prevGroup && prevGroup.count <= 2;
        const className = afterNarrowDateGroup ? "recentDateGroup isAfterNarrowDateGroup" : "recentDateGroup";
        const shiftPx = 0;
        const extraWidthPx = group.count <= 2 && index < groups.length - 1 ? (group.count === 1 ? 70 : 44) : 0;
        return `
        <div class="${className}" style="--tab-count:${group.count}; --date-shift-x:${shiftPx}px; --date-extra-width:${extraWidthPx}px">
          ${escapeHtml(group.label)}
        </div>
      `;
      }).join("")}
    </div>
    <div class="recentTimeRow">
      ${visibleTabs.map((item, index) => {
        const key = recentTabKey(item);
        return `
          <button class="tabTime${key === activeRecentTabKey ? " isActive" : ""}" type="button"
                  data-path="${escapeHtml(item.path)}"
                  data-opened-at="${escapeHtml(item.openedAt)}"
                  data-recent-index="${recentWindowStart + index}"
                  title="${escapeHtml(item.path)}">
            ${escapeHtml(formatTabTime(item.openedAt))}
          </button>
        `;
      }).join("")}
    </div>
    <button class="recentNavArrow recentNavArrowRight" type="button" aria-label="右のタブへ移動" title="右のタブへ移動">
      <svg class="recentNavIconSvg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M9.8 4.8L15.7 12l-5.9 7.2" />
      </svg>
    </button>
  `;

  area.querySelectorAll(".tabTime").forEach(button => {
    button.addEventListener("click", () => {
      const index = Number(button.dataset.recentIndex);
      const item = tabs[index];
      if (item) openCode(item.path, { addRecent: false, recentItem: item });
    });
  });

  const recentPrevButton = area.querySelector(".recentNavArrowLeft");
  const recentNextButton = area.querySelector(".recentNavArrowRight");
  if (recentPrevButton) {
    recentPrevButton.addEventListener("click", event => {
      event.preventDefault();
      // ページ送りではなく、表示ウィンドウを1タブ分だけ左へずらす。
      shiftRecentWindow(-1);
    });
  }
  if (recentNextButton) {
    recentNextButton.addEventListener("click", event => {
      event.preventDefault();
      // ページ送りではなく、表示ウィンドウを1タブ分だけ右へずらす。
      shiftRecentWindow(1);
    });
  }
}

function openRelativeRecentTab(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!tabs.length) return;

  let index = tabs.findIndex(item => recentTabKey(item) === activeRecentTabKey);
  if (index < 0) index = tabs.findIndex(item => item.path === currentCodePath);
  if (index < 0) index = 0;

  const nextIndex = (index + offset + tabs.length) % tabs.length;
  const next = tabs[nextIndex];
  if (next && next.path) openCode(next.path, { addRecent: false, recentItem: next });
}

function moveMainTabByKeyboard(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  const total = 2 + tabs.length;
  if (total <= 0) return;

  let index = 0;
  if (currentView === "search") {
    index = 1;
  } else if (currentView === "code") {
    const activeIndex = tabs.findIndex(item => recentTabKey(item) === activeRecentTabKey);
    const pathIndex = tabs.findIndex(item => item.path === currentCodePath);
    index = 2 + (activeIndex >= 0 ? activeIndex : Math.max(0, pathIndex));
  }

  const nextIndex = (index + offset + total) % total;
  if (nextIndex === 0) {
    showView("home");
    return;
  }
  if (nextIndex === 1) {
    showView("search");
    return;
  }

  const recentItem = tabs[nextIndex - 2];
  if (recentItem && recentItem.path) {
    openCode(recentItem.path, { addRecent: false, recentItem });
  }
}

function addHistory(key, value, fallback) {
  if (!value) return;
  if (key === FILE_HISTORY_STORAGE_KEY) {
    const current = readArray(key, fallback || []);
    const next = normalizeFileHistoryValues([value].concat(current));
    saveArray(key, next);
    return;
  }
  const next = readArray(key, fallback).filter(item => item !== value);
  next.unshift(value);
  saveArray(key, next);
}

function buildPlaceholderHistory(count = INITIAL_HISTORY_SAMPLE_COUNT) {
  return Array.from({ length: count }, () => HISTORY_PLACEHOLDER_VALUE);
}

function isPlaceholderHistoryValue(value) {
  return String(value || "").trim() === HISTORY_PLACEHOLDER_VALUE;
}

function isValidFileHistoryPath(path) {
  const text = String(path || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) return false;

  // 過去版で localStorage に入った「ファイル名だけ」「列分割後の断片」などのゴミを除外する。
  // ファイル履歴は、NIKKO.nkCCIS/kyak.online.jar/... のようなフルパスだけを正とする。
  if (text.indexOf("/") < 0) return false;
  if (/^(undefined|null|nan)$/i.test(text)) return false;
  return true;
}

function cleanDirectoryGroupName(value) {
  const text = String(value || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) return text;

  // 2列目のパス要素が kyak.online.jar / xxx.war / xxx.zip の場合は、
  // DIRGROUP としては拡張子を落として kyak.online の形で表示する。
  return text.replace(/\.(jar|war|ear|zip)$/i, "");
}

function getPathPartsForGroup(path) {
  return String(path || "")
    .split("/")
    .map(part => part.trim())
    .filter(Boolean);
}

function isKnownMigrationGroupSegment(value) {
  return /^(NIKKO|BPS|RPS)\./i.test(String(value || "").trim());
}

function isLikelyDirectoryOnlyPath(parts) {
  if (!Array.isArray(parts) || parts.length < 2) return false;
  return /^(lib|java|src|source|sql|xml|jsp|sh|config|conf|classes)$/i.test(parts[1]);
}

function extractMigrationGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";

  // NIKKO.nkCCIS/... / BPS.xxx/... / RPS.xxx/... は1階層目が移行グループ。
  if (isKnownMigrationGroupSegment(parts[0])) {
    return normalizeMigrationGroupName(parts[0]);
  }

  // SMBC/smbc_dbac/... のように1階層目が移行グループ、2階層目がディレクトリグループの形式。
  // kayk.online/lib/... のように2階層目が lib の場合は、1階層目をディレクトリグループとして扱う。
  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return normalizeMigrationGroupName(parts[0]);
  }

  return "";
}

function extractDirectoryGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";

  if (isKnownMigrationGroupSegment(parts[0])) {
    return cleanDirectoryGroupName(parts[1] || "");
  }

  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return cleanDirectoryGroupName(parts[1] || parts[0]);
  }

  return cleanDirectoryGroupName(parts[0]);
}

function stringifyHistoryValueForCompare(value) {
  const entry = splitHistoryStorageValue(value);
  return [
    entry.path || "",
    entry.openedAtRaw || "",
    entry.fileName || "",
    entry.group || "",
    entry.directoryGroup || ""
  ].join("");
}

function normalizeHistoryValues(values) {
  const result = [];
  const used = new Set();
  (Array.isArray(values) ? values : []).forEach(value => {
    const text = String(value || "").trim();
    const path = getHistoryEntryPath(value);
    if (!text || !path || isPlaceholderHistoryValue(path) || used.has(path)) return;
    used.add(path);
    result.push(text);
  });
  return result;
}

function compareFileHistoryItems(a, b) {
  const timeDiff = toSafeDate(b.openedAt).getTime() - toSafeDate(a.openedAt).getTime();
  if (timeDiff !== 0) return timeDiff;
  return String(a.path || "").localeCompare(String(b.path || ""));
}

function normalizeFileHistoryValues(values) {
  const map = new Map();
  (Array.isArray(values) ? values : []).forEach((value, index) => {
    const entry = splitHistoryStorageValue(value);
    const path = entry.path;
    if (!isValidFileHistoryPath(path)) return;

    const openedAt = parseHistoryOpenedAt(entry.openedAtRaw, new Date(Date.now() - index * 60 * 1000));
    const normalizedValue = createHistoryStorageValue(path, openedAt, {
      fileName: entry.fileName,
      group: entry.group,
      directoryGroup: entry.directoryGroup,
      initialSeed: entry.initialSeed,
      seedMarker: entry.seedMarker
    });
    const existing = map.get(path);
    if (!existing || toSafeDate(openedAt).getTime() > toSafeDate(existing.openedAt).getTime()) {
      map.set(path, { path, openedAt, value: normalizedValue });
    }
  });

  return Array.from(map.values())
    .sort(compareFileHistoryItems)
    .map(item => item.value);
}

function seedFileHistoryStorage(key, values, sampleValues) {
  let result = normalizeFileHistoryValues(values);
  if (!result.length) {
    result = normalizeFileHistoryValues(sampleValues);
  }

  const raw = Array.isArray(values) ? values.map(stringifyHistoryValueForCompare).filter(Boolean) : [];
  const normalized = result.map(stringifyHistoryValueForCompare).filter(Boolean);
  if (!USE_SAMPLE_DATA && normalized.join("") !== raw.join("")) {
    saveArray(key, result);
  }
  return result;
}

function getDisplayFileHistoryRows(values, count = FILE_HISTORY_HOME_DISPLAY_LIMIT) {
  return normalizeFileHistoryValues(values).slice(0, count);
}

function addSearchResultsToFileHistory(rows, openedAt = new Date()) {
  if (USE_SAMPLE_DATA) return;
  const additions = (Array.isArray(rows) ? rows : [])
    .map((row, index) => normalizeSearchRow(row, index))
    .filter(row => row && !row.placeholder && isValidFileHistoryPath(row.path))
    .map(row => createHistoryStorageValue(row.path, openedAt, {
      fileName: row.fileName,
      group: row.group,
      directoryGroup: row.directoryGroup
    }));
  if (!additions.length) return;

  const current = readArray(FILE_HISTORY_STORAGE_KEY, []);
  saveArray(FILE_HISTORY_STORAGE_KEY, normalizeFileHistoryValues(additions.concat(current)));
  sessionRecentTabs = null;
  renderRecentTabs();
}

function seedHistoryStorage(key, values, sampleValues, count = INITIAL_HISTORY_SAMPLE_COUNT) {
  const original = normalizeHistoryValues(values);
  const result = original.slice();
  const used = new Set(result);

  (Array.isArray(sampleValues) ? sampleValues : []).forEach(value => {
    if (result.length >= count) return;
    const text = String(value || "").trim();
    if (!text || isPlaceholderHistoryValue(text) || used.has(text)) return;
    used.add(text);
    result.push(text);
  });

  // 初回表示や履歴20件未満の環境では、サンプルを含めて20件までlocalStorageへ保存する。
  // 後で固定サンプル値に差し替えるだけで、全ユーザーの初回起動時に20件入った状態を再現できる。
  // 過去版で入った「-」補完も、保存し直すことで履歴データから除去する。
  const rawLength = Array.isArray(values) ? values.length : 0;
  const hasStorageDifference = rawLength !== original.length || result.join("") !== original.join("");
  if (!USE_SAMPLE_DATA && hasStorageDifference) {
    saveArray(key, result);
  }
  return result;
}

function getDisplayHistoryRows(values, count = INITIAL_HISTORY_SAMPLE_COUNT) {
  return normalizeHistoryValues(values).slice(0, count);
}

function normalizeMigrationGroupName(value) {
  const text = String(value || "").trim();
  if (!text) return "";

  // NIKKO. / BPS. / RPS. 始まりは、その接頭辞を空文字へ置換する。
  // 例: NIKKO.nkCCIS -> nkCCIS
  const withoutKnownPrefix = text.replace(/^(NIKKO|BPS|RPS)\./, "");
  if (withoutKnownPrefix !== text) return withoutKnownPrefix;

  // 既存データ互換: SMBC.SMBC / fast2024.fast2024 / nikkoEZ.nikkoEZ なども
  // 画面上は後半の移行グループ名だけを表示する。
  const dotIndex = text.indexOf(".");
  return dotIndex >= 0 ? text.substring(dotIndex + 1) : text;
}

function formatHistoryFileParts(value) {
  const entry = splitHistoryStorageValue(value);
  const path = entry.path;
  if (!isValidFileHistoryPath(path)) {
    return [HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE];
  }

  const pathParts = getPathPartsForGroup(path);
  const fileName = entry.fileName || pathParts[pathParts.length - 1] || path;
  const group = normalizeMigrationGroupName(entry.group || extractMigrationGroupFromPath(path));
  const directoryGroup = cleanDirectoryGroupName(entry.directoryGroup || extractDirectoryGroupFromPath(path));
  return [fileName, group, directoryGroup];
}

function formatHistoryFileHtml(value) {
  const parts = formatHistoryFileParts(value);
  const names = ["name", "group", "area"];
  return parts.map((part, index) =>
    `<span class="historyToken historyToken-${names[index] || index}">${escapeHtml(part)}</span>`
  ).join("");
}

function formatHistoryFileCellsHtml(value, cellClassPrefix = "historyFile") {
  const parts = formatHistoryFileParts(value);
  const classes = ["Name", "Group", "Dir"];
  return parts.map((part, index) =>
    `<td class="${cellClassPrefix}${classes[index]}">${escapeHtml(part)}</td>`
  ).join("");
}


function renderGlobalHistoryMini(files) {
  const body = $("globalHistoryMiniBody");
  if (!body) return;

  // ソースコード画面右側の履歴も、初回・20件未満ならサンプルで20件まで埋める。
  // 「-」補完ではなく、ユーザーが初回表示時の見た目を把握できるサンプル行として扱う。
  const source = normalizeFileHistoryValues(files).slice(0, FILE_HISTORY_MINI_DISPLAY_LIMIT);

  body.innerHTML = source.map((value, index) => {
    const path = getHistoryEntryPath(value);
    const isPlaceholder = !isValidFileHistoryPath(path);
    return `
      <tr class="globalHistoryMiniRow${isPlaceholder ? " isPlaceholderHistoryRow" : ""}" data-path="${isPlaceholder ? "" : escapeHtml(path)}" title="${escapeHtml(path)}">
        <td class="globalHistoryMiniNoCell">${index + 1}</td>
        ${formatHistoryFileCellsHtml(value, "globalHistoryMiniFile")}
      </tr>
    `;
  }).join("");

  body.querySelectorAll("tr").forEach(row => {
    row.addEventListener("click", () => {
      if (!row.dataset.path) return;
      openCode(row.dataset.path);
    });
  });
}

function formatHistorySearchHtml(value) {
  if (isPlaceholderHistoryValue(value)) {
    return [HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE]
      .map((part, index) =>
        `<span class="historySearchToken historySearchToken-${index}">${escapeHtml(part)}</span>`
      )
      .join("");
  }

  return String(value || "")
    .split("|")
    .map(part => part.trim())
    .filter(Boolean)
    .map((part, index) =>
      `<span class="historySearchToken historySearchToken-${index}">${escapeHtml(part)}</span>`
    )
    .join("");
}

function setSelectValueByTextOrValue(selectElement, value, fallback = "ALL") {
  if (!selectElement) return;
  const target = String(value || fallback).trim();
  const normalizedTarget = target.toLowerCase();
  const option = Array.from(selectElement.options).find(item => {
    const optionValue = String(item.value || "").trim().toLowerCase();
    const optionText = String(item.textContent || "").trim().toLowerCase();
    return optionValue === normalizedTarget || optionText === normalizedTarget;
  });
  selectElement.value = option ? option.value : fallback;
}

function fillSearchFormFromHistory(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim());

  const keyword = parts[0] || "";
  const group = parts[1] || "ALL";
  const language = parts[2] || "ALL";

  const keywordInput = $("keywordInput");
  if (keywordInput) keywordInput.value = keyword;

  setSelectValueByTextOrValue($("groupSelect"), group, "ALL");
  refreshGroupCombo({ resetFilter: true });
  setSelectValueByTextOrValue($("languageSelect"), language, "ALL");
}

function openSearchFromHistory(value) {
  fillSearchFormFromHistory(value);
  showView("search");
  runSearch(true, "prefix");
}

function renderHistory() {
  let files = readFileHistoryValues();
  let words = USE_SAMPLE_DATA ? sampleSearchWords : readArray("krugle.history.words", []);

  if (!USE_SAMPLE_DATA) {
    words = seedHistoryStorage("krugle.history.words", words, sampleSearchWords, INITIAL_HISTORY_SAMPLE_COUNT);
  }

  const displayFiles = getDisplayFileHistoryRows(files, FILE_HISTORY_HOME_DISPLAY_LIMIT);
  const displayWords = getDisplayHistoryRows(words, INITIAL_HISTORY_SAMPLE_COUNT);

  renderGlobalHistoryMini(files);

  $("historyFileBody").innerHTML = displayFiles.map((value, index) => {
    const path = getHistoryEntryPath(value);
    const isPlaceholder = !isValidFileHistoryPath(path);
    return `
      <tr class="${isPlaceholder ? "isPlaceholderHistoryRow" : ""}" data-path="${isPlaceholder ? "" : escapeHtml(path)}" title="${escapeHtml(path)}">
        <td>${index + 1}</td>
        ${formatHistoryFileCellsHtml(value, "historyFile")}
      </tr>
    `;
  }).join("");

  $("historySearchBody").innerHTML = displayWords.map((value, index) => {
    const isPlaceholder = isPlaceholderHistoryValue(value);
    return `
      <tr class="${isPlaceholder ? "isPlaceholderHistoryRow" : ""}" data-keyword="${isPlaceholder ? "" : escapeHtml(value)}" title="${escapeHtml(value)}">
        <td>${index + 1}</td>
        <td class="historySearchText">${formatHistorySearchHtml(value)}</td>
      </tr>
    `;
  }).join("");

  document.querySelectorAll("#historyFileBody tr").forEach(row => {
    row.addEventListener("click", () => {
      if (!row.dataset.path) return;
      openCode(row.dataset.path);
    });
  });
  document.querySelectorAll("#historySearchBody tr").forEach(row => {
    row.addEventListener("click", () => {
      if (!row.dataset.keyword) return;
      openSearchFromHistory(row.dataset.keyword);
    });
  });
}

function setActiveTab(viewName) {
  document.querySelectorAll(".tabBtn").forEach(button => button.classList.remove("isActive"));
  if (viewName !== "code") {
    document.querySelectorAll(".tabTime").forEach(button => button.classList.remove("isActive"));
  }
  const target = document.querySelector(`.tabBtn[data-view="${viewName}"]:not(.tabFile)`);
  if (target) target.classList.add("isActive"); }

function showView(viewName) {
  currentView = viewName;
  document.body.classList.toggle("isCodeScreen", viewName === "code");
  document.querySelectorAll(".viewBlock").forEach(view => view.classList.remove("isVisible"));
  $(`${viewName}View`).classList.add("isVisible");
  setActiveTab(viewName);
  if (viewName === "home") renderHistory();
  if (viewName === "code") renderCode(); }

function getDirectoryGroup(path) {
  return extractDirectoryGroupFromPath(path);
}

async function runSearch(saveHistory = true, mode = "prefix") {
  const startedAt = new Date();
  const params = buildSearchParams(mode);
  lastSearchMode = mode;
  lastSearchParams = params;

  if (saveHistory) {
    addHistory("krugle.history.words", `${params.rawKeyword} | ${params.projectText || params.project} | ${params.languageText || params.language}`, []);
  }

  setSummaryFromParams(params, startedAt, null, "検索中");
  const body = $("resultBody");
  if (body) body.innerHTML = `<tr><td colspan="5">検索中...</td></tr>`;

  if (USE_SAMPLE_DATA) {
    const endedAt = new Date(startedAt.getTime() + 1000);
    lastSearchResults = sampleResults.map(normalizeSearchRow);
    setSummaryFromParams(params, startedAt, endedAt, lastSearchResults.length);
    addSearchResultsToFileHistory(lastSearchResults, endedAt);
    renderSearchRows(lastSearchResults);
    return;
  }

  try {
    const data = await fetchJson("/search", {
      keyword: params.keyword,
      project: params.project,
      language: params.languageForApi,
      findin: params.findin,
      clone: params.clone,
      source_disp: params.source_disp
    });
    const endedAt = new Date();
    const serverRows = Array.isArray(data.rows) ? data.rows : data.results;
    lastSearchResults = Array.isArray(serverRows) ? serverRows.map(normalizeSearchRow) : [];
    setSummaryFromServer(data.summary, params, startedAt, endedAt, lastSearchResults.length);
    addSearchResultsToFileHistory(lastSearchResults, endedAt);
    if (typeof data.resultHtml === "string") {
      renderSearchHtml(data.resultHtml, lastSearchResults);
    } else {
      renderSearchRows(lastSearchResults);
    }
  } catch (e) {
    console.error(e);
    lastSearchResults = [];
    setSummaryFromParams(params, startedAt, new Date(), 0);
    if (body) body.innerHTML = `<tr><td colspan="5">/search 接続失敗：${escapeHtml(e.message)}</td></tr>`;
    showCopyFeedback("/search 接続失敗");
  }
}

async function openCode(path, options = {}) {
  currentCodePath = getHistoryEntryPath(path || currentCodePath);
  currentCodeMeta = options.row ? Object.assign({}, options.row) : { path: currentCodePath };
  currentCodeMeta.path = currentCodePath;
  currentSourceText = "読み込み中...";
  currentSourceLanguage = inferLanguageFromPath(currentCodePath, currentCodeMeta.language || "java");
  activeCodePanel = "source";

  if (options.addRecent === false && options.recentItem) {
    activeRecentTabKey = recentTabKey(normalizeRecentTab(options.recentItem, 0));
    renderRecentTabs();
  } else {
    addRecentTab(currentCodePath, currentCodeMeta || {});
  }

  showView("code");

  if (USE_SAMPLE_DATA) {
    setCurrentTableNames(["MST_CUSTOMER", "KYF1940", "RPS_TABLE_LIST"]);
    currentSourceText = sampleCode;
    renderCode(currentSourceText, currentSourceLanguage);
    return;
  }

  const sourceParams = {
    path: currentCodeMeta.path || currentCodePath,
    fullPath: currentCodeMeta.path || currentCodePath,
    filePath: currentCodeMeta.path || currentCodePath,
    project: currentCodeMeta.project || "",
    href: currentCodeMeta.href || "",
    sourceUrl: currentCodeMeta.sourceUrl || "",
    language: currentSourceLanguage,
    source_disp: "YES"
  };
  const directUrl = `${apiPath("/source")}?${buildQueryString(sourceParams)}`;

  try {
    // sourceはGETで呼ぶ。ブラウザで直接URL確認もしやすくする。
    const data = await fetchJson("/source", sourceParams, { method: "GET" });
    currentSourceText = data.source || data.text || "";
    currentSourceLanguage = data.language || currentSourceLanguage;
    setCurrentTableNames(data.tableNames || []);
    if (data.tableListError) {
      console.warn("table list load failed:", data.tableListError);
    }
    renderCode(currentSourceText, currentSourceLanguage);
  } catch (e) {
    console.error(e);
    currentSourceText = `/source 接続失敗

${e.message}

直接確認URL:
${directUrl}

確認ポイント:
1. krugleapi.war がCORS対応版か
2. /krugleapi/source が404にならないか
3. Chrome DevToolsのNetworkでAccess-Control-Allow-Originが返っているか`;
    renderCode(currentSourceText, "plaintext");
    showCopyFeedback("/source 接続失敗");
  }
}

function renderCode(sourceText = currentSourceText, language = currentSourceLanguage) {
  const codeBlock = $("codeBlock");
  const source = sourceText || (USE_SAMPLE_DATA ? sampleCode : "");
  let displayText = source;
  let displayLanguage = language || inferLanguageFromPath(currentCodePath, "java");

  if (activeCodePanel === "ai") {
    displayText = sampleAiCode;
    displayLanguage = "java";
  } else if (activeCodePanel === "summary") {
    displayText = sampleSummaryText;
    displayLanguage = "plaintext";
  }

  $("codeTitle").textContent = currentCodePath || "";

  document.querySelectorAll(".codeModeTab").forEach(button => {
    button.classList.toggle("isActive", button.dataset.codePanel === activeCodePanel);
  });

  codeBlock.removeAttribute("data-highlighted");
  delete codeBlock.dataset.highlighted;

  codeBlock.className = `language-${displayLanguage}`;
  codeBlock.textContent = displayText || "";
  setCodeFontSize(codeFontSize);

  if (window.hljs) {
    window.hljs.highlightElement(codeBlock);
  }

  if (activeCodePanel === "source") {
    enhanceSourceHighlights(codeBlock, {
      language: displayLanguage,
      path: currentCodePath
    });
  }

  renderRecentTabs();
}

function normalizeTableNames(tableNames) {
  const out = [];
  const seen = new Set();
  (Array.isArray(tableNames) ? tableNames : []).forEach(value => {
    const name = String(value == null ? "" : value).trim();
    const key = name.toUpperCase();
    if (!key || seen.has(key)) return;
    seen.add(key);
    out.push(name);
  });
  return out;
}

function setCurrentTableNames(tableNames) {
  currentTableNames = normalizeTableNames(tableNames);
  currentTableNameSet = new Set(currentTableNames.map(name => name.toUpperCase()));
}

function normalizeHighlightLanguage(language) {
  const value = String(language || "").toLowerCase();
  if (value === "java" || value === "language-java") return "java";
  if (value === "sql" || value === "language-sql") return "sql";
  return value;
}

function enhanceSourceHighlights(codeBlock, options = {}) {
  if (!codeBlock || !codeBlock.textContent) return;

  const language = normalizeHighlightLanguage(options.language || inferLanguageFromPath(options.path || currentCodePath, "plaintext"));
  const path = String(options.path || currentCodePath || "");
  const isJava = language === "java" || /\.java(?:$|[?#])/i.test(path);
  const javaSourceClassName = isJava ? getJavaSourceClassName(path) : "";
  const tableSet = currentTableNameSet || new Set();
  const fullText = codeBlock.textContent || "";

  // フレームワーク側（package に appfw を含む .java）は、テーブル名・Javaクラス名ともに自前ハイライトしない。
  if (isJava && isAppfwJavaSource(fullText, path)) return;

  const javaCommentRanges = isJava ? findJavaCommentRanges(fullText) : [];
  const javaDeclarationRanges = isJava ? findJavaDeclarationRanges(fullText) : [];
  const javaImportExclusions = isJava ? buildJavaImportHighlightExclusions(fullText) : new Set();

  const textNodes = collectHighlightTargetTextNodes(codeBlock, isJava);
  textNodes.forEach(item => replaceTextNodeWithCodeHighlights(item, {
    isJava,
    tableSet,
    fullText,
    javaCommentRanges,
    javaDeclarationRanges,
    javaImportExclusions,
    javaSourceClassName
  }));
}

function collectHighlightTargetTextNodes(root, isJava) {
  const result = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let offset = 0;

  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue || "";
    const start = offset;
    offset += text.length;

    if (!text || !CODE_IDENTIFIER_PATTERN.test(text)) {
      CODE_IDENTIFIER_PATTERN.lastIndex = 0;
      continue;
    }
    CODE_IDENTIFIER_PATTERN.lastIndex = 0;

    const parent = node.parentElement;
    if (!parent) continue;
    if (parent.closest && parent.closest(".codeKeywordLink")) continue;

    // .java はコメント内を一切ハイライトしない。
    if (isJava && parent.closest && parent.closest(".hljs-comment")) continue;

    result.push({ node, text, start });
  }
  return result;
}

function replaceTextNodeWithCodeHighlights(item, context) {
  const node = item.node;
  const text = item.text;
  const start = item.start;
  const fragment = document.createDocumentFragment();
  let lastIndex = 0;
  CODE_IDENTIFIER_PATTERN.lastIndex = 0;
  let match;

  while ((match = CODE_IDENTIFIER_PATTERN.exec(text)) !== null) {
    const keyword = match[0];
    const index = match.index;
    const globalIndex = start + index;
    const highlight = classifyCodeKeyword(keyword, globalIndex, context);

    if (index > lastIndex) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex, index)));
    }

    if (highlight) {
      const link = document.createElement("button");
      link.type = "button";
      link.className = "codeKeywordLink " + highlight.className;
      link.dataset.keyword = keyword;
      link.dataset.keywordType = highlight.type;
      link.style.setProperty("--keyword-hit-width", "calc(" + keyword.length + "ch + 1.7em)");
      link.textContent = keyword;
      link.title = highlight.title;
      fragment.appendChild(link);
    } else {
      fragment.appendChild(document.createTextNode(keyword));
    }

    lastIndex = index + keyword.length;
  }

  if (lastIndex < text.length) {
    fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
  }

  if (node.parentNode) node.parentNode.replaceChild(fragment, node);
}

function classifyCodeKeyword(keyword, globalIndex, context) {
  const isJava = context.isJava;
  const tableSet = context.tableSet;
  const fullText = context.fullText;
  const javaCommentRanges = context.javaCommentRanges || [];
  const javaDeclarationRanges = context.javaDeclarationRanges || [];
  const javaImportExclusions = context.javaImportExclusions || new Set();
  const javaSourceClassName = String(context.javaSourceClassName || "");
  const upper = keyword.toUpperCase();

  // 表示中の .java ファイル自身のクラス名は、自前ハイライトの対象外にする。
  // 例: KakzJohoSyutkQueryAccessor.java -> KakzJohoSyutkQueryAccessor は強調しない。
  if (isJava && javaSourceClassName && keyword === javaSourceClassName) {
    return null;
  }

  if (isJava && (
    isJavaPackageOrImportLineAt(fullText, globalIndex) ||
    isIndexInRanges(globalIndex, javaCommentRanges) ||
    isIndexInRanges(globalIndex, javaDeclarationRanges)
  )) {
    return null;
  }

  // java.sql/java.util など Java 標準パッケージ由来、appfw 由来のクラスはハイライトしない。
  if (isJava && (
    javaImportExclusions.has(keyword) ||
    isJavaOrFrameworkQualifiedIdentifierAt(fullText, globalIndex)
  )) {
    return null;
  }

  // テーブル名は .java でも SQL/XML/JSP 等でも同一ルールでハイライトする。
  if (tableSet && tableSet.has(upper)) {
    return {
      type: "table",
      className: "codeTableKeyword",
      title: keyword + " テーブル名"
    };
  }

  if (isJava && isJavaClassNameCandidate(keyword)) {
    return {
      type: "java-class",
      className: "codeJavaClassKeyword",
      title: keyword + " Javaクラス名"
    };
  }

  return null;
}

function getJavaSourceClassName(path) {
  const cleanPath = String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/");
  const fileName = cleanPath.substring(cleanPath.lastIndexOf("/") + 1);
  return /\.java$/i.test(fileName) ? fileName.slice(0, -5) : "";
}

function isJavaPackageOrImportLineAt(fullText, index) {
  const source = String(fullText || "");
  const lineStart = source.lastIndexOf("\n", Math.max(0, index - 1)) + 1;
  let lineEnd = source.indexOf("\n", index);
  if (lineEnd < 0) lineEnd = source.length;
  const line = source.slice(lineStart, lineEnd);
  return /^\s*(?:package|import\s+(?:static\s+)?)\b/.test(line);
}


function isAppfwJavaSource(sourceText, path) {
  const source = String(sourceText || "");
  const packageMatch = source.match(/^\s*package\s+([^;]+);/m);
  const packageName = packageMatch ? packageMatch[1].trim() : "";
  const pathText = String(path || "");

  return /(^|\.)appfw(\.|$)/i.test(packageName) ||
    /(?:^|[\\/._-])appfw(?:[\\/._-]|$)/i.test(pathText) ||
    /\.appfw\./i.test(pathText);
}

function buildJavaImportHighlightExclusions(sourceText) {
  const excludes = new Set();
  const source = String(sourceText || "");
  const importPattern = /^\s*import\s+(?:static\s+)?([^;]+);/gm;
  let match;

  while ((match = importPattern.exec(source)) !== null) {
    const importPath = String(match[1] || "").trim();
    if (!importPath || !isIgnoredJavaImportPackage(importPath)) continue;

    const className = extractImportedClassName(importPath);
    if (className) excludes.add(className);
  }

  return excludes;
}

function isIgnoredJavaImportPackage(importPath) {
  const value = String(importPath || "").trim().toLowerCase();
  return value.startsWith("java.") ||
    value.startsWith("javax.") ||
    value.startsWith("jdk.") ||
    value.startsWith("sun.") ||
    value.startsWith("com.sun.") ||
    value.startsWith("org.w3c.") ||
    value.startsWith("org.xml.sax.") ||
    /(^|\.)appfw(\.|$)/i.test(value);
}

function extractImportedClassName(importPath) {
  const cleaned = String(importPath || "").trim();
  if (!cleaned || cleaned.endsWith(".*")) return "";

  const parts = cleaned.split(".").filter(Boolean);
  for (let i = parts.length - 1; i >= 0; i--) {
    if (/^[A-Z_$]/.test(parts[i])) return parts[i];
  }
  return "";
}

function isJavaOrFrameworkQualifiedIdentifierAt(sourceText, index) {
  const source = String(sourceText || "");
  const prefix = source.slice(Math.max(0, index - 220), index);
  const qualifiedPrefixMatch = prefix.match(/(?:[$A-Za-z_][_$A-Za-z0-9]*\.)+$/);
  if (!qualifiedPrefixMatch) return false;

  const qualifiedPrefix = qualifiedPrefixMatch[0].toLowerCase();
  return qualifiedPrefix.startsWith("java.") ||
    qualifiedPrefix.startsWith("javax.") ||
    qualifiedPrefix.startsWith("jdk.") ||
    qualifiedPrefix.startsWith("sun.") ||
    qualifiedPrefix.startsWith("com.sun.") ||
    qualifiedPrefix.startsWith("org.w3c.") ||
    qualifiedPrefix.startsWith("org.xml.sax.") ||
    /(^|\.)appfw\./i.test(qualifiedPrefix);
}

function findJavaDeclarationRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  const declarationLinePattern = /^\s*(?:@[A-Za-z0-9_.$]+(?:\([^)]*\))?\s*)*(?:(?:public|protected|private|abstract|final|static|strictfp)\s+)*(?:class|interface|enum|record)\s+[A-Za-z_$][_$A-Za-z0-9]*/;
  const extendsImplementsLinePattern = /\b(?:extends|implements)\b/;
  let lineStart = 0;
  let inClassDeclaration = false;

  while (lineStart <= source.length) {
    let lineEnd = source.indexOf("\n", lineStart);
    if (lineEnd < 0) lineEnd = source.length;
    const line = source.slice(lineStart, lineEnd);
    const trimmed = line.trim();
    const targetLine = trimmed && !trimmed.startsWith("//") && !trimmed.startsWith("*");
    const startsClassDeclaration = targetLine && declarationLinePattern.test(line);
    const isExtendsOrImplementsLine = targetLine && extendsImplementsLinePattern.test(line);

    if (targetLine && (inClassDeclaration || startsClassDeclaration || isExtendsOrImplementsLine)) {
      ranges.push({ start: lineStart, end: lineEnd });
    }

    if (startsClassDeclaration && !/[{;]/.test(line)) {
      inClassDeclaration = true;
    }
    if (inClassDeclaration && /[{;]/.test(line)) {
      inClassDeclaration = false;
    }

    if (lineEnd >= source.length) break;
    lineStart = lineEnd + 1;
  }

  return ranges;
}

function findJavaCommentRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  let quote = "";
  let escaped = false;

  for (let i = 0; i < source.length; i++) {
    const ch = source.charAt(i);
    const next = source.charAt(i + 1);

    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === quote) {
        quote = "";
      }
      continue;
    }

    if (ch === "\"" || ch === "'") {
      quote = ch;
      continue;
    }

    if (ch === "/" && next === "/") {
      const start = i;
      let end = source.indexOf("\n", i + 2);
      if (end < 0) end = source.length;
      ranges.push({ start, end });
      i = end;
      continue;
    }

    if (ch === "/" && next === "*") {
      const start = i;
      let end = source.indexOf("*/", i + 2);
      end = end < 0 ? source.length : end + 2;
      ranges.push({ start, end });
      i = end - 1;
    }
  }
  return ranges;
}

function isIndexInRanges(index, ranges) {
  for (let i = 0; i < ranges.length; i++) {
    if (index >= ranges[i].start && index < ranges[i].end) return true;
    if (index < ranges[i].start) return false;
  }
  return false;
}

function isJavaClassNameCandidate(keyword) {
  if (!keyword) return false;
  if (JAVA_STANDARD_CLASS_EXCLUDES.has(keyword)) return false;
  if (JAVA_RESERVED_WORD_EXCLUDES.has(keyword)) return false;
  if (!/^[A-Z][A-Za-z0-9_$]*$/.test(keyword)) return false;

  // SELECT_FOR_UPDATE や DB_UPDJI1 などの定数・カラム名は、クラス名としては除外する。
  if (/^[A-Z0-9_$]+$/.test(keyword)) return false;

  return true;
}

const CODE_IDENTIFIER_PATTERN = /[$#A-Za-z_][_$#A-Za-z0-9]*/g;

const JAVA_RESERVED_WORD_EXCLUDES = new Set([
  "Abstract", "Assert", "Boolean", "Break", "Byte", "Case", "Catch", "Char", "Class", "Const",
  "Continue", "Default", "Do", "Double", "Else", "Enum", "Extends", "Final", "Finally", "Float",
  "For", "Goto", "If", "Implements", "Import", "Instanceof", "Int", "Interface", "Long", "Native",
  "New", "Package", "Private", "Protected", "Public", "Return", "Short", "Static", "Strictfp", "Super",
  "Switch", "Synchronized", "This", "Throw", "Throws", "Transient", "Try", "Void", "Volatile", "While"
]);

const JAVA_STANDARD_CLASS_EXCLUDES = new Set([
  "Appendable", "AutoCloseable", "Boolean", "Byte", "Character", "CharSequence", "Class", "ClassLoader",
  "Cloneable", "Comparable", "Compiler", "Double", "Enum", "Exception", "Float", "Integer", "Iterable",
  "Long", "Math", "Number", "Object", "Package", "Process", "ProcessBuilder", "Readable", "Runtime",
  "RuntimeException", "SecurityManager", "Short", "StackTraceElement", "StrictMath", "String", "StringBuffer",
  "StringBuilder", "System", "Thread", "ThreadGroup", "ThreadLocal", "Throwable", "Void",
  "BigDecimal", "BigInteger", "Date", "Calendar", "GregorianCalendar", "Locale", "TimeZone", "Optional",
  "List", "ArrayList", "LinkedList", "Map", "HashMap", "LinkedHashMap", "TreeMap", "Set", "HashSet",
  "LinkedHashSet", "TreeSet", "Collection", "Collections", "Arrays", "Iterator", "Enumeration", "Objects",
  "Comparator", "Queue", "Deque", "ArrayDeque", "Properties", "Random", "UUID", "Timer", "TimerTask",
  "File", "InputStream", "OutputStream", "Reader", "Writer", "BufferedReader", "BufferedWriter",
  "InputStreamReader", "OutputStreamWriter", "IOException", "FileInputStream", "FileOutputStream", "PrintWriter",
  "PrintStream", "Serializable", "Externalizable",
  "Charset", "StandardCharsets", "ByteBuffer", "Path", "Paths", "Files", "URL", "URI", "URLConnection",
  "HttpURLConnection", "URLEncoder", "URLDecoder",
  "Connection", "DriverManager", "PreparedStatement", "CallableStatement", "Statement", "ResultSet", "SQLException",
  "SQLWarning", "Savepoint", "DatabaseMetaData", "ResultSetMetaData", "ParameterMetaData", "Types",
  "Timestamp", "Time", "Blob", "Clob", "NClob", "SQLXML", "Array", "Ref", "RowId", "Struct"
]);

document.addEventListener("click", event => {
  const keywordButton = event.target.closest ? event.target.closest(".codeKeywordLink") : null;
  if (!keywordButton) return;

  const keyword = keywordButton.dataset.keyword || keywordButton.textContent || "";
  if (!keyword) return;

  const typeLabel = keywordButton.dataset.keywordType === "table" ? "テーブル" : "Javaクラス";
  alert(`${typeLabel}を開く予定です：${keyword}`);
});


function setCodeFontSize(nextSize) {
  const next = Number(nextSize);
  codeFontSize = Math.min(CODE_FONT_MAX, Math.max(CODE_FONT_MIN, Number.isFinite(next) ? next : 14));

  const codeView = $("codeView");
  if (codeView) {
    codeView.style.setProperty("--code-font-size", `${codeFontSize}px`);
  }

  const codeBlock = $("codeBlock");
  if (codeBlock) {
    codeBlock.style.setProperty("font-size", `${codeFontSize}px`, "important");
  }
}

function showCopyFeedback(message = "コピーしました") {
  let toast = $("copyToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "copyToast";
    toast.className = "copyToast";
    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.classList.add("isVisible");
  window.clearTimeout(showCopyFeedback.timer);
  showCopyFeedback.timer = window.setTimeout(() => {
    toast.classList.remove("isVisible");
  }, 1400);

  const button = $("codeCopyBtn");
  if (button) {
    const originalText = button.dataset.originalText || button.textContent;
    button.dataset.originalText = originalText;
    button.textContent = "\u30b3\u30d4\u30fc\u6e08";
    button.classList.add("isCopied");
    window.clearTimeout(showCopyFeedback.buttonTimer);
    showCopyFeedback.buttonTimer = window.setTimeout(() => {
      button.textContent = button.dataset.originalText || "Copy";
      button.classList.remove("isCopied");
    }, 1400);
  }
}

function fallbackCopyText(text) {
  const area = document.createElement("textarea");
  area.value = text;
  area.setAttribute("readonly", "readonly");
  area.style.position = "fixed";
  area.style.left = "-9999px";
  area.style.top = "0";
  document.body.appendChild(area);
  area.focus();
  area.select();

  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch (e) {
    ok = false;
  }

  document.body.removeChild(area);
  return ok;
}

function downloadCurrent() {
  if (currentView === "search") {
    const params = lastSearchParams || buildSearchParams(lastSearchMode || "prefix");
    submitDownload("/download", {
      path_output_format: "PATH",
      keyword: params.keyword,
      project: params.project,
      language: params.languageForApi,
      findin: params.findin,
      clone: params.clone
    });
    return;
  }

  let filename = "krugle.txt";
  let text = "";
  if (currentView === "code") {
    filename = safeDownloadFileName(currentCodePath, "code.txt");
    text = $("codeBlock").textContent;
  } else {
    filename = "history.csv";
    text = readFileHistoryValues().map((value, index) => `${index + 1},${csv(value)}`).join("\n");
  }
  const blob = new Blob([new Uint8Array([0xef, 0xbb, 0xbf]), text], { type: "text/plain;charset=utf-8" });
  const link = document.createElement("a");
  link.download = filename;
  link.href = URL.createObjectURL(blob);
  link.click();
  URL.revokeObjectURL(link.href);
}

async function copyCurrent() {
  const visibleView = document.querySelector(".viewBlock.isVisible");
  const text = currentView === "code" ? $("codeBlock").textContent : (visibleView ? visibleView.innerText : "");

  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
    } else if (!fallbackCopyText(text)) {
      throw new Error("fallback copy failed");
    }
    showCopyFeedback("コピーしました");
  } catch (e) {
    if (fallbackCopyText(text)) {
      showCopyFeedback("コピーしました");
    } else {
      showCopyFeedback("コピーできませんでした");
    }
  }
}

function csv(value) {
  return `"${String(value).replaceAll('"', '""')}"`; }

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}



/* === 2026-07-01 fix4: native select search filter === */
let groupSelectOriginalModel = null;

function readGroupSelectModel(select) {
  if (!select) return [];
  const model = [];
  Array.from(select.children || []).forEach(child => {
    const tag = child.tagName ? child.tagName.toLowerCase() : "";
    if (tag === "option") {
      model.push({
        type: "option",
        value: child.value,
        text: child.textContent || child.value,
        className: child.className || "",
        disabled: !!child.disabled
      });
      return;
    }
    if (tag === "optgroup") {
      model.push({
        type: "optgroup",
        label: child.label || "",
        options: Array.from(child.children || []).filter(option => option.tagName && option.tagName.toLowerCase() === "option").map(option => ({
          value: option.value,
          text: option.textContent || option.value,
          className: option.className || "",
          disabled: !!option.disabled
        }))
      });
    }
  });
  return model;
}

function makeGroupSelectOptionHtml(option, selectedValue) {
  const className = option.className ? ` class="${escapeHtml(option.className)}"` : "";
  const disabled = option.disabled ? " disabled" : "";
  const selected = option.value === selectedValue ? " selected" : "";
  return `<option value="${escapeHtml(option.value)}"${className}${disabled}${selected}>${escapeHtml(option.text)}</option>`;
}

function optionMatchesGroupSelectQuery(option, query) {
  if (!query) return true;
  const text = String(option.text || "").toLowerCase();
  const value = String(option.value || "").toLowerCase();
  return text.includes(query) || value.includes(query);
}

function renderFilteredGroupSelectOptions(queryText = "") {
  const select = $("groupSelect");
  if (!select) return;
  if (!groupSelectOriginalModel || !groupSelectOriginalModel.length) {
    groupSelectOriginalModel = readGroupSelectModel(select);
  }

  const query = String(queryText || "").trim().toLowerCase();
  const selectedValue = select.value || "ALL";
  const html = [];
  let firstEnabledValue = "";
  let selectedStillExists = false;

  groupSelectOriginalModel.forEach(entry => {
    if (entry.type === "option") {
      if (!optionMatchesGroupSelectQuery(entry, query)) return;
      if (!entry.disabled && !firstEnabledValue) firstEnabledValue = entry.value;
      if (entry.value === selectedValue) selectedStillExists = true;
      html.push(makeGroupSelectOptionHtml(entry, selectedValue));
      return;
    }

    if (entry.type === "optgroup") {
      const items = entry.options.filter(option => optionMatchesGroupSelectQuery(option, query));
      if (!items.length) return;
      html.push(`<optgroup label="${escapeHtml(entry.label)}">`);
      items.forEach(option => {
        if (!option.disabled && !firstEnabledValue) firstEnabledValue = option.value;
        if (option.value === selectedValue) selectedStillExists = true;
        html.push(makeGroupSelectOptionHtml(option, selectedValue));
      });
      html.push("</optgroup>");
    }
  });

  if (!html.length) {
    html.push(`<option value="" class="groupSelectEmpty" disabled selected>該当なし</option>`);
  }

  select.innerHTML = html.join("");
  if (selectedStillExists) {
    select.value = selectedValue;
  } else if (firstEnabledValue) {
    select.value = firstEnabledValue;
  }
}

function resetGroupSelectFilterSource() {
  const select = $("groupSelect");
  if (!select) return;
  groupSelectOriginalModel = readGroupSelectModel(select);
}

function initNativeGroupSelectFilter() {
  const field = $("groupSelectField") || document.querySelector(".fieldGroup");
  const select = $("groupSelect");
  const searchInput = $("groupSelectSearchInput");
  const searchButton = $("groupSelectSearchBtn");
  if (!field || !select || !searchInput || !searchButton) return;

  resetGroupSelectFilterSource();

  if (searchButton.dataset.bound === "1") return;
  searchButton.dataset.bound = "1";

  const openSearch = () => {
    field.dataset.groupSelectBeforeSearch = select.value || "ALL";
    field.classList.add("isGroupSearchOpen");
    searchInput.hidden = false;
    searchButton.setAttribute("aria-expanded", "true");
    setTimeout(() => {
      searchInput.focus({ preventScroll: true });
      searchInput.select();
    }, 0);
  };

  const closeSearch = (restorePrevious = true) => {
    const previousValue = field.dataset.groupSelectBeforeSearch || select.value || "ALL";
    field.classList.remove("isGroupSearchOpen");
    searchInput.value = "";
    searchInput.hidden = true;
    searchButton.setAttribute("aria-expanded", "false");
    renderFilteredGroupSelectOptions("");
    if (restorePrevious) {
      const exists = Array.from(select.options).some(option => option.value === previousValue && !option.disabled);
      if (exists) select.value = previousValue;
    }
    select.focus({ preventScroll: true });
  };

  searchButton.addEventListener("click", event => {
    event.preventDefault();
    if (field.classList.contains("isGroupSearchOpen") && !searchInput.value) {
      closeSearch();
    } else {
      openSearch();
    }
  });

  searchInput.addEventListener("input", () => {
    renderFilteredGroupSelectOptions(searchInput.value);
  });

  searchInput.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      event.preventDefault();
      closeSearch();
      return;
    }
    if (event.key === "ArrowDown") {
      // 検索後も native select の ArrowDown/スクロール操作を使えるように select へフォーカスを渡す。
      event.preventDefault();
      select.focus({ preventScroll: true });
    }
  });

  select.addEventListener("change", () => {
    // 選択後も検索条件を残すと候補が欠けたままになるため、通常一覧へ戻す。
    if (field.classList.contains("isGroupSearchOpen")) {
      const selected = select.value;
      field.dataset.groupSelectBeforeSearch = selected;
      searchInput.value = "";
      renderFilteredGroupSelectOptions("");
      select.value = selected;
    }
  });
}


const QUICK_LINK_CSV_PATH = "images/links.csv";
const QUICK_LINK_ICON_PATH = "images/quick-link.svg";
const QUICK_LINK_FALLBACK_ROWS = [
  { label: "CRUD", url: "http://10.202.6.34/BatchSupportSiteManager/crud/crudInit" },
  { label: "HULFT", url: "http://10.202.6.36/cgi-bin/si/index.cgi?controller=HulftList" },
  { label: "RPS", url: "http://10.202.168.238:19001/" },
  { label: "本番RPS", url: "http://10.202.168.238:13010/" },
  { label: "jpmon", url: "http://jpmon.dc/app_index.html" },
  { label: "Desknets", url: "http://d9grphonv01.nss.nksol.co.jp/scripts/dneo/dneo.exe" }
];

function splitQuickLinkCsvLine(line) {
  const cells = [];
  let value = "";
  let inQuote = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line.charAt(i);
    const next = line.charAt(i + 1);
    if (ch === '"' && inQuote && next === '"') {
      value += '"';
      i += 1;
    } else if (ch === '"') {
      inQuote = !inQuote;
    } else if (ch === "," && !inQuote) {
      cells.push(value.trim());
      value = "";
    } else {
      value += ch;
    }
  }
  cells.push(value.trim());
  return cells;
}

function normalizeQuickLinkUrl(url) {
  const value = String(url || "").trim();
  if (!value) return "#";
  if (/^(https?:|mailto:|file:|\/|#)/i.test(value)) return value;
  return `http://${value}`;
}

function parseQuickLinkCsv(text) {
  const rows = [];
  String(text || "")
    .replace(/^\uFEFF/, "")
    .split(/\r?\n/)
    .forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) return;
      const cells = splitQuickLinkCsvLine(line);
      const label = (cells.shift() || "").trim();
      const url = cells.join(",").trim();
      if (!label || !url) return;
      rows.push({ label, url: normalizeQuickLinkUrl(url) });
    });
  return rows;
}

function decodeQuickLinkCsvBuffer(buffer) {
  let text = new TextDecoder("utf-8").decode(buffer);
  if (text.includes("・・")) {
    try {
      const sjisText = new TextDecoder("shift_jis").decode(buffer);
      if (!sjisText.includes("・・")) text = sjisText;
    } catch (ignore) {
      // Edge/Chrome では shift_jis を利用できる。失敗した場合は UTF-8 の結果を使う。
    }
  }
  return text;
}

function orderQuickLinkRows(rows, listElement) {
  const map = new Map();
  rows.forEach(row => {
    if (row && row.label) map.set(row.label, row);
  });

  const currentOrder = Array.from(listElement.querySelectorAll(".quickLinkItem"))
    .map(item => item.dataset.linkName || item.textContent.trim())
    .filter(Boolean);

  const ordered = [];
  currentOrder.forEach(label => {
    if (map.has(label)) {
      ordered.push(map.get(label));
      map.delete(label);
    }
  });

  rows.forEach(row => {
    if (map.has(row.label)) {
      ordered.push(row);
      map.delete(row.label);
    }
  });

  return ordered;
}

function createQuickLinkItem(row) {
  const link = document.createElement("a");
  link.className = "quickLinkItem";
  link.href = normalizeQuickLinkUrl(row.url);
  link.dataset.linkName = row.label;
  if (link.href && link.getAttribute("href") !== "#") {
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  }

  const icon = document.createElement("img");
  icon.className = "quickLinkIconImg";
  icon.src = QUICK_LINK_ICON_PATH;
  icon.alt = "";
  icon.setAttribute("aria-hidden", "true");
  icon.addEventListener("error", () => {
    icon.style.display = "none";
  }, { once: true });

  const text = document.createElement("span");
  text.textContent = row.label;

  link.appendChild(icon);
  link.appendChild(text);
  return link;
}

function renderQuickLinks(rows) {
  const list = $("quickLinkList");
  if (!list) return;

  const orderedRows = orderQuickLinkRows(rows, list);
  list.innerHTML = "";

  if (!orderedRows.length) {
    const empty = document.createElement("div");
    empty.className = "quickLinkItem quickLinkItemEmpty";
    empty.textContent = "links.csv にリンクがありません";
    list.appendChild(empty);
    return;
  }

  orderedRows.forEach(row => {
    list.appendChild(createQuickLinkItem(row));
  });
}

async function loadQuickLinksFromCsv() {
  const list = $("quickLinkList");
  if (!list) return;
  const csvPath = list.dataset.linksCsv || QUICK_LINK_CSV_PATH;

  try {
    const response = await fetch(csvPath, { cache: "no-store" });
    if (!response.ok) throw new Error(`links.csv load failed: ${response.status}`);
    const buffer = await response.arrayBuffer();
    const rows = parseQuickLinkCsv(decodeQuickLinkCsvBuffer(buffer));
    renderQuickLinks(rows);
  } catch (error) {
    // file:// 直開きや CSV 未配置でも画面が壊れないように、同内容の初期値で表示する。
    renderQuickLinks(QUICK_LINK_FALLBACK_ROWS);
  }
}

function bindEvents() {
  const on = (id, eventName, handler) => {
    const element = $(id);
    if (element) element.addEventListener(eventName, handler);
  };

  document.querySelectorAll(".tabBtn").forEach(button => {
    button.addEventListener("click", () => {
      if (button.classList.contains("tabFile")) {
        const index = Number(button.dataset.code || 0);
        openCode(sampleFiles[index] || sampleFiles[0]);
        document.querySelectorAll(".tabBtn").forEach(item => item.classList.remove("isActive"));
        button.classList.add("isActive");
      } else {
        showView(button.dataset.view);
      }
    });
  });
  on("searchBtn", "click", () => {
    showView("search");
    runSearch(true, "prefix");
  });
  on("sampleBtn", "click", () => {
    showView("search");
    runSearch(true, "fuzzy");
  });
  on("downloadBtn", "click", downloadCurrent);
  on("copyBtn", "click", copyCurrent);
  on("krugleBadge", "click", () => {
    window.location.href = "index.html";
  });

  // 通常のネイティブ select に戻す。カスタム検索コンボは初期化しない。

  const quickLinkDock = $("quickLinkDock");
  const quickLinkTrigger = $("quickLinkTrigger");
  const quickLinkOverlay = $("quickLinkOverlay");
  const quickLinkPanel = $("quickLinkPanel");
  const quickLinkClose = $("quickLinkClose");
  const setQuickLinkExpanded = expanded => {
    if (quickLinkTrigger) quickLinkTrigger.setAttribute("aria-expanded", expanded ? "true" : "false");
    if (quickLinkOverlay) {
      quickLinkOverlay.classList.toggle("isOpen", expanded);
      quickLinkOverlay.setAttribute("aria-hidden", expanded ? "false" : "true");

      // 閉じた後の透明な前面要素が、背面の履歴テーブル hover を邪魔しないようにする。
      if (expanded) {
        quickLinkOverlay.removeAttribute("hidden");
        quickLinkOverlay.style.display = "flex";
        quickLinkOverlay.style.pointerEvents = "auto";
        quickLinkOverlay.style.visibility = "visible";
        quickLinkOverlay.style.zIndex = "900";
      } else {
        quickLinkOverlay.setAttribute("hidden", "hidden");
        quickLinkOverlay.style.display = "none";
        quickLinkOverlay.style.pointerEvents = "none";
        quickLinkOverlay.style.visibility = "hidden";
        quickLinkOverlay.style.zIndex = "-1";
      }
    }
    document.body.classList.toggle("quickLinksOpen", expanded);
  };
  const openQuickLinks = () => setQuickLinkExpanded(true);
  const closeQuickLinks = () => {
    setQuickLinkExpanded(false);
  };
  if (quickLinkOverlay) setQuickLinkExpanded(false);

  if (quickLinkDock && quickLinkTrigger && quickLinkOverlay) {
    quickLinkDock.addEventListener("mouseenter", openQuickLinks);
    quickLinkTrigger.addEventListener("focus", openQuickLinks);
    quickLinkTrigger.addEventListener("click", event => {
      event.preventDefault();
      openQuickLinks();
      if (quickLinkPanel) quickLinkPanel.focus({ preventScroll: true });
    });
    if (quickLinkClose) {
      quickLinkClose.addEventListener("click", event => {
        event.preventDefault();
        closeQuickLinks();
      });
    }
    quickLinkOverlay.addEventListener("click", event => {
      if (event.target === quickLinkOverlay) closeQuickLinks();
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape" && quickLinkOverlay.classList.contains("isOpen")) {
        event.preventDefault();
        closeQuickLinks();
      }
    });
  }


  if (quickLinkPanel) {
    quickLinkPanel.addEventListener("click", event => {
      const link = event.target.closest ? event.target.closest(".quickLinkItem") : null;
      if (!link || link.tagName.toLowerCase() !== "a") return;
      if (!link.getAttribute("href") || link.getAttribute("href") === "#") {
        event.preventDefault();
        const label = link.textContent.trim() || "リンク";
        showCopyFeedback(`${label} のURLは未設定です`);
      }
    });
  }
  on("codePrevBtn", "click", () => openRelativeRecentTab(-1));
  on("codeNextBtn", "click", () => openRelativeRecentTab(1));
  on("codeCopyBtn", "click", copyCurrent);
  on("codeDownloadBtn", "click", downloadCurrent);
  document.querySelectorAll(".codeModeTab").forEach(button => {
    button.addEventListener("click", () => {
      if (button.disabled || button.getAttribute("aria-disabled") === "true") return;
      activeCodePanel = button.dataset.codePanel || "source";
      renderCode();
    });
  });
  on("smallBtn", "click", () => setCodeFontSize(codeFontSize - CODE_FONT_STEP));
  on("largeBtn", "click", () => setCodeFontSize(codeFontSize + CODE_FONT_STEP));
  on("keywordInput", "keydown", event => {
    if (event.key === "Enter") {
      showView("search");
      runSearch(true, "prefix");
    }
  });

  document.addEventListener("keydown", event => {
    if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
    const tagName = event.target && event.target.tagName ? event.target.tagName.toLowerCase() : "";
    if (["input", "select", "textarea"].includes(tagName)) return;
    event.preventDefault();
    moveMainTabByKeyboard(event.key === "ArrowRight" ? 1 : -1);
  });

  const stalker = $("mouseStalker");
  const hoverTargetSelector = [
    "button",
    "#historyFileBody tr",
    "#historySearchBody tr",
    ".tabTime",
    ".recentNavArrow",
    ".krugleBadge",
    ".quickLinkDock",
    ".quickLinkTrigger",
    ".quickLinkOverlay",
    ".quickLinkClose",
    ".quickLinkItem",
    ".searchPanel input",
    ".searchPanel select",
    ".groupCombo",
    ".groupComboItem",
    ".groupComboSearch",
    ".searchPanel .cloneField",
    ".globalHistoryMini tr"
  ].join(",");

  document.addEventListener("mousemove", event => {
    stalker.style.transform = `translate(${event.clientX}px, ${event.clientY}px)`;
    if (event.target.closest && event.target.closest(hoverTargetSelector)) {
      stalker.classList.add("isActive");
    } else {
      stalker.classList.remove("isActive");
    }
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  bindEvents();
  await loadQuickLinksFromCsv();
  resetInitialSearchSummary();
  renderInitialResultPlaceholders();
  renderRecentTabs();
  await loadInitialData();
  initNativeGroupSelectFilter();
  renderHistory();
});


