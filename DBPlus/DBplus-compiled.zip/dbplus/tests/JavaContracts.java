package example.dbplus;

import java.io.StringReader;
import java.lang.reflect.*;
import java.sql.*;
import java.util.*;

/** DBへ接続せず、JDBC境界の偽ResultSetで3000/3001件とリソース解放を検証する。 */
public final class JavaContracts {
    private static boolean statementClosed,resultClosed; private static int bound,maxRows; private static String sql;
    static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    static Object defaultValue(Class<?> type){if(type==boolean.class)return false;if(type==int.class||type==short.class)return 0;if(type==long.class)return 0L;return null;}
    @SuppressWarnings("unchecked") static <T>T proxy(Class<T> type,InvocationHandler h){return (T)Proxy.newProxyInstance(type.getClassLoader(),new Class<?>[]{type},h);}
    static ResultSet records(List<Map<String,Object>> rows){final int[] index={-1};return proxy(ResultSet.class,(p,m,args)->{
        String name=m.getName();if(name.equals("next"))return ++index[0]<rows.size();if(name.equals("close"))return null;
        if(name.equals("getString")){Object v=rows.get(index[0]).get(args[0]);return v==null?null:String.valueOf(v);}
        if(name.equals("getInt"))return ((Number)rows.get(index[0]).get(args[0])).intValue();return defaultValue(m.getReturnType());});}
    static Connection connection(int count){
        DatabaseMetaData meta=proxy(DatabaseMetaData.class,(p,m,args)->{
            switch(m.getName()){
                case "getIdentifierQuoteString":return "\"";
                case "getSearchStringEscape":return "\\";
                case "getColumns":return records(Arrays.asList(Api.map("TABLE_SCHEM","S","TABLE_NAME","T","COLUMN_NAME","ID","TYPE_NAME","VARCHAR","ORDINAL_POSITION",1,"COLUMN_SIZE",100,"NULLABLE",1,"COLUMN_DEF",null,"REMARKS","")));
                case "getPrimaryKeys":return records(Arrays.asList(Api.map("KEY_SEQ",1,"COLUMN_NAME","ID")));
                default:return defaultValue(m.getReturnType());
            }
        });
        return proxy(Connection.class,(p,m,args)->{
            if(m.getName().equals("getMetaData"))return meta;
            if(m.getName().equals("prepareStatement")){
                sql=(String)args[0];return proxy(PreparedStatement.class,(ps,method,a)->{
                    switch(method.getName()){
                        case "setInt":bound=(Integer)a[1];return null;
                        case "setMaxRows":maxRows=(Integer)a[0];return null;
                        case "close":statementClosed=true;return null;
                        case "executeQuery":
                            final int[] index={-1};ResultSetMetaData rmeta=proxy(ResultSetMetaData.class,(q,mm,aa)->mm.getName().equals("getColumnType")?Types.VARCHAR:defaultValue(mm.getReturnType()));
                            return proxy(ResultSet.class,(rs,mm,aa)->{
                                switch(mm.getName()){
                                    case "next":return ++index[0]<count;
                                    case "getMetaData":return rmeta;
                                    case "getCharacterStream":return new StringReader(index[0]==0?"<script>alert(1)</script> & 日本語😀":String.valueOf(index[0]+1));
                                    case "close":resultClosed=true;return null;
                                    default:return defaultValue(mm.getReturnType());
                                }
                            });
                        default:return defaultValue(method.getReturnType());
                    }
                });
            }
            return defaultValue(m.getReturnType());
        });
    }
    public static void main(String[] args)throws Exception{
        check(HtmlRenderer.escape("<&\"'>").equals("&lt;&amp;&quot;&#39;&gt;"),"HTML escape");
        HtmlRenderer.Preview preview=HtmlRenderer.preview(new StringReader("a😀b"),2);check(preview.text.equals("a")&&preview.truncated,"surrogate pair boundary");
        Profiles.Profile profile=new Profiles.Profile("id","label","postgresql","java:comp/env/jdbc/Test",Arrays.asList("S"),Arrays.asList("T"),"catalog","","","");
        for(int count:new int[]{0,1,2999,3000,3001}){
            statementClosed=resultClosed=false;Map<String,Object> d=new JdbcRepository().data(connection(count),profile,"S","T",new Deadline());
            check(d.get("returnedRows").equals(Math.min(3000,count)),"returnedRows "+count);check(d.get("hasMore").equals(count>3000),"hasMore "+count);
            check(bound==3001&&maxRows==3001&&sql.endsWith("LIMIT ?"),"DB-side limit");check(statementClosed&&resultClosed,"JDBC resources closed");
            if(count>0){List<?> rows=(List<?>)d.get("rowsHtml");check(rows.get(0).toString().contains("&lt;script&gt;"),"escaped server HTML");}
        }
        Map<String,Object> def=HtmlRenderer.table(HtmlRenderer.DEFINITION,Collections.emptyList(),"tableDefinitionTable","0件");check(def.get("html").toString().contains("colspan=\"12\""),"definition 12 columns");
        System.out.println("Java contract checks passed: 0/1/2999/3000/3001, SQL limit, escaping, Unicode, resource close.");
    }
}
