package jp.dbplus;

import java.nio.file.*;
import java.util.*;
import java.lang.reflect.*;
import java.sql.*;

/** 添付の実HTMLとJDBCプロキシで、検索・解析・5000件上限を外部接続せず確認する。 */
public final class ContractTest {
    static int checks;
    static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);checks++;}
    static String read(Path root,String path) throws Exception{return Rps.decode(Files.readAllBytes(root.resolve(path)),"auto");}
    public static void main(String[] args) throws Exception {
        Path root=Paths.get(args[0]);Config c=new Config(new Properties());c.schema="KYKOWNER";c.dbtype="KYKDB";
        String html=read(root,"src/test/resources/page3.html");
        RpsService.Page page=RpsService.parsePage(html,c,Rps.Kind.TABLE,3);
        check(page.rows.size()==50,"実HTMLの50行");check(page.total==4471&&page.totalPages==90&&page.page==3,"実HTMLのページ数");
        check(!page.rows.get(0).name.isEmpty()&&!Rps.cell(page.rows.get(0),4).isEmpty(),"物理名・日本語名");
        boolean wrong=false;try{RpsService.parsePage(html,c,Rps.Kind.TABLE,1);}catch(Rps.RpsException e){wrong=true;}check(wrong,"ページ不一致の検出");
        for(Rps.Kind kind:Rps.Kind.values()){
            String url=RpsService.listUrl(kind,c,2,"KYF","", "", "prefix");
            Map<String,String> q=Rps.query(url);check(q.get("page").equals("2")&&q.get("keyword_db").equals("KYKDB"),kind+"ページ・DB条件");
            check(q.get(kind==Rps.Kind.SYNONYM?"keyword_name":"keyword_object_name").equals("KYF%"),kind+"前方一致");
            check(!url.contains("全件表示"),"全件取得なし");
            List<String> header=Arrays.asList(kind.headers);List<String> cells=new ArrayList<>(Collections.nCopies(kind.headers.length,""));cells.set(0,"KYKDB");cells.set(1,"SAMPLE");cells.set(2,"2.4");cells.set(kind.name2Index(),"日本語名称");
            StringBuilder table=new StringBuilder("<table class='std_hover'><tr>");for(String h:header)table.append("<td>").append(h).append("</td>");table.append("</tr><tr>");for(String v:cells)table.append("<td>").append(v).append("</td>");table.append("</tr></table>");
            check(Rps.parse(table.toString(),kind,c).get(0).name.equals("SAMPLE"),kind+"列解析");
        }
        check(Rps.query(RpsService.listUrl(Rps.Kind.TABLE,c,1,"%KYF%","%顧客%","","contains")).get("keyword_description").equals("%顧客%"),"日本語部分一致");
        check(RpsService.keyword("", "contains").isEmpty(),"空検索条件");
        check(Rps.loginForm("<input type='password' name='pass'>"),"認証フォーム検出");
        check(Rps.hasSchemaField("<input name='schema' value=''>"),"ログイン直後の未選択スキーマ");
        RpsService.Definition d=RpsService.parseDefinition(read(root,"src/test/resources/columns.html"));
        check(d.rows.size()==116&&d.names.size()==116,"116項目の定義解析");
        check(d.names.get("DB_UPDJI1").contains("更新"),"日本語カラム名");
        Catalog catalog=new Catalog(read(root,"src/main/webapp/WEB-INF/DBSchema.csv"));check(catalog.entries.size()==77,"CSV接続定義件数");
        Catalog legacy=new Catalog(read(root,"src/main/webapp/WEB-INF/DBSchema.properties"));
        check(legacy.entries.size()==catalog.entries.size(),"従来TSVの後方互換");
        for(int i=0;i<catalog.entries.size();i++){
            check(catalog.entries.get(i).url().equals(legacy.entries.get(i).url())
                &&catalog.entries.get(i).user.equals(legacy.entries.get(i).user)
                &&catalog.entries.get(i).password.equals(legacy.entries.get(i).password),"CSV変換で接続定義を維持");
        }

        Catalog.Entry e=catalog.resolve("","KYKDB","KYKOWNER");check(e.user.equals("OBJECT_KYKOWNER")&&e.url().startsWith("jdbc:oracle:thin:@//"),"DBSchema接続解決");
        boolean ambiguous=false;try{catalog.resolve("","EZDB","IMPUSER");}catch(IllegalArgumentException ex){ambiguous=true;}check(ambiguous,"重複接続先を勝手に選ばない");
        String publicJson=Json.write(catalog.publicEntries());check(!publicJson.contains("password")&&!publicJson.contains("user_name"),"DB認証情報を返さない");
        check(Json.write(Json.obj("x","\"\\\n\t\u0001")).equals("{\"x\":\"\\\"\\\\\\n\\t\\u0001\"}"),"JSON制御文字");
        check(OracleReader.dataSql("日本語所有者","表\"名").equals("SELECT * FROM \"日本語所有者\".\"表\"\"名\" WHERE ROWNUM <= ?"),"識別子クォート");
        Map<String,Object> result=OracleReader.data(fakeConnection(),c,"KYF0010",d.names);
        check(result.get("rowCount").equals(5000)&&Boolean.TRUE.equals(result.get("limitReached")),"5000件で打切り、上限到達を明示");
        check(((List<?>)result.get("rows")).size()==5000,"実データ件数");
        check(((Map<?,?>)((List<?>)result.get("columns")).get(0)).get("japaneseName").equals(d.names.get("DB_UPDJI1")),"カラム名で日本語を照合");
        
        List<List<String>> csv=Catalog.records("a,b,c\r\n1,\"x,y\r\nz\",\"p\"\"q\"\r\n2,,",',');
        check(csv.size()==3&&csv.get(1).get(1).equals("x,y\r\nz")&&csv.get(1).get(2).equals("p\"q")&&csv.get(2).get(2).isEmpty(),"CSV引用符・改行・空列");
        boolean invalidCsv=false;try{Catalog.records("a,\"unclosed",',');}catch(java.io.IOException ex){invalidCsv=true;}check(invalidCsv,"CSV破損を検出");
        check(DbplusServlet.kind("table")==Rps.Kind.TABLE,"API種別");
        boolean badMode=false;try{RpsService.listUrl(Rps.Kind.TABLE,c,1,"","","","wrong");}catch(IllegalArgumentException ex){badMode=true;}check(badMode,"検索モード不正");
        System.out.println("ContractTest: "+checks+" checks passed");
    }
    static Object defaultValue(Class<?> type){if(type==boolean.class)return false;if(type==int.class)return 0;if(type==long.class)return 0L;return null;}
    @SuppressWarnings("unchecked") static <T>T proxy(Class<T> type,InvocationHandler h){return (T)Proxy.newProxyInstance(ContractTest.class.getClassLoader(),new Class<?>[]{type},h);}
    static Connection fakeConnection(){
        return proxy(Connection.class,(p,m,a)->{
            if(m.getName().equals("prepareStatement")){
                boolean metadata=((String)a[0]).contains("ALL_OBJECTS");
                return proxy(PreparedStatement.class,(ps,method,values)->{
                    if(!metadata&&method.getName().equals("setInt"))check(values[0].equals(1)&&values[1].equals(5000),"ROWNUMに5000をbind");
                    if(!metadata&&method.getName().equals("setMaxRows"))check(values[0].equals(5000),"JDBC上限5000");
                    if(method.getName().equals("executeQuery")){
                        int[] cursor={0};
                        return proxy(ResultSet.class,(rs,rm,ra)->{
                            if(rm.getName().equals("next"))return ++cursor[0]<=(metadata?1:5002);
                            if(rm.getName().equals("getString"))return "20261020";
                            if(rm.getName().equals("getMetaData"))return proxy(ResultSetMetaData.class,(md,mm,ma)->{
                                switch(mm.getName()){case "getColumnCount":return 1;case "getColumnLabel":return "DB_UPDJI1";case "getColumnTypeName":return "VARCHAR2";case "getColumnType":return Types.VARCHAR;default:return defaultValue(mm.getReturnType());}
                            });return defaultValue(rm.getReturnType());
                        });
                    }
                    return defaultValue(method.getReturnType());
                });
            }
            return defaultValue(m.getReturnType());
        });
    }
}
