# 依存と配布範囲

| 依存 | 固定版 | 使用範囲 | ライセンス |
| --- | --- | --- | --- |
| TypeScript | 5.9.3 | ビルド時のみ | Apache-2.0 |
| Dart Sass | 1.93.2 | ビルド時のみ | MIT |
| jsdom | 26.1.0 | DOM契約テストのみ | MIT |
| javax.servlet-api | 3.1.0 | コンパイル用provided。WARには同梱しない | CDDL/GPLv2 with Classpath Exception |
| Gson | 2.10.1 | JSON生成。WARにJARを同梱 | Apache-2.0 |

JavaのMaven pluginはpom.xmlに版を固定しています。ECJ 3.33.0は今回の検証環境で使用したcompilerで、配布物へは同梱していません。

npm依存の実体（node_modules）はZIPに含めません。package-lock.jsonから取得します。GsonのライセンスはこのディレクトリのLICENSE-Gson.txtに含めます。依存JAR内のメタデータを保持し、変更していません。

参考WARのJDBCドライバ・設定・既存アプリ・参考サイトの巨大JS/CSSは配布物へ含めません。
