# DB+ — 実装・設計・実行手順

版：1.0 / 作成：2026-10-07 / HTML5・TypeScript・SCSS / Java 8・Servlet 3.1

本ZIPは、添付の設計書 `README(6).md` とKrugle＋のHTML・CSS・JS・WARを基準に生成したDB+のソース一式です。ブラウザ用のJS・CSSを同梱するため、画面の確認だけならNode.jsによる再ビルドは不要です。**DB接続値は未提供です。画面検証用のデモと実DB接続用のServletを明確に分けています。実DB接続・コンテナ配置・最新版Edge/Chromeでの検証は未実施です。**

最も詳細な原設計は [docs/Design-Original.md](docs/Design-Original.md) に添付文書をそのまま保存しています。本書は今回の実装の実態、設定、採用判断、検証、残る環境依存項目を記載します。原設計にある「今回は実装を含まない」は原文作成時点の説明です。現在の納品範囲は本書を参照してください。

## 1. 出力構成

| ファイル・ディレクトリ | 用途 |
| --- | --- |
| `index.html` | 固定ID付きのHTML5画面。ホーム、共有詳細、4サブタブ、左レール、Links、セル詳細 |
| `js/main.ts` | TypeScript元ソース。API、仮想表、履歴、キャッシュ、画面Controller |
| `js/main.js` | TypeScriptから生成したES2020モジュール |
| `css/main.scss` | SCSS入口。部品ごとに整理した規則。生成CSSへの手書き追加はしない |
| `css/_tokens.scss` | 配色・フォント・行高などの基礎値 |
| `css/_mixins.scss` | card、focus、button、metadata-tableの共通mixin |
| `css/main.css` | Dart Sassから生成したCSS |
| `config/ui.json` | 相対APIベース、配置ID、Linksの設定 |
| `config/dbplus-config.example.properties` | サーバ接続許可プロファイルの設定例 |
| `images/dbplus.svg` | 同梱のDB+ favicon。外部画像／CDN依存なし |
| `scripts/demo_server.py` | Python標準ライブラリのローカル画面検証サーバ。架空データからサーバ側でHTML生成 |
| `scripts/stage_webapp.py` | クライアント生成物をServletのwebappへ配置 |
| `scripts/check_java.py` | 同梱WARのクラスでJava契約テストを実行。JDKのjavac/javaが必要 |
| `server/src/main/java/example/dbplus/` | Servlet・Service・JDBC・RPS・Renderer・設定ソース |
| `server/src/main/webapp/` | コンパイル済みクライアント資産とWEB-INF/web.xml |
| `server/pom.xml` | Java 8／WAR／Servlet 3.1 provided／Gsonの依存とビルド設定 |
| `server/dbplus.war` | コンパイル済みの配置候補WAR。環境設定・実コンテナ確認が必要 |
| `tests/` | Python API契約、Java JDBC境界、jsdom DOM操作テスト |
| `docs/Design-Original.md` | 添付の2031行の詳細設計書。原文を保持 |
| `docs/Validation.md` | 今回の検証結果と未確認範囲 |
| `docs/Third-Party.md` | 依存ライブラリ、版、使用範囲 |
| `package.json` / `package-lock.json` / `tsconfig.json` | 固定版ビルド依存、lockfile、strict型検査 |

Java package `example.dbplus` は仮名です。社内の命名規約が決まればpackage、web.xmlのServlet名、テストを一緒に変更してください。

## 2. 最初に画面を確認する

Python 3.10以上を用意し、ZIPを展開した `dbplus` ディレクトリで実行します。

```bash
python scripts/demo_server.py
```

Windowsで `python` が使えず `py` ランチャーが利用できる場合は、`py -3 scripts/demo_server.py` に置き換えます。ブラウザで `http://127.0.0.1:8080/` を開きます。ポートが使用中なら `--port 8081` を付けます。停止はCtrl+Cです。サーバは127.0.0.1だけにbindします。

1. 接続先「画面検証用デモDB」とスキーマを確認します。
2. 「一覧を取得」を押します。最大4000件のJSONを取得します。
3. 絞り込みへ `KYF1940` を入力し、一覧の行またはテーブル名を選択します。
4. ヘッダーの上段にスキーマ、下段にテーブル名が表示されます。
5. 詳細内の4サブタブを切り替えます。初回の通信は1回だけです。
6. データ表を最下部までスクロールすると3000行目が表示されます。全3000行をDOMへ置きません。
7. 画面再読み込みで履歴タブを復元します。復元だけでは詳細APIを一斉送信しません。

**index.htmlをファイルのダブルクリック（file://）で開くとAPI・ES modulesの読み込みが正常に動作しません。HTTPサーバ経由で開いてください。**

デモは実DBに接続しません。接続先名、画面のDEMO表示、定義取得元、データ警告によって架空データであることを表示します。デモAPIと本番APIは同じJSON契約ですが、Pythonを本番Servletの代替として採用したわけではありません。

### デモの検証対象

| テーブル | 確認できる状態 |
| --- | --- |
| `KYF1940` / `KYF1941` | 3000行、上限超過、12列定義、10列Index、8列Synonym |
| `EMPTY_TABLE` | 0行でも列見出しを表示する |
| `LONG_TEXT` | 2048 UTF-16コード単位相当のプレビュー表示。Java Rendererはサロゲートペア切断を防ぐ |
| `PARTIAL_ERROR` | 定義だけ失敗し、データ・Index・Synonymを使用できる |
| `TABLE_...` | 一覧4000件の仮想化確認 |

デモの一覧は内部に4001件あり、返却は4000件、hasMore=trueです。実DBにはこれらのサンプルテーブルを作成しません。SQL NULL、空文字、文字列NULL、HTMLに見える文字、高精度小数を確認できるセルを用意しています。

## 3. フロントエンドの再ビルド

Node.jsとnpmを利用可能な環境で、展開ディレクトリから実行します。

```bash
npm ci
npm run check
npm run build
npm run stage
```

TypeScript 5.9.3、Dart Sass 1.93.2を固定しています。`npm ci` にはパッケージ取得が必要です。インターネット分離環境では、承認済みの社内npmミラー／配布済み依存を使用してください。画面の実行時にはnpm、CDN、外部フォント接続を要求しません。

- TS：target/module ES2020、strict=true、noEmitOnError=true。出力は同じ `js/` ディレクトリです。
- SCSS：`@use` と `@mixin` / `@include` で共通化。生成CSSに `!important` 宣言はありません。
- HTML：`<script type="module" src="js/main.js">` と `css/main.css` を読み込みます。
- `npm run stage` は生成物のみをwebappへコピーします。TS、SCSS、デモ、接続設定例はWAR公開領域へ含めません。

元TS・SCSSを変更し、再コンパイルしてください。生成JS・CSSだけに変更を加えると、次のビルドで失われます。

## 4. 実DBへの配置

### 4.1 配置前に決める情報

| 項目 | 現在の状態／実装 |
| --- | --- |
| DB製品・版 | 未確定。PostgreSQL、Oracle 11g系の候補SQLアダプタを同梱。全DB対応ではない |
| コンテナ | javax.servlet 3.1とJava 8対応が必要。実コンテナへの配置未検証 |
| 接続方式 | JNDI DataSource。URL・ユーザー・パスワードはコンテナ管理 |
| 接続の公開範囲 | profiles、schemas、tablesをサーバ設定で許可。全テーブル許可は明示的な `*` のみ |
| 認証・権限 | 既存環境の認証と参照専用DBユーザーを使用する前提。独自ログイン／ユーザー別許可判定は未追加 |
| 定義元 | `catalog` / `rps` / `none` を明示選択。無言フォールバックなし |
| RPS対応 | 実スキーマ名とRPS SCHEMAを同名対応。DBTYPE・VERSIONを設定。異名マッピングは環境確定後に追加 |
| JDBCドライバ | 同梱しない。会社で承認されたJava 8対応ドライバをJNDI側へ配置 |
| 接続プール | 借用待ち3秒・socket/read timeout等は製品固有設定。コンテナ管理者が設定 |

### 4.2 サーバ設定

`config/dbplus-config.example.properties` を公開ディレクトリ外へ複製します。実スキーマ名、正式テーブル名、接続ID、JNDI名に変更します。

```text
-Ddbplus.config=/absolute/path/dbplus.properties
```

上記のJVMプロパティをコンテナ起動設定へ追加します。WindowsのパスはコンテナのJVMオプションの引用規則に従います。未設定時は接続先一覧が空になり、架空のJDBC接続値で接続しません。

- プロファイルに登録していないconnectionIdは403。
- 許可スキーマ外は403。
- テーブル許可リスト外は403。
- 許可名でもDBカタログに正式なTABLEとして存在しない場合は404。
- JDBCメタデータのパターン `%` / `_` をエスケープし、戻り値も正式名で再照合します。
- SQL識別子はDBの引用符を使用して引用します。ブラウザから任意SQLは受け付けません。

プロファイルは配置単位の許可リストです。ログインユーザー別に対象を分ける業務要件がある場合、既存認証の主体と許可リストを結ぶ設計が別途必要です。

### 4.3 ビルド／WAR

JDK 8とMavenがある環境で、クライアントのビルド・stage後に実行します。

```bash
cd server
mvn package
```

出力は `server/target/dbplus.war` です。初回は依存取得が必要です。社内Mavenミラーがある場合は承認済み設定を使用してください。Servlet APIはprovidedのためWARへ同梱しません。Gson 2.10.1はWARに含めます。参考WARのPostgreSQL／Oracleドライバや既存接続設定を再配布していません。

同梱 `server/dbplus.war` はJava 8 API互換でコンパイルしたクラスと今回の静的資産をZIP形式で組み立てたものです。Maven実行によるWARではありません。クラス形式52を検査していますが、JDK 8実機ビルド・実コンテナ起動は未確認です。環境決定後は上記手順で再生成してください。

## 5. 画面とデザイン

参考Krugle＋から、背景 `#f7f7f8`、白いカード、18〜22px級の角丸、丸い検索フォーム、上部ヘッダー、左上ブランド、左下Linksを引き継ぎました。緑の操作色はアクセント `#e87545`、操作文字／主ボタン `#bd4d22`、淡い面 `#fff1e9` に置き換えています。エラー色は別に定義しています。

- 本文14px、letter-spacing .036em。参考のfont-familyスタックを維持。
- フォームラベル12px、定義／データ表12px、一覧14px。
- ヘッダーテーブル名12px、その上のスキーマ10px。
- データ／一覧行高32px。定義の説明は折り返し可能で固定行高にしない。
- 定義見出しは参考と同じ黄色 `#fffda8`。
- 参考に含まれないフォント・ロゴ資産を仮定せず、外部フォントを追加していません。
- PC表示を主対象とし、狭い画面では検索フォームを2列／1列に切り替えます。

参考CSSは大量の末尾パッチを含むためコピーせず、必要な形・基礎値を整理して新規SCSSへ実装しました。参考サイトの最終computed styleとのピクセル比較は未実施です。

## 6. ホームとヘッダーの設計

初期表示はホームです。接続先API→スキーマAPIを初期化し、一覧は取得操作時だけ通信します。接続先変更で旧スキーマ・旧一覧を破棄します。スキーマ変更でも旧一覧を破棄し、現在の条件と古い一覧が混ざりません。

テーブル名・日本語名称の絞り込みは、取得済みJSONへ大文字小文字を無視した部分一致を行います。絞り込みのたびにDBへ再問い合わせしません。0件時も見出しを残します。上限に到達した一覧は完全な一覧ではないことを、絞り込み後も表示します。

テーブルの一意キーは `JSON.stringify([connectionId, schemaName, tableName])` です。同名別スキーマ・別接続先を区別します。動的DOM IDは連番です。テーブル名をCSSセレクタ／DOM IDへ埋め込みません。

選択したテーブルはヘッダーに追加され、初回詳細APIで4タブの情報をまとめて取得します。共有詳細領域は1つだけです。100個のタブを復元しても100個の詳細DOMを作りません。

## 7. API契約

| GET相対パス | パラメータ | 応答 |
| --- | --- | --- |
| `api/connections` | なし | 許可接続先の表示情報 |
| `api/schemas` | connectionId | 許可スキーマ |
| `api/tables` | connectionId、schemaName | 最大4000件の一覧JSON、hasMore、取得時刻 |
| `api/table-detail` | connectionId、schemaName、tableName | ref、取得時刻、data、definition、indexes、synonyms |

応答はprotocolVersion=1とrequestIdを含みます。詳細refは要求refと一致させます。ブラウザはHTTPステータスとContent-Typeを確認してからJSONを読み、認証画面HTMLをテーブル情報として挿入しません。

詳細APIのdataは、列情報、サーバ生成theadHtml、最大3000件のrowsHtml文字列配列を返します。生のDBセル値の配列をクライアントでHTML化しません。定義・Index・Synonymは完成表HTMLを返します。フロントでは可視行だけをinnerHTMLへ挿入します。

各タブの状態は `ready` / `empty` / `unsupported` / `unavailable` / `forbidden` / `error` です。TypeScriptは成功・非対応・失敗のdiscriminated unionを使用し、成功時だけ行HTML／完成HTMLを参照します。部分失敗はpartial=trueで表示します。Synonym機能非対応だけならpartial=falseです。

HTTPエラーは400、403、404、413、503、504等を共通JSONで返します。配置環境の認証により401／認証ページが返る場合もブラウザは成功扱いにしません。SQLの生メッセージ、資格情報、DBセル値はAPIエラーに含めません。

## 8. サーバ取得とHTML生成

### 8.1 データ

- カタログ順の明示列SELECT。業務テーブルの無制限 `SELECT *` は使用しません。
- 主キーの列順でORDER BY。主キーがなければ並び順未保証を表示します。代替一意キーの自動推定は未実装です。
- PostgreSQL：LIMIT ?、Oracle 11g候補：内側ORDER BY＋外側ROWNUM <= ?。Oracle外側にもORDER BYを付けます。
- SQLとsetMaxRowsに3001を指定し、3001件目は存在確認だけに使用。返却／HTML化は3000行まで。
- setFetchSize(200)はヒントであり件数上限ではありません。
- 高精度数値・日時はJDBCの文字列表現を維持し、JavaScript numberへ変換しません。DB固有日時書式はドライバ依存です。必要な業務書式は環境確定後に専用formatterを追加してください。
- SQL NULLには専用class、空文字は空欄、文字列NULLは通常文字を使います。
- テキスト／CLOBはReaderで2048 UTF-16コード単位までプレビューし、1文字超過判定、サロゲートペア切断防止を行います。
- バイナリ本体は返却せず型と取得省略を示します。特殊型は未対応を示します。
- DB値、列名、定義値はサーバでHTMLエスケープし、その完成HTMLをGsonでJSON化します。
- Connection、Statement、ResultSet、Reader、InputStreamをtry-with-resourcesで閉じます。

### 8.2 定義12列

`No. / 項目名 / キー / Par / データ型 / データ長 / NULL制約 / 日本語名称 / 項目説明 / 外部参照 / 省略時値 / CHECK制約`

列名・順序と `tableInfoTableWrap / tableDefinitionTableWrap / tableInfoTable / tableDefinitionTable` の構造を保持します。サンプルデータ列を13列目へ追加しません。

catalog設定では物理名、型、列順、サイズ、NULL、デフォルト、コメント、主キーを取得し、未知のPar等は空欄と明示します。rps設定では、RPS_TABLE_LISTをDBTYPE・SCHEMA・VERSION・NAMEで検索し、候補が0件／複数ならunavailableです。対応IDからRPS_TABLE_DATAの12項目をNO順に取得します。RPS取得失敗でcatalogへ無言変更しません。

### 8.3 インデックス10列

JDBC getIndexInfoの統計行を除外し、schema→index名→列位置で並べます。複合インデックスの構成列ごとに1行です。対応制約をunique属性だけで推定しません。式がJDBCで取れない場合は「式（JDBC情報では取得不可）」と表示します。DB固有の式・状態・制約の完全取得ではないことを警告します。

### 8.4 シノニム8列

Oracle候補ではALL_SYNONYMSのTABLE_OWNER・TABLE_NAMEを一致させ、DB_LINK IS NULLの直接・ローカル参照を取得します。PRIVATE／PUBLICを分けます。DB全体の完全一覧とは説明しません。連鎖参照・遠隔参照は初期範囲外です。PostgreSQL設定ではタブを残しunsupportedを表示します。

## 9. 仮想スクロール

データと一覧は同じVirtualGridを使います。table / thead / tbody構造を維持し、tbodyに上スペーサー、可視行、下スペーサーを置きます。スペーサーはtr > td > divで、aria-hidden=true、colspanは列数です。

```text
H = viewport.clientHeight - stickyヘッダーの実測高さ
start = max(0, floor(scrollTop / 32) - 8)
end = min(N, ceil((scrollTop + H) / 32) + 8)
上スペーサー = start * 32
下スペーサー = (N - end) * 32
```

scrollはrequestAnimationFrameで集約し、start/endが同じならtbodyを再生成しません。ResizeObserverで枠サイズ変更を検知します。横スクロールだけでは行範囲を再生成しません。全行をtemplateや非表示DOMへ先にパースすることもありません。

データは返された行HTMLの可視sliceだけを使い、一覧は可視JSON項目だけHTML化します。列幅はcolgroupへ適用し、thead/tbodyが同じtableに属するため横スクロールを共有します。行高はCSSのセルpadding、border、内部spanを含め32pxに揃える設計です。実ブラウザでの行高測定とズーム検証は残っています。

論理行番号をaria-rowindex、取得済み行数＋見出しをaria-rowcountへ反映します。一覧のテーブル名はbuttonで、行クリックとEnter/Spaceが同じ選択になります。上下矢印で一覧buttonを移動できます。タブは左右矢印／Home／Endで移動します。

セル詳細は表示済みspanのtextContentをpreへコピーし、取得済みプレビューの範囲を表示します。全LOBの追加取得は行いません。ブラウザのページ内検索やコピーはDOM内行だけが対象になり得ます。

## 10. 状態・競合・キャッシュ・履歴

API待機35秒、サーバの論理期限30秒、SQL query timeoutは残時間内で最大10秒です。ドライバのネットワーク停止やメタデータ取得にはプール／socket timeoutの追加設定が必要です。ブラウザabortはサーバSQLを確実に停止する仕組みではありません。

接続先／スキーマ／詳細要求には世代番号とAbortControllerを使います。A→Bへ切り替えた後でAの応答が返っても、世代・ref・アクティブキーを照合し、BのDOM／キャッシュを上書きしません。同じテーブルを連打した場合は進行中Promiseを共有します。再取得は旧要求を破棄して4タブを更新します。

詳細キャッシュはLRU最近2件、TTL60秒、UTF-16概算16MiBです。アクティブな1件だけがsoft上限を超える場合は表示のため保持し、他を捨てます。取得時刻はサーバfetchedAtであり、キャッシュ再表示時に現在時刻へ書き換えません。テーブル・サブタブ単位で縦横のスクロール位置をメモリ保存します。

履歴キーは `dbplus.history.tables.v1:<deploymentId>:<contextPath>` とし、同一オリジンの別配置／デモを分離します。保存はversion=1と、connectionId、schemaName、tableName、lastViewedAtだけです。最大100件、日時の新しい順、同じTableRefの重複除去です。DB行、HTML、資格情報は保存しません。

破損JSON・不正項目・日時・許可されない接続IDを検証し、不要なキーを除去します。localStorageが利用できなくても閲覧できます。storageイベントで履歴を統合しますが、他ウィンドウの操作で現在の画面は切り替えません。新規履歴は有効な詳細応答を受けた後に登録します。

## 11. サイズと性能

返却データは最大3000行、一覧は4000件です。詳細JSON全体は非圧縮UTF-8で16MiBまでです。データHTMLはメモリの増殖を抑える追加の保守的予算として8MiBまでに設定しています。データが予算を超えた場合はdataをRESULT_TOO_LARGEにし、他の情報を残します。全体が16MiBを超える場合は413です。

応答上限とクライアントキャッシュsoft上限は単位も役割も別です。HTML文字数だけをUTF-8バイト上限判定に使用しません。ブラウザ表示が軽くてもSQLが速いとは限りません。実DBの実行計画、接続借用、転送サイズ、初期描画、スクロール、列数／長文、同時利用数を実環境で測定してください。

## 12. Linksの設定

`config/ui.json` のlinksへ設定します。URLは設定例として構造だけ示します。

```json
{
  "apiBase": "api/",
  "deploymentId": "dbplus",
  "links": [{"label": "利用手順", "url": "docs/usage.html"}]
}
```

上のusage.htmlは配置環境で作成する例で、同梱ファイルではありません。実際に存在するURLへ変更してください。空配列なら「リンクが未設定です」。HTTP/HTTPSだけを許可し、別タブはnoopener noreferrerを設定します。クリック、Esc、外側クリックで開閉し、閉じた後はトリガーへフォーカスを戻します。参考サイトの社内URLは転記していません。

## 13. テストと検証範囲

```bash
npm run check
npm run build
npm test
npm run test:dom
python scripts/check_java.py
```

最後のコマンドはJDKのjavac/javaが必要です。Mavenビルド後のWARを確認する場合は `python scripts/check_java.py --war server/target/dbplus.war` を指定します。

実施結果は [docs/Validation.md](docs/Validation.md) を参照してください。DOMテストはjsdomの高さを制御した契約検証であり、実ブラウザの画面／速度検証ではありません。JavaはJava 17環境上のECJ compilerに `--release 8` を指定してコンパイル／実行しました。JDK 8実機で実行済みとは説明しません。

## 14. 要件R01〜R34の実装対応

| 要件 | 実装対応 |
| --- | --- |
| R01〜R05 | HTML5＋SCSS＋TypeScript。Angular/React/Vue/jQueryは依存に入れない |
| R06 | データVirtualGrid。全件DOM生成を避ける |
| R07 | javax.servlet 3.1／Java 8 API互換。実コンテナ確認は未実施 |
| R08 | JNDI許可プロファイル、スキーマ／正式テーブル名検証。実DB接続は環境設定待ち |
| R09〜R10 | HtmlRendererがセル／定義HTMLを生成し、クライアントが可視HTMLを挿入 |
| R11〜R12 | SQL＋JDBC上限、3000件の返却。実DBSQLは対象版で要検証 |
| R13 | data、definition、indexes、synonymsの4サブタブ |
| R14 | 定義12列とclass構造を保持 |
| R15 | JDBC index情報。DB固有情報の限界を警告 |
| R16 | Oracle候補の直接Synonym、PostgreSQL unsupported。実DB確認待ち |
| R17〜R19 | Krugle＋の形／基礎フォント／サイズ、暖色アクセント。最終画面の比較は未実施 |
| R20 | ES2020＋DOM／ResizeObserver等。最新Edge/Chrome実機確認は未実施 |
| R21〜R24 | 初期ホーム、最大4000件JSON、table構造、一部一致検索、行選択 |
| R25〜R26 | 1回の詳細APIで4タブ取得、テーブル別ヘッダータブ |
| R27 | 左上DB+、左下Links |
| R28〜R30 | localStorage履歴、テーブル名＋上段スキーマ表示 |
| R31 | 固定ID、動的data属性、動的タブID連番 |
| R32〜R34 | CSS宣言のimportantなし、section/divの構造、SCSSmixin共通化 |

## 15. 今回の採用判断と残る確認

原設計の推奨多ファイル構成は、今回の指定 `js/main.ts` / `css/main.scss` を中心にまとめました。TS内はApiClient、VirtualGrid、HistoryStore、DetailCache、AppControllerに責務を分け、SCSSはtokens/mixinsをpartialに分離しています。ソース規模が増えた場合は元設計のController単位のモジュールへ切り出せます。

未確定事項を理由にUI／API／Rendererの作成を止めず、DB候補アダプタと設定例まで作成しました。ただし実環境対応を確認済みとは扱いません。残る主要項目はDB製品・版、JDBCとコンテナの承認版、JNDI／プール期限、RPS対応、認証／ユーザー別許可、実ブラウザの行高／ズーム、SQL実行計画／性能です。

今後の修正依頼では、このZIPの最新ソースと本書、再現操作、期待表示、使用DB／ブラウザ情報を一緒に渡してください。重要なコードを省略記号に置き換えず、変更したTS／SCSS・生成JS／CSS・サーバAPI・テスト・設計を整合させます。
