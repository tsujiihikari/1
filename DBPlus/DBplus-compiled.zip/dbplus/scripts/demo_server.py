#!/usr/bin/env python3
"""明示的な画面検証用デモ。実データと混同しない。HTML生成はHTTPサーバ側。"""
import argparse
import html
import json
import sys
import time
import uuid
from datetime import datetime, timezone
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parents[1]
DEFINITION_HEAD = ['No.', '項目名', 'キー', 'Par', 'データ型', 'データ長', 'NULL制約', '日本語名称', '項目説明', '外部参照', '省略時値', 'CHECK制約']
INDEX_HEAD = ['No.', 'インデックススキーマ', 'インデックス名', 'UNIQUE', '種別', '列位置', '列名・式', '昇順／降順', '対応制約', '状態・補足']
SYNONYM_HEAD = ['No.', 'シノニム所有者', 'シノニム名', '参照先スキーマ', '参照先オブジェクト', 'DBリンク', '区分', '補足']
COLUMNS = [('ID','NUMBER',120), ('NAME','VARCHAR2',240), ('AMOUNT','NUMBER',180), ('UPDATED_AT','TIMESTAMP',220), ('NOTE','CLOB',340)]
SPECIAL = ['KYF1940', 'KYF1941', 'EMPTY_TABLE', 'LONG_TEXT', 'PARTIAL_ERROR']

def envelope(**values):
    return dict(protocolVersion=1, requestId=str(uuid.uuid4()), **values)

def now():
    return datetime.now(timezone.utc).isoformat()

def table_names():
    # 4001件目は超過確認のためだけに存在する。
    return sorted(SPECIAL + [f'TABLE_{i:04}' for i in range(1, 3997)])

def table_html(head, rows, classname, empty):
    header = '<tr>' + ''.join('<th scope="col">'+html.escape(str(h))+'</th>' for h in head) + '</tr>'
    body = ''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in r)+'</tr>' for r in rows)
    body = body or '<tr><td colspan="'+str(len(head))+'">'+html.escape(empty)+'</td></tr>'
    return '<div class="tableInfoTableWrap tableDefinitionTableWrap"><table class="tableInfoTable '+classname+'"><thead>'+header+'</thead><tbody>'+body+'</tbody></table></div>'

def fragment(head, rows, classname, empty, **extra):
    return dict(status='ready' if rows else 'empty', recordCount=len(rows), html=table_html(head,rows,classname,empty), warnings=[], **extra)

def row_html(index, values):
    cells = []
    for value in values:
        if value is None:
            cells.append('<td><span class="dbp-cell dbp-null">NULL</span></td>')
        else:
            preview = str(value).encode('utf-16-le')[:4096].decode('utf-16-le', errors='ignore')
            attr = ' data-truncated="true"' if len(str(value).encode('utf-16-le')) > 4096 else ''
            cells.append('<td><span class="dbp-cell"'+attr+'>'+html.escape(preview)+'</span></td>')
    return '<tr data-row-index="'+str(index)+'" aria-rowindex="'+str(index+2)+'">'+''.join(cells)+'</tr>'

def detail(ref):
    name = ref['tableName']
    count = 0 if name == 'EMPTY_TABLE' else 3000
    rows = []
    for i in range(count):
        note = '<img src=x onerror=alert(1)> & "引用"' if i == 0 else 'NULL' if i == 1 else '' if i == 2 else None if i % 11 == 0 else 'デモ用データ'
        if name == 'LONG_TEXT' and i == 0:
            note = '長文プレビュー😀' * 500
        rows.append(row_html(i,[str(i+1),f'サンプル {i+1:04}', '12345678901234567890.123456789', '2026-10-07 09:00:00.000',note]))
    data = dict(status='ready' if count else 'empty',maxRows=3000,returnedRows=count,hasMore=count == 3000,totalRowCount=None,columnCount=len(COLUMNS), columns=[dict(name=n,jdbcTypeName=t,widthPx=w) for n,t,w in COLUMNS], orderGuaranteed=True,orderBy=[dict(columnName='ID',direction='ASC')],previewMaxChars=2048,previewTruncatedCells=1 if name == 'LONG_TEXT' else 0,theadHtml='<tr>'+''.join('<th scope="col">'+n+'</th>' for n,_,_ in COLUMNS)+'</tr>', rowsHtml=rows,warnings=['画面検証用の架空データです。'])
    definitions = [[i+1,n,'PK' if i == 0 else '', '', t,'22' if t == 'NUMBER' else '240','NOT NULL' if i == 0 else '', ['識別子','名称','金額','更新日時','備考'][i], '画面検証用の定義です。','','',''] for i,(n,t,_) in enumerate(COLUMNS)]
    definition = fragment(DEFINITION_HEAD,definitions,'tableDefinitionTable','定義項目がありません。',source='demo',definitionVersion='demo-1')
    if name == 'PARTIAL_ERROR':
        definition = dict(status='error',error=dict(code='DEMO_DEFINITION_ERROR',message='デモ：定義元の取得失敗を再現しています。'),warnings=[])
    indexes = fragment(INDEX_HEAD,[[1,ref['schemaName'],'PK_'+name,'有','B-TREE',1,'ID','ASC','PRIMARY KEY','デモ用']],'tableIndexTable','参照可能なインデックスはありません。')
    synonyms = fragment(SYNONYM_HEAD,[[1,'PUBLIC','SYN_'+name,ref['schemaName'],name,'','PUBLIC','直接・ローカル参照（デモ）']],'tableSynonymTable','直接参照するシノニムはありません。')
    return envelope(ref=ref,connectionLabel='画面検証用デモDB',logicalName='画面検証用テーブル',fetchedAt=now(),partial=name == 'PARTIAL_ERROR',data=data,definition=definition,indexes=indexes,synonyms=synonyms)

class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed = urlsplit(self.path)
        if not parsed.path.startswith('/api/'):
            return super().do_GET()
        params = {k:v[0] for k,v in parse_qs(parsed.query).items()}
        endpoint = parsed.path.removeprefix('/api/')
        if endpoint == 'connections':
            return self.send_json(envelope(items=[dict(connectionId='demo',label='画面検証用デモDB',dbProduct='DEMO')]))
        if params.get('connectionId') != 'demo':
            return self.send_json(envelope(error=dict(code='CONNECTION_DENIED',message='接続先が許可されていません。')),403)
        if endpoint == 'schemas':
            return self.send_json(envelope(connectionId='demo',items=[dict(schemaName=n,label=n) for n in ['SCHEMA_A','SCHEMA_B']]))
        schema = params.get('schemaName')
        if schema not in ['SCHEMA_A','SCHEMA_B']:
            return self.send_json(envelope(error=dict(code='SCHEMA_DENIED',message='スキーマが許可されていません。')),403)
        if endpoint == 'tables':
            names = table_names()
            return self.send_json(envelope(connectionId='demo',schemaName=schema,fetchedAt=now(),maxTables=4000,returnedTables=4000,hasMore=len(names)>4000,items=[dict(tableName=n,schemaName=schema,logicalName='画面検証用',objectType='TABLE') for n in names[:4000]]))
        if endpoint == 'table-detail':
            name = params.get('tableName')
            if name not in table_names():
                return self.send_json(envelope(error=dict(code='TABLE_NOT_FOUND',message='テーブルがありません。')),404)
            return self.send_json(detail(dict(connectionId='demo',schemaName=schema,tableName=name)))
        return self.send_json(envelope(error=dict(code='NOT_FOUND',message='APIがありません。')),404)

    def send_json(self, body, status=200):
        payload = json.dumps(body,ensure_ascii=False).encode('utf-8')
        self.send_response(status); self.send_header('Content-Type','application/json; charset=UTF-8'); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(payload))); self.end_headers(); self.wfile.write(payload)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8080)
    args = parser.parse_args()
    print(f'DB+ DEMO: http://127.0.0.1:{args.port}/ （架空データ・ローカルのみ）',flush=True)
    ThreadingHTTPServer(('127.0.0.1',args.port),partial(Handler,directory=str(ROOT))).serve_forever()
