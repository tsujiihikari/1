import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ConstantDynamic;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.TypePath;
import org.objectweb.asm.signature.SignatureReader;
import org.objectweb.asm.signature.SignatureVisitor;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * JAR/Class dependency analyzer using ASM.
 *
 * Java source/runtime target: Java 8+
 * Dependencies:
 *   - ASM 9.x core (asm-9.x.jar)
 *   - PostgreSQL JDBC driver (postgresql-42.x.x.jar)
 *
 * Usage:
 *   javac -cp asm-9.x.jar Main.java
 *   java -Xmx2048m -cp .:asm-9.x.jar:postgresql-42.x.x.jar Main [scanRoot] [outputDir]
 *
 * Windows classpath separator:
 *   java -Xmx2048m -cp .;asm-9.x.jar;postgresql-42.x.x.jar Main [scanRoot] [outputDir]
 *
 * Output files:
 *   class_def.csv
 *   method_def.csv
 *   class_ref.csv
 *   method_call.csv
 *   processing_flow.txt
 *
 * PostgreSQL tables are truncated at startup and then populated in batches.
 */
public class Main {

    private static final int ASM_API = Opcodes.ASM9;

    // JVM access-flag values not needed from ASM constants directly. Keeping these local also
    // makes the class/method-context distinction explicit (some bits are intentionally reused).
    private static final int ACC_SUPER_FLAG = 0x0020;
    private static final int ACC_BRIDGE_FLAG = 0x0040;
    private static final int ACC_VARARGS_FLAG = 0x0080;
    private static final int ACC_SYNTHETIC_FLAG = 0x1000;
    private static final int ACC_ANNOTATION_FLAG = 0x2000;
    private static final int ACC_ENUM_FLAG = 0x4000;

    /** Per-class uncompressed byte limit. Prevents an abnormal/zip-bomb entry from consuming unlimited heap. */
    private static final int MAX_CLASS_BYTES = Integer.getInteger("asm.maxClassBytes", 32 * 1024 * 1024);

    /** Bounded resolver cache: speeds up repeated calls without unbounded heap growth. */
    private static final int METHOD_RESOLVE_CACHE_SIZE =
            Integer.getInteger("asm.methodResolveCacheSize", 50000);

    private static final String RESOLVED = "RESOLVED";
    private static final String AMBIGUOUS = "AMBIGUOUS_DUPLICATE_CLASS";
    private static final String AMBIGUOUS_HIERARCHY = "AMBIGUOUS_METHOD_HIERARCHY";
    private static final String NOT_FOUND_IN_GROUP = "NOT_FOUND_IN_GROUP";
    private static final String JDK = "JDK";
    private static final String EXTERNAL = "EXTERNAL_NOT_FOUND";
    private static final String HIERARCHY_LIMIT = "HIERARCHY_DEPTH_LIMIT";
    private static final int MAX_HIERARCHY_DEPTH = 256;

    /** Only application classes below jp.co.* are indexed, analyzed, and emitted. */
    private static final String TARGET_PACKAGE_PREFIX = "jp.co.";
    private static final String TARGET_INTERNAL_PREFIX = "jp/co/";

    /** PostgreSQL output is enabled by default; override with -Dasm.dbEnabled=false for CSV-only runs/tests. */
    private static final boolean DB_ENABLED = Boolean.parseBoolean(
            System.getProperty("asm.dbEnabled", "true"));
    private static final String DB_URL = System.getProperty("asm.dbUrl",
            "jdbc:postgresql://10.205.7.19:5432/postgres?reWriteBatchedInserts=true");
    private static final String DB_USER = System.getProperty("asm.dbUser", "postgres");
    private static final String DB_PASSWORD = System.getProperty("asm.dbPassword", "postgres");
    private static final int DB_BATCH_SIZE = Integer.getInteger("asm.dbBatchSize", 1000);
    private static final int DB_COMMIT_ROWS = Integer.getInteger("asm.dbCommitRows", 20000);
    private static final int FLOW_MAX_DEPTH = Integer.getInteger("asm.flowMaxDepth", 256);

    private static final Set<String> JDK_PREFIXES = new HashSet<String>(Arrays.asList(
            "java.", "javax.", "jdk.", "sun.", "com.sun.", "org.w3c.", "org.xml.", "org.ietf."
    ));

    public static void main(String[] args) throws Exception {
        Path scanRoot = args.length >= 1
                ? Paths.get(args[0]).toAbsolutePath().normalize()
                : findScanRoot();

        Path outputDir = args.length >= 2
                ? Paths.get(args[1]).toAbsolutePath().normalize()
                : Paths.get("asm-output").toAbsolutePath().normalize();

        if (!Files.isDirectory(scanRoot)) {
            throw new IllegalArgumentException("scanRoot is not a directory: " + scanRoot);
        }
        if (MAX_CLASS_BYTES < 1024) {
            throw new IllegalArgumentException("asm.maxClassBytes is too small: " + MAX_CLASS_BYTES);
        }
        if (METHOD_RESOLVE_CACHE_SIZE < 0) {
            throw new IllegalArgumentException(
                    "asm.methodResolveCacheSize must be >= 0: " + METHOD_RESOLVE_CACHE_SIZE);
        }
        if (DB_BATCH_SIZE <= 0) {
            throw new IllegalArgumentException("asm.dbBatchSize must be > 0: " + DB_BATCH_SIZE);
        }
        if (DB_COMMIT_ROWS <= 0) {
            throw new IllegalArgumentException("asm.dbCommitRows must be > 0: " + DB_COMMIT_ROWS);
        }
        if (FLOW_MAX_DEPTH <= 0) {
            throw new IllegalArgumentException("asm.flowMaxDepth must be > 0: " + FLOW_MAX_DEPTH);
        }

        Files.createDirectories(outputDir);

        System.out.println("SCAN_ROOT=" + normalize(scanRoot.toString()));
        System.out.println("OUTPUT_DIR=" + normalize(outputDir.toString()));
        System.out.println("MAX_CLASS_BYTES=" + MAX_CLASS_BYTES);
        System.out.println("METHOD_RESOLVE_CACHE_SIZE=" + METHOD_RESOLVE_CACHE_SIZE);
        System.out.println("TARGET_PACKAGE=" + TARGET_PACKAGE_PREFIX + "*");
        System.out.println("DB_ENABLED=" + DB_ENABLED);
        if (DB_ENABLED) {
            System.out.println("DB_URL=" + DB_URL);
            System.out.println("DB_USER=" + DB_USER);
            System.out.println("DB_BATCH_SIZE=" + DB_BATCH_SIZE);
            System.out.println("DB_COMMIT_ROWS=" + DB_COMMIT_ROWS);
        }
        System.out.println("FLOW_MAX_DEPTH=" + FLOW_MAX_DEPTH);

        List<JarInfo> jars = discoverJars(scanRoot, outputDir);
        Collections.sort(jars);
        if (jars.isEmpty()) {
            throw new IllegalStateException("No .jar files found under: " + scanRoot);
        }

        System.out.println("JAR_COUNT=" + jars.size());

        Stats stats = new Stats();
        List<GroupWork> groups = groupJars(jars);
        System.out.println("GROUP_COUNT=" + groups.size());
        System.out.println("MAX_HEAP_MB="
                + (Runtime.getRuntime().maxMemory() / (1024L * 1024L)));

        try (DbOutputs db = new DbOutputs();
             CsvOutputs out = new CsvOutputs(outputDir, stats, db);
             FlowTextOutput flowOut = new FlowTextOutput(outputDir.resolve("processing_flow.txt"))) {
            if (DB_ENABLED) {
                db.truncateAll();
            }

            // IMPORTANT: process one directory group at a time. The index, call graph, and
            // resolver cache are discarded before moving to the next group, so heap usage is
            // bounded by the largest single group rather than by all classes below IKO/Master.
            for (int i = 0; i < groups.size(); i++) {
                GroupWork group = groups.get(i);
                System.out.println("[GROUP " + (i + 1) + "/" + groups.size() + "] "
                        + group.group + " JARS=" + group.jars.size());
                processGroup(group, out, flowOut, stats);
                out.commitGroup();
            }
            if (DB_ENABLED) {
                db.analyzeAll();
            }
        }

        System.out.println("DONE");
        System.out.println("CLASS_DEF_ROWS=" + stats.classDefRows);
        System.out.println("METHOD_DEF_ROWS=" + stats.methodDefRows);
        System.out.println("CLASS_REF_ROWS=" + stats.classRefRows);
        System.out.println("METHOD_CALL_ROWS=" + stats.methodCallRows);
        System.out.println("CLASS_CALL_ROWS=" + stats.classCallRows);
        System.out.println("FLOW_STARTS=" + stats.flowStarts);
        System.out.println("SKIPPED_CLASS_ENTRIES=" + stats.skippedClassEntries);
    }

    // ---------------------------------------------------------------------
    // Root/JAR discovery
    // ---------------------------------------------------------------------

    private static Path findScanRoot() throws IOException {
        Path cwd = Paths.get("").toAbsolutePath().normalize();
        LinkedHashSet<Path> candidates = new LinkedHashSet<Path>();

        Path p = cwd;
        while (p != null) {
            candidates.add(p.resolve("IKO").resolve("Master").normalize());
            Path fileName = p.getFileName();
            Path parent = p.getParent();
            if (fileName != null && parent != null && "Master".equals(fileName.toString())) {
                Path parentName = parent.getFileName();
                if (parentName != null && "IKO".equals(parentName.toString())) {
                    candidates.add(p);
                }
            }
            p = p.getParent();
        }

        candidates.add(cwd.resolve("Master").normalize());
        candidates.add(cwd);

        for (Path candidate : candidates) {
            if (Files.isDirectory(candidate) && containsJar(candidate)) {
                return candidate.toAbsolutePath().normalize();
            }
        }

        throw new IllegalStateException(
                "Could not auto-detect IKO/Master or another directory containing JARs. "
                        + "Pass scanRoot as the first argument. cwd=" + cwd);
    }

    private static boolean containsJar(Path root) throws IOException {
        final boolean[] found = new boolean[]{false};
        Files.walkFileTree(root, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (attrs.isRegularFile() && isJar(file)) {
                    found[0] = true;
                    return FileVisitResult.TERMINATE;
                }
                return FileVisitResult.CONTINUE;
            }
        });
        return found[0];
    }

    private static List<JarInfo> discoverJars(final Path scanRoot, final Path outputDir) throws IOException {
        final List<JarInfo> jars = new ArrayList<JarInfo>();
        final Path root = scanRoot.toAbsolutePath().normalize();
        final Path out = outputDir.toAbsolutePath().normalize();
        final boolean outputInsideRoot = out.startsWith(root);

        Files.walkFileTree(scanRoot, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                Path n = dir.toAbsolutePath().normalize();
                if (outputInsideRoot && !out.equals(root)
                        && (n.equals(out) || n.startsWith(out))) {
                    return FileVisitResult.SKIP_SUBTREE;
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (attrs.isRegularFile() && isJar(file)) {
                    jars.add(new JarInfo(scanRoot, file));
                }
                return FileVisitResult.CONTINUE;
            }
        });
        return jars;
    }

    private static boolean isJar(Path path) {
        return Files.isRegularFile(path)
                && path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".jar");
    }

    /**
     * Group is the application directory above helper directories such as jar/lib.
     * Examples with scanRoot=IKO/Master:
     *   nikkoEZ/ez.web.online/jar/app.jar           -> nikkoEZ/ez.web.online
     *   nkCCIS/tsnodryak.online.jar/lib/common.jar -> nkCCIS/tsnodryak.online.jar
     */
    private static String determineGroup(Path scanRoot, Path jarPath) {
        Path parent = jarPath.getParent();
        if (parent == null) {
            return ".";
        }

        // Primary rule from the requirements: the directory group is the *.online or
        // *.online.jar directory (for example nikkoEZ/ez.web.online or
        // nkCCIS/tsnodryak.online.jar). Search this BEFORE jar/lib helper directories so
        // deeper nested lib directories can never split one logical directory group.
        Path cursor = parent;
        while (cursor != null && cursor.startsWith(scanRoot)) {
            String lower = fileName(cursor).toLowerCase(Locale.ROOT);
            if (lower.endsWith(".online") || lower.endsWith(".online.jar")) {
                return relative(scanRoot, cursor);
            }
            if (cursor.equals(scanRoot)) {
                break;
            }
            cursor = cursor.getParent();
        }

        // Fallback for reduced test trees whose directory names do not follow the real
        // *.online naming convention. The directory immediately above a jar/lib helper
        // directory is treated as the group.
        cursor = parent;
        while (cursor != null && cursor.startsWith(scanRoot)) {
            String name = fileName(cursor);
            if (isHelperDir(name)) {
                Path groupDir = cursor;
                while (groupDir != null && groupDir.startsWith(scanRoot)
                        && isHelperDir(fileName(groupDir))) {
                    groupDir = groupDir.getParent();
                }
                if (groupDir != null && groupDir.startsWith(scanRoot)) {
                    return relative(scanRoot, groupDir);
                }
            }
            if (cursor.equals(scanRoot)) {
                break;
            }
            cursor = cursor.getParent();
        }

        // Reduced test trees: all JARs immediately under the selected root can share one group.
        if (parent.equals(scanRoot)) {
            return ".";
        }
        return relative(scanRoot, parent);
    }

    private static boolean isHelperDir(String name) {
        return "jar".equalsIgnoreCase(name) || "lib".equalsIgnoreCase(name);
    }

    private static String fileName(Path path) {
        Path n = path == null ? null : path.getFileName();
        return n == null ? "" : n.toString();
    }

    private static String relative(Path root, Path path) {
        try {
            String s = normalize(root.relativize(path).toString());
            return s.length() == 0 ? "." : s;
        } catch (RuntimeException e) {
            return normalize(path.toString());
        }
    }

    private static List<GroupWork> groupJars(List<JarInfo> jars) {
        // jars are already sorted by group/path. LinkedHashMap preserves that order.
        Map<String, List<JarInfo>> byGroup = new LinkedHashMap<String, List<JarInfo>>();
        for (JarInfo jar : jars) {
            List<JarInfo> list = byGroup.get(jar.group);
            if (list == null) {
                list = new ArrayList<JarInfo>();
                byGroup.put(jar.group, list);
            }
            list.add(jar);
        }

        List<GroupWork> result = new ArrayList<GroupWork>(byGroup.size());
        for (Map.Entry<String, List<JarInfo>> e : byGroup.entrySet()) {
            result.add(new GroupWork(e.getKey(), e.getValue()));
        }
        return result;
    }

    /**
     * All large, group-specific data is local to this method. Once it returns, the entire
     * class/method index and the bounded resolver cache become garbage-collectable.
     */
    private static void processGroup(GroupWork group, CsvOutputs out,
                                     FlowTextOutput flowOut, Stats stats) {
        Index index = new Index();
        ClassCallGraph callGraph = new ClassCallGraph(group.group);

        // PASS 1: index only this directory group and emit definition rows immediately.
        for (int i = 0; i < group.jars.size(); i++) {
            JarInfo jar = group.jars.get(i);
            System.out.println("  [INDEX " + (i + 1) + "/" + group.jars.size() + "] "
                    + jar.relativePath);
            indexJar(jar, index, out, stats);
        }

        MethodResolver resolver = new MethodResolver(index);

        // PASS 2: resolve references/calls only against this group's index.
        for (int i = 0; i < group.jars.size(); i++) {
            JarInfo jar = group.jars.get(i);
            System.out.println("  [ANALYZE " + (i + 1) + "/" + group.jars.size() + "] "
                    + jar.relativePath);
            analyzeJar(jar, index, resolver, out, callGraph, stats);
        }

        // Persist the compact class-to-class call graph after the group has been analyzed.
        // This avoids one DB row per bytecode invocation and is also the source for flow text.
        for (ClassCallEdge edge : callGraph.sortedEdges()) {
            out.writeClassCall(edge);
        }
        stats.flowStarts += flowOut.writeGroup(group.group, index, callGraph);
    }

    // ---------------------------------------------------------------------
    // PASS 1 - definitions/index
    // ---------------------------------------------------------------------

    private static void indexJar(JarInfo jarInfo, Index index, CsvOutputs out, Stats stats) {
        JarFile jar = null;
        try {
            jar = new JarFile(jarInfo.path.toFile(), false);
            java.util.Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                // Do not even decompress/parse non-jp.co.* classes.
                if (!isTargetClassEntry(entry)) {
                    continue;
                }

                ClassReader cr = readClassReader(jar, entry, jarInfo, stats);
                if (cr == null || !isTargetInternalClassName(cr.getClassName())) {
                    continue;
                }

                DefinitionVisitor visitor = new DefinitionVisitor(jarInfo);
                try {
                    cr.accept(visitor, ClassReader.SKIP_FRAMES);
                } catch (RuntimeException e) {
                    stats.skippedClassEntries++;
                    warn("INDEX_CLASS", jarInfo, entry, e);
                    continue;
                }

                if (visitor.classDef != null) {
                    index.add(visitor.classDef);
                    // CSV failures are deliberately not swallowed as class-parse failures.
                    // Disk-full / permission errors must stop the run instead of producing
                    // silently incomplete analysis files.
                    out.writeClassDef(visitor.classDef);
                    for (MethodDef method : visitor.classDef.methods.values()) {
                        out.writeMethodDef(visitor.classDef, method);
                    }
                }
            }
        } catch (IOException e) {
            warn("INDEX_JAR", jarInfo, null, e);
        } catch (OutputWriteException e) {
            throw e;
        } catch (RuntimeException e) {
            warn("INDEX_JAR", jarInfo, null, e);
        } finally {
            closeQuietly(jar);
        }
    }

    private static final class DefinitionVisitor extends ClassVisitor {
        private final JarInfo jarInfo;
        private ClassDef classDef;

        DefinitionVisitor(JarInfo jarInfo) {
            super(ASM_API);
            this.jarInfo = jarInfo;
        }

        @Override
        public void visit(int version, int access, String name, String signature,
                          String superName, String[] interfaces) {
            String className = internalToClass(name);
            if (!isTargetClassName(className)) {
                classDef = null;
                return;
            }

            ClassDef d = new ClassDef();
            d.group = jarInfo.group;
            d.jarPath = jarInfo.relativePath;
            d.className = className;
            d.access = access;

            String superClass = internalToClass(superName);
            d.superClassName = isTargetClassName(superClass) ? superClass : "";
            if (interfaces != null) {
                for (String intf : interfaces) {
                    String interfaceClass = internalToClass(intf);
                    if (isTargetClassName(interfaceClass)) {
                        d.interfaces.add(interfaceClass);
                    }
                }
            }
            classDef = d;
        }

        @Override
        public void visitSource(String source, String debug) {
            if (classDef != null) {
                classDef.sourceFile = source;
            }
        }

        @Override
        public MethodVisitor visitMethod(final int access, final String name,
                                         final String descriptor, String signature,
                                         String[] exceptions) {
            if (classDef == null) {
                return null;
            }

            final MethodDef m = new MethodDef();
            m.name = name;
            m.descriptor = descriptor;
            m.access = access;

            final Type[] argumentTypes = safeArgumentTypes(descriptor);
            final int[] parameterSlots = argumentSlots(access, argumentTypes);
            classDef.methods.put(new MethodKey(name, descriptor), m);

            return new MethodVisitor(ASM_API) {
                private int visitParameterIndex = 0;

                @Override
                public void visitParameter(String parameterName, int parameterAccess) {
                    if (visitParameterIndex < argumentTypes.length
                            && parameterName != null && parameterName.length() > 0) {
                        if (m.parameterNames == null) {
                            m.parameterNames = new String[argumentTypes.length];
                        }
                        m.parameterNames[visitParameterIndex] = parameterName;
                    }
                    visitParameterIndex++;
                }

                @Override
                public void visitLocalVariable(String localName, String localDescriptor,
                                               String localSignature, Label start, Label end,
                                               int index) {
                    if (localName == null || localName.length() == 0) {
                        return;
                    }
                    // A later local variable may reuse a parameter slot. Only an LVT entry
                    // whose scope starts at bytecode offset 0 is safe to treat as a parameter.
                    try {
                        if (start == null || start.getOffset() != 0) {
                            return;
                        }
                    } catch (IllegalStateException e) {
                        return;
                    }
                    for (int i = 0; i < parameterSlots.length; i++) {
                        if (parameterSlots[i] == index
                                && localDescriptor != null
                                && localDescriptor.equals(argumentTypes[i].getDescriptor())) {
                            if (m.parameterNames == null) {
                                m.parameterNames = new String[argumentTypes.length];
                            }
                            if (m.parameterNames[i] == null) {
                                m.parameterNames[i] = localName;
                            }
                            break;
                        }
                    }
                }

                @Override
                public void visitLineNumber(int line, Label start) {
                    if (m.firstLine < 0 || line < m.firstLine) {
                        m.firstLine = line;
                    }
                    if (line > m.lastLine) {
                        m.lastLine = line;
                    }
                }
            };
        }
    }

    // ---------------------------------------------------------------------
    // PASS 2 - references/calls
    // ---------------------------------------------------------------------

    private static void analyzeJar(JarInfo jarInfo, Index index, MethodResolver resolver,
                                   CsvOutputs out, ClassCallGraph callGraph, Stats stats) {
        JarFile jar = null;
        try {
            jar = new JarFile(jarInfo.path.toFile(), false);
            java.util.Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                // Do not even decompress/parse non-jp.co.* classes.
                if (!isTargetClassEntry(entry)) {
                    continue;
                }

                ClassReader cr = readClassReader(jar, entry, jarInfo, stats);
                if (cr == null || !isTargetInternalClassName(cr.getClassName())) {
                    continue;
                }

                try {
                    cr.accept(new DependencyVisitor(jarInfo, index, resolver, out, callGraph),
                            ClassReader.SKIP_FRAMES);
                } catch (OutputWriteException e) {
                    throw e;
                } catch (RuntimeException e) {
                    stats.skippedClassEntries++;
                    warn("ANALYZE_CLASS", jarInfo, entry, e);
                }
            }
        } catch (IOException e) {
            warn("ANALYZE_JAR", jarInfo, null, e);
        } catch (OutputWriteException e) {
            throw e;
        } catch (RuntimeException e) {
            warn("ANALYZE_JAR", jarInfo, null, e);
        } finally {
            closeQuietly(jar);
        }
    }

    private static final class DependencyVisitor extends ClassVisitor {
        private final JarInfo originJar;
        private final Index index;
        private final MethodResolver resolver;
        private final CsvOutputs out;
        private final ClassCallGraph callGraph;

        private String originClass = "";
        private String sourceFile = "";

        /** One set per class only; discarded after each ClassReader.accept(). */
        private final Set<String> classRefDedupe = new HashSet<String>();

        DependencyVisitor(JarInfo originJar, Index index, MethodResolver resolver,
                          CsvOutputs out, ClassCallGraph callGraph) {
            super(ASM_API);
            this.originJar = originJar;
            this.index = index;
            this.resolver = resolver;
            this.out = out;
            this.callGraph = callGraph;
        }

        @Override
        public void visit(int version, int access, String name, String signature,
                          String superName, String[] interfaces) {
            originClass = internalToClass(name);
            addRef("", -1, "EXTENDS", internalToClass(superName));
            if (interfaces != null) {
                for (String intf : interfaces) {
                    addRef("", -1, "IMPLEMENTS", internalToClass(intf));
                }
            }
            collectClassOrMethodSignature(signature, new RefConsumer("", -1, "CLASS_SIGNATURE"));
        }

        @Override
        public void visitSource(String source, String debug) {
            sourceFile = safe(source);
        }

        @Override
        public void visitOuterClass(String owner, String name, String descriptor) {
            addRef("", -1, "OUTER_CLASS", internalToClass(owner));
            collectDescriptor(descriptor, new RefConsumer("", -1, "OUTER_METHOD_DESCRIPTOR"));
        }

        @Override
        public void visitInnerClass(String name, String outerName, String innerName, int access) {
            addRef("", -1, "INNER_CLASS", internalToClass(name));
            addRef("", -1, "INNER_OUTER_CLASS", internalToClass(outerName));
        }

        @Override
        public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
            collectDescriptor(descriptor, new RefConsumer("", -1, "CLASS_ANNOTATION"));
            return new DepAnnotationVisitor("", -1, "CLASS_ANNOTATION_VALUE");
        }

        @Override
        public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath,
                                                     String descriptor, boolean visible) {
            collectDescriptor(descriptor, new RefConsumer("", -1, "CLASS_TYPE_ANNOTATION"));
            return new DepAnnotationVisitor("", -1, "CLASS_TYPE_ANNOTATION_VALUE");
        }

        @Override
        public FieldVisitor visitField(int access, String name, String descriptor,
                                       String signature, Object value) {
            collectDescriptor(descriptor, new RefConsumer("", -1, "FIELD_TYPE"));
            collectTypeSignature(signature, new RefConsumer("", -1, "FIELD_SIGNATURE"));
            collectConstant(value, new RefConsumer("", -1, "FIELD_CONSTANT"));

            return new FieldVisitor(ASM_API) {
                @Override
                public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
                    collectDescriptor(descriptor, new RefConsumer("", -1, "FIELD_ANNOTATION"));
                    return new DepAnnotationVisitor("", -1, "FIELD_ANNOTATION_VALUE");
                }


                @Override
                public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath,
                                                             String descriptor, boolean visible) {
                    collectDescriptor(descriptor,
                            new RefConsumer("", -1, "FIELD_TYPE_ANNOTATION"));
                    return new DepAnnotationVisitor("", -1,
                            "FIELD_TYPE_ANNOTATION_VALUE");
                }
            };
        }

        @Override
        public MethodVisitor visitMethod(final int access, final String name,
                                         final String descriptor, String signature,
                                         String[] exceptions) {
            final MethodDef indexed = index.findMethodExact(
                    originJar.group, originClass, name, descriptor, originJar.relativePath);
            final String readableOrigin = indexed == null
                    ? readableMethod(originClass, access, name, descriptor, null)
                    : readableMethod(originClass, access, name, descriptor, indexed.parameterNames);

            collectDescriptor(descriptor, new RefConsumer(readableOrigin, -1, "METHOD_DESCRIPTOR"));
            collectClassOrMethodSignature(signature,
                    new RefConsumer(readableOrigin, -1, "METHOD_SIGNATURE"));
            if (exceptions != null) {
                for (String ex : exceptions) {
                    addRef(readableOrigin, -1, "THROWS", internalToClass(ex));
                }
            }

            return new MethodVisitor(ASM_API) {
                private int line = -1;

                @Override
                public void visitLineNumber(int newLine, Label start) {
                    line = newLine;
                }

                @Override
                public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {
                    addRef(readableOrigin, line, "CATCH_TYPE", internalToClass(type));
                }

                @Override
                public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
                    collectDescriptor(desc, new RefConsumer(readableOrigin, line, "METHOD_ANNOTATION"));
                    return new DepAnnotationVisitor(readableOrigin, line, "METHOD_ANNOTATION_VALUE");
                }


                @Override
                public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath,
                                                             String desc, boolean visible) {
                    collectDescriptor(desc,
                            new RefConsumer(readableOrigin, line, "METHOD_TYPE_ANNOTATION"));
                    return new DepAnnotationVisitor(readableOrigin, line,
                            "METHOD_TYPE_ANNOTATION_VALUE");
                }

                @Override
                public AnnotationVisitor visitInsnAnnotation(int typeRef, TypePath typePath,
                                                             String desc, boolean visible) {
                    collectDescriptor(desc,
                            new RefConsumer(readableOrigin, line, "INSN_TYPE_ANNOTATION"));
                    return new DepAnnotationVisitor(readableOrigin, line,
                            "INSN_TYPE_ANNOTATION_VALUE");
                }

                @Override
                public AnnotationVisitor visitTryCatchAnnotation(int typeRef, TypePath typePath,
                                                                 String desc, boolean visible) {
                    collectDescriptor(desc,
                            new RefConsumer(readableOrigin, line, "TRY_CATCH_TYPE_ANNOTATION"));
                    return new DepAnnotationVisitor(readableOrigin, line,
                            "TRY_CATCH_TYPE_ANNOTATION_VALUE");
                }

                @Override
                public AnnotationVisitor visitLocalVariableAnnotation(
                        int typeRef, TypePath typePath, Label[] start, Label[] end,
                        int[] index, String desc, boolean visible) {
                    collectDescriptor(desc,
                            new RefConsumer(readableOrigin, line, "LOCAL_TYPE_ANNOTATION"));
                    return new DepAnnotationVisitor(readableOrigin, line,
                            "LOCAL_TYPE_ANNOTATION_VALUE");
                }

                @Override
                public AnnotationVisitor visitParameterAnnotation(int parameter, String desc,
                                                                  boolean visible) {
                    collectDescriptor(desc,
                            new RefConsumer(readableOrigin, line, "PARAMETER_ANNOTATION"));
                    return new DepAnnotationVisitor(readableOrigin, line,
                            "PARAMETER_ANNOTATION_VALUE");
                }

                @Override
                public void visitTypeInsn(int opcode, String type) {
                    String kind;
                    switch (opcode) {
                        case Opcodes.NEW: kind = "NEW"; break;
                        case Opcodes.ANEWARRAY: kind = "ANEWARRAY"; break;
                        case Opcodes.CHECKCAST: kind = "CHECKCAST"; break;
                        case Opcodes.INSTANCEOF: kind = "INSTANCEOF"; break;
                        default: kind = "TYPE_INSN"; break;
                    }
                    if (type != null && type.startsWith("[")) {
                        collectDescriptor(type, new RefConsumer(readableOrigin, line, kind));
                    } else {
                        addRef(readableOrigin, line, kind, internalToClass(type));
                    }
                }

                @Override
                public void visitMultiANewArrayInsn(String desc, int dims) {
                    collectDescriptor(desc,
                            new RefConsumer(readableOrigin, line, "MULTIANEWARRAY"));
                }

                @Override
                public void visitFieldInsn(int opcode, String owner, String fieldName,
                                           String fieldDescriptor) {
                    addRef(readableOrigin, line, fieldOpcodeName(opcode), internalToClass(owner));
                    collectDescriptor(fieldDescriptor,
                            new RefConsumer(readableOrigin, line, "FIELD_DESCRIPTOR"));
                }

                @Override
                public void visitMethodInsn(int opcode, String owner, String calledName,
                                            String calledDescriptor, boolean isInterface) {
                    String ownerClass = internalToClass(owner);
                    addRef(readableOrigin, line, methodOpcodeName(opcode), ownerClass);
                    collectDescriptor(calledDescriptor,
                            new RefConsumer(readableOrigin, line, "CALLED_METHOD_DESCRIPTOR"));

                    if (isTargetClassName(ownerClass)) {
                        MethodResolution r = resolver.resolve(
                                originJar.group, ownerClass, calledName, calledDescriptor);
                        // Exclude calls whose resolved definition is JDK/external.
                        // Missing jp.co.* targets are kept as NOT_FOUND_IN_GROUP.
                        if (!JDK.equals(r.status) && !EXTERNAL.equals(r.status)) {
                            out.writeMethodCall(originJar.group, originJar.relativePath,
                                    originClass, readableOrigin, sourceFile, line,
                                    methodOpcodeName(opcode), ownerClass, calledName, calledDescriptor,
                                    readableMethod(ownerClass, 0, calledName, calledDescriptor, null),
                                    r, dispatchKind(opcode));
                            callGraph.addCall(originJar.relativePath, originClass, ownerClass,
                                    index.resolveClass(originJar.group, ownerClass));
                        }
                    }
                }

                @Override
                public void visitInvokeDynamicInsn(String invokedName, String invokedDescriptor,
                                                   Handle bootstrapMethodHandle,
                                                   Object... bootstrapMethodArguments) {
                    collectDescriptor(invokedDescriptor,
                            new RefConsumer(readableOrigin, line, "INVOKEDYNAMIC_DESCRIPTOR"));
                    inspectHandle(readableOrigin, line, bootstrapMethodHandle,
                            "BOOTSTRAP_HANDLE", false);
                    if (bootstrapMethodArguments != null) {
                        for (Object arg : bootstrapMethodArguments) {
                            inspectBootstrapArg(readableOrigin, line, arg);
                        }
                    }
                }

                @Override
                public void visitLdcInsn(Object value) {
                    collectConstant(value, new RefConsumer(readableOrigin, line, "LDC_CLASS"));
                    if (value instanceof ConstantDynamic) {
                        inspectConstantDynamic(readableOrigin, line, (ConstantDynamic) value);
                    }
                }

                private void inspectBootstrapArg(String originMethod, int currentLine, Object arg) {
                    if (arg instanceof Handle) {
                        // Lambda/metafactory implementation handles are real bytecode method references.
                        inspectHandle(originMethod, currentLine, (Handle) arg,
                                "BOOTSTRAP_ARG_HANDLE", true);
                    } else if (arg instanceof Type) {
                        collectType((Type) arg,
                                new RefConsumer(originMethod, currentLine, "BOOTSTRAP_TYPE"));
                    } else if (arg instanceof ConstantDynamic) {
                        inspectConstantDynamic(originMethod, currentLine, (ConstantDynamic) arg);
                    }
                }

                private void inspectConstantDynamic(String originMethod, int currentLine,
                                                    ConstantDynamic cd) {
                    if (cd == null) {
                        return;
                    }
                    collectDescriptor(cd.getDescriptor(),
                            new RefConsumer(originMethod, currentLine,
                                    "CONSTANT_DYNAMIC_DESCRIPTOR"));
                    inspectHandle(originMethod, currentLine, cd.getBootstrapMethod(),
                            "CONSTANT_DYNAMIC_BOOTSTRAP", false);
                    for (int i = 0; i < cd.getBootstrapMethodArgumentCount(); i++) {
                        inspectBootstrapArg(originMethod, currentLine,
                                cd.getBootstrapMethodArgument(i));
                    }
                }

                private void inspectHandle(String originMethod, int currentLine, Handle handle,
                                           String kind, boolean emitMethodCall) {
                    if (handle == null) {
                        return;
                    }
                    String ownerClass = internalToClass(handle.getOwner());
                    addRef(originMethod, currentLine, kind, ownerClass);
                    collectDescriptor(handle.getDesc(),
                            new RefConsumer(originMethod, currentLine, kind + "_DESCRIPTOR"));

                    if (emitMethodCall && isMethodHandleTag(handle.getTag())
                            && isTargetClassName(ownerClass)) {
                        MethodResolution r = resolver.resolve(originJar.group, ownerClass,
                                handle.getName(), handle.getDesc());
                        if (!JDK.equals(r.status) && !EXTERNAL.equals(r.status)) {
                            out.writeMethodCall(originJar.group, originJar.relativePath,
                                    originClass, originMethod, sourceFile, currentLine,
                                    handleTagName(handle.getTag()), ownerClass,
                                    handle.getName(), handle.getDesc(),
                                    readableMethod(ownerClass, 0, handle.getName(),
                                            handle.getDesc(), null),
                                    r, "DYNAMIC_HANDLE");
                            callGraph.addCall(originJar.relativePath, originClass, ownerClass,
                                    index.resolveClass(originJar.group, ownerClass));
                        }
                    }
                }
            };
        }

        private final class RefConsumer implements TypeConsumer {
            private final String method;
            private final int line;
            private final String kind;

            RefConsumer(String method, int line, String kind) {
                this.method = method;
                this.line = line;
                this.kind = kind;
            }

            @Override
            public void accept(String className) {
                addRef(method, line, kind, className);
            }
        }

        private final class DepAnnotationVisitor extends AnnotationVisitor {
            private final String method;
            private final int line;
            private final String kind;

            DepAnnotationVisitor(String method, int line, String kind) {
                super(ASM_API);
                this.method = method;
                this.line = line;
                this.kind = kind;
            }

            @Override
            public void visit(String name, Object value) {
                collectConstant(value, new RefConsumer(method, line, kind));
            }

            @Override
            public void visitEnum(String name, String descriptor, String value) {
                collectDescriptor(descriptor, new RefConsumer(method, line, kind + "_ENUM"));
            }

            @Override
            public AnnotationVisitor visitAnnotation(String name, String descriptor) {
                collectDescriptor(descriptor, new RefConsumer(method, line, kind + "_NESTED"));
                return new DepAnnotationVisitor(method, line, kind);
            }

            @Override
            public AnnotationVisitor visitArray(String name) {
                return new DepAnnotationVisitor(method, line, kind);
            }
        }

        /**
         * class_ref.csv intentionally deduplicates by origin class + kind + target class.
         * The first observed method/line is kept only as a locator. This prevents row explosion.
         */
        private void addRef(String originMethod, int line, String kind, String targetClass) {
            if (!isTargetClassName(originClass) || !isTargetClassName(targetClass)
                    || targetClass.equals(originClass)) {
                return;
            }
            String key = kind + '\u0001' + targetClass;
            if (!classRefDedupe.add(key)) {
                return;
            }
            ClassResolution cr = index.resolveClass(originJar.group, targetClass);
            out.writeClassRef(originJar.group, originJar.relativePath, originClass,
                    safe(originMethod), sourceFile, line, kind, targetClass, cr);
        }
    }

    // ---------------------------------------------------------------------
    // Index/resolution
    // ---------------------------------------------------------------------

    private static final class Index {
        // group -> className -> zero/one/multiple definitions
        private final Map<String, Map<String, List<ClassDef>>> classes =
                new HashMap<String, Map<String, List<ClassDef>>>();

        void add(ClassDef d) {
            Map<String, List<ClassDef>> byClass = classes.get(d.group);
            if (byClass == null) {
                byClass = new HashMap<String, List<ClassDef>>();
                classes.put(d.group, byClass);
            }
            List<ClassDef> defs = byClass.get(d.className);
            if (defs == null) {
                defs = new ArrayList<ClassDef>(1);
                byClass.put(d.className, defs);
            }
            defs.add(d);
        }

        List<ClassDef> find(String group, String className) {
            Map<String, List<ClassDef>> byClass = classes.get(group);
            if (byClass == null) {
                return Collections.emptyList();
            }
            List<ClassDef> defs = byClass.get(className);
            return defs == null ? Collections.<ClassDef>emptyList() : defs;
        }

        List<String> classNames(String group) {
            Map<String, List<ClassDef>> byClass = classes.get(group);
            if (byClass == null || byClass.isEmpty()) {
                return Collections.emptyList();
            }
            List<String> result = new ArrayList<String>(byClass.keySet());
            Collections.sort(result);
            return result;
        }

        MethodDef findMethodExact(String group, String className, String name,
                                  String descriptor, String jarPath) {
            List<ClassDef> defs = find(group, className);
            for (ClassDef d : defs) {
                if (d.jarPath.equals(jarPath)) {
                    return d.methods.get(new MethodKey(name, descriptor));
                }
            }
            return null;
        }

        ClassResolution resolveClass(String group, String className) {
            List<ClassDef> defs = find(group, className);
            if (defs.size() == 1) {
                return ClassResolution.resolved(defs.get(0).jarPath);
            }
            if (defs.size() > 1) {
                List<String> candidates = new ArrayList<String>(defs.size());
                for (ClassDef d : defs) {
                    candidates.add(d.jarPath);
                }
                Collections.sort(candidates);
                return ClassResolution.ambiguous(candidates);
            }
            // Only jp.co.* reaches this resolver. A missing target therefore means
            // "not found in this directory group", not third-party/JDK.
            return ClassResolution.notFound(NOT_FOUND_IN_GROUP);
        }
    }

    private static final class MethodResolver {
        private final Index index;
        private final Map<String, MethodResolution> cache;

        MethodResolver(Index index) {
            this.index = index;
            if (METHOD_RESOLVE_CACHE_SIZE == 0) {
                this.cache = null;
            } else {
                this.cache = new LinkedHashMap<String, MethodResolution>(1024, 0.75f, true) {
                    @Override
                    protected boolean removeEldestEntry(Map.Entry<String, MethodResolution> eldest) {
                        return size() > METHOD_RESOLVE_CACHE_SIZE;
                    }
                };
            }
        }

        MethodResolution resolve(String group, String owner, String name, String descriptor) {
            String cacheKey = group + '\u0001' + safe(owner) + '\u0001'
                    + safe(name) + '\u0001' + safe(descriptor);
            if (cache != null) {
                MethodResolution cached = cache.get(cacheKey);
                if (cached != null) {
                    return cached;
                }
            }

            MethodResolution result = resolveUncached(group, owner, name, descriptor);
            if (cache != null) {
                cache.put(cacheKey, result);
            }
            return result;
        }

        private MethodResolution resolveUncached(String group, String owner, String name,
                                                  String descriptor) {
            if (owner == null || owner.length() == 0) {
                return MethodResolution.notFound(NOT_FOUND_IN_GROUP);
            }

            // Constructors are never inherited.
            if ("<init>".equals(name)) {
                return resolveExactOwner(group, owner, name, descriptor);
            }

            MethodKey key = new MethodKey(name, descriptor);
            List<ClassDef> ownerDefs = index.find(group, owner);
            if (ownerDefs.size() > 1) {
                return ambiguousDuplicateClass(ownerDefs, key);
            }
            if (ownerDefs.isEmpty()) {
                // owner is jp.co.* because non-target packages are filtered before resolution.
                return MethodResolution.notFound(NOT_FOUND_IN_GROUP);
            }

            // Fast path: most calls resolve on the symbolic owner itself. Avoid allocating
            // hierarchy traversal collections for this overwhelmingly common case.
            ClassDef ownerDef = ownerDefs.get(0);
            MethodDef ownMethod = ownerDef.methods.get(key);
            if (ownMethod != null) {
                return MethodResolution.resolved(ownerDef, ownMethod);
            }

            List<String> interfaceRoots = null;
            if (!ownerDef.interfaces.isEmpty()) {
                interfaceRoots = new ArrayList<String>(ownerDef.interfaces);
            }

            String fallbackStatus = NOT_FOUND_IN_GROUP;
            String current = (ownerDef.access & Opcodes.ACC_INTERFACE) != 0
                    ? "" : ownerDef.superClassName;
            int depth = 0;

            // Valid Java class hierarchies are acyclic. A hard depth bound protects against
            // malformed bytecode without allocating a HashSet for every cache miss.
            while (current != null && current.length() > 0) {
                if (++depth > MAX_HIERARCHY_DEPTH) {
                    return MethodResolution.notFound(HIERARCHY_LIMIT);
                }

                List<ClassDef> defs = index.find(group, current);
                if (defs.size() > 1) {
                    return ambiguousDuplicateClass(defs, key);
                }
                if (defs.isEmpty()) {
                    fallbackStatus = mergeMissingStatus(fallbackStatus, current);
                    break;
                }

                ClassDef d = defs.get(0);
                MethodDef m = d.methods.get(key);
                if (m != null) {
                    return MethodResolution.resolved(d, m);
                }

                if (!d.interfaces.isEmpty()) {
                    if (interfaceRoots == null) {
                        interfaceRoots = new ArrayList<String>();
                    }
                    interfaceRoots.addAll(d.interfaces);
                }

                if ((d.access & Opcodes.ACC_INTERFACE) != 0) {
                    break;
                }
                current = d.superClassName;
            }

            MethodResolution interfaceResult = resolveInterfaces(
                    group, key,
                    interfaceRoots == null ? Collections.<String>emptyList() : interfaceRoots,
                    fallbackStatus);
            if (interfaceResult != null) {
                if ((ownerDef.access & Opcodes.ACC_INTERFACE) != 0
                        && NOT_FOUND_IN_GROUP.equals(interfaceResult.status)
                        && isJava8ObjectPublicInstanceMethod(name, descriptor)) {
                    return MethodResolution.notFound(JDK);
                }
                return interfaceResult;
            }

            if ((ownerDef.access & Opcodes.ACC_INTERFACE) != 0
                    && isJava8ObjectPublicInstanceMethod(name, descriptor)) {
                return MethodResolution.notFound(JDK);
            }
            return MethodResolution.notFound(fallbackStatus);
        }

        private MethodResolution resolveInterfaces(String group, MethodKey key,
                                                   List<String> roots, String fallbackStatus) {
            if (roots.isEmpty()) {
                return null;
            }

            Deque<InterfaceNode> queue = new ArrayDeque<InterfaceNode>();
            Set<String> visited = new HashSet<String>();
            List<InterfaceMethodCandidate> matches =
                    new ArrayList<InterfaceMethodCandidate>();
            String missingStatus = fallbackStatus;

            for (String root : roots) {
                if (root != null && root.length() > 0) {
                    queue.addLast(new InterfaceNode(root, 0));
                }
            }

            while (!queue.isEmpty()) {
                InterfaceNode node = queue.removeFirst();
                if (!visited.add(node.className)) {
                    continue;
                }
                if (node.depth > MAX_HIERARCHY_DEPTH) {
                    return MethodResolution.notFound(HIERARCHY_LIMIT);
                }

                List<ClassDef> defs = index.find(group, node.className);
                if (defs.size() > 1) {
                    return ambiguousDuplicateClass(defs, key);
                }
                if (defs.isEmpty()) {
                    missingStatus = mergeMissingStatus(missingStatus, node.className);
                    continue;
                }

                ClassDef d = defs.get(0);
                MethodDef m = d.methods.get(key);
                if (m != null) {
                    matches.add(new InterfaceMethodCandidate(d, m));
                }

                // Continue into parents even after a declaration is found.
                // JVM interface resolution chooses maximally-specific declarations.
                for (String parent : d.interfaces) {
                    if (parent != null && parent.length() > 0) {
                        queue.addLast(new InterfaceNode(parent, node.depth + 1));
                    }
                }
            }

            if (matches.isEmpty()) {
                return MethodResolution.notFound(missingStatus);
            }

            List<InterfaceMethodCandidate> maximal =
                    new ArrayList<InterfaceMethodCandidate>(matches.size());

            for (int i = 0; i < matches.size(); i++) {
                InterfaceMethodCandidate candidate = matches.get(i);
                boolean shadowed = false;

                for (int j = 0; j < matches.size(); j++) {
                    if (i == j) {
                        continue;
                    }
                    InterfaceMethodCandidate other = matches.get(j);
                    if (isStrictSubInterface(group,
                            other.owner.className, candidate.owner.className)) {
                        shadowed = true;
                        break;
                    }
                }

                if (!shadowed) {
                    maximal.add(candidate);
                }
            }

            if (maximal.size() == 1) {
                InterfaceMethodCandidate c = maximal.get(0);
                return MethodResolution.resolved(c.owner, c.method);
            }

            List<String> candidates = new ArrayList<String>(maximal.size());
            for (InterfaceMethodCandidate c : maximal) {
                candidates.add(c.owner.jarPath + "!" + c.owner.className + "#"
                        + readableMethod(c.owner.className, c.method.access, c.method.name,
                        c.method.descriptor, c.method.parameterNames));
            }
            Collections.sort(candidates);
            return MethodResolution.ambiguous(AMBIGUOUS_HIERARCHY, candidates);
        }

        private boolean isStrictSubInterface(String group, String possibleChild,
                                             String possibleParent) {
            if (possibleChild == null || possibleParent == null
                    || possibleChild.equals(possibleParent)) {
                return false;
            }

            Deque<InterfaceNode> queue = new ArrayDeque<InterfaceNode>();
            Set<String> visited = new HashSet<String>();
            queue.addLast(new InterfaceNode(possibleChild, 0));

            while (!queue.isEmpty()) {
                InterfaceNode node = queue.removeFirst();
                if (!visited.add(node.className)) {
                    continue;
                }
                if (node.depth > MAX_HIERARCHY_DEPTH) {
                    return false;
                }

                List<ClassDef> defs = index.find(group, node.className);
                if (defs.size() != 1) {
                    continue;
                }

                for (String parent : defs.get(0).interfaces) {
                    if (possibleParent.equals(parent)) {
                        return true;
                    }
                    if (parent != null && parent.length() > 0) {
                        queue.addLast(new InterfaceNode(parent, node.depth + 1));
                    }
                }
            }
            return false;
        }

        private static final class InterfaceMethodCandidate {
            final ClassDef owner;
            final MethodDef method;

            InterfaceMethodCandidate(ClassDef owner, MethodDef method) {
                this.owner = owner;
                this.method = method;
            }
        }

        private String mergeMissingStatus(String current, String missingClass) {
            if (isTargetClassName(missingClass)) {
                return NOT_FOUND_IN_GROUP;
            }
            if (!isJdkClass(missingClass)) {
                return EXTERNAL;
            }
            return EXTERNAL.equals(current) ? current : JDK;
        }

        private MethodResolution resolveExactOwner(String group, String owner,
                                                   String name, String descriptor) {
            List<ClassDef> defs = index.find(group, owner);
            MethodKey key = new MethodKey(name, descriptor);
            if (defs.size() > 1) {
                return ambiguousDuplicateClass(defs, key);
            }
            if (defs.size() == 1) {
                MethodDef m = defs.get(0).methods.get(key);
                return m == null
                        ? MethodResolution.notFound(NOT_FOUND_IN_GROUP)
                        : MethodResolution.resolved(defs.get(0), m);
            }
            return MethodResolution.notFound(
                    isTargetClassName(owner) ? NOT_FOUND_IN_GROUP
                            : (isJdkClass(owner) ? JDK : EXTERNAL));
        }

        private MethodResolution ambiguousDuplicateClass(List<ClassDef> defs, MethodKey key) {
            List<String> candidates = new ArrayList<String>();
            for (ClassDef d : defs) {
                MethodDef m = d.methods.get(key);
                if (m == null) {
                    candidates.add(d.jarPath + "!" + d.className);
                } else {
                    candidates.add(d.jarPath + "!" + d.className + "#"
                            + readableMethod(d.className, m.access, m.name,
                            m.descriptor, m.parameterNames));
                }
            }
            Collections.sort(candidates);
            return MethodResolution.ambiguous(AMBIGUOUS, candidates);
        }

        private static final class InterfaceNode {
            final String className;
            final int depth;

            InterfaceNode(String className, int depth) {
                this.className = className;
                this.depth = depth;
            }
        }
    }

    // ---------------------------------------------------------------------
    // Class-call graph / Adapter-rooted text flow
    // ---------------------------------------------------------------------

    private static final class ClassCallGraph {
        private final String group;
        private final Map<String, Map<String, ClassCallEdge>> edgesByOrigin =
                new HashMap<String, Map<String, ClassCallEdge>>();

        ClassCallGraph(String group) {
            this.group = group;
        }

        void addCall(String originJar, String originClass, String targetClass, ClassResolution r) {
            if (!isTargetClassName(originClass) || !isTargetClassName(targetClass)
                    || originClass.equals(targetClass)) {
                return;
            }
            String originKey = graphKey(originJar, originClass);
            Map<String, ClassCallEdge> byTarget = edgesByOrigin.get(originKey);
            if (byTarget == null) {
                byTarget = new HashMap<String, ClassCallEdge>();
                edgesByOrigin.put(originKey, byTarget);
            }
            ClassCallEdge edge = byTarget.get(targetClass);
            if (edge == null) {
                edge = new ClassCallEdge();
                edge.group = group;
                edge.originJar = safe(originJar);
                edge.originClass = originClass;
                edge.targetClass = targetClass;
                edge.targetJar = safe(r.targetJar);
                edge.resolutionStatus = safe(r.status);
                edge.candidates = safe(r.candidates);
                byTarget.put(targetClass, edge);
            }
            edge.callCount++;
        }

        List<ClassCallEdge> outgoing(String originJar, String originClass) {
            Map<String, ClassCallEdge> byTarget = edgesByOrigin.get(graphKey(originJar, originClass));
            if (byTarget == null || byTarget.isEmpty()) {
                return Collections.emptyList();
            }
            List<ClassCallEdge> result = new ArrayList<ClassCallEdge>(byTarget.values());
            Collections.sort(result);
            return result;
        }

        private String graphKey(String jar, String className) {
            return safe(jar) + '\u0001' + safe(className);
        }

        List<ClassCallEdge> sortedEdges() {
            List<ClassCallEdge> result = new ArrayList<ClassCallEdge>();
            for (Map<String, ClassCallEdge> byTarget : edgesByOrigin.values()) {
                result.addAll(byTarget.values());
            }
            Collections.sort(result);
            return result;
        }
    }

    private static final class ClassCallEdge implements Comparable<ClassCallEdge> {
        String group = "";
        String originJar = "";
        String originClass = "";
        String targetClass = "";
        String targetJar = "";
        String resolutionStatus = "";
        String candidates = "";
        long callCount;

        @Override
        public int compareTo(ClassCallEdge other) {
            int c = originJar.compareTo(other.originJar);
            if (c != 0) {
                return c;
            }
            c = originClass.compareTo(other.originClass);
            if (c != 0) {
                return c;
            }
            return targetClass.compareTo(other.targetClass);
        }
    }

    private static final class FlowTextOutput implements Closeable {
        private final BufferedWriter writer;

        FlowTextOutput(Path path) throws IOException {
            writer = new BufferedWriter(
                    new OutputStreamWriter(Files.newOutputStream(path), StandardCharsets.UTF_8),
                    256 * 1024);
            writeLine("# ASM processing flow");
            writeLine("# Start classes: simple class name ends with Adapter");
            writeLine("# Only jp.co.* class-to-class method calls are included.");
            writeLine("");
        }

        long writeGroup(String group, Index index, ClassCallGraph graph) {
            long starts = 0;
            List<String> classNames = index.classNames(group);
            for (String className : classNames) {
                if (!isAdapterStartClass(className)) {
                    continue;
                }
                List<ClassDef> defs = new ArrayList<ClassDef>(index.find(group, className));
                Collections.sort(defs, new java.util.Comparator<ClassDef>() {
                    @Override
                    public int compare(ClassDef a, ClassDef b) {
                        return a.jarPath.compareTo(b.jarPath);
                    }
                });
                for (ClassDef startDef : defs) {
                    starts++;
                    writeLine("============================================================");
                    writeLine("GROUP: " + group);
                    writeLine("START: " + className + " [jar=" + startDef.jarPath + "]");
                    writeLine(className);

                    Set<String> path = new HashSet<String>();
                    Set<String> expanded = new HashSet<String>();
                    path.add(flowNodeKey(startDef.jarPath, className));
                    writeChildren(graph, startDef.jarPath, className, 1, path, expanded);
                    writeLine("");
                }
            }
            return starts;
        }

        private void writeChildren(ClassCallGraph graph, String originJar, String originClass,
                                   int depth, Set<String> path, Set<String> expanded) {
            if (depth > FLOW_MAX_DEPTH) {
                writeLine(indent(depth) + "-> [DEPTH_LIMIT " + FLOW_MAX_DEPTH + "]");
                return;
            }
            String originKey = flowNodeKey(originJar, originClass);
            if (!expanded.add(originKey)) {
                return;
            }

            List<ClassCallEdge> edges = graph.outgoing(originJar, originClass);
            for (ClassCallEdge edge : edges) {
                StringBuilder line = new StringBuilder();
                line.append(indent(depth)).append("-> ").append(edge.targetClass)
                        .append(" [calls=").append(edge.callCount);
                if (edge.targetJar.length() > 0) {
                    line.append(", jar=").append(edge.targetJar);
                }
                if (!RESOLVED.equals(edge.resolutionStatus)) {
                    line.append(", status=").append(edge.resolutionStatus);
                }
                line.append(']');

                String targetKey = flowNodeKey(edge.targetJar, edge.targetClass);
                if (RESOLVED.equals(edge.resolutionStatus) && path.contains(targetKey)) {
                    line.append(" [CYCLE]");
                    writeLine(line.toString());
                    continue;
                }
                if (RESOLVED.equals(edge.resolutionStatus) && expanded.contains(targetKey)) {
                    line.append(" [ALREADY_EXPANDED]");
                    writeLine(line.toString());
                    continue;
                }

                writeLine(line.toString());
                if (RESOLVED.equals(edge.resolutionStatus) && edge.targetJar.length() > 0) {
                    path.add(targetKey);
                    writeChildren(graph, edge.targetJar, edge.targetClass,
                            depth + 1, path, expanded);
                    path.remove(targetKey);
                }
            }
        }

        private String flowNodeKey(String jar, String className) {
            return safe(jar) + '\u0001' + safe(className);
        }

        private void writeLine(String text) {
            try {
                writer.write(text);
                writer.newLine();
            } catch (IOException e) {
                throw new OutputWriteException("Flow text write failed", e);
            }
        }

        @Override
        public void close() throws IOException {
            writer.close();
        }
    }

    private static boolean isAdapterStartClass(String className) {
        if (!isTargetClassName(className)) {
            return false;
        }
        int dot = className.lastIndexOf('.');
        String simpleName = dot >= 0 ? className.substring(dot + 1) : className;
        return simpleName.indexOf('$') < 0 && simpleName.endsWith("Adapter");
    }

    private static String indent(int depth) {
        StringBuilder b = new StringBuilder(depth * 2);
        for (int i = 0; i < depth; i++) {
            b.append("  ");
        }
        return b.toString();
    }

    // ---------------------------------------------------------------------
    // PostgreSQL
    // ---------------------------------------------------------------------

    private static final class DbOutputs implements Closeable {
        private Connection connection;
        private PreparedStatement classDef;
        private PreparedStatement methodDef;
        private PreparedStatement classRef;
        private PreparedStatement methodCall;
        private PreparedStatement classCall;

        private int classDefBatch;
        private int methodDefBatch;
        private int classRefBatch;
        private int methodCallBatch;
        private int classCallBatch;
        private int rowsSinceCommit;

        DbOutputs() throws SQLException {
            if (!DB_ENABLED) {
                return;
            }
            try {
                Class.forName("org.postgresql.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(
                        "PostgreSQL JDBC driver not found. Add postgresql-42.x.x.jar to classpath.", e);
            }

            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            connection.setAutoCommit(false);

            classDef = connection.prepareStatement(
                    "INSERT INTO JAVA_ASM_CLASS_DEF "
                            + "(GROUP_NAME,JAR_PATH,CLASS_NAME,CLASS_ACCESS,SUPER_CLASS,INTERFACES,"
                            + "SOURCE_FILE,IS_ADAPTER) VALUES (?,?,?,?,?,?,?,?)");
            methodDef = connection.prepareStatement(
                    "INSERT INTO JAVA_ASM_METHOD_DEF "
                            + "(GROUP_NAME,JAR_PATH,CLASS_NAME,METHOD_NAME,DESCRIPTOR,READABLE_METHOD,"
                            + "METHOD_ACCESS,SOURCE_FILE,FIRST_LINE,LAST_LINE) VALUES (?,?,?,?,?,?,?,?,?,?)");
            classRef = connection.prepareStatement(
                    "INSERT INTO JAVA_ASM_CLASS_REF "
                            + "(GROUP_NAME,ORIGIN_JAR,ORIGIN_CLASS,FIRST_ORIGIN_METHOD,ORIGIN_SOURCE_FILE,"
                            + "FIRST_ORIGIN_LINE,REFERENCE_KIND,TARGET_CLASS,TARGET_JAR,RESOLUTION_STATUS,"
                            + "CANDIDATES) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
            methodCall = connection.prepareStatement(
                    "INSERT INTO JAVA_ASM_METHOD_CALL "
                            + "(GROUP_NAME,ORIGIN_JAR,ORIGIN_CLASS,ORIGIN_METHOD,ORIGIN_SOURCE_FILE,"
                            + "ORIGIN_LINE,OPCODE,BYTECODE_OWNER,CALLED_METHOD_NAME,CALLED_DESCRIPTOR,"
                            + "BYTECODE_CALLED_METHOD,DEFINITION_JAR,DEFINITION_CLASS,DEFINITION_METHOD,"
                            + "DEFINITION_SOURCE_FILE,DEFINITION_FIRST_LINE,DISPATCH,RESOLUTION_STATUS,"
                            + "CANDIDATES) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            classCall = connection.prepareStatement(
                    "INSERT INTO JAVA_ASM_CLASS_CALL "
                            + "(GROUP_NAME,ORIGIN_JAR,ORIGIN_CLASS,TARGET_CLASS,TARGET_JAR,"
                            + "RESOLUTION_STATUS,CANDIDATES,CALL_COUNT) VALUES (?,?,?,?,?,?,?,?)");
        }

        void truncateAll() {
            if (!DB_ENABLED) {
                return;
            }
            Statement statement = null;
            try {
                statement = connection.createStatement();
                statement.executeUpdate(
                        "TRUNCATE TABLE JAVA_ASM_CLASS_CALL, JAVA_ASM_METHOD_CALL, "
                                + "JAVA_ASM_CLASS_REF, JAVA_ASM_METHOD_DEF, JAVA_ASM_CLASS_DEF "
                                + "RESTART IDENTITY");
                connection.commit();
                System.out.println("DB_TRUNCATE=DONE");
            } catch (SQLException e) {
                rollbackQuietly();
                throw new OutputWriteException("PostgreSQL TRUNCATE failed", e);
            } finally {
                closeQuietly(statement);
            }
        }

        void analyzeAll() {
            if (!DB_ENABLED) {
                return;
            }
            Statement statement = null;
            try {
                flushAndCommit();
                statement = connection.createStatement();
                statement.executeUpdate("ANALYZE JAVA_ASM_CLASS_DEF");
                statement.executeUpdate("ANALYZE JAVA_ASM_METHOD_DEF");
                statement.executeUpdate("ANALYZE JAVA_ASM_CLASS_REF");
                statement.executeUpdate("ANALYZE JAVA_ASM_METHOD_CALL");
                statement.executeUpdate("ANALYZE JAVA_ASM_CLASS_CALL");
                System.out.println("DB_ANALYZE=DONE");
            } catch (SQLException e) {
                rollbackQuietly();
                throw new OutputWriteException("PostgreSQL ANALYZE failed", e);
            } finally {
                closeQuietly(statement);
            }
        }

        void writeClassDef(ClassDef d) {
            if (!DB_ENABLED) return;
            try {
                int i = 1;
                classDef.setString(i++, d.group);
                classDef.setString(i++, d.jarPath);
                classDef.setString(i++, d.className);
                classDef.setString(i++, classAccessString(d.access));
                classDef.setString(i++, safe(d.superClassName));
                classDef.setString(i++, join(d.interfaces, ";"));
                classDef.setString(i++, safe(d.sourceFile));
                classDef.setBoolean(i++, isAdapterStartClass(d.className));
                classDef.addBatch();
                classDefBatch++;
                afterRow(classDef, TableKind.CLASS_DEF);
            } catch (SQLException e) {
                throw dbFailure("JAVA_ASM_CLASS_DEF insert failed", e);
            }
        }

        void writeMethodDef(ClassDef c, MethodDef m) {
            if (!DB_ENABLED) return;
            try {
                int i = 1;
                methodDef.setString(i++, c.group);
                methodDef.setString(i++, c.jarPath);
                methodDef.setString(i++, c.className);
                methodDef.setString(i++, m.name);
                methodDef.setString(i++, m.descriptor);
                methodDef.setString(i++, readableMethod(c.className, m.access, m.name,
                        m.descriptor, m.parameterNames));
                methodDef.setString(i++, methodAccessString(m.access));
                methodDef.setString(i++, safe(c.sourceFile));
                setNullableInt(methodDef, i++, m.firstLine);
                setNullableInt(methodDef, i++, m.lastLine);
                methodDef.addBatch();
                methodDefBatch++;
                afterRow(methodDef, TableKind.METHOD_DEF);
            } catch (SQLException e) {
                throw dbFailure("JAVA_ASM_METHOD_DEF insert failed", e);
            }
        }

        void writeClassRef(String group, String originJar, String originClass,
                           String originMethod, String originSource, int line,
                           String kind, String targetClass, ClassResolution r) {
            if (!DB_ENABLED) return;
            try {
                int i = 1;
                classRef.setString(i++, group);
                classRef.setString(i++, originJar);
                classRef.setString(i++, originClass);
                classRef.setString(i++, originMethod);
                classRef.setString(i++, safe(originSource));
                setNullableInt(classRef, i++, line);
                classRef.setString(i++, kind);
                classRef.setString(i++, targetClass);
                classRef.setString(i++, safe(r.targetJar));
                classRef.setString(i++, safe(r.status));
                classRef.setString(i++, safe(r.candidates));
                classRef.addBatch();
                classRefBatch++;
                afterRow(classRef, TableKind.CLASS_REF);
            } catch (SQLException e) {
                throw dbFailure("JAVA_ASM_CLASS_REF insert failed", e);
            }
        }

        void writeMethodCall(String group, String originJar, String originClass,
                             String originMethod, String originSource, int line,
                             String opcode, String bytecodeOwner, String calledName,
                             String calledDescriptor, String bytecodeReadable,
                             MethodResolution r, String dispatch) {
            if (!DB_ENABLED) return;
            try {
                int i = 1;
                methodCall.setString(i++, group);
                methodCall.setString(i++, originJar);
                methodCall.setString(i++, originClass);
                methodCall.setString(i++, originMethod);
                methodCall.setString(i++, safe(originSource));
                setNullableInt(methodCall, i++, line);
                methodCall.setString(i++, opcode);
                methodCall.setString(i++, bytecodeOwner);
                methodCall.setString(i++, calledName);
                methodCall.setString(i++, calledDescriptor);
                methodCall.setString(i++, bytecodeReadable);
                methodCall.setString(i++, safe(r.definitionJar));
                methodCall.setString(i++, safe(r.definitionClass));
                methodCall.setString(i++, safe(r.definitionMethod));
                methodCall.setString(i++, safe(r.definitionSource));
                setNullableInt(methodCall, i++, r.definitionFirstLine);
                methodCall.setString(i++, dispatch);
                methodCall.setString(i++, safe(r.status));
                methodCall.setString(i++, safe(r.candidates));
                methodCall.addBatch();
                methodCallBatch++;
                afterRow(methodCall, TableKind.METHOD_CALL);
            } catch (SQLException e) {
                throw dbFailure("JAVA_ASM_METHOD_CALL insert failed", e);
            }
        }

        void writeClassCall(ClassCallEdge e) {
            if (!DB_ENABLED) return;
            try {
                int i = 1;
                classCall.setString(i++, e.group);
                classCall.setString(i++, e.originJar);
                classCall.setString(i++, e.originClass);
                classCall.setString(i++, e.targetClass);
                classCall.setString(i++, e.targetJar);
                classCall.setString(i++, e.resolutionStatus);
                classCall.setString(i++, e.candidates);
                classCall.setLong(i++, e.callCount);
                classCall.addBatch();
                classCallBatch++;
                afterRow(classCall, TableKind.CLASS_CALL);
            } catch (SQLException ex) {
                throw dbFailure("JAVA_ASM_CLASS_CALL insert failed", ex);
            }
        }

        private void afterRow(PreparedStatement ps, TableKind kind) throws SQLException {
            rowsSinceCommit++;
            if (batchCount(kind) >= DB_BATCH_SIZE) {
                ps.executeBatch();
                setBatchCount(kind, 0);
            }
            if (rowsSinceCommit >= DB_COMMIT_ROWS) {
                flushAndCommit();
            }
        }

        void flushAndCommit() {
            if (!DB_ENABLED) return;
            try {
                flushBatches();
                connection.commit();
                rowsSinceCommit = 0;
            } catch (SQLException e) {
                rollbackQuietly();
                throw dbFailure("PostgreSQL batch/commit failed", e);
            }
        }

        private void flushBatches() throws SQLException {
            if (classDefBatch > 0) { classDef.executeBatch(); classDefBatch = 0; }
            if (methodDefBatch > 0) { methodDef.executeBatch(); methodDefBatch = 0; }
            if (classRefBatch > 0) { classRef.executeBatch(); classRefBatch = 0; }
            if (methodCallBatch > 0) { methodCall.executeBatch(); methodCallBatch = 0; }
            if (classCallBatch > 0) { classCall.executeBatch(); classCallBatch = 0; }
        }

        private int batchCount(TableKind kind) {
            switch (kind) {
                case CLASS_DEF: return classDefBatch;
                case METHOD_DEF: return methodDefBatch;
                case CLASS_REF: return classRefBatch;
                case METHOD_CALL: return methodCallBatch;
                case CLASS_CALL: return classCallBatch;
                default: return 0;
            }
        }

        private void setBatchCount(TableKind kind, int value) {
            switch (kind) {
                case CLASS_DEF: classDefBatch = value; break;
                case METHOD_DEF: methodDefBatch = value; break;
                case CLASS_REF: classRefBatch = value; break;
                case METHOD_CALL: methodCallBatch = value; break;
                case CLASS_CALL: classCallBatch = value; break;
                default: break;
            }
        }

        private static void setNullableInt(PreparedStatement ps, int index, int value)
                throws SQLException {
            if (value < 0) {
                ps.setNull(index, java.sql.Types.INTEGER);
            } else {
                ps.setInt(index, value);
            }
        }

        private OutputWriteException dbFailure(String message, SQLException e) {
            rollbackQuietly();
            return new OutputWriteException(message, e);
        }

        private void rollbackQuietly() {
            if (connection != null) {
                try { connection.rollback(); } catch (SQLException ignored) { }
            }
        }

        @Override
        public void close() throws IOException {
            if (!DB_ENABLED) return;
            OutputWriteException failure = null;
            try {
                flushAndCommit();
            } catch (OutputWriteException e) {
                failure = e;
            }
            closeQuietly(classCall);
            closeQuietly(methodCall);
            closeQuietly(classRef);
            closeQuietly(methodDef);
            closeQuietly(classDef);
            closeQuietly(connection);
            if (failure != null) {
                throw new IOException(failure.getMessage(), failure);
            }
        }

        private enum TableKind { CLASS_DEF, METHOD_DEF, CLASS_REF, METHOD_CALL, CLASS_CALL }
    }

    // ---------------------------------------------------------------------
    // CSV
    // ---------------------------------------------------------------------

    private static final class CsvOutputs implements Closeable {
        private final BufferedWriter classDef;
        private final BufferedWriter methodDef;
        private final BufferedWriter classRef;
        private final BufferedWriter methodCall;
        private final Stats stats;
        private final DbOutputs db;

        CsvOutputs(Path dir, Stats stats, DbOutputs db) throws IOException {
            this.stats = stats;
            this.db = db;
            classDef = newCsvWriter(dir.resolve("class_def.csv"));
            methodDef = newCsvWriter(dir.resolve("method_def.csv"));
            classRef = newCsvWriter(dir.resolve("class_ref.csv"));
            methodCall = newCsvWriter(dir.resolve("method_call.csv"));

            row(classDef, "group", "jar_path", "class_name", "class_access",
                    "super_class", "interfaces", "source_file");
            row(methodDef, "group", "jar_path", "class_name", "method_name",
                    "descriptor", "readable_method", "method_access",
                    "source_file", "first_line", "last_line");
            row(classRef, "group", "origin_jar", "origin_class", "first_origin_method",
                    "origin_source_file", "first_origin_line", "reference_kind",
                    "target_class", "target_jar", "resolution_status", "candidates");
            row(methodCall, "group", "origin_jar", "origin_class", "origin_method",
                    "origin_source_file", "origin_line", "opcode", "bytecode_owner",
                    "called_method_name", "called_descriptor", "bytecode_called_method",
                    "definition_jar", "definition_class", "definition_method",
                    "definition_source_file", "definition_first_line", "dispatch",
                    "resolution_status", "candidates");
        }

        void writeClassDef(ClassDef d) {
            row(classDef, d.group, d.jarPath, d.className, classAccessString(d.access),
                    safe(d.superClassName), join(d.interfaces, ";"), safe(d.sourceFile));
            db.writeClassDef(d);
            stats.classDefRows++;
        }

        void writeMethodDef(ClassDef c, MethodDef m) {
            row(methodDef, c.group, c.jarPath, c.className, m.name, m.descriptor,
                    readableMethod(c.className, m.access, m.name, m.descriptor, m.parameterNames),
                    methodAccessString(m.access), safe(c.sourceFile),
                    number(m.firstLine), number(m.lastLine));
            db.writeMethodDef(c, m);
            stats.methodDefRows++;
        }

        void writeClassRef(String group, String originJar, String originClass,
                           String originMethod, String originSource, int line,
                           String kind, String targetClass, ClassResolution r) {
            row(classRef, group, originJar, originClass, originMethod, safe(originSource),
                    number(line), kind, targetClass, r.targetJar, r.status, r.candidates);
            db.writeClassRef(group, originJar, originClass, originMethod, originSource,
                    line, kind, targetClass, r);
            stats.classRefRows++;
        }

        void writeMethodCall(String group, String originJar, String originClass,
                             String originMethod, String originSource, int line,
                             String opcode, String bytecodeOwner, String calledName,
                             String calledDescriptor, String bytecodeReadable,
                             MethodResolution r, String dispatch) {
            row(methodCall, group, originJar, originClass, originMethod, safe(originSource),
                    number(line), opcode, bytecodeOwner, calledName, calledDescriptor,
                    bytecodeReadable, r.definitionJar, r.definitionClass,
                    r.definitionMethod, r.definitionSource, number(r.definitionFirstLine),
                    dispatch, r.status, r.candidates);
            db.writeMethodCall(group, originJar, originClass, originMethod, originSource,
                    line, opcode, bytecodeOwner, calledName, calledDescriptor,
                    bytecodeReadable, r, dispatch);
            stats.methodCallRows++;
        }

        void writeClassCall(ClassCallEdge edge) {
            db.writeClassCall(edge);
            stats.classCallRows++;
        }

        void commitGroup() {
            db.flushAndCommit();
        }

        @Override
        public void close() throws IOException {
            IOException first = null;
            try { classDef.close(); } catch (IOException e) { first = e; }
            try { methodDef.close(); } catch (IOException e) { if (first == null) first = e; else first.addSuppressed(e); }
            try { classRef.close(); } catch (IOException e) { if (first == null) first = e; else first.addSuppressed(e); }
            try { methodCall.close(); } catch (IOException e) { if (first == null) first = e; else first.addSuppressed(e); }
            if (first != null) {
                throw first;
            }
        }
    }

    private static BufferedWriter newCsvWriter(Path path) throws IOException {
        // Large sequential output is common. A larger buffer substantially reduces write calls
        // while remaining tiny relative to a 2 GB heap.
        return new BufferedWriter(
                new OutputStreamWriter(Files.newOutputStream(path), StandardCharsets.UTF_8),
                256 * 1024);
    }

    private static void row(BufferedWriter w, String... values) {
        try {
            for (int i = 0; i < values.length; i++) {
                if (i > 0) {
                    w.write(',');
                }
                w.write(csv(values[i]));
            }
            w.newLine();
        } catch (IOException e) {
            throw new OutputWriteException("CSV write failed", e);
        }
    }

    private static String csv(String s) {
        s = safe(s);
        if (s.indexOf(',') < 0 && s.indexOf('"') < 0
                && s.indexOf('\n') < 0 && s.indexOf('\r') < 0) {
            return s;
        }
        return '"' + s.replace("\"", "\"\"") + '"';
    }

    private static final class OutputWriteException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        OutputWriteException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    // ---------------------------------------------------------------------
    // Type/signature helpers
    // ---------------------------------------------------------------------

    private interface TypeConsumer {
        void accept(String className);
    }

    private static void collectDescriptor(String descriptor, TypeConsumer consumer) {
        if (descriptor == null || descriptor.length() == 0) {
            return;
        }
        try {
            if (descriptor.charAt(0) == '(') {
                Type mt = Type.getMethodType(descriptor);
                Type[] args = mt.getArgumentTypes();
                for (Type arg : args) {
                    collectType(arg, consumer);
                }
                collectType(mt.getReturnType(), consumer);
            } else {
                collectType(Type.getType(descriptor), consumer);
            }
        } catch (RuntimeException ignored) {
            // Malformed descriptor: ignore this metadata item, continue the JAR.
        }
    }

    private static void collectType(Type type, TypeConsumer consumer) {
        if (type == null) {
            return;
        }
        switch (type.getSort()) {
            case Type.OBJECT:
                consumer.accept(type.getClassName());
                break;
            case Type.ARRAY:
                collectType(type.getElementType(), consumer);
                break;
            case Type.METHOD:
                Type[] args = type.getArgumentTypes();
                for (Type arg : args) {
                    collectType(arg, consumer);
                }
                collectType(type.getReturnType(), consumer);
                break;
            default:
                break;
        }
    }

    private static void collectClassOrMethodSignature(String signature, TypeConsumer consumer) {
        if (signature == null || signature.length() == 0) {
            return;
        }
        try {
            new SignatureReader(signature).accept(new CollectingSignatureVisitor(consumer));
        } catch (RuntimeException ignored) {
            // Continue other metadata.
        }
    }

    private static void collectTypeSignature(String signature, TypeConsumer consumer) {
        if (signature == null || signature.length() == 0) {
            return;
        }
        try {
            new SignatureReader(signature).acceptType(new CollectingSignatureVisitor(consumer));
        } catch (RuntimeException ignored) {
            // Continue other metadata.
        }
    }

    private static final class CollectingSignatureVisitor extends SignatureVisitor {
        private final TypeConsumer consumer;
        private String currentClassInternal;

        CollectingSignatureVisitor(TypeConsumer consumer) {
            super(ASM_API);
            this.consumer = consumer;
        }

        @Override
        public void visitClassType(String name) {
            currentClassInternal = name;
            consumer.accept(internalToClass(name));
        }

        @Override
        public void visitInnerClassType(String name) {
            if (currentClassInternal != null) {
                currentClassInternal = currentClassInternal + "$" + name;
                consumer.accept(internalToClass(currentClassInternal));
            }
        }

        @Override
        public void visitEnd() {
            currentClassInternal = null;
        }
    }

    private static void collectConstant(Object value, TypeConsumer consumer) {
        if (value instanceof Type) {
            collectType((Type) value, consumer);
        } else if (value instanceof Handle) {
            Handle h = (Handle) value;
            consumer.accept(internalToClass(h.getOwner()));
            collectDescriptor(h.getDesc(), consumer);
        } else if (value instanceof ConstantDynamic) {
            ConstantDynamic cd = (ConstantDynamic) value;
            collectDescriptor(cd.getDescriptor(), consumer);
            Handle bsm = cd.getBootstrapMethod();
            if (bsm != null) {
                consumer.accept(internalToClass(bsm.getOwner()));
                collectDescriptor(bsm.getDesc(), consumer);
            }
            for (int i = 0; i < cd.getBootstrapMethodArgumentCount(); i++) {
                collectConstant(cd.getBootstrapMethodArgument(i), consumer);
            }
        }
    }

    // ---------------------------------------------------------------------
    // JAR/class input safety
    // ---------------------------------------------------------------------

    /** Fast JAR-entry gate used before class bytes are read. */
    private static boolean isTargetClassEntry(JarEntry entry) {
        return isClassEntry(entry)
                && entry.getName().startsWith(TARGET_INTERNAL_PREFIX);
    }

    private static boolean isTargetInternalClassName(String internalName) {
        return internalName != null && internalName.startsWith(TARGET_INTERNAL_PREFIX);
    }

    private static boolean isTargetClassName(String className) {
        return className != null && className.startsWith(TARGET_PACKAGE_PREFIX);
    }

    private static boolean isClassEntry(JarEntry entry) {
        if (entry == null || entry.isDirectory()) {
            return false;
        }
        String name = entry.getName();
        if (!name.endsWith(".class")) {
            return false;
        }
        // Java 8 does not use multi-release entries. Skipping them also avoids duplicate indexing.
        return !name.startsWith("META-INF/versions/");
    }

    private static ClassReader readClassReader(JarFile jar, JarEntry entry,
                                               JarInfo info, Stats stats) {
        long declared = entry.getSize();
        if (declared > MAX_CLASS_BYTES || declared > Integer.MAX_VALUE) {
            stats.skippedClassEntries++;
            System.err.println("WARN CLASS_TOO_LARGE " + info.relativePath + "!"
                    + entry.getName() + " size=" + declared);
            return null;
        }

        InputStream in = null;
        try {
            in = jar.getInputStream(entry);

            if (declared >= 0) {
                // JAR entries normally know their uncompressed size. Allocate exactly once;
                // this avoids ByteArrayOutputStream growth and its final full-array copy.
                byte[] bytes = new byte[(int) declared];
                int offset = 0;
                while (offset < bytes.length) {
                    int n = in.read(bytes, offset, bytes.length - offset);
                    if (n < 0) {
                        stats.skippedClassEntries++;
                        System.err.println("WARN TRUNCATED_CLASS " + info.relativePath + "!"
                                + entry.getName() + " expected=" + declared + " actual=" + offset);
                        return null;
                    }
                    if (n == 0) {
                        int one = in.read();
                        if (one < 0) {
                            stats.skippedClassEntries++;
                            System.err.println("WARN TRUNCATED_CLASS " + info.relativePath + "!"
                                    + entry.getName() + " expected=" + declared + " actual=" + offset);
                            return null;
                        }
                        bytes[offset++] = (byte) one;
                    } else {
                        offset += n;
                    }
                }

                if (in.read() != -1) {
                    stats.skippedClassEntries++;
                    System.err.println("WARN CLASS_SIZE_MISMATCH " + info.relativePath + "!"
                            + entry.getName() + " declared=" + declared + " actual>declared");
                    return null;
                }
                return new ClassReader(bytes);
            }

            // Unknown entry size is uncommon. Use a bounded dynamically-grown buffer.
            byte[] buffer = new byte[8192];
            int capacity = Math.min(8192, MAX_CLASS_BYTES);
            byte[] bytes = new byte[capacity];
            int total = 0;
            int n;
            while ((n = in.read(buffer)) >= 0) {
                if (n == 0) {
                    continue;
                }
                if (total > MAX_CLASS_BYTES - n) {
                    stats.skippedClassEntries++;
                    System.err.println("WARN CLASS_TOO_LARGE " + info.relativePath + "!"
                            + entry.getName() + " uncompressed>" + MAX_CLASS_BYTES);
                    return null;
                }
                int required = total + n;
                if (required > bytes.length) {
                    int next = bytes.length;
                    while (next < required) {
                        int doubled = next << 1;
                        if (doubled <= 0 || doubled > MAX_CLASS_BYTES) {
                            next = MAX_CLASS_BYTES;
                            break;
                        }
                        next = doubled;
                    }
                    bytes = Arrays.copyOf(bytes, next);
                }
                System.arraycopy(buffer, 0, bytes, total, n);
                total += n;
            }
            if (total != bytes.length) {
                bytes = Arrays.copyOf(bytes, total);
            }
            return new ClassReader(bytes);
        } catch (IOException e) {
            stats.skippedClassEntries++;
            warn("READ_CLASS", info, entry, e);
            return null;
        } catch (RuntimeException e) {
            stats.skippedClassEntries++;
            warn("READ_CLASS", info, entry, e);
            return null;
        } finally {
            closeQuietly(in);
        }
    }

    // ---------------------------------------------------------------------
    // Model
    // ---------------------------------------------------------------------

    private static final class GroupWork {
        final String group;
        final List<JarInfo> jars;

        GroupWork(String group, List<JarInfo> jars) {
            this.group = group;
            this.jars = jars;
        }
    }

    private static final class JarInfo implements Comparable<JarInfo> {
        final Path path;
        final String relativePath;
        final String group;

        JarInfo(Path scanRoot, Path path) {
            this.path = path.toAbsolutePath().normalize();
            this.relativePath = relative(scanRoot, this.path);
            this.group = determineGroup(scanRoot, this.path);
        }

        @Override
        public int compareTo(JarInfo other) {
            int c = group.compareTo(other.group);
            return c != 0 ? c : relativePath.compareTo(other.relativePath);
        }
    }

    private static final class ClassDef {
        String group = "";
        String jarPath = "";
        String className = "";
        String superClassName = "";
        String sourceFile = "";
        int access;
        final List<String> interfaces = new ArrayList<String>();
        final Map<MethodKey, MethodDef> methods = new HashMap<MethodKey, MethodDef>();
    }

    private static final class MethodDef {
        String name = "";
        String descriptor = "";
        int access;
        int firstLine = -1;
        int lastLine = -1;
        String[] parameterNames;
    }

    private static final class MethodKey {
        final String name;
        final String descriptor;

        MethodKey(String name, String descriptor) {
            this.name = name;
            this.descriptor = descriptor;
        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof MethodKey)) {
                return false;
            }
            MethodKey other = (MethodKey) o;
            return name.equals(other.name) && descriptor.equals(other.descriptor);
        }

        @Override
        public int hashCode() {
            return 31 * name.hashCode() + descriptor.hashCode();
        }
    }

    private static final class ClassResolution {
        String targetJar = "";
        String status = NOT_FOUND_IN_GROUP;
        String candidates = "";

        static ClassResolution resolved(String jar) {
            ClassResolution r = new ClassResolution();
            r.targetJar = jar;
            r.status = RESOLVED;
            return r;
        }

        static ClassResolution ambiguous(List<String> candidates) {
            ClassResolution r = new ClassResolution();
            r.status = AMBIGUOUS;
            r.candidates = join(candidates, ";");
            return r;
        }

        static ClassResolution notFound(String status) {
            ClassResolution r = new ClassResolution();
            r.status = status;
            return r;
        }
    }

    private static final class MethodResolution {
        String definitionJar = "";
        String definitionClass = "";
        String definitionMethod = "";
        String definitionSource = "";
        int definitionFirstLine = -1;
        String status = NOT_FOUND_IN_GROUP;
        String candidates = "";

        static MethodResolution resolved(ClassDef c, MethodDef m) {
            MethodResolution r = new MethodResolution();
            r.definitionJar = c.jarPath;
            r.definitionClass = c.className;
            r.definitionMethod = readableMethod(c.className, m.access, m.name,
                    m.descriptor, m.parameterNames);
            r.definitionSource = safe(c.sourceFile);
            r.definitionFirstLine = m.firstLine;
            r.status = RESOLVED;
            return r;
        }

        static MethodResolution ambiguous(String status, List<String> candidates) {
            MethodResolution r = new MethodResolution();
            r.status = status;
            r.candidates = join(candidates, ";");
            return r;
        }

        static MethodResolution notFound(String status) {
            MethodResolution r = new MethodResolution();
            r.status = status;
            return r;
        }
    }

    private static final class Stats {
        long classDefRows;
        long methodDefRows;
        long classRefRows;
        long methodCallRows;
        long classCallRows;
        long flowStarts;
        long skippedClassEntries;
    }

    // ---------------------------------------------------------------------
    // Formatting / ASM opcode helpers
    // ---------------------------------------------------------------------

    private static Type[] safeArgumentTypes(String descriptor) {
        try {
            return Type.getArgumentTypes(descriptor);
        } catch (RuntimeException e) {
            return new Type[0];
        }
    }

    private static int[] argumentSlots(int access, Type[] args) {
        int[] slots = new int[args.length];
        int slot = (access & Opcodes.ACC_STATIC) != 0 ? 0 : 1;
        for (int i = 0; i < args.length; i++) {
            slots[i] = slot;
            slot += args[i].getSize();
        }
        return slots;
    }

    private static String readableMethod(String ownerClass, int access, String name,
                                         String descriptor, String[] parameterNames) {
        Type mt;
        try {
            mt = Type.getMethodType(descriptor);
        } catch (RuntimeException e) {
            return name + descriptor;
        }

        StringBuilder sb = new StringBuilder();
        String modifiers = methodAccessString(access);
        if (modifiers.length() > 0) {
            sb.append(modifiers).append(' ');
        }

        if ("<init>".equals(name)) {
            sb.append(simpleName(ownerClass));
        } else if ("<clinit>".equals(name)) {
            sb.append("<clinit>");
        } else {
            sb.append(mt.getReturnType().getClassName()).append(' ').append(name);
        }

        sb.append('(');
        Type[] args = mt.getArgumentTypes();
        for (int i = 0; i < args.length; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(args[i].getClassName());
            if (parameterNames != null && i < parameterNames.length
                    && parameterNames[i] != null && parameterNames[i].length() > 0) {
                sb.append(' ').append(parameterNames[i]);
            }
        }
        sb.append(')');
        return sb.toString();
    }

    /**
     * Class and method access flags must be formatted separately.
     * Several JVM access bits intentionally have different meanings by context
     * (for example ACC_SUPER == ACC_SYNCHRONIZED).
     */
    private static String classAccessString(int access) {
        List<String> x = new ArrayList<String>();
        if ((access & Opcodes.ACC_PUBLIC) != 0) x.add("public");
        if ((access & Opcodes.ACC_PROTECTED) != 0) x.add("protected");
        if ((access & Opcodes.ACC_PRIVATE) != 0) x.add("private");
        if ((access & Opcodes.ACC_FINAL) != 0) x.add("final");
        if ((access & ACC_SUPER_FLAG) != 0) x.add("super");
        if ((access & Opcodes.ACC_INTERFACE) != 0) x.add("interface");
        if ((access & Opcodes.ACC_ABSTRACT) != 0) x.add("abstract");
        if ((access & ACC_SYNTHETIC_FLAG) != 0) x.add("synthetic");
        if ((access & ACC_ANNOTATION_FLAG) != 0) x.add("annotation");
        if ((access & ACC_ENUM_FLAG) != 0) x.add("enum");
        return join(x, " ");
    }

    private static String methodAccessString(int access) {
        List<String> x = new ArrayList<String>();
        if ((access & Opcodes.ACC_PUBLIC) != 0) x.add("public");
        if ((access & Opcodes.ACC_PROTECTED) != 0) x.add("protected");
        if ((access & Opcodes.ACC_PRIVATE) != 0) x.add("private");
        if ((access & Opcodes.ACC_ABSTRACT) != 0) x.add("abstract");
        if ((access & Opcodes.ACC_STATIC) != 0) x.add("static");
        if ((access & Opcodes.ACC_FINAL) != 0) x.add("final");
        if ((access & Opcodes.ACC_SYNCHRONIZED) != 0) x.add("synchronized");
        if ((access & ACC_BRIDGE_FLAG) != 0) x.add("bridge");
        if ((access & ACC_VARARGS_FLAG) != 0) x.add("varargs");
        if ((access & Opcodes.ACC_NATIVE) != 0) x.add("native");
        if ((access & Opcodes.ACC_STRICT) != 0) x.add("strictfp");
        if ((access & ACC_SYNTHETIC_FLAG) != 0) x.add("synthetic");
        return join(x, " ");
    }

    private static String fieldOpcodeName(int opcode) {
        switch (opcode) {
            case Opcodes.GETSTATIC: return "GETSTATIC";
            case Opcodes.PUTSTATIC: return "PUTSTATIC";
            case Opcodes.GETFIELD: return "GETFIELD";
            case Opcodes.PUTFIELD: return "PUTFIELD";
            default: return "FIELD_INSN_" + opcode;
        }
    }

    private static String methodOpcodeName(int opcode) {
        switch (opcode) {
            case Opcodes.INVOKEVIRTUAL: return "INVOKEVIRTUAL";
            case Opcodes.INVOKESTATIC: return "INVOKESTATIC";
            case Opcodes.INVOKESPECIAL: return "INVOKESPECIAL";
            case Opcodes.INVOKEINTERFACE: return "INVOKEINTERFACE";
            default: return "METHOD_INSN_" + opcode;
        }
    }

    private static String dispatchKind(int opcode) {
        if (opcode == Opcodes.INVOKEVIRTUAL || opcode == Opcodes.INVOKEINTERFACE) {
            return "DYNAMIC_DISPATCH_POSSIBLE";
        }
        return "STATICALLY_RESOLVED";
    }

    private static boolean isMethodHandleTag(int tag) {
        return tag == Opcodes.H_INVOKEVIRTUAL
                || tag == Opcodes.H_INVOKESTATIC
                || tag == Opcodes.H_INVOKESPECIAL
                || tag == Opcodes.H_NEWINVOKESPECIAL
                || tag == Opcodes.H_INVOKEINTERFACE;
    }

    private static String handleTagName(int tag) {
        switch (tag) {
            case Opcodes.H_INVOKEVIRTUAL: return "HANDLE_INVOKEVIRTUAL";
            case Opcodes.H_INVOKESTATIC: return "HANDLE_INVOKESTATIC";
            case Opcodes.H_INVOKESPECIAL: return "HANDLE_INVOKESPECIAL";
            case Opcodes.H_NEWINVOKESPECIAL: return "HANDLE_NEWINVOKESPECIAL";
            case Opcodes.H_INVOKEINTERFACE: return "HANDLE_INVOKEINTERFACE";
            default: return "HANDLE_" + tag;
        }
    }

    private static boolean isJava8ObjectPublicInstanceMethod(
            String name, String descriptor) {
        if ("getClass".equals(name) && "()Ljava/lang/Class;".equals(descriptor)) return true;
        if ("hashCode".equals(name) && "()I".equals(descriptor)) return true;
        if ("equals".equals(name) && "(Ljava/lang/Object;)Z".equals(descriptor)) return true;
        if ("toString".equals(name) && "()Ljava/lang/String;".equals(descriptor)) return true;
        if ("notify".equals(name) && "()V".equals(descriptor)) return true;
        if ("notifyAll".equals(name) && "()V".equals(descriptor)) return true;
        if ("wait".equals(name)) {
            return "()V".equals(descriptor)
                    || "(J)V".equals(descriptor)
                    || "(JI)V".equals(descriptor);
        }
        return false;
    }

    private static boolean isJdkClass(String className) {
        if (className == null) {
            return false;
        }
        for (String prefix : JDK_PREFIXES) {
            if (className.startsWith(prefix)) {
                return true;
            }
        }
        return false;
    }

    private static String internalToClass(String internal) {
        return internal == null ? "" : internal.replace('/', '.');
    }

    private static String simpleName(String className) {
        if (className == null) {
            return "";
        }
        int dot = className.lastIndexOf('.');
        String s = dot >= 0 ? className.substring(dot + 1) : className;
        int dollar = s.lastIndexOf('$');
        return dollar >= 0 ? s.substring(dollar + 1) : s;
    }

    private static String normalize(String s) {
        return s == null ? "" : s.replace('\\', '/');
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }

    private static String number(int n) {
        return n < 0 ? "" : Integer.toString(n);
    }

    private static String join(List<String> values, String separator) {
        if (values == null || values.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (String value : values) {
            if (value == null || value.length() == 0) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(separator);
            }
            sb.append(value);
        }
        return sb.toString();
    }

    private static void warn(String kind, JarInfo jar, JarEntry entry, Throwable t) {
        String where = jar == null ? "" : jar.relativePath;
        if (entry != null) {
            where += "!" + entry.getName();
        }
        System.err.println("WARN " + kind + " " + where + " : "
                + t.getClass().getName() + ": " + safe(t.getMessage()));
    }

    private static void closeQuietly(Object obj) {
        if (obj == null) {
            return;
        }
        try {
            if (obj instanceof AutoCloseable) {
                ((AutoCloseable) obj).close();
            }
        } catch (Exception ignored) {
            // no-op
        }
    }
}
