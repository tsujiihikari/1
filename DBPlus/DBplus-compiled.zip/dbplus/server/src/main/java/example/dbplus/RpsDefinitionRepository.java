package example.dbplus;

import java.sql.*;
import java.util.*;

/** 接続プロファイルのDBTYPE・VERSION＋正式スキーマ・テーブルで候補を一意解決する。 */
final class RpsDefinitionRepository {
    Map<String,Object> fetch(Connection c,Profiles.Profile p,String schema,String table,Deadline d) throws SQLException {
        String id=null,logical="";
        String match="SELECT ID,NAME2 FROM RPS_TABLE_LIST WHERE DBTYPE=? AND SCHEMA=? AND VERSION=? AND NAME=?";
        try(PreparedStatement s=c.prepareStatement(match)){d.apply(s);s.setString(1,p.rpsDbType);s.setString(2,schema);s.setString(3,p.rpsVersion);s.setString(4,table);s.setMaxRows(2);
            try(ResultSet r=s.executeQuery()){if(!r.next())return Api.failure("unavailable","RPS_NOT_FOUND","対応するRPS定義が見つかりません。");id=r.getString(1);logical=r.getString(2);if(r.next())return Api.failure("unavailable","RPS_AMBIGUOUS","定義候補を一意に特定できません。");}}
        String sql="SELECT NO,NAME,PKKEY,PART,KATA,COLUMN_SIZE,NULL_CONST,NAME2,DESCRIPTION,REFERENCE,DEFAULT_VALUE,CHECK_CONST FROM RPS_TABLE_DATA WHERE TABLE_LIST_ID=? ORDER BY NO";
        List<List<String>> rows=new ArrayList<>();
        try(PreparedStatement s=c.prepareStatement(sql)){d.apply(s);s.setString(1,id);s.setMaxRows(2001);try(ResultSet r=s.executeQuery()){while(r.next()){d.check();if(rows.size()==2000)throw new SQLException("RPS項目上限超過");List<String> row=new ArrayList<>();for(int i=1;i<=12;i++)row.add(r.getString(i));rows.add(row);}}}
        Map<String,Object> result=HtmlRenderer.table(HtmlRenderer.DEFINITION,rows,"tableDefinitionTable","RPS_TABLE_DATAに項目がありません。");result.put("source","rps");result.put("definitionVersion",p.rpsVersion);result.put("logicalName",logical==null?"":logical);return result;
    }
}
