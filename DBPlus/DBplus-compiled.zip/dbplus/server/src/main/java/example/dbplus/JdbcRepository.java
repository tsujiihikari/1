package example.dbplus;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;

/** 許可プロファイル＋カタログの正式名を検証してから、引用済み識別子をSQLへ組み立てる。 */
final class JdbcRepository {
    static final int MAX_ROWS=3000, MAX_TABLES=4000, PREVIEW=2048;
    private static final int HTML_BUDGET=8*1024*1024; // JSON全体の最終上限はServletで16MiB。
    private static String pattern(DatabaseMetaData meta,String exact) throws SQLException {
        String e=meta.getSearchStringEscape(); if(e==null||e.isEmpty())return exact;
        return exact.replace(e,e+e).replace("%",e+"%").replace("_",e+"_");
    }
    void verifyProduct(Connection c,Profiles.Profile p) throws SQLException {
        String product=c.getMetaData().getDatabaseProductName().toLowerCase(Locale.ROOT);
        if(("postgresql".equals(p.dialect)&&!product.contains("postgresql"))||("oracle11g".equals(p.dialect)&&!product.contains("oracle"))) throw new SQLException("設定とDB製品が不一致");
    }
    Map<String,Object> tables(Connection c,Profiles.Profile p,String schema,Deadline deadline) throws SQLException {
        DatabaseMetaData m=c.getMetaData(); SortedSet<String> names=new TreeSet<>(); boolean more=false;
        // JDBCメタデータの戻り順序を仮定せず、辞書順の先頭4000＋判定1件を保持する。
        try(ResultSet r=m.getTables(c.getCatalog(),pattern(m,schema),"%",new String[]{"TABLE"})) {
            while(r.next()){deadline.check();if(!schema.equals(r.getString("TABLE_SCHEM")))continue;String name=r.getString("TABLE_NAME");if(!p.allowsTable(name))continue;names.add(name);if(names.size()>MAX_TABLES+1){names.remove(names.last());more=true;}}
        }
        more|=names.size()>MAX_TABLES;List<Map<String,Object>> rows=new ArrayList<>();
        for(String name:names){if(rows.size()==MAX_TABLES)break;rows.add(Api.map("tableName",name,"schemaName",schema,"logicalName","","objectType","TABLE"));}
        return Api.map("connectionId",p.id,"schemaName",schema,"fetchedAt",Api.now(),"maxTables",MAX_TABLES,"returnedTables",rows.size(),"hasMore",more,"items",rows);
    }
    void validateTable(Connection c,Profiles.Profile p,String schema,String table,Deadline deadline) throws SQLException,Api.Problem {
        if(!p.allowsTable(table))throw new Api.Problem(403,"TABLE_ACCESS_DENIED","このテーブルは許可されていません。");
        DatabaseMetaData m=c.getMetaData();try(ResultSet r=m.getTables(c.getCatalog(),pattern(m,schema),pattern(m,table),new String[]{"TABLE"})) {
            while(r.next()){deadline.check();if(schema.equals(r.getString("TABLE_SCHEM"))&&table.equals(r.getString("TABLE_NAME")))return;}
        }
        throw new Api.Problem(404,"TABLE_NOT_FOUND","参照可能な対象テーブルが見つかりません。");
    }
    private String quote(Connection c,String name) throws SQLException {String q=c.getMetaData().getIdentifierQuoteString().trim();if(q.isEmpty())throw new SQLException("識別子引用未対応");return q+name.replace(q,q+q)+q;}
    List<Column> columns(Connection c,String schema,String table,Deadline deadline) throws SQLException {
        DatabaseMetaData m=c.getMetaData(); List<Column> out=new ArrayList<>();
        try(ResultSet r=m.getColumns(c.getCatalog(),pattern(m,schema),pattern(m,table),"%")){
            while(r.next()){deadline.check();if(!schema.equals(r.getString("TABLE_SCHEM"))||!table.equals(r.getString("TABLE_NAME")))continue;
                out.add(new Column(r.getString("COLUMN_NAME"),r.getString("TYPE_NAME"),r.getInt("ORDINAL_POSITION"),r.getInt("COLUMN_SIZE"),r.getInt("NULLABLE"),r.getString("COLUMN_DEF"),r.getString("REMARKS")));
                if(out.size()>2000)throw new SQLException("列上限超過");
            }
        }
        out.sort(Comparator.comparingInt(x->x.position));if(out.isEmpty())throw new SQLException("列情報がありません");return out;
    }
    private SortedMap<Integer,String> primaryKeys(Connection c,String schema,String table,Deadline d) throws SQLException {
        SortedMap<Integer,String> keys=new TreeMap<>();try(ResultSet r=c.getMetaData().getPrimaryKeys(c.getCatalog(),schema,table)){while(r.next()){d.check();keys.put(r.getInt("KEY_SEQ"),r.getString("COLUMN_NAME"));}}return keys;
    }
    Map<String,Object> data(Connection c,Profiles.Profile p,String schema,String table,Deadline d) throws Exception {
        List<Column> columns=columns(c,schema,table,d); SortedMap<Integer,String> pk=primaryKeys(c,schema,table,d);
        Set<String> allowed=new HashSet<>();for(Column x:columns)allowed.add(x.name); if(!allowed.containsAll(pk.values()))throw new SQLException("キー列不一致");
        List<String> select=new ArrayList<>(),order=new ArrayList<>();List<Map<String,Object>> meta=new ArrayList<>(),orderBy=new ArrayList<>();
        for(Column x:columns){select.add(quote(c,x.name));meta.add(Api.map("name",x.name,"jdbcTypeName",x.type,"widthPx",Math.min(400,Math.max(120,x.name.length()*10+60))));}
        for(String key:pk.values()){order.add(quote(c,key));orderBy.add(Api.map("columnName",key,"direction","ASC"));}
        String sort=order.isEmpty()?"":" ORDER BY "+String.join(", ",order);
        String base="SELECT "+String.join(", ",select)+" FROM "+quote(c,schema)+"."+quote(c,table)+sort;
        String sql="postgresql".equals(p.dialect)?base+" LIMIT ?":"SELECT * FROM ("+base+") WHERE ROWNUM <= ?";
        // Oracle外側にもキー順を明示し、上限選択後の表示順を固定する。
        if("oracle11g".equals(p.dialect))sql+=sort;
        List<String> rows=new ArrayList<>();boolean more=false;int truncated=0,bytes=0;
        try(PreparedStatement s=c.prepareStatement(sql)){d.apply(s);s.setInt(1,MAX_ROWS+1);s.setMaxRows(MAX_ROWS+1);s.setFetchSize(200);
            try(ResultSet r=s.executeQuery()){
                while(r.next()){d.check();if(rows.size()==MAX_ROWS){more=true;break;}List<HtmlRenderer.Preview> values=new ArrayList<>();
                    for(int i=1;i<=columns.size();i++){d.check();HtmlRenderer.Preview v=value(r,i);values.add(v);if(v.truncated)truncated++;}
                    String row=HtmlRenderer.row(rows.size(),values);bytes+=row.getBytes(StandardCharsets.UTF_8).length;
                    if(bytes>HTML_BUDGET)return Api.failure("error","RESULT_TOO_LARGE","データ結果が表示用サイズ上限を超えました。");rows.add(row);
                }
            }
        }
        return Api.map("status",rows.isEmpty()?"empty":"ready","maxRows",MAX_ROWS,"returnedRows",rows.size(),"hasMore",more,"totalRowCount",null,"columnCount",meta.size(),"columns",meta,"orderGuaranteed",!pk.isEmpty(),"orderBy",orderBy,"previewMaxChars",PREVIEW,"previewTruncatedCells",truncated,"theadHtml",HtmlRenderer.header(meta),"rowsHtml",rows,"warnings",pk.isEmpty()?Arrays.asList("主キーがないため取得順序は未保証です。"):Collections.emptyList());
    }
    private HtmlRenderer.Preview value(ResultSet r,int i) throws SQLException,IOException {
        int type=r.getMetaData().getColumnType(i);
        switch(type){
            case Types.CHAR:case Types.VARCHAR:case Types.LONGVARCHAR:case Types.NCHAR:case Types.NVARCHAR:case Types.LONGNVARCHAR:case Types.CLOB:case Types.NCLOB:
                try(Reader reader=r.getCharacterStream(i)){return HtmlRenderer.preview(reader,PREVIEW);}
            case Types.BINARY:case Types.VARBINARY:case Types.LONGVARBINARY:case Types.BLOB:
                // NULLだけを確認し、バイナリ本体の全読込・base64転送をしない。
                try(InputStream in=r.getBinaryStream(i)){return new HtmlRenderer.Preview(in==null?null:"[バイナリ: "+r.getMetaData().getColumnTypeName(i)+" / 本体取得省略]",false);}
            case Types.ARRAY:case Types.STRUCT:case Types.JAVA_OBJECT:case Types.OTHER:case Types.SQLXML:
                return new HtmlRenderer.Preview("[特殊型: "+r.getMetaData().getColumnTypeName(i)+" / 値表示未対応]",false);
            default:
                // 数値の精度や日時のオフセットを保つためドライバ文字列表現を維持する。
                String v=r.getString(i);return HtmlRenderer.preview(v==null?null:new StringReader(v),PREVIEW);
        }
    }
    Map<String,Object> definition(Connection c,String schema,String table,Deadline d) throws SQLException {
        List<Column> cols=columns(c,schema,table,d);SortedMap<Integer,String> pk=primaryKeys(c,schema,table,d);List<List<String>> rows=new ArrayList<>();
        for(Column x:cols)rows.add(Arrays.asList(String.valueOf(x.position),x.name,pk.containsValue(x.name)?"PK":"","",x.type,String.valueOf(x.size),x.nullable==DatabaseMetaData.columnNoNulls?"NOT NULL":x.nullable==DatabaseMetaData.columnNullable?"":"不明","",x.remarks,"",x.defaultValue,""));
        Map<String,Object> result=HtmlRenderer.table(HtmlRenderer.DEFINITION,rows,"tableDefinitionTable","定義項目がありません。");result.put("source","catalog");result.put("definitionVersion","");result.put("warnings",Arrays.asList("DBカタログ由来。日本語名称・Par・外部参照・CHECK制約等の業務定義は取得できません。"));return result;
    }
    Map<String,Object> indexes(Connection c,String schema,String table,Deadline d) throws SQLException {
        List<Index> indexes=new ArrayList<>();try(ResultSet r=c.getMetaData().getIndexInfo(c.getCatalog(),schema,table,false,true)){
            while(r.next()){d.check();short type=r.getShort("TYPE");if(type==DatabaseMetaData.tableIndexStatistic)continue;
                String owner=schema;String col=r.getString("COLUMN_NAME");String asc=r.getString("ASC_OR_DESC");
                indexes.add(new Index(owner==null?schema:owner,r.getString("INDEX_NAME"),r.getInt("ORDINAL_POSITION"),col==null?"式（JDBC情報では取得不可）":col,"A".equals(asc)?"ASC":"D".equals(asc)?"DESC":"不明",r.getBoolean("NON_UNIQUE")?"無":"有",type==DatabaseMetaData.tableIndexClustered?"CLUSTERED":type==DatabaseMetaData.tableIndexHashed?"HASHED":"その他",r.getString("FILTER_CONDITION")));
                if(indexes.size()>10000)throw new SQLException("インデックス定義上限超過");
            }
        }
        indexes.sort(Comparator.comparing((Index x)->x.owner).thenComparing(x->x.name==null?"":x.name).thenComparingInt(x->x.position));List<List<String>> rows=new ArrayList<>();int no=0;
        for(Index x:indexes)rows.add(Arrays.asList(String.valueOf(++no),x.owner,x.name,x.unique,x.type,String.valueOf(x.position),x.column,x.direction,"",x.filter));
        Map<String,Object> result=HtmlRenderer.table(HtmlRenderer.INDEXES,rows,"tableIndexTable","このテーブルの参照可能なインデックスはありません。");result.put("warnings",Arrays.asList("JDBCメタデータ由来。式・対応制約・有効状態等のDB固有情報は完全取得ではありません。"));return result;
    }
    Map<String,Object> synonyms(Connection c,Profiles.Profile p,String schema,String table,Deadline d) throws SQLException {
        if(!"oracle11g".equals(p.dialect))return Api.failure("unsupported","SYNONYM_UNSUPPORTED","この接続先ではOracle型のシノニムに対応していません。");
        String sql="SELECT OWNER,SYNONYM_NAME,TABLE_OWNER,TABLE_NAME,DB_LINK FROM ALL_SYNONYMS WHERE TABLE_OWNER=? AND TABLE_NAME=? AND DB_LINK IS NULL ORDER BY OWNER,SYNONYM_NAME";
        List<List<String>> rows=new ArrayList<>();try(PreparedStatement s=c.prepareStatement(sql)){d.apply(s);s.setString(1,schema);s.setString(2,table);s.setMaxRows(10001);try(ResultSet r=s.executeQuery()){while(r.next()){d.check();if(rows.size()==10000)throw new SQLException("シノニム定義上限超過");String owner=r.getString(1);rows.add(Arrays.asList(String.valueOf(rows.size()+1),owner,r.getString(2),r.getString(3),r.getString(4),r.getString(5),"PUBLIC".equals(owner)?"PUBLIC":"PRIVATE","直接・ローカル参照"));}}}
        Map<String,Object> result=HtmlRenderer.table(HtmlRenderer.SYNONYMS,rows,"tableSynonymTable","直接参照するシノニムはありません。");result.put("warnings",Arrays.asList("ALL_SYNONYMSで参照可能な範囲。連鎖・DBリンク付きの遠隔参照は対象外です。"));return result;
    }
    private static final class Column {final String name,type,defaultValue,remarks;final int position,size,nullable;Column(String name,String type,int position,int size,int nullable,String def,String remarks){this.name=name;this.type=type;this.position=position;this.size=size;this.nullable=nullable;this.defaultValue=def;this.remarks=remarks;}}
    private static final class Index {final String owner,name,column,direction,unique,type,filter;final int position;Index(String o,String n,int p,String c,String d,String u,String t,String f){owner=o;name=n;position=p;column=c;direction=d;unique=u;type=t;filter=f;}}
}
