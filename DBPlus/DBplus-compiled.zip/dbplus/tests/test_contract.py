"""サーバ生成HTML、上限、0件、部分失敗を外部契約として検証する。"""
import importlib.util
import json
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('demo',Path(__file__).resolve().parents[1]/'scripts/demo_server.py')
demo=importlib.util.module_from_spec(spec);spec.loader.exec_module(demo)

class ContractTest(unittest.TestCase):
    def ref(self,name): return dict(connectionId='demo',schemaName='SCHEMA_A',tableName=name)
    def test_maximum_and_last_row(self):
        d=demo.detail(self.ref('KYF1940'));p=d['data']
        self.assertEqual(len(p['rowsHtml']),3000)
        self.assertTrue(p['hasMore'])
        self.assertIn('data-row-index="2999"',p['rowsHtml'][-1])
        self.assertLess(len(json.dumps(d).encode('utf8')),16*1024*1024)
    def test_escape_null_precision_and_definition_columns(self):
        d=demo.detail(self.ref('KYF1940'))
        self.assertIn('&lt;img',d['data']['rowsHtml'][0]);self.assertNotIn('<img',d['data']['rowsHtml'][0])
        self.assertIn('12345678901234567890.123456789',d['data']['rowsHtml'][0])
        self.assertIn('dbp-null',d['data']['rowsHtml'][11]);self.assertNotIn('dbp-null',d['data']['rowsHtml'][1])
        self.assertEqual(d['definition']['html'].count('<th scope='),12)
        self.assertEqual(d['indexes']['html'].count('<th scope='),10)
        self.assertEqual(d['synonyms']['html'].count('<th scope='),8)
    def test_empty_preserves_columns(self):
        d=demo.detail(self.ref('EMPTY_TABLE'))
        self.assertEqual(d['data']['status'],'empty');self.assertEqual(d['data']['rowsHtml'],[])
        self.assertEqual(d['data']['columnCount'],5);self.assertIn('<th',d['data']['theadHtml'])
    def test_partial_failure_preserves_other_panels(self):
        d=demo.detail(self.ref('PARTIAL_ERROR'))
        self.assertTrue(d['partial']);self.assertEqual(d['definition']['status'],'error');self.assertEqual(d['data']['status'],'ready')
    def test_long_text_preview(self):
        d=demo.detail(self.ref('LONG_TEXT'))
        self.assertEqual(d['data']['previewTruncatedCells'],1);self.assertIn('data-truncated="true"',d['data']['rowsHtml'][0])
    def test_list_probe(self): self.assertEqual(len(demo.table_names()),4001)

if __name__=='__main__': unittest.main()
