import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.text.html.parser.ParserDelegator;

/** RPS定義とOracle辞書を取得し、カレントディレクトリに結果HTMLを出力する。Java 8以降。 */
public class Main {
    enum Kind {
        TABLE("table", "テーブル", "テーブル名", new String[]{"DB識別名", "テーブル名", "Ver", "Par", "日本語名称", "最大想定件数", "最終更新日", "担当者", "個人情報", "DDL", "統計情報", "情報", "状況"}),
        INDEX("index", "インデックス", "インデックス名", new String[]{"DB識別名", "インデックス名", "Ver", "テーブル名", "Type", "Par", "日本語名称", "最終更新日", "担当者", "DDL", "情報"}),
        VIEW("view", "ビュー", "ビュー名", new String[]{"DB識別名", "ビュー名", "Ver", "エイリアス", "With Option", "日本語名称", "最終更新日", "担当者", "DDL"}),
        SYNONYM("synonym", "シノニム", "シノニム名", new String[]{"DB識別名", "シノニム名", "Ver", "設定元スキーマ", "設定元オブジェクト", "タイプ", "設定元状況", "DBリンク", "パブリック区分", "権限設定先", "S", "U", "I", "D", "A", "E", "最終更新日", "担当者", "日本語名称", "DDL"});
        final String path, title, nameLabel; final String[] headers;
        Kind(String p, String t, String n, String[] h) { path=p; title=t; nameLabel=n; headers=h; }
        int name2Index() { return this==TABLE?4:this==INDEX?6:this==VIEW?5:18; }
        int dataColumns() { return this==TABLE?9:this==INDEX?9:this==VIEW?8:19; }
    }
    /** DBTYPEはRPSのDB識別名。Oracleの接続先は別途jdbc.urlで対応付ける。 */
    static class Config {
        final Properties p = new Properties();
        String schema, dbtype, mode; long deadline;
        Config(Path path) throws Exception {
            // 既存の設定を変えずに利用するため、UTF-8/Windows-31Jの両方を読む。
            if (Files.exists(path)) try (Reader r=new StringReader(readLocal(path,"auto"))) { p.load(r); }
            schema=get("schema", "KYKOWNER"); dbtype=get("dbtype", "KYKDB"); mode=get("mode", "live");
            if (!Arrays.asList("live", "offline").contains(mode)) throw new Exception("modeはliveまたはofflineです。");
            if (schema.isEmpty() || dbtype.isEmpty()) throw new Exception("schemaとdbtypeは必須です。");
            deadline=System.nanoTime()+number("total.timeout.seconds",540)*1000000000L;
        }
        String get(String k,String d) { return p.getProperty(k,d).trim(); }
        int number(String k,int d) { int n=Integer.parseInt(get(k,""+d)); if(n<=0)throw new IllegalArgumentException(k+"は正数です。");return n; }
        boolean yes(String k) { return Boolean.parseBoolean(get(k,"false")); }
        String secret(String k, String env) { String v=System.getenv(env);return v==null?p.getProperty(k,""):v; }
        String required(String k) throws Exception {String v=get(k,"");if(v.isEmpty())throw new Exception(k+"を設定してください。");return v;}
        int remainingMillis() throws IOException {long n=(deadline-System.nanoTime())/1000000L;if(n<=0)throw new IOException("全体実行時間の上限に達しました。");return (int)Math.min(n,Integer.MAX_VALUE);}
    }
    static class Row {
        final List<String> cells=new ArrayList<>(); final Map<String,String> db=new LinkedHashMap<>();
        String name="",owner="",dbtype=""; boolean rps, oracle;
    }
    static class Part {
        final List<Row> rows=new ArrayList<>(); String rpsState="未取得",dbState="未取得";
    }
    /** 自前の診断だけを結果HTMLに出す。認証URLやCookieを例外表示しない。 */
    static class RpsException extends IOException {
        RpsException(String message) { super(message); }
    }
    public static class Report {
        final EnumMap<Kind,Part> parts=new EnumMap<>(Kind.class);
        final List<String> messages=new ArrayList<>(); boolean failed;
        Report(){for(Kind k:Kind.values())parts.put(k,new Part());}
    }
    public static void main(String[] args) {
        if(args.length>0 && "--self-test".equals(args[0])) {try{selfTest();}catch(Exception e){throw new RuntimeException(e);}return;}
        try {
            Path configPath=args.length>0?Paths.get(args[0]):Paths.get("config.properties");
            if(args.length==0&&!Files.exists(configPath))configPath=Paths.get("OK_config.properties");
            if(!Files.isRegularFile(configPath))throw new IOException("設定ファイルなし");
            Config c=new Config(configPath);
            Report r=collect(c);
            Path out=Paths.get(c.get("output.html","result.html")).toAbsolutePath();
            writeHtml(out,c,r);
            System.out.println("HTML出力: "+out);
            for(Kind k:Kind.values())System.out.println(k.title+": "+r.parts.get(k).rows.size()+"件 / RPS="+r.parts.get(k).rpsState+" / Oracle="+r.parts.get(k).dbState);
            if(r.failed)System.exit(2);
        } catch(Exception e) {System.err.println("実行できません。設定・入力ファイル・出力先を確認してください。例外種別: "+e.getClass().getSimpleName());System.exit(1);}
    }
    /** 将来Servletから呼び出す場合も取得処理とHTML生成を分離して利用可能。 */
    static Report collect(Config c) throws Exception {
        Report r=new Report();
        if("offline".equals(c.mode)) {
            String bundle=readLocal(Paths.get(c.get("offline.bundle","RPSサイトのHTML一覧.txt")),c.get("offline.charset","auto"));
            String[] docs=bundle.split("(?i)(?=<!DOCTYPE\\s+html)");
            for(Kind k:Kind.values()) {
                Part p=r.parts.get(k); boolean found=false;
                for(String d:docs) if(Pattern.compile("(?is)<form\\b[^>]*action\\s*=\\s*[\"']/"+k.path+"/list[\"']").matcher(d).find()) {
                    p.rows.addAll(parse(d,k,c));found=true;
                }
                p.rpsState=found?"添付HTML（保存ページ分のみ）":"添付HTMLなし";
                p.dbState="未接続（オフライン）";
                if(!found){r.failed=true;r.messages.add(k.title+"の保存HTMLがありません。");}
            }
            r.messages.add("オフライン確認：添付HTMLに含まれるページだけを表示しています。全件取得およびOracleとの照合は未実施です。");
        } else {
            try {
                Http h=new Http(c); h.loginAndSetSchema();
                for(Kind k:Kind.values()) {
                    Part p=r.parts.get(k);
                    try {fetch(h,k,c,p);}
                    catch(Exception e){p.rpsState="取得失敗・途中まで";r.failed=true;r.messages.add(k.title+"：RPS取得失敗（"+failure(e)+"）。");}
                }
            } catch(Exception e) {
                r.failed=true;r.messages.add("RPSの認証／スキーマ設定に失敗（"+failure(e)+"）。接続設定を確認してください。");
                for(Part p:r.parts.values())p.rpsState="認証／スキーマ設定失敗";
            }
            try {
                c.remainingMillis();Class.forName("oracle.jdbc.OracleDriver");
                Properties props=new Properties();props.setProperty("user",c.required("jdbc.user"));
                props.setProperty("password",c.secret("jdbc.password","DBPLUS_JDBC_PASSWORD"));
                props.setProperty("oracle.net.CONNECT_TIMEOUT",""+Math.min(c.number("http.connect.timeout.ms",15000),c.remainingMillis()));
                props.setProperty("oracle.jdbc.ReadTimeout",""+Math.min(c.number("jdbc.read.timeout.ms",30000),c.remainingMillis()));
                try(Connection conn=DriverManager.getConnection(c.required("jdbc.url"),props)) {
                    // この接続ではSELECT以外を発行しない。
                    for(Kind k:Kind.values()) {
                        Part p=r.parts.get(k);
                        try {List<Row> db=readOracle(conn,k,c);merge(p,db,k,c);p.dbState="辞書取得完了";}
                        catch(Exception e){p.dbState="取得失敗";r.failed=true;r.messages.add(k.title+"：Oracle辞書取得失敗（"+category(e)+"）。参照権限を確認してください。");}
                    }
                }
            } catch(Exception e) {r.failed=true;r.messages.add("Oracle接続失敗（"+category(e)+"）。JAR・接続先・認証情報を確認してください。");for(Part p:r.parts.values())if("未取得".equals(p.dbState))p.dbState="接続失敗";}
            r.messages.add("OracleのALL_*辞書は接続ユーザーから参照できる範囲です。完全な一覧には対象所有者での接続、または許可されたDBA_*辞書の利用が必要です。");
        }
        for(Part p:r.parts.values()) Collections.sort(p.rows,Comparator.comparing((Row x)->x.name).thenComparing(x->x.owner).thenComparing(x->cell(x,2)));
        return r;
    }
    static String category(Exception e){return e instanceof SQLException?"SQLエラー "+((SQLException)e).getErrorCode():e.getClass().getSimpleName();}
    static String failure(Exception e) {
        if(e instanceof RpsException)return e.getMessage();
        if(e instanceof SocketTimeoutException)return "接続または読取タイムアウト";
        if(e instanceof ConnectException)return "接続できません。接続先・ポート・ネットワークを確認してください";
        if(e instanceof UnknownHostException)return "接続先の名前を解決できません";
        return category(e);
    }

    // ---------- RPSへのHTTP接続：Cookieはインスタンス内だけで保持する ----------
    static class Http {
        final Config c; final URI base; final CookieManager cookies=new CookieManager(null,CookiePolicy.ACCEPT_ALL);
        Http(Config c) throws Exception {this.c=c;base=new URI(c.get("rps.base.url","http://10.202.168.238:19001"));if(base.getHost()==null || base.getUserInfo()!=null || base.getQuery()!=null)throw new IOException("RPS URL不正");}
        boolean same(URI u){return Objects.equals(base.getScheme(),u.getScheme())&&Objects.equals(base.getHost(),u.getHost())&&base.getPort()==u.getPort();}
        URI resolve(String u) throws Exception {URI v=base.resolve(u);if(!same(v))throw new IOException("異なる接続先への遷移はできません。");return v;}
        String request(String target,String body) throws Exception {
            URI u=resolve(target);String method=body==null?"GET":"POST";
            for(int hop=0;hop<10;hop++) {
                c.remainingMillis();
                Proxy proxy=Proxy.NO_PROXY;
                if(c.yes("proxy.enabled"))proxy=new Proxy(Proxy.Type.HTTP,new InetSocketAddress(c.required("proxy.host"),c.number("proxy.port",8080)));
                HttpURLConnection con=(HttpURLConnection)u.toURL().openConnection(proxy);
                try {
                    con.setConnectTimeout(Math.min(c.number("http.connect.timeout.ms",15000),c.remainingMillis()));
                    con.setReadTimeout(Math.min(c.number("http.read.timeout.ms",30000),c.remainingMillis()));
                    con.setInstanceFollowRedirects(false);con.setRequestMethod(method);
                    con.setRequestProperty("User-Agent","Mozilla/5.0");con.setRequestProperty("Accept","text/html");
                    for(Map.Entry<String,List<String>> e:cookies.get(u,Collections.<String,List<String>>emptyMap()).entrySet())con.setRequestProperty(e.getKey(),String.join("; ",e.getValue()));
                    if("POST".equals(method)) {con.setDoOutput(true);con.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");byte[] b=body.getBytes(StandardCharsets.UTF_8);con.setFixedLengthStreamingMode(b.length);try(OutputStream o=con.getOutputStream()){o.write(b);}}
                    int status=con.getResponseCode();cookies.put(u,con.getHeaderFields());
                    if(status==301||status==302||status==303||status==307||status==308) {
                        String loc=con.getHeaderField("Location");if(loc==null)throw new IOException("Locationなし");
                        URI next=u.resolve(loc);if(!same(next))throw new IOException("接続先の異なるリダイレクト");
                        u=next;if(status==303||((status==301||status==302)&&"POST".equals(method))){method="GET";body=null;}continue;
                    }
                    if(status!=200)throw new RpsException("HTTP "+status+"（"+u.getPath()+"）");
                    byte[] b;try(InputStream in=con.getInputStream()){b=readBytes(in,c);}
                    String override=c.get("rps.charset","auto");
                    if(!"auto".equalsIgnoreCase(override))return new String(b,Charset.forName(override));
                    Matcher m=Pattern.compile("(?i)charset\\s*=\\s*['\"]?([a-zA-Z0-9_-]+)").matcher(nvl(con.getContentType()));
                    if(m.find())try {
                        return Charset.forName(m.group(1)).newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                            .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString();
                    } catch(IllegalArgumentException | CharacterCodingException ignored) { /* 宣言と実バイトが異なる場合は再判別 */ }
                    return decode(b,"auto");
                } finally {con.disconnect();}
            }
            throw new IOException("リダイレクト上限");
        }
        void loginAndSetSchema() throws Exception {
            String html;
            if(c.yes("rps.login.enabled")) {
                // 添付サンプルのGETログイン方式。秘密情報をログ・結果HTMLへ出力しない。
                String path=c.get("rps.login.path","/login/login");
                String q="domain="+enc(c.required("rps.domain"))+"&shain_cd="+enc(c.required("rps.user"))+"&pass="+enc(c.secret("rps.password","DBPLUS_RPS_PASSWORD"));
                html=request(path+(path.contains("?")?"&":"?")+q,null);
            } else html=request("/table/list?pm=ent",null);
            String token=token(html);if(token.isEmpty())throw new RpsException("ログイン応答にCSRFトークンがありません");
            String result=request("/schema/set_schema","schema="+enc(c.schema)+"&utf8="+enc("\u2713")+"&authenticity_token="+enc(token));
            // POST応答または一覧画面で、実際に選択された所有者を検証する。
            if(!schemaValue(result).equals(c.schema))result=request("/table/list?pm=ent",null);
            if(!schemaValue(result).equals(c.schema))throw new RpsException("スキーマ設定後の画面に指定スキーマがありません");
        }
    }
    static void fetch(Http h,Kind k,Config c,Part p) throws Exception {
        // 実画面の「全件表示」と同じパラメータ。未定義のtype=ALLは送らない。
        String next=listUrl(k,1,true);
        Set<String> seenUrls=new HashSet<>(),seenRows=new HashSet<>(),seenRawRows=new HashSet<>();int page=0;
        boolean pagedFallback=false;String allFailure="";
        int expected=-1,readCount=0;
        while(!next.isEmpty()) {
            c.remainingMillis();if(++page>c.number("rps.max.pages",1000)||!seenUrls.add(h.resolve(next).toString()))throw new RpsException("ページが循環したか、rps.max.pagesに達しました");
            String html;List<Row> rows;
            try {
                html=h.request(next,null);
                validateListSchema(html,c);
                // 件数はDBTYPEで絞る前の件数を検査する。
                rows=parse(html,k,c,false);
            } catch(Exception e) {
                // 全件表示が使えない場合は、提示された50件検索URLで再取得する。
                if(page!=1||pagedFallback)throw e;
                allFailure=failure(e);pagedFallback=true;page=0;
                next=listUrl(k,1,false);continue;
            }
            if(expected<0)expected=totalCount(html);
            int rawCount=rows.size(),rawBefore=seenRawRows.size();
            for(Row x:rows)seenRawRows.add(x.dbtype+"\u0000"+x.name+"\u0000"+String.join("\u0001",x.cells));
            readCount=seenRawRows.size();
            rows.removeIf(x->!c.dbtype.equals(x.dbtype));
            for(Row x:rows)if(seenRows.add(x.dbtype+"\u0000"+x.name+"\u0000"+cell(x,2)+"\u0000"+String.join("\u0001",x.cells)))p.rows.add(x);
            String current=next;next=nextLink(html,k,h);
            if(!next.isEmpty()&&rawCount==0)throw new RpsException("空の一覧に次ページがあるため取得を中止しました");
            if(page>1&&rawCount>0&&rawBefore==seenRawRows.size())throw new RpsException("取得済みと同じデータが返されました。ページ指定を確認してください");
            if(next.isEmpty()&&expected>readCount) {
                // rel=nextがなくても、全件数から未取得が分かれば明示的に次を要求する。
                if(rawCount==0)throw new RpsException("表示全件数に達する前に一覧が空になりました");
                Map<String,String> q=query(current);
                int currentPage=q.containsKey("page")?Integer.parseInt(q.get("page")):1;
                next=listUrl(k,currentPage+1,false);
            }
            System.out.println("RPS "+k.title+" page="+page+" 累計="+p.rows.size());
            if(!next.isEmpty()){c.remainingMillis();Thread.sleep(Math.min(c.number("rps.interval.ms",100),c.remainingMillis()));}
        }
        p.rpsState=pagedFallback?"全ページ取得完了（50件検索へ切替："+allFailure+"）":"全ページ取得完了（全件表示）";
    }
    static void validateListSchema(String html,Config c) throws IOException {
        if(!schemaValue(html).equals(c.schema))throw new RpsException("一覧画面のスキーマ不一致または認証切れ");
    }
    static String listUrl(Kind k,int page,boolean all) throws Exception {
        String q="/"+k.path+"/list?utf8="+enc("\u2713")+"&pm=ent&keyword_db=";
        if(k==Kind.SYNONYM)q+="&keyword_name=&keyword_obj_name=";
        else {
            q+="&keyword_object_name=";
            if(k==Kind.INDEX)q+="&keyword_table_name=";
            q+="&keyword_description=";
        }
        return q+"&keyword_group_name=&submit="+enc(all?"全件表示":"検索")+(all?"":"&page="+page);
    }
    static int totalCount(String html) {
        Matcher m=Pattern.compile("全\\s*([0-9,]+)\\s*件").matcher(clean(html));
        if(m.find())try{return Integer.parseInt(m.group(1).replace(",",""));}catch(NumberFormatException ignored){}
        return -1;
    }
    static String nextLink(String html,Kind k,Http h) throws Exception {
        Matcher a=Pattern.compile("(?is)<a\\b([^>]*)>").matcher(html);
        while(a.find()) {String at=a.group(1);if(Arrays.asList(attr(at,"rel").split("\\s+")).contains("next")||Arrays.asList(attr(at,"class").split("\\s+")).contains("next_page")) {
            String href=attr(at,"href");if(href.isEmpty())continue;URI u=h.resolve(href);
            if(!u.getPath().equals("/"+k.path+"/list"))throw new RpsException("次ページURLの種類が一致しません");return u.toString();}}
        // 旧画面のようにページ番号だけがリンクになっている場合にも対応する。
        Matcher current=Pattern.compile("(?is)<(?:em|span)\\b[^>]*class\\s*=\\s*['\"]current['\"][^>]*>\\s*(\\d+)\\s*</(?:em|span)>").matcher(html);
        if(current.find()) {
            int page=Integer.parseInt(current.group(1));a.reset();
            while(a.find()) {
                String href=attr(a.group(1),"href");if(href.isEmpty())continue;
                URI u=new URI(href);if(!("/"+k.path+"/list").equals(u.getPath()))continue;
                u=h.resolve(href);
                if(String.valueOf(page+1).equals(query(href).get("page")))return u.toString();
            }
        }
        return "";
    }
    static String token(String html){String value=input(html,"authenticity_token");if(!value.isEmpty())return value;Matcher m=Pattern.compile("(?is)<meta\\b([^>]*)>").matcher(html);while(m.find())if("csrf-token".equals(attr(m.group(1),"name")))return attr(m.group(1),"content");return "";}
    static String schemaValue(String html){return input(html,"schema");}
    static String input(String html,String name){Matcher m=Pattern.compile("(?is)<input\\b([^>]*)>").matcher(html);while(m.find())if(name.equals(attr(m.group(1),"name")))return attr(m.group(1),"value");return "";}
    static String attr(String attrs,String name) {
        Matcher m=Pattern.compile("(?is)(?:^|\\s)"+Pattern.quote(name)+"\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))").matcher(attrs);
        return m.find()?entities(m.group(1)!=null?m.group(1):m.group(2)!=null?m.group(2):m.group(3)):"";
    }
    // 保存HTMLにも実サイトにも同じパーサーを利用。ソース中のスクリプト等は出力しない。
    static List<Row> parse(String html,Kind k,Config c) throws Exception {
        return parse(html,k,c,true);
    }
    static List<Row> parse(String html,Kind k,Config c,boolean filterDbtype) throws Exception {
        // 外側のレイアウト表に依存せずstd_hover開始タグを直接探す。
        Matcher start=Pattern.compile("(?is)<table\\b[^>]*\\bclass\\s*=\\s*(?:\"[^\"]*\\bstd_hover\\b[^\"]*\"|'[^']*\\bstd_hover\\b[^']*'|std_hover)[^>]*>").matcher(html);
        if(!start.find())throw new RpsException(k.title+"の一覧表std_hoverが見つかりません。検索条件または認証を確認してください");
        int end=html.toLowerCase(Locale.ROOT).indexOf("</table",start.end());if(end<0)throw new RpsException("一覧表の終端がありません");
        String table=html.substring(start.end(),end);
        List<Row> out=new ArrayList<>();Matcher tr=Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr\\s*>").matcher(table);
        boolean header=false; int[] columnMap=null;
        while(tr.find()) {
            List<String> cells=new ArrayList<>();Matcher td=Pattern.compile("(?is)<t[dh]\\b[^>]*>(.*?)</t[dh]\\s*>").matcher(tr.group(1));
            while(td.find())cells.add(clean(td.group(1)));
            if(cells.contains(k.nameLabel)&&cells.contains("DB識別名")){
                header=true;
                if(k!=Kind.SYNONYM) {
                    columnMap=new int[k.headers.length];Arrays.fill(columnMap,-1);
                    for(int j=0;j<k.headers.length;j++)for(int z=0;z<cells.size();z++)
                        if(normalizeHeader(k.headers[j]).equals(normalizeHeader(cells.get(z)))){columnMap[j]=z;break;}
                    if(columnMap[0]<0||columnMap[1]<0||columnMap[2]<0||columnMap[k.name2Index()]<0)
                        throw new RpsException(k.title+"の必須列が見つかりません");
                }
                continue;
            }
            if(cells.size()<k.dataColumns())continue;
            if(columnMap!=null) {
                List<String> normalized=new ArrayList<>();
                for(int z:columnMap)normalized.add(z>=0&&z<cells.size()?cells.get(z):"");
                cells=normalized;
            }
            if(filterDbtype&&!cells.get(0).equals(c.dbtype))continue;
            Row r=new Row();r.cells.addAll(cells);r.dbtype=cells.get(0);r.name=cells.get(1);r.owner=k==Kind.SYNONYM&&"Y".equals(cell(r,8))?"PUBLIC":c.schema;r.rps=true;
            // 正常版と同じく、テーブル/索引の識別情報は詳細リンクのクエリを優先する。
            // 統計や参照先へのリンクには別スキーマがあり得るため、対象の詳細リンクだけを見る。
            Matcher a=Pattern.compile("(?is)<a\\b([^>]*)>").matcher(tr.group(1));
            while(a.find()) {
                String href=attr(a.group(1),"href");String detailPath=href.split("\\?",2)[0];
                if(!detailPath.endsWith("/column/show_"+k.path))continue;
                Map<String,String> q=query(href);
                if(q.containsKey("instance")&&!r.dbtype.equals(q.get("instance")))throw new RpsException("一覧のDB識別名と詳細リンクが一致しません");
                if(q.containsKey("schema")&&!c.schema.equals(q.get("schema")))throw new RpsException("一覧の詳細リンクが指定スキーマと一致しません");
                String key=k==Kind.TABLE?"table_name":k==Kind.INDEX?"index_name":"";
                if(!key.isEmpty()&&q.containsKey(key)) {r.name=q.get(key);r.cells.set(1,r.name);}
                if(q.containsKey("version"))r.cells.set(2,q.get("version"));
                if(q.containsKey("description"))r.cells.set(k.name2Index(),q.get("description"));
                break;
            }
            if(r.name.isEmpty())throw new RpsException("オブジェクト名が空です");out.add(r);
        }
        if(!header)throw new RpsException(k.title+"の一覧ヘッダーが想定と異なります");
        return out;
    }
    static String normalizeHeader(String h) {
        return h.replaceAll("\\s+", "").replace("テーブル名称","日本語名称")
            .replace("Partition","Par");
    }
    static Map<String,String> query(String url) throws Exception {
        Map<String,String> q=new HashMap<>();int i=url.indexOf('?');if(i<0)return q;
        for(String kv:url.substring(i+1).split("&")){String[] a=kv.split("=",2);q.put(URLDecoder.decode(a[0],"UTF-8"),a.length==2?URLDecoder.decode(a[1],"UTF-8"):"");}return q;
    }
    static String clean(String s){return entities(s.replaceAll("(?is)<script\\b.*?</script>","").replaceAll("(?is)<style\\b.*?</style>","").replaceAll("(?is)<[^>]*>"," ")).replace('\u00a0',' ').replaceAll("\\s+"," ").trim();}
    static String entities(String s) {
        // Swingの標準HTMLエンティティ辞書を初期化。追加JARは不要。
        Matcher m=Pattern.compile("&(#x[0-9a-fA-F]+|#\\d+|[a-zA-Z][a-zA-Z0-9]+);").matcher(s);StringBuffer b=new StringBuffer();
        while(m.find()){String n=m.group(1),v=m.group();try{if(n.startsWith("#")){int cp=Integer.parseInt(n.substring(n.startsWith("#x")?2:1),n.startsWith("#x")?16:10);v=new String(Character.toChars(cp));}else{javax.swing.text.html.parser.Entity e=javax.swing.text.html.parser.DTD.getDTD("html32").getEntity(n);if(e!=null)v=new String(e.getData());}}catch(Exception ignored){}m.appendReplacement(b,Matcher.quoteReplacement(v));}m.appendTail(b);return b.toString();
    }
    static {try{new ParserDelegator().parse(new StringReader(""),new HTMLEditorKit.ParserCallback(){},true);}catch(IOException e){throw new ExceptionInInitializerError(e);}}

    // ---------- Oracle辞書：所有者は必ずバインド変数で指定 ----------
    static List<Row> readOracle(Connection conn,Kind k,Config c) throws Exception {
        String prefix=c.get("dictionary.scope","ALL").toUpperCase(Locale.ROOT);
        if(!prefix.equals("ALL")&&!prefix.equals("DBA"))throw new Exception("辞書種別はALL/DBAです。");
        String sql;
        if(k==Kind.TABLE)sql="SELECT t.OWNER,t.TABLE_NAME NAME,tc.COMMENTS,t.TABLESPACE_NAME,t.NUM_ROWS,t.PARTITIONED,t.TEMPORARY,TO_CHAR(t.LAST_ANALYZED,'YYYY-MM-DD HH24:MI:SS') LAST_ANALYZED FROM "+prefix+"_TABLES t LEFT JOIN "+prefix+"_TAB_COMMENTS tc ON tc.OWNER=t.OWNER AND tc.TABLE_NAME=t.TABLE_NAME AND tc.TABLE_TYPE='TABLE' WHERE t.OWNER=? ORDER BY t.TABLE_NAME";
        else if(k==Kind.INDEX)sql="SELECT OWNER,INDEX_NAME NAME,TABLE_OWNER,TABLE_NAME,INDEX_TYPE,UNIQUENESS,PARTITIONED,STATUS,TABLESPACE_NAME FROM "+prefix+"_INDEXES WHERE OWNER=? ORDER BY INDEX_NAME";
        else if(k==Kind.VIEW)sql="SELECT v.OWNER,v.VIEW_NAME NAME,tc.COMMENTS,v.TEXT_LENGTH FROM "+prefix+"_VIEWS v LEFT JOIN "+prefix+"_TAB_COMMENTS tc ON tc.OWNER=v.OWNER AND tc.TABLE_NAME=v.VIEW_NAME AND tc.TABLE_TYPE='VIEW' WHERE v.OWNER=? ORDER BY v.VIEW_NAME";
        else sql="SELECT s.OWNER,s.SYNONYM_NAME NAME,s.TABLE_OWNER,s.TABLE_NAME,s.DB_LINK,tc.COMMENTS FROM "+prefix+"_SYNONYMS s LEFT JOIN "+prefix+"_TAB_COMMENTS tc ON tc.OWNER=s.TABLE_OWNER AND tc.TABLE_NAME=s.TABLE_NAME AND s.DB_LINK IS NULL WHERE "+(c.yes("synonym.include.public")?"(s.OWNER=? OR s.OWNER='PUBLIC')":"s.OWNER=?")+" ORDER BY s.OWNER,s.SYNONYM_NAME";
        List<Row> rows=new ArrayList<>();
        try(PreparedStatement st=prepare(conn,sql,c)) {st.setString(1,c.schema);try(ResultSet rs=st.executeQuery()) {ResultSetMetaData md=rs.getMetaData();while(rs.next()) {c.remainingMillis();Row r=new Row();r.name=rs.getString("NAME");r.owner=rs.getString("OWNER");r.dbtype=c.dbtype;r.oracle=true;for(int i=1;i<=md.getColumnCount();i++)r.db.put(md.getColumnLabel(i),nvl(rs.getString(i)));rows.add(r);}}}
        if(k==Kind.INDEX) {
            Map<String,Row> byName=new HashMap<>();for(Row r:rows)byName.put(r.name,r);
            String cols="SELECT INDEX_NAME,COLUMN_NAME,COLUMN_POSITION,DESCEND FROM "+prefix+"_IND_COLUMNS WHERE INDEX_OWNER=? ORDER BY INDEX_NAME,COLUMN_POSITION";
            try(PreparedStatement st=prepare(conn,cols,c)){st.setString(1,c.schema);try(ResultSet rs=st.executeQuery()){while(rs.next()){c.remainingMillis();Row r=byName.get(rs.getString(1));if(r!=null){String old=nvl(r.db.get("COLUMNS"));r.db.put("COLUMNS",old+(old.isEmpty()?"":", ")+rs.getString(2)+" "+rs.getString(4));}}}}
        }
        return rows;
    }
    static PreparedStatement prepare(Connection conn,String sql,Config c) throws Exception {PreparedStatement st=conn.prepareStatement(sql);try{st.setFetchSize(200);st.setQueryTimeout(Math.min(c.number("jdbc.query.timeout.seconds",60),Math.max(1,c.remainingMillis()/1000)));return st;}catch(Exception e){st.close();throw e;}}
    static void merge(Part p,List<Row> db,Kind k,Config c) {
        Map<String,Row> map=new LinkedHashMap<>();for(Row r:db)map.put(r.owner+"\u0000"+r.name,r);
        Set<String> used=new HashSet<>();for(Row r:p.rows){String key=r.owner+"\u0000"+r.name;Row d=map.get(key);if(d!=null){r.oracle=true;r.db.putAll(d.db);used.add(key);}}
        for(Map.Entry<String,Row> e:map.entrySet())if(!used.contains(e.getKey()))p.rows.add(e.getValue());
    }
    static byte[] readBytes(InputStream in,Config c) throws Exception {ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[16384];int n;while((n=in.read(buf))!=-1){c.remainingMillis();if(b.size()+n>64*1024*1024)throw new IOException("HTMLが64MiBを超えました。");b.write(buf,0,n);}return b.toByteArray();}
    static String readLocal(Path p,String charset) throws Exception {return decode(Files.readAllBytes(p),charset);}
    static String decode(byte[] bytes,String charset) throws Exception {
        if(!"auto".equalsIgnoreCase(charset))return new String(bytes,Charset.forName(charset));
        try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString().replaceFirst("^\\uFEFF","");}
        catch(CharacterCodingException e){return new String(bytes,Charset.forName("Windows-31J"));}
    }
    static String cell(Row r,int i){return i<r.cells.size()?r.cells.get(i):"";}
    static String nvl(String s){return s==null?"":s;}
    static String enc(String s) throws Exception{return URLEncoder.encode(s,"UTF-8");}
    static String esc(String s){return nvl(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
    // ---------- HTML：RPS風の赤いヘッダー・色別タブ・黄色い一覧見出し ----------
    static void writeHtml(Path path,Config c,Report report) throws Exception {
        try(BufferedWriter w=Files.newBufferedWriter(path,StandardCharsets.UTF_8)) {
            w.write("<!doctype html><html lang='ja'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>DB+ RPS・Oracle オブジェクト一覧</title><style>");
            w.write("*{box-sizing:border-box}body{margin:0;background:#fff;color:#222;font:13px Meiryo,'Yu Gothic',sans-serif}header{background:#900;color:white;padding:12px 22px;display:flex;gap:24px;align-items:center}header strong{font-size:22px}header span{opacity:.9}.layout{display:grid;grid-template-columns:172px minmax(0,1fr);min-height:90vh}aside{padding:20px 12px;background:#fafafa;border-right:1px solid #ccc}aside b{display:block;margin:8px 0}aside a{display:block;color:#2449a1;padding:7px 0}main{padding:18px 20px;min-width:0}h1{font-size:18px;margin:0 0 12px}h2{font-size:15px}.meta{color:#555;font-size:12px}.notice{background:#fff8de;border:1px solid #dec97d;padding:10px 14px;margin:12px 0;line-height:1.7}.notice p{margin:3px 0}nav{display:flex;gap:4px;margin-top:18px;flex-wrap:wrap}button,select,input{font:inherit}nav button{border:1px solid #aaa;border-bottom:4px solid var(--color);background:#eee;padding:8px 20px;cursor:pointer}nav button[aria-selected=true]{background:var(--color);color:white;border-color:var(--color)}section{border-top:5px solid var(--color);padding:10px 0 0}.toolbar{display:flex;align-items:center;gap:10px;padding:10px;background:#f7f7f7;border:1px solid #ddd;flex-wrap:wrap}.toolbar input{width:320px;max-width:100%;padding:5px}.summary{padding:10px 0;color:#555}.scroll{overflow:auto;max-height:65vh;border:1px solid #aaa}table{border-collapse:collapse;font-size:12px;width:100%}th,td{border:1px solid #bbb;padding:5px 8px;white-space:nowrap;text-align:left}th{background:#ffff99;position:sticky;top:0;z-index:1}tbody tr:nth-child(even){background:#f0f0f0}tbody tr:hover{background:#e5f0ff}td.name{color:#154b9b;font-weight:600}td.jp{min-width:190px;white-space:normal}td.status{background:#f4f7fa}.pages{display:flex;gap:12px;align-items:center;margin-top:10px}.pages button{padding:5px 12px}.empty{padding:20px;color:#777}footer{padding:16px;color:#666;border-top:1px solid #ddd;font-size:12px}a{color:#174eaa}[hidden]{display:none!important}@media(max-width:700px){.layout{grid-template-columns:1fr}aside{display:none}main{padding:12px}}@media print{aside,nav,.toolbar,.pages{display:none!important}.layout{display:block}section[hidden],tbody tr[hidden]{display:table-row!important}section[hidden]{display:block!important}.scroll{max-height:none;overflow:visible}header{color:#000;background:white}th{position:static}}");
            w.write("</style></head><body><header><strong>DB+ / 開発RPS</strong><span>RPS定義・Oracleディクショナリ一覧</span></header><div class='layout'><aside><b>取得対象</b>スキーマ<br>"+esc(c.schema)+"<br><br>DBTYPE<br>"+esc(c.dbtype)+"<br><br><b>エントリ定義</b>");
            for(Kind k:Kind.values())w.write("<a href='#"+k.path+"' data-tab='"+k.path+"'>・"+k.title+"</a>");
            w.write("<br><b>出力形式</b>単一HTML / UTF-8<br>外部ライブラリ不要</aside><main><h1>エントリー定義 "+esc(c.schema)+" / "+esc(c.dbtype)+"</h1><div class='meta'>取得日時："+new SimpleDateFormat("yyyy/MM/dd HH:mm:ss Z").format(new java.util.Date())+"　モード："+esc(c.mode)+"　辞書："+esc(c.get("dictionary.scope","ALL"))+"_*</div><div class='notice'>");
            if(report.failed)w.write("<p><b>一部の取得に失敗しています。以下の取得状況を確認してください。</b></p>");
            for(String s:report.messages)w.write("<p>"+esc(s)+"</p>");
            w.write("<p>日本語名称はRPSを優先し、空欄の場合はOracleのCOMMENTSを使用します。RPSとOracleの名称は別列でも確認できます。</p></div><nav role='tablist' aria-label='オブジェクト種類'>");
            for(Kind k:Kind.values())w.write("<button type='button' role='tab' id='tab-"+k.path+"' aria-controls='"+k.path+"' aria-selected='false' style='--color:"+color(k)+"' data-tab='"+k.path+"'>"+k.title+"（"+report.parts.get(k).rows.size()+"）</button>");
            w.write("</nav>");
            for(Kind k:Kind.values()) {
                Part p=report.parts.get(k);String[] dh=dbHeaders(k);
                w.write("<section id='"+k.path+"' role='tabpanel' aria-labelledby='tab-"+k.path+"' style='--color:"+color(k)+"'><h2>"+k.title+"一覧</h2><div class='meta'>RPS："+esc(p.rpsState)+"　／　Oracle："+esc(p.dbState)+"</div><div class='toolbar'><label>絞り込み <input type='search' placeholder='物理名・日本語名称・設定元など' aria-label='"+k.title+"の絞り込み'></label><label>表示件数 <select><option>50</option><option>100</option><option>500</option></select></label><button type='button' class='reset'>クリア</button></div><div class='summary' aria-live='polite'>全 "+p.rows.size()+" 件</div><div class='scroll'><table><thead><tr><th>取得元</th><th>所有者</th>");
                for(String s:k.headers)w.write("<th>"+esc(s.equals("日本語名称")?"日本語名称（表示用）":s)+"</th>");
                w.write("<th>RPS日本語名称</th>");for(String s:dh)w.write("<th>Oracle："+esc(s)+"</th>");w.write("</tr></thead><tbody>");
                for(Row r:p.rows) {
                    w.write("<tr><td class='status'>"+(r.rps&&r.oracle?"RPS + Oracle":r.rps?"RPS":"Oracle")+"</td><td>"+esc(r.owner)+"</td>");
                    for(int i=0;i<k.headers.length;i++) {
                        String v=r.rps?cell(r,i):dbCell(r,k,i);
                        if(i==k.name2Index()&&v.isEmpty())v=nvl(r.db.get("COMMENTS"));
                        w.write("<td"+(i==1?" class='name'":i==k.name2Index()?" class='jp'":"")+">");
                        if("DDL".equals(k.headers[i])&&r.rps) {
                            String url=c.get("rps.base.url","http://10.202.168.238:19001")+"/"+k.path+"/show_ddl?utf8="+enc("\u2713")+"&instance="+enc(r.dbtype)+"&version="+enc(cell(r,2))+"&object_name="+enc(r.name);
                            w.write("<a target='_blank' rel='noopener noreferrer' href='"+esc(url)+"'>参照</a>");
                        } else w.write(esc(v));w.write("</td>");
                    }
                    w.write("<td class='jp'>"+esc(cell(r,k.name2Index()))+"</td>");
                    for(String key:dbKeys(k))w.write("<td"+(key.equals("COMMENTS")?" class='jp'":"")+">"+esc(r.db.get(key))+"</td>");
                    w.write("</tr>");
                }
                w.write("</tbody></table></div><div class='empty'"+(p.rows.isEmpty()?"":" hidden")+">表示するデータはありません。取得状況も確認してください。</div><div class='pages'><button type='button' class='prev'>前へ</button><span class='pageinfo'></span><button type='button' class='next'>次へ</button></div></section>");
            }
            w.write("</main></div><footer>「取得元」は実際に取得できた情報源です。片方だけの行は、未接続・権限不足・保存ページ不足でも発生するため、定義漏れとは断定できません。DDL参照はRPSを開きます（RPSへのログインが必要です）。</footer><script>\n");
            w.write("'use strict';const sections=[...document.querySelectorAll('section')];function tab(id){if(!sections.some(s=>s.id===id))id='table';sections.forEach(s=>s.hidden=s.id!==id);document.querySelectorAll('nav button').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.tab===id)));}document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{tab(b.dataset.tab);location.hash=b.dataset.tab;}));window.addEventListener('hashchange',()=>tab(location.hash.slice(1)));sections.forEach(s=>{const rows=[...s.querySelectorAll('tbody tr')],text=rows.map(r=>r.textContent.toLocaleLowerCase()),q=s.querySelector('input'),size=s.querySelector('select');let page=0,filtered=rows;function render(){const n=Number(size.value),max=Math.max(1,Math.ceil(filtered.length/n));page=Math.max(0,Math.min(page,max-1));rows.forEach(r=>r.hidden=true);filtered.slice(page*n,(page+1)*n).forEach(r=>r.hidden=false);s.querySelector('.summary').textContent='該当 '+filtered.length+' 件 / 全 '+rows.length+' 件';s.querySelector('.pageinfo').textContent=(page+1)+' / '+max+' ページ';s.querySelector('.prev').disabled=page===0;s.querySelector('.next').disabled=page+1>=max;s.querySelector('.empty').hidden=filtered.length!==0;}q.addEventListener('input',()=>{const v=q.value.toLocaleLowerCase();filtered=rows.filter((r,i)=>text[i].includes(v));page=0;render();});size.addEventListener('change',()=>{page=0;render();});s.querySelector('.reset').onclick=()=>{q.value='';filtered=rows;page=0;render();};s.querySelector('.prev').onclick=()=>{page--;render();};s.querySelector('.next').onclick=()=>{page++;render();};render();});tab(location.hash.slice(1));\n");
            w.write("</script></body></html>");
        }
    }
    static String color(Kind k){return k==Kind.TABLE?"#339933":k==Kind.INDEX?"#a239a2":k==Kind.VIEW?"#369d9b":"#6a9933";}
    static String[] dbKeys(Kind k) {return k==Kind.TABLE?new String[]{"COMMENTS","TABLESPACE_NAME","NUM_ROWS","PARTITIONED","TEMPORARY","LAST_ANALYZED"}:k==Kind.INDEX?new String[]{"TABLE_OWNER","TABLE_NAME","INDEX_TYPE","UNIQUENESS","COLUMNS","PARTITIONED","STATUS","TABLESPACE_NAME"}:k==Kind.VIEW?new String[]{"COMMENTS","TEXT_LENGTH"}:new String[]{"TABLE_OWNER","TABLE_NAME","DB_LINK","COMMENTS"};}
    static String[] dbHeaders(Kind k){return k==Kind.TABLE?new String[]{"COMMENTS","表領域","統計上の件数","パーティション","一時表","最終統計取得日時"}:k==Kind.INDEX?new String[]{"テーブル所有者","テーブル名","索引種別","一意性","構成列（順序）","パーティション","状態","表領域"}:k==Kind.VIEW?new String[]{"COMMENTS","定義文字数"}:new String[]{"参照先所有者","参照先名","DBリンク","参照先COMMENTS"};}
    static String dbCell(Row r,Kind k,int i) {
        if(i==0)return r.dbtype;if(i==1)return r.name;if(i==k.name2Index())return nvl(r.db.get("COMMENTS"));
        if(k==Kind.INDEX){if(i==3)return nvl(r.db.get("TABLE_NAME"));if(i==4)return nvl(r.db.get("UNIQUENESS"));}
        if(k==Kind.SYNONYM){if(i==3)return nvl(r.db.get("TABLE_OWNER"));if(i==4)return nvl(r.db.get("TABLE_NAME"));if(i==7)return nvl(r.db.get("DB_LINK"));if(i==8)return r.owner.equals("PUBLIC")?"Y":"N";}
        return "";
    }
    // 外部接続なしで、重要な名前の取り扱い・照合・エスケープを検証する。
    static void selfTest() throws Exception {
        Config c=new Config(Paths.get("__missing_test_config__"));
        String html="<input value='KYKOWNER' name='schema'><table class='std_hover'><tr><td>DB識別名</td><td>テーブル名</td><td>Ver</td><td>Par</td><td>日本語名称</td><td>最大想定件数</td><td>最終更新日</td><td>担当者</td><td>個人情報</td></tr><tr><td>KYKDB</td><td>日本語&amp;表</td><td>1.0</td><td>なし</td><td>日本語&#x540D;</td><td>10</td><td>20261015</td><td>担当</td><td>なし</td></tr><tr><td>OTHER</td><td>別表</td><td>1</td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>";
        List<Row> parsed=parse(html,Kind.TABLE,c);check(parsed.size()==1,"DBTYPE完全一致");check(parsed.get(0).name.equals("日本語&表"),"日本語物理名");check(cell(parsed.get(0),4).equals("日本語名"),"エンティティ");
        Part p=new Part();p.rows.addAll(parsed);Row d=new Row();d.name="日本語&表";d.owner=c.schema;d.oracle=true;d.db.put("COMMENTS","DBコメント");Row extra=new Row();extra.name="DB_ONLY";extra.owner=c.schema;extra.oracle=true;merge(p,Arrays.asList(d,extra),Kind.TABLE,c);check(p.rows.size()==2&&p.rows.get(0).oracle,"辞書突合・和集合");
        check(esc("<script>\"&").equals("&lt;script&gt;&quot;&amp;"),"HTMLエスケープ");
        check(schemaValue(html).equals(c.schema),"属性順序");
        check(decode("日本語".getBytes("Windows-31J"),"auto").equals("日本語"),"CP932自動判別");
        boolean rejected=false;try{parse("<html>login</html>",Kind.TABLE,c);}catch(IOException e){rejected=true;}check(rejected,"ログイン画面の誤認防止");
        Http h=new Http(c);check(nextLink("<a href='/table/list?pm=ent&amp;page=2' rel='next'>次</a>",Kind.TABLE,h).endsWith("pm=ent&page=2"),"次ページ");
        System.out.println("SELF-TEST OK (8 checks)");
    }
    static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);}
}
