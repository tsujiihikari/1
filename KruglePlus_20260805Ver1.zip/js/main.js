"use strict";

// Servlet API接続先は、このタブの最初の1回だけ判定する。
// 1) 社内Tomcat  2) 予備Tomcat の順に /init を確認し、成功したURLをsessionStorageへ保存する。
const USE_SAMPLE_DATA = false;
const KRUGLE_CONTEXT_PATH = "/krugleapi";
const KRUGLE_API_PRIMARY_BASE = "http://10.205.7.19:8080/krugleapi/";
const KRUGLE_API_SECONDARY_BASE = "http://133.18.42.50:8080/krugleapi/";
const API_SESSION_STORAGE_KEY = "krugle.api.base.url";
const API_SESSION_VERSION_KEY = "krugle.api.base.version";
const API_SESSION_VERSION = "20260727_table_info_mock_v5";
const API_PROBE_TIMEOUT_PRIMARY_MS = 1000;
const API_PROBE_TIMEOUT_SECONDARY_MS = 1500;
const API_ACCESS_TIMEOUT_MS = 20000;
const TABLE_INFO_MOCK_ENDPOINT = "/table-info-mock";

// 2026-07-28 修正2: 検索結果タブの初期表示条件。
// ServletはKrugleへ接続できる場合は実検索し、接続できない場合は
// WEB-INF/classes/mock-search/KrugleSearchResult.csv の52件を返す。
const INITIAL_SEARCH_CONDITION = Object.freeze({
  keyword: "KYF1940",
  project: "NIKKO.nkCCIS",
  language: "Java",
  mode: "normal"
});

// 同一ブラウザタブ内で開いたサイト内タブを、一意IDでたどるためのSessionStorage履歴。
// 表示位置（何番目）には依存せず、ホーム・検索結果は固定ID、時刻タブは「日時＋完全パス」をIDにする。
const TAB_NAVIGATION_STORAGE_KEY = "krugle.session.tab.navigation.state";
const TAB_NAVIGATION_VERSION_KEY = "krugle.session.tab.navigation.version";
const TAB_NAVIGATION_VERSION = "20260722_backspace_unique_tab_v9";
const TAB_NAVIGATION_CURRENT_ID_KEY = "krugle.session.tab.navigation.currentId";
const TAB_NAVIGATION_LIMIT = 300;
let restoringTabNavigation = false;
let sourceOpenRequestSequence = 0;

let activeApiBase = readSessionStorage(API_SESSION_VERSION_KEY) === API_SESSION_VERSION
  ? normalizeApiBase(readSessionStorage(API_SESSION_STORAGE_KEY))
  : "";
let resolvedApiInitData = null;
let apiResolvePromise = null;

const FILE_HISTORY_STORAGE_KEY = "krugle.history.files";
const SEARCH_HISTORY_STORAGE_KEY = "krugle.history.words";
const FILE_HISTORY_INITIALIZED_VERSION_KEY = "krugle.history.files.initialized.version";
const FILE_HISTORY_INITIAL_VERSION = "20260722_full_path_v1";
const FILE_HISTORY_INITIAL_SEED_MARKER = "INITIAL_FILE_STORAGE_VALUES_20260708_home_history_seed_width_fix2";
const INITIAL_FILE_STORAGE_VALUES = [
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzNys_java.jar/jp/co/fnt/stp1/app/apptier/back/az/nys/model/KyakJkyKjnHjnSyutkTask.java,2026/07/01_12:30:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtt_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctt/model/KjoYmdSyutkTask.java,2026/07/01_12:20:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtt_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctt/model/KjoYmdUpdTask.java,2026/07/01_12:10:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjEdd_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/edd/model/KjEddHojnJohoTask.java,2026/07/01_12:00:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjEdd_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/edd/model/KjEddKabunusiYakuinTorkTask.java,2026/07/01_11:50:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzKzt_java.jar/jp/co/fnt/stp1/app/apptier/back/az/kzt/model/SaknRyuhoGKjo1K2KMainTask.java,2026/07/01_11:40:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjUhk_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/uhk/model/KjUhkDelTask.java,2026/07/01_11:30:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjUhk_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/uhk/model/KjUhkJohoSearchTask.java,2026/07/01_11:20:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtc_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctc/model/KysJohoKjnSyutkTask.java,2026/07/01_11:10:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzJky_java.jar/jp/co/fnt/stp1/app/apptier/back/az/jky/model/SaknRyuhoGKjoInqTask.java,2026/07/01_11:00:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzJky_java.jar/jp/co/fnt/stp1/app/apptier/back/az/jky/model/SaknRyuhoGKjoTask.java,2026/07/01_10:50:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYK5470_upd.sql,2026/07/01_12:30:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF9800_Ikan.sql,2026/07/01_12:20:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF6510_INS.sql,2026/07/01_12:10:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4410_spool.sql,2026/07/01_12:00:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF3030upd_From_CC.sql,2026/07/01_11:50:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISD0607_KYK5300_02_SPOOL.sql,2026/07/01_11:40:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF3030spool_To_CC.sql,2026/07/01_11:30:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4400_BZN_spool.sql,2026/07/01_11:20:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISALTD218.sql,2026/07/01_11:10:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4301_PL_SEL.sql,2026/07/01_11:00:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISALTD078.sql,2026/07/01_10:50:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/meigara/MeigaraIchiran.java,2026/07/01_12:30:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiApplication.java,2026/07/01_12:20:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiApplicationCommand.java,2026/07/01_12:10:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiBbApplication.java,2026/07/01_12:00:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiBbApplicationCommand.java,2026/07/01_11:50:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiPoApplication.java,2026/07/01_11:40:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_po/meigara/MeigaraIchiran.java,2026/07/01_11:30:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_po/sinkoku_jyokyo/KbSnkokMeisaiBbPOApplication.java,2026/07/01_11:20:00"
];
const sampleFiles = INITIAL_FILE_STORAGE_VALUES;
const RECENT_TAB_STORE_LIMIT = 100;
const RECENT_TAB_VISIBLE_LIMIT = 25;
const RECENT_TAB_MIN_COUNT = 0;
const FILE_HISTORY_HOME_DISPLAY_LIMIT = 300;
const FILE_HISTORY_MINI_DISPLAY_LIMIT = 20;
const INITIAL_HISTORY_SAMPLE_COUNT = 30;
const HISTORY_PLACEHOLDER_VALUE = "-";
const INITIAL_RESULT_PLACEHOLDER_COUNT = 30;
let recentWindowStart = 0;
// 2026-07-31 修正6: ヘッダー数字タブのactive/visitedは、Pathではなく画面上のタブIDで揮発的に管理する。
// SessionStorageには保存しないため、サイトを開き直すと初期状態に戻る。
let activeRecentTabKey = "";
const volatileVisitedRecentTabIds = new Set();
let manualRecentWindowShift = false;


function splitHistoryStorageValue(value) {
  if (value && typeof value === "object") {
    const path = String(value.path || value.fullPath || value.filePath || value.filePathName || value.file || value.name || "").trim();
    const openedAt = value.openedAt || value.time || value.updateTime || value.dateTime || value.timestamp || "";
    const fileName = value.fileName || value.file || value.name || "";
    const project = value.project || value.projectName || value.projectValue || value.fullProject || "";
    const group = value.group || value.migrationGroup || value.ikogroup || value.ikoGroup || value.projectGroup || "";
    const directoryGroup = value.directoryGroup || value.dirGroup || value.directory || value.dir || "";
    return {
      path,
      openedAtRaw: String(openedAt || "").trim(),
      fileName: String(fileName || "").trim(),
      project: String(project || "").trim(),
      group: String(group || "").trim(),
      directoryGroup: String(directoryGroup || "").trim(),
      initialSeed: value.__initialFileHistorySeed === true || value.initialSeed === true,
      seedMarker: String(value.__initialFileHistorySeedMarker || value.seedMarker || "").trim(),
      raw: value
    };
  }

  const text = String(value || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) {
    return { path: text, openedAtRaw: "", fileName: "", project: "", group: "", directoryGroup: "", initialSeed: false, seedMarker: "", raw: text };
  }

  const commaIndex = text.lastIndexOf(",");
  if (commaIndex > 0) {
    return {
      path: text.substring(0, commaIndex).trim(),
      openedAtRaw: text.substring(commaIndex + 1).trim(),
      fileName: "",
      project: "",
      group: "",
      directoryGroup: "",
      initialSeed: false,
      seedMarker: "",
      raw: text
    };
  }

  return { path: text, openedAtRaw: "", fileName: "", project: "", group: "", directoryGroup: "", initialSeed: false, seedMarker: "", raw: text };
}

function parseHistoryOpenedAt(value, fallbackDate) {
  const raw = String(value || "").trim();
  const fallback = fallbackDate ? toSafeDate(fallbackDate) : new Date();
  if (!raw) return fallback.toISOString();

  const normalized = raw
    .replace(/_/g, "T")
    .replace(/\//g, "-")
    .replace(/\s+/g, "T");
  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? fallback.toISOString() : date.toISOString();
}

function formatHistoryStorageDate(value) {
  const date = toSafeDate(value || new Date());
  const pad = number => String(number).padStart(2, "0");
  return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())}_${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function createHistoryStorageValue(path, openedAt, meta = {}) {
  const pathEntry = splitHistoryStorageValue(path);
  const project = normalizeProjectValue(meta.project || meta.projectName || meta.projectValue || pathEntry.project || "");
  const rawGroup = meta.group || meta.migrationGroup || meta.ikogroup || meta.ikoGroup || pathEntry.group || "";
  const group = normalizeMigrationGroupName(rawGroup);
  const fullPath = buildCompleteKruglePath(pathEntry.path, project, rawGroup);
  if (!fullPath || isPlaceholderHistoryValue(fullPath)) return fullPath;

  const result = {
    path: fullPath,
    openedAt: formatHistoryStorageDate(openedAt || new Date())
  };

  const fileName = String(meta.fileName || meta.file || meta.name || pathEntry.fileName || "").trim();
  const directoryGroup = cleanDirectoryGroupName(meta.directoryGroup || meta.dirGroup || meta.directory || pathEntry.directoryGroup || "");
  const initialSeed = meta.initialSeed === true || meta.__initialFileHistorySeed === true;
  const seedMarker = String(meta.seedMarker || meta.__initialFileHistorySeedMarker || (initialSeed ? FILE_HISTORY_INITIAL_SEED_MARKER : "")).trim();

  if (fileName) result.fileName = fileName;
  if (project) result.project = project;
  if (group) result.group = group;
  if (directoryGroup) result.directoryGroup = directoryGroup;
  if (initialSeed) {
    result.__initialFileHistorySeed = true;
    result.__initialFileHistorySeedMarker = seedMarker || FILE_HISTORY_INITIAL_SEED_MARKER;
  }
  return result;
}

function getHistoryEntryPath(value) {
  const entry = splitHistoryStorageValue(value);
  return buildCompleteKruglePath(entry.path, entry.project, entry.group);
}

function getHistoryEntryOpenedAt(value, fallbackDate) {
  const entry = splitHistoryStorageValue(value);
  return parseHistoryOpenedAt(entry.openedAtRaw, fallbackDate);
}

function buildRecentTabFromHistoryValue(value, fallbackDate) {
  const path = getHistoryEntryPath(value);
  if (!path || isPlaceholderHistoryValue(path)) return null;
  return {
    path,
    openedAt: getHistoryEntryOpenedAt(value, fallbackDate)
  };
}


function readStoredArray(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) ? value : [];
  } catch (e) {
    return [];
  }
}

function createInitialFileHistorySeedValues() {
  return normalizeFileHistoryValues((Array.isArray(INITIAL_FILE_STORAGE_VALUES) ? INITIAL_FILE_STORAGE_VALUES : [])
    .map((value, index) => {
      const entry = splitHistoryStorageValue(value);
      const path = entry.path;
      if (!isValidFileHistoryPath(path)) return null;
      const openedAt = parseHistoryOpenedAt(entry.openedAtRaw, new Date(Date.now() - index * 60 * 1000));
      return createHistoryStorageValue(path, openedAt, {
        fileName: entry.fileName,
        project: entry.project,
        group: entry.group,
        directoryGroup: entry.directoryGroup,
        initialSeed: true,
        seedMarker: FILE_HISTORY_INITIAL_SEED_MARKER
      });
    })
    .filter(Boolean));
}

function isCurrentInitialFileHistorySeed(value) {
  const entry = splitHistoryStorageValue(value);
  return entry.initialSeed === true && entry.seedMarker === FILE_HISTORY_INITIAL_SEED_MARKER;
}

function isAnyInitialFileHistorySeed(value) {
  const entry = splitHistoryStorageValue(value);
  return entry.initialSeed === true || Boolean(entry.seedMarker);
}

function createInitialFileHistoryCompareSet(seedValues) {
  return new Set((Array.isArray(seedValues) ? seedValues : [])
    .map(stringifyHistoryValueForCompare)
    .filter(Boolean));
}

function initializeFileHistoryStorageIfNeeded() {
  if (USE_SAMPLE_DATA) return;
  try {
    const seedValues = createInitialFileHistorySeedValues();
    const seedCompareSet = createInitialFileHistoryCompareSet(seedValues);
    const storedValues = readStoredArray(FILE_HISTORY_STORAGE_KEY);
    const hasCurrentSeed = storedValues.some(isCurrentInitialFileHistorySeed);

    // INITIAL_FILE_STORAGE_VALUES 由来の旧データだけを先にクリーンする。
    // ただし、現在のマーカー付き seed は残し、ユーザーが実際に開いた同一ファイルの別日時履歴は消さない。
    const cleanedValues = storedValues.filter(value => {
      if (isCurrentInitialFileHistorySeed(value)) return true;
      if (isAnyInitialFileHistorySeed(value)) return false;
      return !seedCompareSet.has(stringifyHistoryValueForCompare(value));
    });

    const nextValues = hasCurrentSeed
      ? normalizeFileHistoryValues(cleanedValues)
      : normalizeFileHistoryValues(seedValues.concat(cleanedValues));

    const before = storedValues.map(stringifyHistoryValueForCompare).join("\u0001");
    const after = nextValues.map(stringifyHistoryValueForCompare).join("\u0001");
    if (before !== after || !hasCurrentSeed) {
      saveArray(FILE_HISTORY_STORAGE_KEY, nextValues);
    }
    localStorage.setItem(FILE_HISTORY_INITIALIZED_VERSION_KEY, FILE_HISTORY_INITIAL_VERSION);
  } catch (e) {
    console.warn("file history storage initialize failed", e);
  }
}

function readFileHistoryValues() {
  const fallback = createInitialFileHistorySeedValues();
  if (USE_SAMPLE_DATA) return normalizeFileHistoryValues(fallback);
  initializeFileHistoryStorageIfNeeded();
  const values = readArray(FILE_HISTORY_STORAGE_KEY, fallback);
  return seedFileHistoryStorage(FILE_HISTORY_STORAGE_KEY, values, fallback);
}

function buildSampleRecentTabs() {
  // 時間タブも、ホーム履歴・右側履歴と同じ「フルパス,日時」の元データから作る。
  const result = [];
  const base = new Date("2026-07-07T10:01:04");
  sampleFiles.forEach((value, index) => {
    const fallback = new Date(base.getTime() - (index * 60 * 1000));
    const item = buildRecentTabFromHistoryValue(value, fallback);
    if (item) result.push(item);
  });
  return result;
}

const sampleRecentTabs = buildSampleRecentTabs();
let sessionRecentTabs = null;

const sampleSearchWords = [
  "TableAccessor | ALL | ALL",
  "CUSTOMER_ID | nkCCIS | java",
  "Command Task Accessor | BPNet | Java",
  "MST_CUSTOMER | SMBC | SQL",
  "QueryAccessor | fast2024 | XML",
  "AccountUpdate | nikkoEZ | ALL",
  "KYF1940 | ALL | java",
  "8jjj8jjeJEjee | nkCCIS | Java",
  "TableAccessor009 | BPNet | SQL",
  "CUSTOMER_ID010 | SMBC | XML",
  "Command Task Accessor011 | fast2024 | ALL",
  "MST_CUSTOMER012 | nikkoEZ | java",
  "QueryAccessor013 | ALL | Java",
  "AccountUpdate014 | nkCCIS | SQL",
  "KYF1940015 | BPNet | XML",
  "8jjj8jjeJEjee016 | SMBC | ALL",
  "TableAccessor017 | fast2024 | java",
  "CUSTOMER_ID018 | nikkoEZ | Java",
  "Command Task Accessor019 | ALL | SQL",
  "MST_CUSTOMER020 | nkCCIS | XML",
  "QueryAccessor021 | BPNet | ALL",
  "AccountUpdate022 | SMBC | java",
  "KYF1940023 | fast2024 | Java",
  "8jjj8jjeJEjee024 | nikkoEZ | SQL",
  "TableAccessor025 | ALL | XML",
  "CUSTOMER_ID026 | nkCCIS | ALL",
  "Command Task Accessor027 | BPNet | java",
  "MST_CUSTOMER028 | SMBC | Java",
  "QueryAccessor029 | fast2024 | SQL",
  "AccountUpdate030 | nikkoEZ | XML",
  "KYF1940031 | ALL | ALL",
  "8jjj8jjeJEjee032 | nkCCIS | java",
  "TableAccessor033 | BPNet | Java",
  "CUSTOMER_ID034 | SMBC | SQL",
  "Command Task Accessor035 | fast2024 | XML",
  "MST_CUSTOMER036 | nikkoEZ | ALL",
  "QueryAccessor037 | ALL | java",
  "AccountUpdate038 | nkCCIS | Java",
  "KYF1940039 | BPNet | SQL",
  "8jjj8jjeJEjee040 | SMBC | XML",
  "TableAccessor041 | fast2024 | ALL",
  "CUSTOMER_ID042 | nikkoEZ | java",
  "Command Task Accessor043 | ALL | Java",
  "MST_CUSTOMER044 | nkCCIS | SQL",
  "QueryAccessor045 | BPNet | XML",
  "AccountUpdate046 | SMBC | ALL",
  "KYF1940047 | fast2024 | java",
  "8jjj8jjeJEjee048 | nikkoEZ | Java",
  "TableAccessor049 | ALL | SQL",
  "CUSTOMER_ID050 | nkCCIS | XML",
  "Command Task Accessor051 | BPNet | ALL",
  "MST_CUSTOMER052 | SMBC | java",
  "QueryAccessor053 | fast2024 | Java",
  "AccountUpdate054 | nikkoEZ | SQL",
  "KYF1940055 | ALL | XML",
  "8jjj8jjeJEjee056 | nkCCIS | ALL",
  "TableAccessor057 | BPNet | java",
  "CUSTOMER_ID058 | SMBC | Java",
  "Command Task Accessor059 | fast2024 | SQL",
  "MST_CUSTOMER060 | nikkoEZ | XML",
  "QueryAccessor061 | ALL | ALL",
  "AccountUpdate062 | nkCCIS | java",
  "KYF1940063 | BPNet | Java",
  "8jjj8jjeJEjee064 | SMBC | SQL",
  "TableAccessor065 | fast2024 | XML",
  "CUSTOMER_ID066 | nikkoEZ | ALL",
  "Command Task Accessor067 | ALL | java",
  "MST_CUSTOMER068 | nkCCIS | Java",
  "QueryAccessor069 | BPNet | SQL",
  "AccountUpdate070 | SMBC | XML",
  "KYF1940071 | fast2024 | ALL",
  "8jjj8jjeJEjee072 | nikkoEZ | java",
  "TableAccessor073 | ALL | Java",
  "CUSTOMER_ID074 | nkCCIS | SQL",
  "Command Task Accessor075 | BPNet | XML",
  "MST_CUSTOMER076 | SMBC | ALL",
  "QueryAccessor077 | fast2024 | java",
  "AccountUpdate078 | nikkoEZ | Java",
  "KYF1940079 | ALL | SQL",
  "8jjj8jjeJEjee080 | nkCCIS | XML"
];

const sampleResults = [
  { file: "KYF1940TableAccessor.java", line: 128, project: "NewNikko", group: "nkCCIS", path: "kayk.online/lib/KjCTMYYYYYY.jar/jp/com/xxx/xxx/xxx/KYF1940TableAccessor.java" },
  { file: "KYF1950TableAccessor.java", line: 82, project: "NewNikko", group: "nkCCIS", path: "kayk.online/lib/KjCTMYYYYYY.jar/jp/com/xxx/xxx/xxx/KYF1950TableAccessor.java" },
  { file: "KjCustomerSearchCommand.java", line: 45, project: "NewNikko", group: "nkCCIS", path: "business-java/lib/KjCommand.jar/jp/com/xxx/command/KjCustomerSearchCommand.java" },
  { file: "KjCustomerSearchTask.java", line: 211, project: "NewNikko", group: "nkCCIS", path: "business-java/lib/KjTask.jar/jp/com/xxx/task/KjCustomerSearchTask.java" },
  { file: "ORD0100QueryAccessor.java", line: 67, project: "BPNet", group: "BPNet", path: "bpnet_dbac/lib/OrderDbac.jar/jp/com/xxx/dbac/ORD0100QueryAccessor.java" },
  { file: "AccountUpdateTableAccessor.java", line: 159, project: "SMBC", group: "SMBC", path: "smbc_dbac/lib/AccountDbac.jar/jp/com/xxx/dbac/AccountUpdateTableAccessor.java" },
  { file: "customer-search.sql", line: 14, project: "fast2024", group: "fast2024", path: "fast/sql/customer/customer-search.sql" },
  { file: "application-context.xml", line: 33, project: "nikkoEZ", group: "nikkoEZ", path: "ez/config/application-context.xml" } ];

const sampleCode = `NIKKO.nkCCIS/efront.online.jar/lib/ApFrKjFtf_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ftf/model/KyakRiskKakzJohoSyutkTask.java


package jp.co.fnt.stp1.app.apptier.front.kj.ftf.model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.fnt.stp1.app.apptier.com.cm.com.exception.SoteiGaSQLException;
import jp.co.fnt.stp1.app.apptier.com.cm.com.task.Task;
import jp.co.fnt.stp1.app.apptier.com.cm.com.task.TaskResult;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.constants.KjFtfAppSymbols;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.constants.KjFtfGyomConst;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.ctrl.param.KakudukeJoho;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.ctrl.param.RiskItem;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1940TableAccessor;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1940TableRecord;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1950TableAccessor;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1950TableRecord;
import jp.co.fnt.stp1.appfw.basefw.APBFWException;
import jp.co.fnt.stp1.appfw.basefw.CommandContext;
import jp.co.fnt.stp1.appfw.basefw.CommandException;
import jp.co.fnt.stp1.appfw.basefw.MsgInfo;

/**
 * <strong>格付算出情報取得タスク</strong>
 * <BR>
 * @author ACC
**/

public class KyakRiskKakzJohoSyutkTask implements Task{
	public static final Map<String,String> KAKUDUKE_KBN_MAP = new HashMap<>();
	static{
		KAKUDUKE_KBN_MAP.put("EH", "00");
		KAKUDUKE_KBN_MAP.put("H", "00");
		KAKUDUKE_KBN_MAP.put("M", "01");
		KAKUDUKE_KBN_MAP.put("L-", "02");
		KAKUDUKE_KBN_MAP.put("L", "02");
	}

    /**
    *  <B>格付算出情報取得する </B>
    * @param CommandContext                コマンドコンテキスト
    * @param kyakCifC                      顧客CIFコード
    * @param coHyjunC                     会社標準コード
    * @exception CommandException          アプリケーションが送出する例外の抽象クラス
    * @exception APBFWException            APBFWが送出する例外の抽象クラス
    **/

    public static TaskResult getKakzJoho(CommandContext context, 
            String kyakCifC, String coHyjunC) throws CommandException, APBFWException {
        // タスクリザルト
        TaskResult taskResult = new TaskResult();

        // 結果格納
		ArrayList<KakudukeJoho> kakudukeJohoList = new ArrayList<KakudukeJoho>();
		String expertJudgement = "";
		String total = "";
		String kakuduke = "";
		String kakudukeKbn = "";

		// DB Accessor
        Kyf1940TableAccessor kyf1940Accessor = new Kyf1940TableAccessor();
        Kyf1950TableAccessor kyf1950Accessor = new Kyf1950TableAccessor();
    	
        Kyf1940TableRecord kyf1940Record = new Kyf1940TableRecord();
        Kyf1950TableRecord kyf1950Record = new Kyf1950TableRecord();
		
        try{
        	// 格付算出根拠情報を取得する
        	kyf1940Accessor.executeQueryKyakRiskKakzJoho(
        			context.getConnectionManager().getConnection(), 
        			coHyjunC, 
        			kyakCifC, 
        			KjFtfGyomConst.RONR_MASY_K_0);
        	
        	// 格付項目名情報を取得する
        	kyf1950Accessor.executeQueryKyakRiskKakzKomkNmJoho(
        			context.getConnectionManager().getConnection(), 
        			coHyjunC, 
        			KjFtfGyomConst.RONR_MASY_K_0);
			
			if ((kyf1940Record = kyf1940Accessor.nextRecord()) != null) {
				// 顧客リスク格付項目名情報
				kyf1950Record = kyf1950Accessor.nextRecord();
				
				// 格付情報_基本項目
				KakudukeJoho basicJoho = editKakudukeJoho(kyf1940Record,kyf1950Record,1,4,"基本項目","10");
				kakudukeJohoList.add(basicJoho);
				
				// 格付情報_加点項目
				KakudukeJoho addJoho = editKakudukeJoho(kyf1940Record,kyf1950Record,5,15,"加点項目","11");
				kakudukeJohoList.add(addJoho);
				
				expertJudgement = kyf1940Record.getExpJuge();
				total = kyf1940Record.getRiskScoreGokei();
				kakuduke = kyf1940Record.getRiskKakzCnd();
				kakudukeKbn = KAKUDUKE_KBN_MAP.get(kakuduke);
				
			} else {
				// データ存在しない場合
				taskResult.setMsgInfo(new MsgInfo("AFKJFTF112001"));
			}
        } catch(SQLException e){
            throw new SoteiGaSQLException(e.getMessage(), e);
        } catch(APBFWException e) {
            throw e;
        } finally{
        		try {
        			kyf1940Accessor.closeStatement();
        			kyf1950Accessor.closeStatement();
    			} catch( SQLException e) {
    				throw new SoteiGaSQLException(e.getMessage(), e);
    			}
        }
        // タスク結果設定
		// 格付情報リストをタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE_LIST, kakudukeJohoList);
		// ExpertJudgementをタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.EXPERT_JUDGEMENT, expertJudgement);
		// 合計をタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.TOTAL, total);
		// 顧客リスク格付をタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE, kakuduke);
		// 顧客リスク格付区分をタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE_KBN, kakudukeKbn);
		
		// タスクリザルト
        taskResult.setEndJtai(TaskResult.OK);
        return taskResult;
    }
    
    /**
     * 格付情報作成
     * @param kyf1940Record KYF1940から取得した情報
     * @param kyf1950Record　KYF1950から取得した情報
     * @param start 情報取得開始位置
     * @param end　情報取得終了位置
     * @param riskNm　リスク要素名
     * @param riskKbn　リスク要素区分
     */
	private static KakudukeJoho editKakudukeJoho(
			Kyf1940TableRecord kyf1940Record, Kyf1950TableRecord kyf1950Record,
			int start, int end, String riskNm, String riskKbn) {
		// リスク格付け情報
		KakudukeJoho joho = new KakudukeJoho();
		// リスク内容リスト
		List<RiskItem> riskItems = new ArrayList<>();
		
		for(int i = start; i <= end; i++){
			RiskItem item = new RiskItem();
			if(kyf1950Record!=null){
				item.setLabel(getItemValue(kyf1950Record,"getKyakAtr"+ String.format("%02d", i)+"nm"));
			}else{
				item.setLabel("");
			}
			item.setPoint(getItemValue(kyf1940Record,"getKyakAtr"+ String.format("%02d", i)+"Pt"));
			riskItems.add(item);
		}
		
		joho.setRiskElementKbn(riskKbn);
		joho.setRiskElementNm(riskNm);
		joho.setRiskItems(riskItems);
		return joho;
	}
	
	/**
     * 項目名によりレコードから項目値を取得
     */
    public static String getItemValue(Object ob, String getName) {
    	String rt = "";
    	try {
    		rt = (String)ob.getClass().getDeclaredMethod(getName).invoke(ob);
    	} catch (Exception e){}
    	return rt;
    }
}`;

const sampleAiCode = `// AIによる解説コード
// このAccessorは、CUSTOMER_IDを条件にMST_CUSTOMERを検索するサンプルです。
// SQL_SELECTで取得項目を定義し、PreparedStatementでバインド変数を設定します。
// ResultSetを1行ずつDTOへ詰め替えて、呼び出し元へListで返却します。

public List<CustomerDto> selectCustomer(Connection con, String customerId) throws Exception {
    // 1. 戻り値用のリストを作成
    List<CustomerDto> result = new ArrayList<CustomerDto>();

    // 2. CUSTOMER_IDを条件に検索
    try (PreparedStatement ps = con.prepareStatement(SQL_SELECT)) {
        ps.setString(1, customerId);

        // 3. 検索結果をDTOへ変換
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                CustomerDto dto = new CustomerDto();
                dto.setCustomerId(rs.getString("CUSTOMER_ID"));
                dto.setCustomerName(rs.getString("CUSTOMER_NAME"));
                dto.setStatus(rs.getString("STATUS"));
                result.add(dto);
            }
        }
    }
    return result;
}`;

const sampleSummaryText = `要約説明

・MST_CUSTOMERを検索するTableAccessorです。
・CUSTOMER_IDを検索条件としてPreparedStatementに設定します。
・取得したCUSTOMER_ID、CUSTOMER_NAME、STATUSをCustomerDtoへ詰め替えます。
・検索結果はList<CustomerDto>として返却します。`;

let currentView = "home";
let currentCodePath = USE_SAMPLE_DATA ? sampleFiles[1] : "";
let codeFontSize = 14;
const CODE_FONT_MIN = 9;
const CODE_FONT_MAX = 24;
const CODE_FONT_STEP = 1;
let activeCodePanel = "source";
let lastSearchParams = null;
let lastSearchMode = "normal";
let lastSearchResults = [];
let currentCodeMeta = null;
let currentSourceText = "";
let currentSourceLanguage = "java";
let currentTableNames = [];
let currentTableNameSet = new Set();
let tableInfoRequestSequence = 0;
let tableInfoState = {
  status: "idle",
  tableName: "",
  candidates: [],
  selected: null,
  tableMeta: null,
  columns: [],
  unique: false,
  error: ""
};
// 2026-08-04 サイト修正6: テーブル情報は1タブ上書きではなく、クリックごとに独立タブとして保持する。
let tableInfoTabSequence = 0;
let tableInfoStates = [];
let activeTableInfoTabId = "";

// コード中のJavaクラス名・テーブル名は、下線を常時表示する。
// このフラグは背景色だけを切り替える。初期状態は必ずOFF。
let codeHighlightBackgroundEnabled = false;

function $(id) {
  return document.getElementById(id);
}

function cssEscapeValue(value) {
  if (window.CSS && typeof window.CSS.escape === "function") {
    return window.CSS.escape(String(value || ""));
  }
  return String(value || "").replace(/["\\]/g, "\\$&");
}

function formatDateTime(value) {
  const date = toSafeDate(value);
  const pad = value => String(value).padStart(2, "0");
  const week = ["日", "月", "火", "水", "木", "金", "土"][date.getDay()];
  return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())}(${week}) ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function formatSummaryDateTimeValue(value, fallbackDate) {
  const text = String(value == null ? "" : value).trim();
  if (text && text !== "-") {
    if (/^\d{4}\/\d{2}\/\d{2}\([日月火水木金土]\)\s+\d{2}:\d{2}:\d{2}$/.test(text)) {
      return text;
    }
    return formatDateTime(text);
  }
  return fallbackDate ? formatDateTime(fallbackDate) : "-";
}


function readSessionStorage(key) {
  try {
    return String(sessionStorage.getItem(key) || "").trim();
  } catch (e) {
    return "";
  }
}

function writeSessionStorage(key, value) {
  try {
    sessionStorage.setItem(key, String(value == null ? "" : value));
  } catch (e) {
    console.warn("sessionStorage write failed", e);
  }
}

function removeSessionStorage(key) {
  try {
    sessionStorage.removeItem(key);
  } catch (e) {
    // sessionStorageが無効でも画面処理は継続する。
  }
}

function normalizeTabNavigationEntry(value) {
  if (!value || typeof value !== "object") return null;

  const type = String(value.type || "").trim();
  if (type === "view") {
    const view = String(value.view || "").trim();
    if (view !== "home" && view !== "search") return null;
    return {
      id: `view:${view}`,
      type: "view",
      view
    };
  }

  if (type === "recent") {
    const path = getHistoryEntryPath(value.path || value.fullPath || value.filePath || "");
    if (!path) return null;

    const openedTime = new Date(value.openedAt || "");
    if (Number.isNaN(openedTime.getTime())) return null;
    const openedAt = openedTime.toISOString();
    const item = { path, openedAt };

    const entry = {
      id: `recent:${recentTabKey(item)}`,
      type: "recent",
      path,
      openedAt
    };

    ["fileName", "project", "group", "directoryGroup", "href", "sourceUrl", "language"].forEach(key => {
      const text = String(value[key] == null ? "" : value[key]).trim();
      if (text) entry[key] = text;
    });
    return entry;
  }

  return null;
}

function createViewTabNavigationEntry(viewName) {
  return normalizeTabNavigationEntry({ type: "view", view: viewName });
}

function createRecentTabNavigationEntry(item, meta = {}) {
  return normalizeTabNavigationEntry(Object.assign({}, meta || {}, {
    type: "recent",
    path: item && item.path,
    openedAt: item && item.openedAt
  }));
}

function readTabNavigationState() {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(TAB_NAVIGATION_STORAGE_KEY) || "{}");
    const entries = Array.isArray(parsed.entries)
      ? parsed.entries.map(normalizeTabNavigationEntry).filter(Boolean).slice(-TAB_NAVIGATION_LIMIT)
      : [];
    const currentId = entries.length ? entries[entries.length - 1].id : "";
    return {
      version: TAB_NAVIGATION_VERSION,
      entries,
      currentId
    };
  } catch (e) {
    return { version: TAB_NAVIGATION_VERSION, entries: [], currentId: "" };
  }
}

function writeTabNavigationState(state) {
  try {
    const entries = (state && Array.isArray(state.entries) ? state.entries : [])
      .map(normalizeTabNavigationEntry)
      .filter(Boolean)
      .slice(-TAB_NAVIGATION_LIMIT);
    const currentId = entries.length ? entries[entries.length - 1].id : "";
    const payload = {
      version: TAB_NAVIGATION_VERSION,
      entries,
      currentId
    };
    sessionStorage.setItem(TAB_NAVIGATION_STORAGE_KEY, JSON.stringify(payload));
    sessionStorage.setItem(TAB_NAVIGATION_CURRENT_ID_KEY, currentId);
    if (document && document.documentElement) {
      document.documentElement.dataset.activeTabId = currentId;
    }
    updateRecentTabVisitedStyles();
  } catch (e) {
    console.warn("tab navigation history write failed", e);
  }
}

function recordTabNavigation(entry) {
  if (restoringTabNavigation) return;
  const normalized = normalizeTabNavigationEntry(entry);
  if (!normalized) return;

  const state = readTabNavigationState();
  const last = state.entries[state.entries.length - 1];
  if (!last || last.id !== normalized.id) {
    state.entries.push(normalized);
  }
  writeTabNavigationState(state);
}

function initializeTabNavigationHistory() {
  const storedVersion = readSessionStorage(TAB_NAVIGATION_VERSION_KEY);
  if (storedVersion !== TAB_NAVIGATION_VERSION) {
    removeSessionStorage(TAB_NAVIGATION_STORAGE_KEY);
    removeSessionStorage(TAB_NAVIGATION_CURRENT_ID_KEY);
    // 旧実装のSessionStorageも消して、壊れた履歴を引き継がない。
    removeSessionStorage("krugle.session.tab.navigation.history");
    removeSessionStorage("krugle.session.tab.navigation.version");
    writeSessionStorage(TAB_NAVIGATION_VERSION_KEY, TAB_NAVIGATION_VERSION);
  }

  // 初期画面はホームなので、サイトを開いた時点から必ず履歴へ入れる。
  recordTabNavigation(createViewTabNavigationEntry("home"));
}

function isBackspaceEditingTarget(target) {
  if (!target) return false;
  const element = target.nodeType === 1 ? target : target.parentElement;
  if (!element) return false;
  if (element.isContentEditable) return true;
  if (element.closest && element.closest('[contenteditable="true"], [contenteditable=""]')) return true;

  const tagName = String(element.tagName || "").toLowerCase();
  if (tagName === "textarea" || tagName === "select") {
    return !element.disabled && !element.readOnly;
  }
  if (tagName === "input") {
    const type = String(element.type || "text").toLowerCase();
    const nonTextTypes = new Set(["button", "checkbox", "color", "file", "hidden", "image", "radio", "range", "reset", "submit"]);
    return !nonTextTypes.has(type) && !element.disabled && !element.readOnly;
  }
  return false;
}

function findRecentTabForNavigation(entry) {
  const normalized = normalizeTabNavigationEntry(entry);
  if (!normalized || normalized.type !== "recent") return null;

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  const exact = tabs.find(item => `recent:${recentTabKey(item)}` === normalized.id);
  if (exact) return exact;

  // 履歴クリアや上限超過で同一IDが消えた場合も、保存済みの完全パスでソースを復元する。
  // 同じパスの最新タブが残っていれば、その実在タブをアクティブにする。
  return tabs.find(item => item.path === normalized.path) || {
    path: normalized.path,
    openedAt: normalized.openedAt
  };
}

function openTabNavigationEntry(entry) {
  const normalized = normalizeTabNavigationEntry(entry);
  if (!normalized) return false;

  restoringTabNavigation = true;
  try {
    if (normalized.type === "view") {
      showView(normalized.view, { recordNavigation: false });
      return true;
    }

    if (normalized.type === "recent") {
      const recentItem = findRecentTabForNavigation(normalized);
      const row = {
        path: normalized.path,
        fileName: normalized.fileName || "",
        project: normalized.project || "",
        group: normalized.group || "",
        directoryGroup: normalized.directoryGroup || "",
        href: normalized.href || "",
        sourceUrl: normalized.sourceUrl || "",
        language: normalized.language || ""
      };
      openCode(normalized.path, {
        addRecent: false,
        recentItem,
        row,
        recordNavigation: false
      });
      return true;
    }
  } finally {
    // openCodeは最初のawaitより前にタブ表示を切り替えるため、ここで解除してよい。
    restoringTabNavigation = false;
  }
  return false;
}

function navigateToPreviousOpenedTab() {
  const state = readTabNavigationState();
  if (state.entries.length <= 1) return false;

  // 最後の要素が現在のタブ。これを取り除き、その直前の一意IDへ戻る。
  state.entries.pop();
  while (state.entries.length) {
    const previous = state.entries[state.entries.length - 1];
    writeTabNavigationState(state);
    if (openTabNavigationEntry(previous)) return true;
    state.entries.pop();
  }

  writeTabNavigationState(state);
  return false;
}

function handleBackspaceTabNavigation(event) {
  const isBackspace = event.key === "Backspace" || event.keyCode === 8;
  if (!isBackspace || event.defaultPrevented || event.isComposing || event.keyCode === 229) return;
  if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || event.repeat) return;
  if (isBackspaceEditingTarget(event.target)) return;

  // ブラウザの「前のページへ戻る」を止め、サイト内タブ履歴だけを1件戻す。
  event.preventDefault();
  event.stopPropagation();
  navigateToPreviousOpenedTab();
}

function normalizeApiBase(base) {
  const value = String(base || "").trim();
  if (!value) return "";
  return value.endsWith("/") ? value : `${value}/`;
}

function apiPathForBase(base, path) {
  const cleanPath = String(path || "").replace(/^\/+/, "");
  const normalizedBase = normalizeApiBase(base);
  if (/^https?:\/\//i.test(normalizedBase)) {
    return new URL(cleanPath, normalizedBase).toString();
  }
  if (normalizedBase) return `${normalizedBase.replace(/\/$/, "")}/${cleanPath}`;
  return `${KRUGLE_CONTEXT_PATH}/${cleanPath}`;
}

function apiPath(path) {
  return apiPathForBase(activeApiBase || KRUGLE_API_PRIMARY_BASE, path);
}

function formBody(params) {
  const body = new URLSearchParams();
  Object.keys(params || {}).forEach(key => {
    const value = params[key];
    if (value !== undefined && value !== null) body.append(key, String(value));
  });
  return body;
}

function buildQueryString(params) {
  return formBody(params).toString();
}

function appendQuery(url, params) {
  const query = buildQueryString(params);
  if (!query) return url;
  return url + (url.indexOf("?") >= 0 ? "&" : "?") + query;
}

function createApiError(message, properties = {}) {
  const error = new Error(message);
  Object.keys(properties).forEach(key => {
    error[key] = properties[key];
  });
  return error;
}

function shouldUseJsonpTransport(options = {}) {
  if (options.transport === "fetch") return false;
  if (options.transport === "jsonp") return true;
  // file://直開きでは通常fetchのCORS判定より先にJSONPを使う。
  // Servlet側がcallbackを処理するため、Origin:nullやPNA制約を受けない。
  return window.location.protocol === "file:";
}

async function fetchJsonViaCors(base, path, params = {}, options = {}) {
  const method = String(options.method || "POST").toUpperCase();
  let url = apiPathForBase(base, path);
  const requestOptions = {
    method,
    headers: { "Accept": "application/json" },
    cache: "no-store",
    mode: "cors",
    credentials: "omit",
    redirect: "follow"
  };

  if (method === "GET") {
    url = appendQuery(url, params);
  } else {
    requestOptions.headers["Content-Type"] = "application/x-www-form-urlencoded;charset=UTF-8";
    requestOptions.body = formBody(params);
  }

  let timeoutId = null;
  let controller = null;
  const timeoutMs = Number(options.timeoutMs || 0);
  if (timeoutMs > 0 && typeof AbortController !== "undefined") {
    controller = new AbortController();
    requestOptions.signal = controller.signal;
    timeoutId = window.setTimeout(() => controller.abort(), timeoutMs);
  }

  let response;
  try {
    response = await fetch(url, requestOptions);
  } catch (e) {
    const timedOut = Boolean(e && e.name === "AbortError");
    const detail = timedOut ? `タイムアウト(${timeoutMs}ms)` : String((e && e.message) || e || "Failed to fetch");
    throw createApiError(`通信失敗: ${detail}\nURL: ${url}`, {
      apiUnavailable: true,
      timedOut,
      url,
      cause: e
    });
  } finally {
    if (timeoutId !== null) window.clearTimeout(timeoutId);
  }

  const text = await response.text();
  let data = {};
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (e) {
      throw createApiError(`JSON解析失敗 HTTP ${response.status}: ${text.substring(0, 300)}\nURL: ${url}`, {
        apiUnavailable: true,
        status: response.status,
        url,
        cause: e
      });
    }
  }

  if (!response.ok) {
    const message = data && data.error ? data.error : `HTTP ${response.status}`;
    throw createApiError(`${message}\nURL: ${url}`, {
      apiUnavailable: response.status === 404 || response.status >= 500,
      status: response.status,
      url,
      responseData: data
    });
  }
  return data;
}

function fetchJsonViaJsonp(base, path, params = {}, options = {}) {
  return new Promise((resolve, reject) => {
    const timeoutMs = Math.max(1, Number(options.timeoutMs || API_ACCESS_TIMEOUT_MS));
    const callbackName = `__krugleJsonp_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const query = Object.assign({}, params, {
      callback: callbackName,
      _: Date.now()
    });
    const url = appendQuery(apiPathForBase(base, path), query);
    const script = document.createElement("script");
    let settled = false;
    let timerId = null;

    const cleanup = () => {
      if (timerId !== null) window.clearTimeout(timerId);
      try { delete window[callbackName]; } catch (e) { window[callbackName] = undefined; }
      if (script.parentNode) script.parentNode.removeChild(script);
    };
    const finish = (handler, value) => {
      if (settled) return;
      settled = true;
      cleanup();
      handler(value);
    };

    window[callbackName] = data => finish(resolve, data || {});
    script.async = true;
    script.src = url;
    script.onerror = () => finish(reject, createApiError(`JSONP通信失敗\nURL: ${url}`, {
      apiUnavailable: true,
      url
    }));
    timerId = window.setTimeout(() => finish(reject, createApiError(`タイムアウト(${timeoutMs}ms)\nURL: ${url}`, {
      apiUnavailable: true,
      timedOut: true,
      url
    })), timeoutMs);
    document.head.appendChild(script);
  });
}

async function fetchJsonAtBase(base, path, params = {}, options = {}) {
  if (shouldUseJsonpTransport(options)) {
    // JSONPはscript GETだけを利用するため、POST指定でもGETクエリへ安全に変換する。
    return fetchJsonViaJsonp(base, path, params, options);
  }
  return fetchJsonViaCors(base, path, params, options);
}

function isMixedContentCandidate(base) {
  return window.location.protocol === "https:" && /^http:\/\//i.test(normalizeApiBase(base));
}

function clearApiBaseSelection() {
  activeApiBase = "";
  resolvedApiInitData = null;
  apiResolvePromise = null;
  removeSessionStorage(API_SESSION_STORAGE_KEY);
  removeSessionStorage(API_SESSION_VERSION_KEY);
  // 旧版が保存した失敗フラグも削除する。
  removeSessionStorage("krugle.api.base.resolved");
  removeSessionStorage("krugle.api.base.error");
}

function saveApiBaseSelection(base) {
  activeApiBase = normalizeApiBase(base);
  writeSessionStorage(API_SESSION_STORAGE_KEY, activeApiBase);
  writeSessionStorage(API_SESSION_VERSION_KEY, API_SESSION_VERSION);
  removeSessionStorage("krugle.api.base.resolved");
  removeSessionStorage("krugle.api.base.error");
}

function validateProbeResponse(data, base) {
  if (!data || data.ok !== true) {
    throw createApiError(`疎通確認の応答形式が不正です。\nURL: ${apiPathForBase(base, "/init")}`, {
      apiUnavailable: true
    });
  }
}

function validateInitResponse(data, base) {
  if (!data || !Array.isArray(data.projects)) {
    throw createApiError(`Servlet /init の応答形式が不正です。\nURL: ${apiPathForBase(base, "/init")}`, {
      apiUnavailable: true
    });
  }
}

async function resolveApiBaseOnce(options = {}) {
  const forceCheck = options.forceCheck === true;
  if (!forceCheck && activeApiBase) {
    return { base: normalizeApiBase(activeApiBase), initData: resolvedApiInitData, cached: true };
  }
  if (!forceCheck && apiResolvePromise) return apiResolvePromise;

  const candidates = [
    { base: KRUGLE_API_PRIMARY_BASE, timeoutMs: API_PROBE_TIMEOUT_PRIMARY_MS },
    { base: KRUGLE_API_SECONDARY_BASE, timeoutMs: API_PROBE_TIMEOUT_SECONDARY_MS }
  ].filter(candidate => !isMixedContentCandidate(candidate.base));

  const promise = (async () => {
    const errors = [];
    for (const candidate of candidates) {
      const base = normalizeApiBase(candidate.base);
      try {
        // 第1段階: Servletだけを短時間確認。Krugle CGIには接続しない。
        const probeData = await fetchJsonAtBase(base, "/init", { probe: "1" }, {
          method: "GET",
          timeoutMs: candidate.timeoutMs
        });
        validateProbeResponse(probeData, base);

        // 第2段階: 同じServletへ本アクセス。この成功後だけSessionStorageへ保存する。
        const initData = await fetchJsonAtBase(base, "/init", {}, {
          method: "GET",
          timeoutMs: API_ACCESS_TIMEOUT_MS
        });
        validateInitResponse(initData, base);

        resolvedApiInitData = initData;
        saveApiBaseSelection(base);
        console.info(`Krugle Servlet API接続OK: ${activeApiBase}`);
        return { base: activeApiBase, initData, cached: false };
      } catch (e) {
        errors.push(`${base} -> ${String(e && e.message ? e.message : e)}`);
      }
    }

    throw createApiError(`Servlet APIへ接続できませんでした。\n${errors.join("\n\n")}`, {
      apiUnavailable: true,
      candidateErrors: errors
    });
  })();

  apiResolvePromise = promise;
  promise.catch(() => {
    if (apiResolvePromise === promise) apiResolvePromise = null;
  });
  return promise;
}

async function fetchJson(path, params = {}, options = {}) {
  const resolved = await resolveApiBaseOnce();
  try {
    return await fetchJsonAtBase(resolved.base, path, params, options);
  } catch (e) {
    if (options.disableFailover === true || !e || e.apiUnavailable !== true) throw e;

    const failedBase = normalizeApiBase(resolved.base);
    clearApiBaseSelection();
    console.warn(`Servlet接続先を再判定します: ${failedBase}`);
    const retryResolved = await resolveApiBaseOnce({ forceCheck: true });
    return fetchJsonAtBase(retryResolved.base, path, params, Object.assign({}, options, { disableFailover: true }));
  }
}

function submitDownload(path, params = {}) {
  const form = document.createElement("form");
  form.method = "POST";
  form.action = apiPath(path);
  form.style.display = "none";
  form.target = "_self";

  Object.keys(params || {}).forEach(key => {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = key;
    input.value = params[key] == null ? "" : String(params[key]);
    form.appendChild(input);
  });

  document.body.appendChild(form);
  form.submit();
  window.setTimeout(() => form.remove(), 1000);
}

function optionText(selectElement) {
  if (!selectElement) return "";
  const option = selectElement.options[selectElement.selectedIndex];
  return option ? option.textContent.trim() : "";
}

function normalizeKeywordForMode(rawKeyword, mode) {
  const keyword = String(rawKeyword || "").trim();

  // 通常検索では入力値を一切加工しない。
  if (mode !== "fuzzy" || !keyword) return keyword;

  // 曖昧検索の場合だけ、存在しない側の * を補う。
  // 既に入力されている先頭・末尾の * はそのまま尊重する。
  const leadingWildcard = keyword.startsWith("*") ? "" : "*";
  const trailingWildcard = keyword.endsWith("*") ? "" : "*";
  return `${leadingWildcard}${keyword}${trailingWildcard}`;
}

function buildSearchParams(mode = "normal") {
  const keywordInput = $("keywordInput");
  const projectSelect = $("groupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  const rawKeyword = keywordInput ? keywordInput.value.trim() : "";
  // 0行目相当の「選択なし」は、検索条件としては全件扱いにする。
  const project = projectSelect && projectSelect.value ? projectSelect.value : "ALL";
  const language = languageSelect && languageSelect.value ? languageSelect.value : "ALL";
  const languageForApi = language === "ALL" ? "ALL" : String(language).toLowerCase();
  const projectText = optionText(projectSelect) || (project === "ALL" ? "すべて" : project);
  const languageText = optionText(languageSelect) || (language === "ALL" ? "すべて" : language);

  return {
    rawKeyword,
    keyword: normalizeKeywordForMode(rawKeyword, mode),
    project,
    projectText,
    language,
    languageText,
    languageForApi,
    findin: "ALL",
    clone: cloneCheck && cloneCheck.checked ? "NO" : "YES",
    source_disp: "NO"
  };
}


function buildSearchParamsFromCondition(condition, mode = "normal") {
  const source = condition || {};
  const rawKeyword = String(source.keyword || "").trim();
  const project = String(source.project || "ALL").trim() || "ALL";
  const language = String(source.language || "ALL").trim() || "ALL";
  const languageForApi = language === "ALL" ? "ALL" : language.toLowerCase();
  const projectText = project === "ALL" ? "すべて" : normalizeMigrationGroupName(project) || project;
  const languageText = language === "ALL" ? "すべて" : language;

  return {
    rawKeyword,
    keyword: normalizeKeywordForMode(rawKeyword, mode),
    project,
    projectText,
    language,
    languageText,
    languageForApi,
    findin: String(source.findin || "ALL").trim() || "ALL",
    clone: source.clone || "YES",
    source_disp: source.source_disp || "NO"
  };
}

function clearInitialSearchForm() {
  const keywordInput = $("keywordInput");
  const groupSelect = $("groupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  if (keywordInput) keywordInput.value = "";
  setSelectValueByTextOrValue(groupSelect, "ALL", "ALL");
  setSelectValueByTextOrValue(languageSelect, "ALL", "ALL");
  if (cloneCheck) cloneCheck.checked = false;
  refreshGroupCombo({ resetFilter: true });
}

function normalizeSearchRow(row, index = 0) {
  const source = row || {};
  const fileName = source.fileName || source.file || source.name || "";
  const project = normalizeProjectValue(source.project || source.projectName || source.projectValue || "");
  const rawPath = source.fullPath || source.filePath || source.path || fileName;
  const path = buildCompleteKruglePath(rawPath, project, source.group || source.migrationGroup || source.ikogroup || source.ikoGroup || "");
  const projectParts = String(project).split(".");
  const rawGroup = source.group || source.migrationGroup || source.ikogroup || source.ikoGroup || extractMigrationGroupFromPath(path) || (projectParts.length > 1 ? projectParts[1] : projectParts[0]) || "";
  const group = normalizeMigrationGroupName(rawGroup);
  const directoryGroup = cleanDirectoryGroupName(source.directoryGroup || source.dirGroup || source.directory || extractDirectoryGroupFromPath(path));

  return {
    no: source.no || String(index + 1),
    fileName,
    lineNo: source.lineNo || source.line || "",
    project,
    group,
    directoryGroup,
    path,
    href: source.href || "",
    sourceUrl: source.sourceUrl || "",
    preview: source.preview || "",
    language: source.language || inferLanguageFromPath(path, "java")
  };
}

function normalizeSearchResultSortKey(value) {
  return String(value || "").trim().toLowerCase();
}

function addPriorityRank(map, value) {
  const key = normalizeSearchResultSortKey(value);
  if (!key || isPlaceholderHistoryValue(key) || map.has(key)) return;
  map.set(key, map.size);
}

function buildSearchResultPriorityMapsFromHistory() {
  const groupRank = new Map();
  const directoryGroupRank = new Map();
  const values = getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT);

  values.forEach(value => {
    const parts = formatHistoryFileParts(value);
    addPriorityRank(groupRank, parts[1]);
    addPriorityRank(directoryGroupRank, parts[2]);
  });

  return { groupRank, directoryGroupRank };
}

function getPriorityRank(map, value) {
  const key = normalizeSearchResultSortKey(value);
  return map && map.has(key) ? map.get(key) : Number.MAX_SAFE_INTEGER;
}

function getSearchResultLanguageRank(row) {
  const language = String(row && (row.language || inferLanguageFromPath(row.path, "")) || "").trim().toLowerCase();
  if (language === "java") return 0;
  if (language === "sql") return 1;

  const pathLanguage = inferLanguageFromPath(row && row.path, "").toLowerCase();
  if (pathLanguage === "java") return 0;
  if (pathLanguage === "sql") return 1;
  return 2;
}

function compareSearchResultRowsByHistoryPriority(a, b, priorityMaps) {
  const groupDiff = getPriorityRank(priorityMaps.groupRank, a.group) - getPriorityRank(priorityMaps.groupRank, b.group);
  if (groupDiff !== 0) return groupDiff;

  const directoryDiff = getPriorityRank(priorityMaps.directoryGroupRank, a.directoryGroup) - getPriorityRank(priorityMaps.directoryGroupRank, b.directoryGroup);
  if (directoryDiff !== 0) return directoryDiff;

  const languageDiff = getSearchResultLanguageRank(a) - getSearchResultLanguageRank(b);
  if (languageDiff !== 0) return languageDiff;

  const nameA = String(a.fileName || a.path || "");
  const nameB = String(b.fileName || b.path || "");
  const nameDiff = nameA.localeCompare(nameB, "ja", { numeric: true, sensitivity: "variant" });
  if (nameDiff !== 0) return nameDiff;

  return String(a.path || "").localeCompare(String(b.path || ""), "ja", { numeric: true, sensitivity: "variant" });
}

function sortSearchResultsForDisplay(rows) {
  const priorityMaps = buildSearchResultPriorityMapsFromHistory();
  return (Array.isArray(rows) ? rows : [])
    .map((row, index) => ({ row: normalizeSearchRow(row, index), index }))
    .sort((a, b) => {
      const diff = compareSearchResultRowsByHistoryPriority(a.row, b.row, priorityMaps);
      return diff !== 0 ? diff : a.index - b.index;
    })
    .map((item, index) => Object.assign({}, item.row, { no: String(index + 1) }));
}


function normalizeCloneDisplayValue(value, params) {
  const raw = value == null ? "" : String(value).trim();
  if (raw === "YES" || raw === "表示" || raw === "表示する") return "表示";
  if (raw === "NO" || raw === "非表示" || raw === "表示しない") return "非表示";

  // 旧WARで日本語定数が文字化けしていても、送信したclone条件から正しく表示する。
  return params && params.clone === "YES" ? "表示" : "非表示";
}

function setText(id, value) {
  const element = $(id);
  if (element) element.textContent = value == null ? "" : String(value);
}

function setSummaryFromParams(params, startedAt, endedAt, hitCount) {
  setText("summaryCount", hitCount == null ? "-" : hitCount);
  setText("summaryKeyword", params ? params.rawKeyword : "");
  setText("summaryProject", params ? (params.projectText || params.project) : "");
  setText("summaryLanguage", params ? (params.languageText || params.language) : "");
  setText("summaryStart", startedAt ? formatDateTime(startedAt) : "-");
  setText("summaryEnd", endedAt ? formatDateTime(endedAt) : "-");
  setText("summaryClone", params && params.clone === "YES" ? "表示" : "非表示");
}

function setSummaryFromServer(summary, params, startedAt, endedAt, fallbackCount) {
  const source = summary || {};
  setText("summaryCount", source.hitCount || source.count || fallbackCount || 0);
  setText("summaryKeyword", source.keyword || (params ? params.rawKeyword : ""));
  setText("summaryProject", source.project || (params ? (params.projectText || params.project) : ""));
  setText("summaryLanguage", source.language || (params ? (params.languageText || params.language) : ""));
  setText("summaryStart", formatSummaryDateTimeValue(source.startTime, startedAt));
  setText("summaryEnd", formatSummaryDateTimeValue(source.endTime, endedAt));
  setText("summaryClone", normalizeCloneDisplayValue(source.clone, params));
}

function buildInitialResultPlaceholderRows(count = INITIAL_RESULT_PLACEHOLDER_COUNT) {
  return Array.from({ length: count }, (_, index) => ({
    no: String(index + 1),
    fileName: HISTORY_PLACEHOLDER_VALUE,
    group: HISTORY_PLACEHOLDER_VALUE,
    directoryGroup: HISTORY_PLACEHOLDER_VALUE,
    path: HISTORY_PLACEHOLDER_VALUE,
    placeholder: true
  }));
}

function renderInitialResultPlaceholders() {
  renderSearchInitialEmptyState();
}

function renderSearchInitialEmptyState() {
  const body = $("resultBody");
  if (!body) return;
  const card = document.querySelector("#searchView .resultCard");
  if (card) {
    card.classList.add("isInitialEmptyResultCard");
    card.classList.remove("hasSearchResultRows");
  }
  body.innerHTML = `
    <tr class="resultEmptyStateRow">
      <td colspan="5">
        <div class="resultEmptyStateMessage">検索結果がここに表示されます</div>
      </td>
    </tr>
  `;
}

function resetInitialSearchSummary() {
  setText("summaryCount", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryKeyword", "");
  setText("summaryProject", "ALL");
  setText("summaryLanguage", "ALL");
  setText("summaryStart", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryEnd", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryClone", "非表示");
}

function bindResultRowEvents(body, normalizedRows = []) {
  if (!body) return;
  body.querySelectorAll("tr[data-index]").forEach(rowElement => {
    const index = Number(rowElement.dataset.index);
    const row = normalizedRows[index] || normalizeSearchRow({
      no: rowElement.dataset.no || String(index + 1),
      fileName: rowElement.dataset.fileName || "",
      project: rowElement.dataset.project || "",
      group: rowElement.dataset.group || "",
      directoryGroup: rowElement.dataset.directoryGroup || "",
      path: rowElement.dataset.path || "",
      href: rowElement.dataset.href || "",
      sourceUrl: rowElement.dataset.sourceUrl || "",
      preview: rowElement.getAttribute("aria-label") || rowElement.dataset.path || "",
      language: rowElement.dataset.language || ""
    }, index);
    const activate = () => {
      if (row && !row.placeholder) openCode(row.path, { row });
    };

    rowElement.addEventListener("click", activate);
    // 2026-08-04 サイト修正1: 検索結果テーブル行では全幅グレー帯を表示しない。
    // クリックでソースを開く挙動のみ維持する。
  });
}

function setResultCardState(rowCount) {
  const card = document.querySelector("#searchView .resultCard");
  if (card) {
    card.classList.remove("isInitialEmptyResultCard");
    card.classList.toggle("hasSearchResultRows", Number(rowCount || 0) > 0);
  }
}

function renderSearchHtml(resultHtml, rows = []) {
  const body = $("resultBody");
  if (!body) return;

  const normalizedRows = Array.isArray(rows) ? rows.map(normalizeSearchRow) : [];
  setResultCardState(normalizedRows.length);
  body.innerHTML = resultHtml || `
    <tr class="resultNoDataRow">
      <td colspan="5">検索結果がありません</td>
    </tr>
  `;
  bindResultRowEvents(body, normalizedRows);
}

function renderSearchRows(rows, options = {}) {
  const body = $("resultBody");
  if (!body) return;

  const isPlaceholderMode = options && options.placeholder === true;
  const normalizedRows = Array.isArray(rows) ? (isPlaceholderMode ? rows : rows.map(normalizeSearchRow)) : [];
  setResultCardState(normalizedRows.length);
  if (!normalizedRows.length) {
    body.innerHTML = `
      <tr class="resultNoDataRow">
        <td colspan="5">検索結果がありません</td>
      </tr>
    `;
    return;
  }

  body.innerHTML = normalizedRows.map((row, index) => `
    <tr class="${row.placeholder ? "isPlaceholderResultRow" : ""}"
        data-index="${index}"
        data-no="${escapeHtml(row.no || String(index + 1))}"
        data-file-name="${escapeHtml(row.fileName || "")}"
        data-project="${escapeHtml(row.project || "")}"
        data-group="${escapeHtml(row.group || "")}"
        data-directory-group="${escapeHtml(row.directoryGroup || "")}"
        data-path="${escapeHtml(row.path || "")}"
        data-language="${escapeHtml(row.language || "")}"
        aria-label="${escapeHtml(row.placeholder ? "" : (row.preview || row.path))}">
      <td>${escapeHtml(row.no || String(index + 1))}</td>
      <td>${escapeHtml(row.fileName || row.path)}</td>
      <td>${escapeHtml(row.group || row.project)}</td>
      <td>${escapeHtml(row.directoryGroup || "")}</td>
      <td>${escapeHtml(row.path || "")}</td>
    </tr>
  `).join("");

  bindResultRowEvents(body, normalizedRows);
}

function inferLanguageFromPath(path, fallback = "plaintext") {
  const value = String(path || "").toLowerCase();
  if (value.endsWith(".java")) return "java";
  if (value.endsWith(".sql")) return "sql";
  if (value.endsWith(".xml")) return "xml";
  if (value.endsWith(".jsp")) return "xml";
  if (value.endsWith(".html") || value.endsWith(".htm")) return "xml";
  if (value.endsWith(".js")) return "javascript";
  if (value.endsWith(".css")) return "css";
  if (value.endsWith(".sh")) return "bash";
  return fallback;
}

const GROUP_SELECT_SECTIONS = [
  {
    key: "NIKKO",
    label: "NIKKO",
    match: value => /^(newnikko|nikko|nk)/i.test(value)
  },
  {
    key: "BPS",
    label: "BPS",
    match: value => /^(bpnet|bps)/i.test(value)
  },
  {
    key: "SY",
    label: "→ SYはじまり",
    match: value => /^sy/i.test(value)
  },
  {
    key: "RPS",
    label: "RPS",
    match: value => /^rps/i.test(value)
  },
  {
    key: "OTHER",
    label: "その他",
    match: () => true
  }
];

function normalizeGroupProjectOption(project) {
  const source = project || {};
  const value = typeof project === "string" ? project : (source.value || source.text || "");
  const text = typeof project === "string" ? project : (source.text || source.value || "");
  const normalized = {
    value: String(value == null ? "" : value).trim(),
    text: String(text == null ? "" : text).trim(),
    selected: Boolean(source && source.selected)
  };
  if (!normalized.value && !normalized.text) return null;
  if (!normalized.text) normalized.text = normalized.value;
  if (!normalized.value) normalized.value = normalized.text;
  return normalized;
}

function isAllProjectOption(option) {
  const value = String(option && option.value || "").trim().toLowerCase();
  const text = String(option && option.text || "").trim().toLowerCase();
  return value === "all" || text === "all" || text === "すべて";
}

function groupProjectClassifierValue(option) {
  return `${option.value || ""} ${option.text || ""}`.replace(/\s+/g, "").trim();
}

function groupProjectDisplayText(option) {
  const rawText = String((option && (option.text || option.value)) || "").trim();
  if (!rawText) return "";

  // Select の value は API から来た値をそのまま保持する。
  // 画面に出す文字だけ、NIKKO. / BPS. / RPS. / SY. などのカテゴリ接頭詞を外す。
  const stripped = rawText.replace(/^(?:NewNikko|NIKKO|BPS|RPS|SY)[._-](?=.)/i, "");
  return stripped || rawText;
}

function findGroupProjectSection(option) {
  const value = groupProjectClassifierValue(option);
  return GROUP_SELECT_SECTIONS.find(section => section.match(value)) || GROUP_SELECT_SECTIONS[GROUP_SELECT_SECTIONS.length - 1];
}

const RECENT_GROUP_SELECT_SECTION_LABEL = "最近閲覧した移行グループ";

function normalizeGroupSelectCompareValue(value) {
  return String(value == null ? "" : value).trim().toLowerCase();
}

function getHistoryMigrationGroupPriority() {
  const result = [];
  const seen = new Set();
  const values = readFileHistoryValues();

  values.forEach(value => {
    const entry = splitHistoryStorageValue(value);
    const rawPath = String(entry.path || "").trim().replace(/\\/g, "/");
    if (!rawPath || isPlaceholderHistoryValue(rawPath)) return;

    const firstSegment = rawPath.replace(/^\/+/, "").split("/")[0] || "";
    const project = normalizeProjectValue(
      entry.project || (isKnownMigrationGroupSegment(firstSegment) ? firstSegment : "")
    );
    const group = normalizeMigrationGroupName(
      entry.group || extractMigrationGroupFromPath(rawPath) || project
    );

    const exactProjectKey = normalizeGroupSelectCompareValue(project);
    const groupKey = normalizeGroupSelectCompareValue(group);
    const uniqueKey = exactProjectKey || groupKey;
    if (!uniqueKey || seen.has(uniqueKey)) return;

    seen.add(uniqueKey);
    result.push({ exactProjectKey, groupKey });
  });

  return result;
}

function getGroupSelectOptionMatchScore(option, historyItem) {
  if (!option || !historyItem) return 0;

  const valueKey = normalizeGroupSelectCompareValue(option.value);
  const projectKey = normalizeGroupSelectCompareValue(normalizeProjectValue(option.value));
  if (historyItem.exactProjectKey &&
      (valueKey === historyItem.exactProjectKey || projectKey === historyItem.exactProjectKey)) {
    return 2;
  }

  if (!historyItem.groupKey) return 0;
  const candidateGroupKeys = [
    normalizeMigrationGroupName(option.value),
    normalizeMigrationGroupName(option.text),
    groupProjectDisplayText(option)
  ].map(normalizeGroupSelectCompareValue).filter(Boolean);

  return candidateGroupKeys.includes(historyItem.groupKey) ? 1 : 0;
}

function isRecentGroupSelectCopiedOption(option) {
  if (!option || !option.parentElement) return false;
  const parent = option.parentElement;
  if (String(parent.tagName || "").toUpperCase() !== "OPTGROUP") return false;
  const label = String(parent.label || parent.getAttribute("label") || "").trim();
  return label === RECENT_GROUP_SELECT_SECTION_LABEL;
}

function collectGroupSelectOptions(select, options = {}) {
  const records = [];
  const seen = new Set();
  const skipRecentCopiedOptions = options.skipRecentCopiedOptions !== false;

  Array.from(select && select.options ? select.options : []).forEach(option => {
    if (!option || option.disabled || isAllProjectOption(option)) return;
    // 上段へコピーした「最近閲覧した移行グループ」は、履歴用の別枠として扱う。
    // 元の optgroup 側の候補順まで履歴順に引きずられないよう、
    // original 一覧を組み直す材料からは除外する。
    if (skipRecentCopiedOptions && isRecentGroupSelectCopiedOption(option)) return;
    const key = normalizeGroupSelectCompareValue(option.value || option.textContent);
    if (!key || seen.has(key)) return;
    seen.add(key);
    records.push({
      value: option.value,
      text: String(option.textContent || option.value || "").trim(),
      className: option.className || "",
      title: option.title || ""
    });
  });

  return records;
}

function appendGroupSelectOption(parent, record) {
  const option = document.createElement("option");
  option.value = record.value;
  option.textContent = record.text;
  if (record.className) option.className = record.className;
  if (record.title) option.title = record.title;
  parent.appendChild(option);
}

function prioritizeGroupSelectOptionsByHistory() {
  const select = $("groupSelect");
  if (!select) return;

  const selectedValue = select.value || "ALL";
  const records = collectGroupSelectOptions(select);
  if (!records.length) return;

  // 最近閲覧した移行グループは上段へ「移動」せず、上段へコピーする。
  // 同じ履歴が複数回あっても、上段のコピーは1件だけにする。
  const copiedIndexes = new Set();
  const recentRecords = [];
  getHistoryMigrationGroupPriority().forEach(historyItem => {
    let matchedIndex = -1;
    let matchedScore = 0;

    records.forEach((record, index) => {
      if (copiedIndexes.has(index)) return;
      const score = getGroupSelectOptionMatchScore(record, historyItem);
      if (score > matchedScore) {
        matchedIndex = index;
        matchedScore = score;
      }
    });

    if (matchedIndex >= 0) {
      copiedIndexes.add(matchedIndex);
      recentRecords.push(records[matchedIndex]);
    }
  });

  // 元の分類欄には全候補を残す。上段へコピーした候補も除外しない。
  const originalBuckets = GROUP_SELECT_SECTIONS.reduce((acc, section) => {
    acc[section.key] = [];
    return acc;
  }, {});

  records.forEach(record => {
    const section = findGroupProjectSection(record);
    originalBuckets[section.key].push(record);
  });

  const fragment = document.createDocumentFragment();
  const allOption = document.createElement("option");
  allOption.value = "ALL";
  allOption.className = "groupSelectAll";
  allOption.textContent = "すべて";
  fragment.appendChild(allOption);

  if (recentRecords.length) {
    const recentGroup = document.createElement("optgroup");
    recentGroup.label = RECENT_GROUP_SELECT_SECTION_LABEL;
    recentRecords.forEach(record => appendGroupSelectOption(recentGroup, record));
    fragment.appendChild(recentGroup);
  }

  GROUP_SELECT_SECTIONS.forEach(section => {
    const items = originalBuckets[section.key] || [];
    if (!items.length) return;
    const group = document.createElement("optgroup");
    group.label = section.label;
    items.forEach(record => appendGroupSelectOption(group, record));
    fragment.appendChild(group);
  });

  select.innerHTML = "";
  select.appendChild(fragment);
  setGroupSelectValue(select, selectedValue);
  refreshGroupCombo({ resetFilter: true });
}

function buildGroupedProjectOptionsHtml(projects) {
  const normalized = (Array.isArray(projects) ? projects : [])
    .map(normalizeGroupProjectOption)
    .filter(Boolean);

  const seen = new Set(["all"]);
  const buckets = GROUP_SELECT_SECTIONS.reduce((acc, section) => {
    acc[section.key] = [];
    return acc;
  }, {});

  normalized.forEach(option => {
    if (isAllProjectOption(option)) return;
    const seenKey = String(option.value || option.text || "").trim().toLowerCase();
    if (!seenKey || seen.has(seenKey)) return;
    seen.add(seenKey);
    const section = findGroupProjectSection(option);
    buckets[section.key].push(option);
  });

  const html = [`<option value="ALL" class="groupSelectAll">すべて</option>`];
  GROUP_SELECT_SECTIONS.forEach(section => {
    const items = buckets[section.key] || [];
    if (!items.length) return;
    html.push(`<optgroup label="${escapeHtml(section.label)}">`);
    items.forEach(item => {
      const displayText = groupProjectDisplayText(item);
      const selected = item.selected ? " selected" : "";
      html.push(`<option value="${escapeHtml(item.value)}"${selected}>${escapeHtml(displayText)}</option>`);
    });
    html.push(`</optgroup>`);
  });
  return html.join("");
}

function setGroupSelectValue(select, currentValue) {
  if (!select) return;
  const target = currentValue || "ALL";
  const hasTarget = Array.from(select.options).some(option => !option.disabled && option.value === target);
  select.value = hasTarget ? target : "ALL";
}


function groupComboOptionMatches(option, query) {
  if (!query) return true;
  const text = String(option && option.textContent || "").toLowerCase();
  const value = String(option && option.value || "").toLowerCase();
  return text.includes(query) || value.includes(query);
}

function getGroupComboElements() {
  return {
    select: $("groupSelect"),
    combo: $("groupCombo"),
    button: $("groupComboButton"),
    search: $("groupComboSearch"),
    list: $("groupComboList")
  };
}

function ensureGroupComboDom() {
  const select = $("groupSelect");
  if (!select) return null;

  const field = select.closest ? select.closest(".field") : null;
  if (field) field.classList.add("fieldGroup");

  let combo = $("groupCombo");
  if (!combo) {
    combo = document.createElement("div");
    combo.id = "groupCombo";
    combo.className = "groupCombo";
    combo.innerHTML = `
      <div id="groupComboButton" class="groupComboButton" role="combobox" aria-haspopup="listbox" aria-expanded="false" aria-controls="groupComboMenu">
        <input id="groupComboSearch" class="groupComboSearch" type="text" autocomplete="off" spellcheck="false" aria-label="移行グループ検索" value="すべて">
        <span class="groupComboArrow" aria-hidden="true"></span>
      </div>
      <div id="groupComboMenu" class="groupComboMenu" role="listbox" aria-label="移行グループ選択">
        <div id="groupComboList" class="groupComboList"></div>
      </div>
    `;
    select.insertAdjacentElement("afterend", combo);
  }

  select.classList.add("nativeGroupSelect");
  if (field) field.classList.add("isComboReady");

  const elements = getGroupComboElements();
  if (!combo.dataset.bound) {
    combo.dataset.bound = "1";
    combo.dataset.searching = "0";

    const openFromDisplay = () => {
      openGroupCombo();
    };

    elements.button.addEventListener("click", event => {
      event.preventDefault();
      openFromDisplay();
    });

    elements.search.addEventListener("focus", () => {
      openFromDisplay();
      // 現在選択中の表示文字は初期表示として残す。
      // そのまま入力すると置き換えられるように全選択する。
      setTimeout(() => elements.search.select(), 0);
    });

    elements.search.addEventListener("input", () => {
      combo.dataset.searching = "1";
      openGroupCombo({ skipSelect: true });
      refreshGroupCombo({ keepOpen: true });
    });

    elements.search.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        event.preventDefault();
        closeGroupCombo();
        elements.search.focus({ preventScroll: true });
        return;
      }
      if (event.key === "Enter") {
        const firstItem = elements.list.querySelector(".groupComboItem");
        if (firstItem) {
          event.preventDefault();
          selectGroupComboValue(firstItem.dataset.value);
        }
        return;
      }
      if (event.key === "ArrowDown") {
        const firstItem = elements.list.querySelector(".groupComboItem");
        if (firstItem) {
          event.preventDefault();
          firstItem.focus({ preventScroll: true });
        }
      }
    });

    elements.list.addEventListener("click", event => {
      const item = event.target.closest ? event.target.closest(".groupComboItem") : null;
      if (!item) return;
      event.preventDefault();
      selectGroupComboValue(item.dataset.value);
    });

    elements.list.addEventListener("keydown", event => {
      const current = event.target.closest ? event.target.closest(".groupComboItem") : null;
      if (!current) return;
      const items = Array.from(elements.list.querySelectorAll(".groupComboItem"));
      const index = items.indexOf(current);
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectGroupComboValue(current.dataset.value);
        return;
      }
      if (event.key === "Escape") {
        event.preventDefault();
        closeGroupCombo();
        elements.search.focus({ preventScroll: true });
        return;
      }
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        const nextIndex = event.key === "ArrowDown" ? Math.min(items.length - 1, index + 1) : Math.max(0, index - 1);
        if (items[nextIndex]) items[nextIndex].focus({ preventScroll: true });
      }
    });

    elements.list.addEventListener("wheel", event => {
      // ドロップダウン内では、ページ側ではなくリスト側を優先して縦スクロールさせる。
      const list = elements.list;
      const maxScrollTop = list.scrollHeight - list.clientHeight;
      const goingUp = event.deltaY < 0;
      const goingDown = event.deltaY > 0;
      const canScrollUp = list.scrollTop > 0;
      const canScrollDown = list.scrollTop < maxScrollTop - 1;
      if ((goingUp && canScrollUp) || (goingDown && canScrollDown)) {
        event.stopPropagation();
      }
    }, { passive: true });

    document.addEventListener("click", event => {
      if (!combo.contains(event.target)) closeGroupCombo();
    });
  }

  refreshGroupCombo({ resetFilter: true, keepOpen: combo.classList.contains("isOpen") });
  return elements;
}

function openGroupCombo(options = {}) {
  const elements = getGroupComboElements();
  if (!elements.combo || !elements.button || !elements.search) return;
  elements.combo.classList.add("isOpen");
  elements.button.setAttribute("aria-expanded", "true");
  refreshGroupCombo({ keepOpen: true });
  if (!options.skipSelect) {
    setTimeout(() => {
      elements.search.focus({ preventScroll: true });
      if (elements.combo.dataset.searching !== "1") elements.search.select();
    }, 0);
  }
}

function closeGroupCombo() {
  const elements = getGroupComboElements();
  if (!elements.combo || !elements.button || !elements.search) return;
  elements.combo.classList.remove("isOpen");
  elements.button.setAttribute("aria-expanded", "false");
  elements.combo.dataset.searching = "0";
  elements.search.value = getSelectedGroupComboLabel(elements.select);
}

function selectGroupComboValue(value) {
  const elements = getGroupComboElements();
  if (!elements.select) return;
  const target = String(value || "ALL");
  const option = Array.from(elements.select.options).find(item => !item.disabled && item.value === target);
  elements.select.value = option ? option.value : "ALL";
  elements.select.dispatchEvent(new Event("change", { bubbles: true }));
  if (elements.combo) elements.combo.dataset.searching = "0";
  if (elements.search) elements.search.value = getSelectedGroupComboLabel(elements.select);
  refreshGroupCombo({ resetFilter: true });
  closeGroupCombo();
  if (elements.search) elements.search.focus({ preventScroll: true });
}

function getSelectedGroupComboLabel(select) {
  if (!select) return "すべて";
  const selected = select.options[select.selectedIndex];
  if (!selected || selected.disabled) return "すべて";
  return String(selected.textContent || selected.value || "すべて").trim() || "すべて";
}

function appendGroupComboItem(fragment, option, className = "") {
  const item = document.createElement("button");
  item.type = "button";
  item.className = `groupComboItem ${className}`.trim();
  item.setAttribute("role", "option");
  item.dataset.value = option.value || "ALL";
  item.textContent = String(option.textContent || option.value || "").trim();
  item.title = option.value || item.textContent;
  item.tabIndex = -1;
  fragment.appendChild(item);
  return item;
}

function refreshGroupCombo(options = {}) {
  const elements = getGroupComboElements();
  const { select, combo, search, list } = elements;
  if (!select || !combo || !search || !list) return;

  if (options.resetFilter) {
    combo.dataset.searching = "0";
    search.value = getSelectedGroupComboLabel(select);
  }

  const query = combo.dataset.searching === "1" ? String(search.value || "").trim().toLowerCase() : "";

  const fragment = document.createDocumentFragment();
  const allOptions = [];
  const sections = [];
  let currentSection = null;

  Array.from(select.options).forEach(option => {
    if (option.disabled && option.classList.contains("groupSelectHeader")) {
      currentSection = { label: String(option.textContent || "").trim(), items: [] };
      sections.push(currentSection);
      return;
    }

    if (option.value === "ALL" || option.classList.contains("groupSelectAll")) {
      allOptions.push(option);
      return;
    }

    if (!currentSection) {
      currentSection = { label: "その他", items: [] };
      sections.push(currentSection);
    }
    currentSection.items.push(option);
  });

  allOptions.forEach(option => {
    if (!query || groupComboOptionMatches(option, query)) {
      const item = appendGroupComboItem(fragment, option, "groupComboAll");
      item.setAttribute("aria-selected", select.value === option.value ? "true" : "false");
      item.classList.toggle("isSelected", select.value === option.value);
    }
  });

  let visibleDataCount = 0;
  sections.forEach(section => {
    const matchedItems = section.items.filter(option => groupComboOptionMatches(option, query));
    if (!matchedItems.length) return;

    const header = document.createElement("div");
    header.className = "groupComboHeader";
    header.textContent = section.label;
    fragment.appendChild(header);

    matchedItems.forEach(option => {
      const item = appendGroupComboItem(fragment, option, "groupComboData");
      const selected = select.value === option.value;
      item.setAttribute("aria-selected", selected ? "true" : "false");
      item.classList.toggle("isSelected", selected);
      visibleDataCount += 1;
    });
  });

  if (!fragment.childNodes.length || (query && visibleDataCount === 0 && !allOptions.some(option => groupComboOptionMatches(option, query)))) {
    const empty = document.createElement("div");
    empty.className = "groupComboEmpty";
    empty.textContent = "該当なし";
    fragment.appendChild(empty);
  }

  const previousScrollTop = list.scrollTop;
  list.innerHTML = "";
  list.appendChild(fragment);
  if (options.keepOpen) list.scrollTop = Math.min(previousScrollTop, Math.max(0, list.scrollHeight - list.clientHeight));
}

async function loadInitialData() {
  if (USE_SAMPLE_DATA) {
    prioritizeGroupSelectOptionsByHistory();
    return;
  }

  try {
    const resolved = await resolveApiBaseOnce();
    let data = resolved.initData;
    if (!data) {
      try {
        data = await fetchJsonAtBase(resolved.base, "/init", {}, {
          method: "GET",
          timeoutMs: API_ACCESS_TIMEOUT_MS
        });
        validateInitResponse(data, resolved.base);
      } catch (e) {
        clearApiBaseSelection();
        const retried = await resolveApiBaseOnce({ forceCheck: true });
        data = retried.initData;
      }
    }

    const projects = Array.isArray(data && data.projects) ? data.projects : [];
    const select = $("groupSelect");
    if (!select) return;
    if (!projects.length) {
      prioritizeGroupSelectOptionsByHistory();
      return;
    }

    const current = select.value || "ALL";
    select.innerHTML = buildGroupedProjectOptionsHtml(projects);
    setGroupSelectValue(select, current);
    prioritizeGroupSelectOptionsByHistory();
  } catch (e) {
    // HTMLに埋め込んだ初期選択肢を残し、画面全体は利用可能な状態にする。
    console.warn("/init 接続失敗。HTML初期値を使用します。", e);
    prioritizeGroupSelectOptionsByHistory();
    showCopyFeedback("Servlet未接続（初期値で表示）");
  }
}

function readArray(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) && value.length > 0 ? value : fallback;
  } catch (e) {
    return fallback;
  }
}

function saveArray(key, value) {
  localStorage.setItem(key, JSON.stringify(value.slice(0, key === FILE_HISTORY_STORAGE_KEY ? 300 : 100))); }

function isAutoFilledRecentTab(item) {
  return Boolean(item && (item.autoFilled === true || item.__autoFilled === true));
}

function createAutoFilledRecentTab(path, openedAt) {
  return {
    path: getHistoryEntryPath(path || currentCodePath || sampleFiles[0]),
    openedAt: toSafeDate(openedAt).toISOString(),
    autoFilled: true
  };
}

function ensureMinimumRecentTabs(tabs) {
  const base = (Array.isArray(tabs) ? tabs : [])
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (base.length === 0) {
    base.push(createAutoFilledRecentTab(currentCodePath || sampleFiles[0], new Date()));
  }

  // 実履歴が35件未満の場合は、画面右端にある最後の時刻から1分ずつ戻して35件まで補完する。
  // 補完行は localStorage へ保存しない。実際に閲覧された履歴と混ざらないよう autoFilled を付ける。
  let cursor = toSafeDate(base[base.length - 1].openedAt);
  const fillerPath = base[base.length - 1].path || currentCodePath || sampleFiles[0];
  while (base.length < RECENT_TAB_MIN_COUNT) {
    cursor = new Date(cursor.getTime() - 60 * 1000);
    base.push(createAutoFilledRecentTab(fillerPath, cursor));
  }

  return base.slice(0, RECENT_TAB_STORE_LIMIT);
}

function readRecentTabs() {
  // ①ホーム履歴、②上段ファイル名タブ、③ソース右側履歴は同じ元データから作る。
  // ファイル名タブは fileStorage に入っているファイル履歴分をそのまま使う。
  // ただし件数が多すぎる場合は、並び順上位100件までに制限する。
  const historyValues = readFileHistoryValues();
  const tabs = normalizeFileHistoryValues(historyValues)
    .map((value, index) => buildRecentTabFromHistoryValue(value, new Date(Date.now() - index * 60 * 1000)))
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  return tabs.map((item, index) => normalizeRecentTab(item, index));
}

function saveRecentTabs(value) {
  // 互換用。時間タブ専用のlocalStorageは使わず、krugle.history.filesを正とする。
}

function recentTabKey(item) {
  if (!item) return "";
  return `${item.openedAt || ""}::${item.path || ""}`;
}

function createRecentTabInstanceId(item, index) {
  const safeIndex = Math.max(0, Number.isFinite(Number(index)) ? Number(index) : 0);
  const path = String(item && item.path || "");
  const openedAt = String(item && item.openedAt || "");
  // PathやopenedAtが同じでも、ヘッダー上の表示位置が違えば別タブとして扱う。
  return `recent-instance:${safeIndex}:${openedAt}:${path}`;
}

function findRecentTabInstanceIndex(tabs, tabId) {
  const id = String(tabId || "");
  if (!id) return -1;
  return (Array.isArray(tabs) ? tabs : []).findIndex((item, index) => createRecentTabInstanceId(item, index) === id);
}

function findRecentTabInstanceIdForItem(targetItem) {
  const target = normalizeRecentTab(targetItem, 0);
  if (!target || !target.path || !target.openedAt) return "";

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  const targetKey = recentTabKey(target);
  let index = tabs.findIndex(item => recentTabKey(item) === targetKey);
  if (index < 0) index = tabs.findIndex(item => item.path === target.path);
  return index >= 0 ? createRecentTabInstanceId(tabs[index], index) : "";
}

function setActiveRecentTabId(tabId) {
  activeRecentTabKey = String(tabId || "");
  if (activeRecentTabKey) volatileVisitedRecentTabIds.add(activeRecentTabKey);
}

function readVisitedRecentTabIdSet() {
  return new Set(volatileVisitedRecentTabIds);
}

function updateRecentTabVisitedStyles() {
  const visitedIds = readVisitedRecentTabIdSet();
  document.querySelectorAll(".tabTime[data-tab-id]").forEach(button => {
    const visited = visitedIds.has(button.dataset.tabId || "");
    button.classList.toggle("isVisited", visited);
    if (visited) {
      button.setAttribute("data-visited", "true");
    } else {
      button.removeAttribute("data-visited");
    }
  });
}

function ensureActiveRecentVisible(tabs) {
  if (!Array.isArray(tabs) || !tabs.length) {
    recentWindowStart = 0;
    return;
  }

  const activeIndex = findRecentTabInstanceIndex(tabs, activeRecentTabKey);
  if (activeIndex < 0) {
    recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
    return;
  }

  if (activeIndex < recentWindowStart) {
    recentWindowStart = activeIndex;
  } else if (activeIndex >= recentWindowStart + RECENT_TAB_VISIBLE_LIMIT) {
    recentWindowStart = activeIndex - RECENT_TAB_VISIBLE_LIMIT + 1;
  }

  recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
}

function addRecentTab(path, meta = {}) {
  const fullPath = getHistoryEntryPath(path);
  if (!fullPath) return null;

  // localStorageへ保存される日時と、画面・SessionStorageで使う一意IDの日時を完全に一致させる。
  // 以前はDateのミリ秒付きIDと、保存後の秒単位IDがずれていたため、同じタブを特定できなかった。
  const openedAt = new Date();
  const storageValue = createHistoryStorageValue(fullPath, openedAt, meta);
  const canonicalOpenedAt = getHistoryEntryOpenedAt(storageValue, openedAt);
  const item = { path: fullPath, openedAt: canonicalOpenedAt };

  addHistory(FILE_HISTORY_STORAGE_KEY, storageValue, []);
  setActiveRecentTabId(createRecentTabInstanceId(item, 0));
  recentWindowStart = 0;
  renderRecentTabs();
  return item;
}

function toSafeDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? new Date() : date;
}

function normalizeRecentTab(item, index) {
  const fallback = sampleRecentTabs[index % sampleRecentTabs.length] || sampleRecentTabs[0];
  const path = getHistoryEntryPath(item && item.path ? item.path : (fallback ? fallback.path : sampleFiles[0]));
  const openedAtValue = item && item.openedAt ? item.openedAt : (fallback ? fallback.openedAt : new Date().toISOString());
  const openedAt = toSafeDate(openedAtValue).toISOString();
  return { path, openedAt, autoFilled: isAutoFilledRecentTab(item) };
}

function formatTabDate(isoText) {
  const date = toSafeDate(isoText);
  const week = ["日", "月", "火", "水", "木", "金", "土"][date.getDay()];
  const pad = value => String(value).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())}(${week})`;
}

// ヘッダー履歴タブには時刻ではなくファイル名を表示する。
// Unicode文字も1文字として数え、先頭12文字を超える場合だけ末尾に「…」を付ける。
function getRecentTabFileName(path) {
  const cleanPath = String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/")
    .replace(/\/+$/, "");
  const fileName = cleanPath.substring(cleanPath.lastIndexOf("/") + 1);
  return fileName || cleanPath || "-";
}

function formatRecentTabFileName(path, maxLength = 12) {
  const fileName = getRecentTabFileName(path);
  const characters = Array.from(fileName);
  return characters.length > maxLength
    ? `${characters.slice(0, maxLength).join("")}…`
    : fileName;
}


// 2026-08-03 サイト修正1: ヘッダー数字タブhover時の黒帯表示文言を整形する。
// 表示形式: ファイル名 = xxx.java ｜ nkCCIS ｜ kyak.online.jar ｜ .java
function getRawDirectoryGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "-";

  if (isKnownMigrationGroupSegment(parts[0])) {
    return parts[1] || "-";
  }

  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return parts[1] || parts[0] || "-";
  }

  return parts[0] || "-";
}

function getFileExtensionLabel(path) {
  const fileName = getRecentTabFileName(path);
  const match = String(fileName || "").match(/\.([^./\\]+)$/);
  return match ? match[1] : "-";
}

function formatRecentTabFullPathBandText(path) {
  const fileName = getRecentTabFileName(path) || "-";
  const group = extractMigrationGroupFromPath(path) || "-";
  const directoryGroup = getRawDirectoryGroupFromPath(path) || "-";
  const extension = getFileExtensionLabel(path);
  return `ファイル名 = ${fileName}　｜　${group}　｜　${directoryGroup}　｜　${extension}`;
}

function ensureRecentTabFullPathViewportBand() {
  let band = $("recentTabFullPathViewportBand");
  if (!band && document.body) {
    band = document.createElement("div");
    band.id = "recentTabFullPathViewportBand";
    band.className = "recentTabFullPathViewportBand";
    band.setAttribute("aria-hidden", "true");
    document.body.appendChild(band);
  }
  return band;
}

// 2026-08-04 サイト修正1: 全幅グレー帯の表示文字をspan単位に分割して配置する。
// 「ファイル名 = ... ｜ nkCCIS ｜ kyak.online.jar ｜ java」の各項目を別spanにする。
function splitFullWidthBandTextItems(text) {
  const value = String(text || "").trim();
  if (!value) return [];
  return value
    .split(/[　\s]*[｜|][　\s]*/)
    .map(part => part.trim())
    .filter(Boolean);
}

function renderFullWidthBandContent(band, text) {
  if (!band) return false;
  const items = splitFullWidthBandTextItems(text);
  band.textContent = "";
  if (!items.length) return false;

  const inner = document.createElement("span");
  inner.className = "recentTabFullPathBandInner";
  items.forEach(item => {
    const part = document.createElement("span");
    part.className = "recentTabFullPathBandPart";
    part.textContent = item;
    inner.appendChild(part);
  });
  band.appendChild(inner);
  return true;
}

// 2026-08-03 サイト修正7: テーブル行hoverでも、ヘッダー数字タブと同じ全幅グレー帯を表示する。
// hover中にENTERを押した場合は、その行クリックと同じ処理を実行する。
let activeFullWidthHoverBandAction = null;

// 2026-08-04 サイト修正3: hover帯からENTER/クリックで遷移した直後に、
// 遷移先で偶然カーソル下にある別要素のhover帯が即時表示されることを抑止する。
let fullWidthHoverBandSuppressUntil = 0;

function isFullWidthHoverBandSuppressed() {
  return Date.now() < fullWidthHoverBandSuppressUntil;
}

function suppressFullWidthHoverBandTemporarily(durationMs = 1200) {
  fullWidthHoverBandSuppressUntil = Date.now() + Math.max(0, Number(durationMs) || 0);
  hideRecentTabFullPathViewportBand();
}

function showRecentTabFullPathViewportBand(text, action) {
  // 2026-08-04 サイト修正2: ヘッダー数字タブhover中もENTERで対象ソースを開けるようにする。
  if (isFullWidthHoverBandSuppressed()) {
    hideRecentTabFullPathViewportBand();
    return;
  }
  activeFullWidthHoverBandAction = null;
  const band = ensureRecentTabFullPathViewportBand();
  if (!band) return;
  const hasContent = renderFullWidthBandContent(band, text);
  band.classList.toggle("isVisible", hasContent);
  document.body.classList.toggle("isRecentTabFullPathBandVisible", hasContent);
  activeFullWidthHoverBandAction = typeof action === "function" && hasContent ? action : null;
}

function hideRecentTabFullPathViewportBand() {
  activeFullWidthHoverBandAction = null;
  const band = $("recentTabFullPathViewportBand");
  if (band) {
    band.classList.remove("isVisible");
  }
  if (document.body) {
    document.body.classList.remove("isRecentTabFullPathBandVisible");
  }
}

function showInteractiveFullWidthHoverBand(text, action) {
  if (isFullWidthHoverBandSuppressed()) {
    hideRecentTabFullPathViewportBand();
    return;
  }
  const band = ensureRecentTabFullPathViewportBand();
  if (!band) return;
  const hasContent = renderFullWidthBandContent(band, text);
  band.classList.toggle("isVisible", hasContent);
  if (document.body) {
    document.body.classList.toggle("isRecentTabFullPathBandVisible", hasContent);
  }
  activeFullWidthHoverBandAction = typeof action === "function" && hasContent ? action : null;
}

function hideInteractiveFullWidthHoverBand(action) {
  if (action && activeFullWidthHoverBandAction && activeFullWidthHoverBandAction !== action) return;
  activeFullWidthHoverBandAction = null;
  const band = $("recentTabFullPathViewportBand");
  if (band) band.classList.remove("isVisible");
  if (document.body) document.body.classList.remove("isRecentTabFullPathBandVisible");
}

function isKeyboardTypingTarget(target) {
  const tagName = target && target.tagName ? target.tagName.toLowerCase() : "";
  if (["input", "select", "textarea"].includes(tagName)) return true;
  return Boolean(target && target.isContentEditable);
}

function activateFullWidthHoverBandActionByEnter(event) {
  if (!activeFullWidthHoverBandAction || !event || event.key !== "Enter") return false;
  if (isKeyboardTypingTarget(event.target)) return false;
  const action = activeFullWidthHoverBandAction;
  event.preventDefault();
  event.stopPropagation();
  suppressFullWidthHoverBandTemporarily();
  action();
  return true;
}

function createHistorySearchBandText(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim())
    .filter(Boolean);
  const keyword = parts[0] || "-";
  const group = parts[1] || "-";
  const language = parts[2] || "-";
  return `検索キーワード = ${keyword}　｜　${group}　｜　${language}`;
}

function createSearchResultBandText(row) {
  const source = row || {};
  const path = source.path || source.fullPath || source.filePath || "";
  const fileName = source.fileName || getRecentTabFileName(path) || source.path || "-";
  const group = normalizeMigrationGroupName(source.group || source.project || extractMigrationGroupFromPath(path) || "-") || "-";
  const directoryGroup = source.directoryGroup || getRawDirectoryGroupFromPath(path) || "-";
  const language = String(source.language || getFileExtensionLabel(path) || "-").replace(/^\./, "") || "-";
  return `ファイル名 = ${fileName}　｜　${group}　｜　${directoryGroup}　｜　${language}`;
}

function bindFullWidthHoverBandToRow(rowElement, text, action) {
  if (!rowElement || !text || typeof action !== "function") return;
  if (rowElement.classList.contains("isPlaceholderHistoryRow") || rowElement.classList.contains("isPlaceholderResultRow")) return;
  if (rowElement.classList.contains("resultEmptyStateRow") || rowElement.classList.contains("resultNoDataRow")) return;

  rowElement.tabIndex = 0;
  rowElement.dataset.hoverBandText = text;
  // 2026-08-04 サイト修正5: 行hover時にブラウザ標準の黒いtitleツールチップを出さない。
  // Full幅のグレー帯は独自UIで表示するため、ネイティブtitleはaria-labelへ退避する。
  const nativeTitle = rowElement.getAttribute("title");
  if (nativeTitle) {
    if (!rowElement.getAttribute("aria-label")) rowElement.setAttribute("aria-label", nativeTitle);
    rowElement.removeAttribute("title");
  }

  const show = () => showInteractiveFullWidthHoverBand(text, action);
  const hide = () => hideInteractiveFullWidthHoverBand(action);

  rowElement.addEventListener("mouseenter", show);
  rowElement.addEventListener("mouseleave", hide);
  rowElement.addEventListener("focusin", show);
  rowElement.addEventListener("focusout", hide);
  rowElement.addEventListener("click", hide);
}

// ヘッダーのファイル履歴タブは、ファイル名そのものではなく日付単位の番号で表示する。
// 同一日付内では古い順に1から採番し、999を超えた場合は1へ戻す。
function getRecentTabNumberLabelForIndex(index) {
  const safeIndex = Math.max(0, Number(index) || 0);
  const number = (safeIndex % 999) + 1;
  return String(number);
}

function createRecentTabNumberLabelMap(tabs) {
  const result = new Map();
  const groupedByDate = new Map();

  (Array.isArray(tabs) ? tabs : []).forEach((item, index) => {
    if (!item || !item.openedAt) return;
    const key = dateKey(item.openedAt);
    if (!groupedByDate.has(key)) groupedByDate.set(key, []);
    groupedByDate.get(key).push({ item, index });
  });

  groupedByDate.forEach(entries => {
    const count = entries.length;
    entries.forEach((entry, index) => {
      // tabsは新しい順。日付内の一番古いタブを1にするため、表示側は降順番号にする。
      result.set(createRecentTabInstanceId(entry.item, entry.index), getRecentTabNumberLabelForIndex(count - 1 - index));
    });
  });

  return result;
}


function dateKey(isoText) {
  const date = toSafeDate(isoText);
  const pad = value => String(value).padStart(2, "0");
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}`;
}

function shiftRecentWindow(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!tabs.length) return;

  const maxStart = Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT);
  recentWindowStart = Math.max(0, Math.min(maxStart, recentWindowStart + offset));
  manualRecentWindowShift = true;
  renderRecentTabs();
}

function renderRecentTabs() {
  const area = $("recentTabArea");
  if (!area) return;

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!activeRecentTabKey && currentView === "code" && currentCodePath && tabs.length) {
    const fallbackActiveIndex = tabs.findIndex(item => item.path === currentCodePath);
    if (fallbackActiveIndex >= 0) {
      setActiveRecentTabId(createRecentTabInstanceId(tabs[fallbackActiveIndex], fallbackActiveIndex));
    }
  }

  if (manualRecentWindowShift) {
    recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
    manualRecentWindowShift = false;
  } else {
    ensureActiveRecentVisible(tabs);
  }

  area.classList.toggle("hasMoreLeft", recentWindowStart > 0);
  area.classList.toggle("hasMoreRight", recentWindowStart + RECENT_TAB_VISIBLE_LIMIT < tabs.length);

  const visibleTabs = tabs.slice(recentWindowStart, recentWindowStart + RECENT_TAB_VISIBLE_LIMIT);
  const recentTabNumberLabelMap = createRecentTabNumberLabelMap(tabs);
  const visitedRecentTabIds = readVisitedRecentTabIdSet();
  const groups = [];
  visibleTabs.forEach(item => {
    const key = dateKey(item.openedAt);
    const last = groups[groups.length - 1];
    if (!last || last.key !== key) {
      groups.push({ key, label: formatTabDate(item.openedAt), count: 1 });
    } else {
      last.count += 1;
    }
  });

  area.innerHTML = `
    <button class="recentNavArrow recentNavArrowLeft" type="button" aria-label="左のタブへ移動" title="左のタブへ移動">
      <svg class="recentNavIconSvg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M14.2 4.8L8.3 12l5.9 7.2" />
      </svg>
    </button>
    <div class="recentDateRow">
      ${groups.map((group, index) => {
        const prevGroup = groups[index - 1];
        const afterNarrowDateGroup = !!prevGroup && prevGroup.count <= 2;
        const className = afterNarrowDateGroup ? "recentDateGroup isAfterNarrowDateGroup" : "recentDateGroup";
        const shiftPx = 0;
        const extraWidthPx = group.count <= 2 && index < groups.length - 1 ? (group.count === 1 ? 70 : 44) : 0;
        return `
        <div class="${className}" style="--tab-count:${group.count}; --date-shift-x:${shiftPx}px; --date-extra-width:${extraWidthPx}px">
          ${escapeHtml(group.label)}
        </div>
      `;
      }).join("")}
    </div>
    <div class="recentTimeRow">
      ${visibleTabs.map((item, index) => {
        const absoluteIndex = recentWindowStart + index;
        const tabId = createRecentTabInstanceId(item, absoluteIndex);
        const isVisited = visitedRecentTabIds.has(tabId);
        const fullFileName = getRecentTabFileName(item.path);
        const numberLabel = recentTabNumberLabelMap.get(tabId) || getRecentTabNumberLabelForIndex(index);
        const fullPathBandText = formatRecentTabFullPathBandText(item.path);
        return `
          <button class="tabTime${isVisited ? " isVisited" : ""}${tabId === activeRecentTabKey ? " isActive" : ""}" type="button"
                  data-tab-id="${escapeHtml(tabId)}"
                  data-path="${escapeHtml(item.path)}"
                  data-opened-at="${escapeHtml(item.openedAt)}"
                  data-recent-index="${absoluteIndex}"
                  data-full-file-name="${escapeHtml(fullFileName)}"
                  data-hover-band-text="${escapeHtml(fullPathBandText)}"
                  data-number-label="${escapeHtml(numberLabel)}"
                  aria-label="${escapeHtml(`ファイル ${fullFileName}、タブ番号 ${numberLabel}`)}"
                  title="${escapeHtml(fullFileName)}">
            <span class="recentTabLabel">${escapeHtml(numberLabel)}</span>
            <span class="recentTabTooltip" role="tooltip" aria-hidden="true">${escapeHtml(fullFileName)}</span>
            <span class="recentTabFullPathBand" role="tooltip" aria-hidden="true">${escapeHtml(fullPathBandText)}</span>
          </button>
        `;
      }).join("")}
    </div>
    <button class="recentNavArrow recentNavArrowRight" type="button" aria-label="右のタブへ移動" title="右のタブへ移動">
      <svg class="recentNavIconSvg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M9.8 4.8L15.7 12l-5.9 7.2" />
      </svg>
    </button>
  `;

  area.querySelectorAll(".tabTime").forEach(button => {
    const openRecentTabSourceFromHeader = () => {
      const index = Number(button.dataset.recentIndex);
      const item = tabs[index];
      if (item) openCode(item.path, { addRecent: false, recentItem: item, recentTabId: button.dataset.tabId || "" });
    };
    const showHeaderHoverBand = () => {
      showRecentTabFullPathViewportBand(
        button.dataset.hoverBandText || button.dataset.path || "",
        openRecentTabSourceFromHeader
      );
    };

    button.addEventListener("mouseenter", showHeaderHoverBand);
    button.addEventListener("mouseleave", hideRecentTabFullPathViewportBand);
    button.addEventListener("focus", showHeaderHoverBand);
    button.addEventListener("blur", hideRecentTabFullPathViewportBand);
    button.addEventListener("click", () => {
      suppressFullWidthHoverBandTemporarily();
      openRecentTabSourceFromHeader();
    });
  });

  const recentPrevButton = area.querySelector(".recentNavArrowLeft");
  const recentNextButton = area.querySelector(".recentNavArrowRight");
  if (recentPrevButton) {
    recentPrevButton.addEventListener("click", event => {
      event.preventDefault();
      // ページ送りではなく、表示ウィンドウを1タブ分だけ左へずらす。
      shiftRecentWindow(-1);
    });
  }
  if (recentNextButton) {
    recentNextButton.addEventListener("click", event => {
      event.preventDefault();
      // ページ送りではなく、表示ウィンドウを1タブ分だけ右へずらす。
      shiftRecentWindow(1);
    });
  }

  updateRecentTabVisitedStyles();
}

function openRelativeRecentTab(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!tabs.length) return;

  let index = findRecentTabInstanceIndex(tabs, activeRecentTabKey);
  if (index < 0) index = tabs.findIndex(item => item.path === currentCodePath);
  if (index < 0) index = 0;

  const nextIndex = (index + offset + tabs.length) % tabs.length;
  const next = tabs[nextIndex];
  if (next && next.path) {
    openCode(next.path, {
      addRecent: false,
      recentItem: next,
      recentTabId: createRecentTabInstanceId(next, nextIndex)
    });
  }
}

function getHeaderKeyboardNavigationRecentTabs() {
  return readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);
}

function getHeaderKeyboardNavigationItems() {
  const items = [
    { type: "view", viewName: "home" },
    { type: "view", viewName: "search" }
  ];

  getHeaderKeyboardNavigationRecentTabs().forEach((item, index) => {
    items.push({
      type: "recent",
      recentItem: item,
      recentIndex: index,
      recentTabId: createRecentTabInstanceId(item, index)
    });
  });

  return items;
}

function getCurrentHeaderKeyboardNavigationIndex(items) {
  if (!Array.isArray(items) || !items.length) return 0;
  if (currentView === "search") return Math.min(1, items.length - 1);
  if (currentView !== "code") return 0;

  const activeIndex = items.findIndex(item =>
    item &&
    item.type === "recent" &&
    item.recentTabId === activeRecentTabKey
  );
  if (activeIndex >= 0) return activeIndex;

  const pathIndex = items.findIndex(item =>
    item &&
    item.type === "recent" &&
    item.recentItem &&
    item.recentItem.path === currentCodePath
  );
  return pathIndex >= 0 ? pathIndex : Math.min(2, items.length - 1);
}

function activateHeaderKeyboardNavigationItem(item) {
  if (!item) return;

  if (item.type === "view") {
    showView(item.viewName);
    return;
  }

  if (item.type === "recent" && item.recentItem && item.recentItem.path) {
    openCode(item.recentItem.path, {
      addRecent: false,
      recentItem: item.recentItem,
      recentTabId: item.recentTabId || createRecentTabInstanceId(item.recentItem, item.recentIndex)
    });
  }
}

function moveMainTabByKeyboard(offset) {
  // ArrowRight / ArrowLeft は、ヘッダー全体のタブ順で移動する。
  // Home → Search → Source Tab 1 → Source Tab 2 → ... → Last → Home の循環。
  // 逆方向は Home ← Search ← Source Tab 1 ← ... ← Last の循環にする。
  const items = getHeaderKeyboardNavigationItems();
  if (!items.length) return;

  const currentIndex = getCurrentHeaderKeyboardNavigationIndex(items);
  const nextIndex = (currentIndex + offset + items.length) % items.length;
  activateHeaderKeyboardNavigationItem(items[nextIndex]);
}

function addHistory(key, value, fallback) {
  if (!value) return;
  if (key === FILE_HISTORY_STORAGE_KEY) {
    const current = readArray(key, fallback || []);
    const next = normalizeFileHistoryValues([value].concat(current));
    saveArray(key, next);
    prioritizeGroupSelectOptionsByHistory();
    return;
  }
  const next = readArray(key, fallback).filter(item => item !== value);
  next.unshift(value);
  saveArray(key, next);
}

function buildPlaceholderHistory(count = INITIAL_HISTORY_SAMPLE_COUNT) {
  return Array.from({ length: count }, () => HISTORY_PLACEHOLDER_VALUE);
}

function isPlaceholderHistoryValue(value) {
  return String(value || "").trim() === HISTORY_PLACEHOLDER_VALUE;
}

function isValidFileHistoryPath(path) {
  const text = String(path || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) return false;

  // 過去版で localStorage に入った「ファイル名だけ」「列分割後の断片」などのゴミを除外する。
  // ファイル履歴は、NIKKO.nkCCIS/kyak.online.jar/... のようなフルパスだけを正とする。
  if (text.indexOf("/") < 0) return false;
  if (/^(undefined|null|nan)$/i.test(text)) return false;
  return true;
}

function cleanDirectoryGroupName(value) {
  const text = String(value || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) return text;

  // 2列目のパス要素が kyak.online.jar / xxx.war / xxx.zip の場合は、
  // DIRGROUP としては拡張子を落として kyak.online の形で表示する。
  return text.replace(/\.(jar|war|ear|zip)$/i, "");
}


function normalizeProjectValue(value) {
  const text = String(value || "").trim().replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
  if (!text || /^(ALL|すべて)$/i.test(text)) return "";
  return text;
}

function resolveProjectFromGroup(group) {
  const normalizedGroup = normalizeMigrationGroupName(group);
  if (!normalizedGroup) return "";

  const select = $("groupSelect");
  if (!select || !select.options) return "";

  const matches = Array.from(select.options)
    .map(option => normalizeProjectValue(option.value))
    .filter(value => value && normalizeMigrationGroupName(value).toLowerCase() === normalizedGroup.toLowerCase());
  return matches.length === 1 ? matches[0] : "";
}

function buildCompleteKruglePath(path, project, group) {
  let rawPath = String(path || "").trim().replace(/\\/g, "/");
  rawPath = rawPath.replace(/^\/+/, "").replace(/\/{2,}/g, "/");
  if (!rawPath || isPlaceholderHistoryValue(rawPath)) return rawPath;

  const normalizedProject = normalizeProjectValue(project) || resolveProjectFromGroup(group);
  const firstSegment = rawPath.split("/")[0] || "";

  // すでに NIKKO.nkCCIS/... のような完全パスなら、そのまま保持する。
  if (isKnownMigrationGroupSegment(firstSegment)) return rawPath;
  if (!normalizedProject) return rawPath;
  if (rawPath === normalizedProject || rawPath.startsWith(`${normalizedProject}/`)) return rawPath;
  return `${normalizedProject}/${rawPath}`;
}

function getPathPartsForGroup(path) {
  return String(path || "")
    .split("/")
    .map(part => part.trim())
    .filter(Boolean);
}

function isKnownMigrationGroupSegment(value) {
  return /^(NIKKO|BPS|RPS)\./i.test(String(value || "").trim());
}

function isLikelyDirectoryOnlyPath(parts) {
  if (!Array.isArray(parts) || parts.length < 2) return false;
  return /^(lib|java|src|source|sql|xml|jsp|sh|config|conf|classes)$/i.test(parts[1]);
}

function extractProjectFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";
  if (isKnownMigrationGroupSegment(parts[0])) return parts[0];
  const group = extractMigrationGroupFromPath(path);
  return resolveProjectFromGroup(group) || group || "";
}

function extractMigrationGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";

  // NIKKO.nkCCIS/... / BPS.xxx/... / RPS.xxx/... は1階層目が移行グループ。
  if (isKnownMigrationGroupSegment(parts[0])) {
    return normalizeMigrationGroupName(parts[0]);
  }

  // SMBC/smbc_dbac/... のように1階層目が移行グループ、2階層目がディレクトリグループの形式。
  // kayk.online/lib/... のように2階層目が lib の場合は、1階層目をディレクトリグループとして扱う。
  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return normalizeMigrationGroupName(parts[0]);
  }

  return "";
}

function extractDirectoryGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";

  if (isKnownMigrationGroupSegment(parts[0])) {
    return cleanDirectoryGroupName(parts[1] || "");
  }

  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return cleanDirectoryGroupName(parts[1] || parts[0]);
  }

  return cleanDirectoryGroupName(parts[0]);
}

function stringifyHistoryValueForCompare(value) {
  const entry = splitHistoryStorageValue(value);
  return [
    getHistoryEntryPath(value) || "",
    entry.openedAtRaw || "",
    entry.fileName || "",
    entry.project || "",
    entry.group || "",
    entry.directoryGroup || ""
  ].join("");
}

function normalizeHistoryValues(values) {
  const result = [];
  const used = new Set();
  (Array.isArray(values) ? values : []).forEach(value => {
    const text = String(value || "").trim();
    const path = getHistoryEntryPath(value);
    if (!text || !path || isPlaceholderHistoryValue(path) || used.has(path)) return;
    used.add(path);
    result.push(text);
  });
  return result;
}

function compareFileHistoryItems(a, b) {
  const timeDiff = toSafeDate(b.openedAt).getTime() - toSafeDate(a.openedAt).getTime();
  if (timeDiff !== 0) return timeDiff;
  return String(a.path || "").localeCompare(String(b.path || ""));
}

function normalizeFileHistoryValues(values) {
  const map = new Map();
  (Array.isArray(values) ? values : []).forEach((value, index) => {
    const entry = splitHistoryStorageValue(value);
    const path = buildCompleteKruglePath(entry.path, entry.project, entry.group);
    if (!isValidFileHistoryPath(path)) return;

    const openedAt = parseHistoryOpenedAt(entry.openedAtRaw, new Date(Date.now() - index * 60 * 1000));
    const normalizedValue = createHistoryStorageValue(path, openedAt, {
      fileName: entry.fileName,
      project: entry.project,
      group: entry.group,
      directoryGroup: entry.directoryGroup,
      initialSeed: entry.initialSeed,
      seedMarker: entry.seedMarker
    });
    const existing = map.get(path);
    if (!existing || toSafeDate(openedAt).getTime() > toSafeDate(existing.openedAt).getTime()) {
      map.set(path, { path, openedAt, value: normalizedValue });
    }
  });

  return Array.from(map.values())
    .sort(compareFileHistoryItems)
    .map(item => item.value);
}

function seedFileHistoryStorage(key, values, sampleValues) {
  let result = normalizeFileHistoryValues(values);
  if (!result.length) {
    result = normalizeFileHistoryValues(sampleValues);
  }

  const raw = Array.isArray(values) ? values.map(stringifyHistoryValueForCompare).filter(Boolean) : [];
  const normalized = result.map(stringifyHistoryValueForCompare).filter(Boolean);
  if (!USE_SAMPLE_DATA && normalized.join("") !== raw.join("")) {
    saveArray(key, result);
  }
  return result;
}

function getDisplayFileHistoryRows(values, count = FILE_HISTORY_HOME_DISPLAY_LIMIT) {
  return normalizeFileHistoryValues(values).slice(0, count);
}

function addSearchResultsToFileHistory(rows, openedAt = new Date()) {
  if (USE_SAMPLE_DATA) return;
  const additions = (Array.isArray(rows) ? rows : [])
    .map((row, index) => normalizeSearchRow(row, index))
    .filter(row => row && !row.placeholder && isValidFileHistoryPath(row.path))
    .map(row => createHistoryStorageValue(row.path, openedAt, {
      fileName: row.fileName,
      project: row.project,
      group: row.group,
      directoryGroup: row.directoryGroup
    }));
  if (!additions.length) return;

  const current = readArray(FILE_HISTORY_STORAGE_KEY, []);
  saveArray(FILE_HISTORY_STORAGE_KEY, normalizeFileHistoryValues(additions.concat(current)));
  prioritizeGroupSelectOptionsByHistory();
  sessionRecentTabs = null;
  renderRecentTabs();
}

function seedHistoryStorage(key, values, sampleValues, count = INITIAL_HISTORY_SAMPLE_COUNT) {
  const original = normalizeHistoryValues(values);
  const result = original.slice();
  const used = new Set(result);

  (Array.isArray(sampleValues) ? sampleValues : []).forEach(value => {
    if (result.length >= count) return;
    const text = String(value || "").trim();
    if (!text || isPlaceholderHistoryValue(text) || used.has(text)) return;
    used.add(text);
    result.push(text);
  });

  // 初回表示や履歴20件未満の環境では、サンプルを含めて20件までlocalStorageへ保存する。
  // 後で固定サンプル値に差し替えるだけで、全ユーザーの初回起動時に20件入った状態を再現できる。
  // 過去版で入った「-」補完も、保存し直すことで履歴データから除去する。
  const rawLength = Array.isArray(values) ? values.length : 0;
  const hasStorageDifference = rawLength !== original.length || result.join("") !== original.join("");
  if (!USE_SAMPLE_DATA && hasStorageDifference) {
    saveArray(key, result);
  }
  return result;
}

function getDisplayHistoryRows(values, count = INITIAL_HISTORY_SAMPLE_COUNT) {
  return normalizeHistoryValues(values).slice(0, count);
}

function normalizeMigrationGroupName(value) {
  const text = String(value || "").trim();
  if (!text) return "";

  // NIKKO. / BPS. / RPS. 始まりは、その接頭辞を空文字へ置換する。
  // 例: NIKKO.nkCCIS -> nkCCIS
  const withoutKnownPrefix = text.replace(/^(NIKKO|BPS|RPS)\./, "");
  if (withoutKnownPrefix !== text) return withoutKnownPrefix;

  // 既存データ互換: SMBC.SMBC / fast2024.fast2024 / nikkoEZ.nikkoEZ なども
  // 画面上は後半の移行グループ名だけを表示する。
  const dotIndex = text.indexOf(".");
  return dotIndex >= 0 ? text.substring(dotIndex + 1) : text;
}

function formatHistoryFileParts(value) {
  const entry = splitHistoryStorageValue(value);
  const path = getHistoryEntryPath(value) || entry.path;
  if (!isValidFileHistoryPath(path)) {
    return [HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE];
  }

  const pathParts = getPathPartsForGroup(path);
  const fileName = String(entry.fileName || pathParts[pathParts.length - 1] || path).trim();

  // 保存済みメタデータが空、旧形式、または「-」でも、完全パス／projectから必ず補完する。
  // 例: NIKKO.nkCCIS/kyak.online.jar/... -> nkCCIS / kyak.online
  const storedGroup = normalizeMigrationGroupName(entry.group);
  const pathGroup = normalizeMigrationGroupName(extractMigrationGroupFromPath(path));
  const projectGroup = normalizeMigrationGroupName(entry.project);
  const group = [storedGroup, pathGroup, projectGroup]
    .find(part => part && !isPlaceholderHistoryValue(part)) || HISTORY_PLACEHOLDER_VALUE;

  const storedDirectoryGroup = cleanDirectoryGroupName(entry.directoryGroup);
  const pathDirectoryGroup = cleanDirectoryGroupName(extractDirectoryGroupFromPath(path));
  const directoryGroup = [storedDirectoryGroup, pathDirectoryGroup]
    .find(part => part && !isPlaceholderHistoryValue(part)) || HISTORY_PLACEHOLDER_VALUE;

  return [fileName || HISTORY_PLACEHOLDER_VALUE, group, directoryGroup];
}

function formatHistoryFileHtml(value) {
  const parts = formatHistoryFileParts(value);
  const names = ["name", "group", "area"];
  return parts.map((part, index) =>
    `<span class="historyToken historyToken-${names[index] || index}">${escapeHtml(part)}</span>`
  ).join("");
}

function formatHistoryFileCellsHtml(value, cellClassPrefix = "historyFile") {
  const parts = formatHistoryFileParts(value);
  const classes = ["Name", "Group", "Dir"];
  return parts.map((part, index) =>
    `<td class="${cellClassPrefix}${classes[index]}">${escapeHtml(part)}</td>`
  ).join("");
}


function renderGlobalHistoryMini(displayFiles) {
  const body = $("globalHistoryMiniBody");
  if (!body) return;

  // ソースコード画面右側もホーム左側と同じ表示配列・同じセル生成処理をそのまま使用する。
  // 件数、並び順、ファイル名、移行グループ、ディレクトリグループを別仕様にしない。
  const source = Array.isArray(displayFiles) ? displayFiles : [];

  body.innerHTML = source.map((value, index) => {
    const path = getHistoryEntryPath(value);
    const isPlaceholder = !isValidFileHistoryPath(path);
    return `
      <tr class="globalHistoryMiniRow${isPlaceholder ? " isPlaceholderHistoryRow" : ""}" data-path="${isPlaceholder ? "" : escapeHtml(path)}" aria-label="${escapeHtml(path)}">
        <td>${index + 1}</td>
        ${formatHistoryFileCellsHtml(value, "historyFile")}
      </tr>
    `;
  }).join("");

  body.querySelectorAll("tr").forEach(row => {
    const activate = () => {
      if (!row.dataset.path) return;
      openCode(row.dataset.path);
    };
    row.addEventListener("click", activate);
    if (row.dataset.path) {
      bindFullWidthHoverBandToRow(row, formatRecentTabFullPathBandText(row.dataset.path), activate);
    }
  });
}

function formatHistorySearchHtml(value) {
  if (isPlaceholderHistoryValue(value)) {
    return [HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE]
      .map((part, index) =>
        `<span class="historySearchToken historySearchToken-${index}">${escapeHtml(part)}</span>`
      )
      .join("");
  }

  return String(value || "")
    .split("|")
    .map(part => part.trim())
    .filter(Boolean)
    .map((part, index) =>
      `<span class="historySearchToken historySearchToken-${index}">${escapeHtml(part)}</span>`
    )
    .join("");
}

// 2026-07-29 再開修正3: AJAX検索ではブラウザ標準の入力履歴に残らないため、
// Krugle+ の検索履歴を datalist へ反映し、検索キーワード入力欄で候補表示できるようにする。
function parseSearchHistoryValue(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim());

  return {
    keyword: parts[0] || "",
    group: parts[1] || "ALL",
    language: parts[2] || "ALL"
  };
}

function getKeywordHistorySuggestions(values, limit = 100) {
  const result = [];
  const used = new Set();

  (Array.isArray(values) ? values : []).forEach(value => {
    const keyword = parseSearchHistoryValue(value).keyword;
    if (!keyword || isPlaceholderHistoryValue(keyword)) return;

    const key = keyword.toLowerCase();
    if (used.has(key)) return;

    used.add(key);
    result.push(keyword);
  });

  return result.slice(0, limit);
}

function renderKeywordHistoryDatalist(values) {
  const list = $("keywordHistoryList");
  if (!list) return;

  let sourceValues = Array.isArray(values)
    ? values
    : (USE_SAMPLE_DATA ? sampleSearchWords : readArray(SEARCH_HISTORY_STORAGE_KEY, []));

  if (!USE_SAMPLE_DATA && !Array.isArray(values)) {
    sourceValues = seedHistoryStorage(SEARCH_HISTORY_STORAGE_KEY, sourceValues, sampleSearchWords, INITIAL_HISTORY_SAMPLE_COUNT);
  }

  const suggestions = getKeywordHistorySuggestions(sourceValues);
  list.innerHTML = suggestions
    .map(keyword => `<option value="${escapeHtml(keyword)}"></option>`)
    .join("");
}

function setSelectValueByTextOrValue(selectElement, value, fallback = "ALL") {
  if (!selectElement) return;
  const target = String(value || fallback).trim();
  const normalizedTarget = target.toLowerCase();
  const option = Array.from(selectElement.options).find(item => {
    const optionValue = String(item.value || "").trim().toLowerCase();
    const optionText = String(item.textContent || "").trim().toLowerCase();
    return optionValue === normalizedTarget || optionText === normalizedTarget;
  });
  selectElement.value = option ? option.value : fallback;
}

function fillSearchFormFromHistory(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim());

  const keyword = parts[0] || "";
  const group = parts[1] || "ALL";
  const language = parts[2] || "ALL";

  const keywordInput = $("keywordInput");
  if (keywordInput) keywordInput.value = keyword;

  setSelectValueByTextOrValue($("groupSelect"), group, "ALL");
  refreshGroupCombo({ resetFilter: true });
  setSelectValueByTextOrValue($("languageSelect"), language, "ALL");
}

function openSearchFromHistory(value) {
  fillSearchFormFromHistory(value);
  showView("search");
  runSearch(true, "normal");
}

function resetStoredHistories() {
  // 履歴以外のlocalStorage設定やSessionStorageは残し、対象の2履歴だけを初期化する。
  localStorage.removeItem(FILE_HISTORY_STORAGE_KEY);
  localStorage.removeItem(SEARCH_HISTORY_STORAGE_KEY);
  localStorage.removeItem(FILE_HISTORY_INITIALIZED_VERSION_KEY);

  const initialFiles = createInitialFileHistorySeedValues().slice(0, INITIAL_HISTORY_SAMPLE_COUNT);
  const initialWords = normalizeHistoryValues(sampleSearchWords).slice(0, INITIAL_HISTORY_SAMPLE_COUNT);

  saveArray(FILE_HISTORY_STORAGE_KEY, initialFiles);
  saveArray(SEARCH_HISTORY_STORAGE_KEY, initialWords);
  localStorage.setItem(FILE_HISTORY_INITIALIZED_VERSION_KEY, FILE_HISTORY_INITIAL_VERSION);
  prioritizeGroupSelectOptionsByHistory();

  // 時刻タブも初期化後のファイル履歴から再構築する。
  sessionRecentTabs = null;
  recentWindowStart = 0;
  activeRecentTabKey = "";
  volatileVisitedRecentTabIds.clear();
  renderRecentTabs();
  renderHistory();
  showCopyFeedback("履歴を30件の初期データに戻しました");
}

function renderHistory() {
  let files = readFileHistoryValues();
  let words = USE_SAMPLE_DATA ? sampleSearchWords : readArray(SEARCH_HISTORY_STORAGE_KEY, []);

  if (!USE_SAMPLE_DATA) {
    words = seedHistoryStorage(SEARCH_HISTORY_STORAGE_KEY, words, sampleSearchWords, INITIAL_HISTORY_SAMPLE_COUNT);
  }

  const displayFiles = getDisplayFileHistoryRows(files, FILE_HISTORY_HOME_DISPLAY_LIMIT);
  const displayWords = getDisplayHistoryRows(words, INITIAL_HISTORY_SAMPLE_COUNT);

  renderKeywordHistoryDatalist(words);
  renderGlobalHistoryMini(displayFiles);

  $("historyFileBody").innerHTML = displayFiles.map((value, index) => {
    const path = getHistoryEntryPath(value);
    const isPlaceholder = !isValidFileHistoryPath(path);
    return `
      <tr class="${isPlaceholder ? "isPlaceholderHistoryRow" : ""}" data-path="${isPlaceholder ? "" : escapeHtml(path)}" aria-label="${escapeHtml(path)}">
        <td>${index + 1}</td>
        ${formatHistoryFileCellsHtml(value, "historyFile")}
      </tr>
    `;
  }).join("");

  $("historySearchBody").innerHTML = displayWords.map((value, index) => {
    const isPlaceholder = isPlaceholderHistoryValue(value);
    return `
      <tr class="${isPlaceholder ? "isPlaceholderHistoryRow" : ""}" data-keyword="${isPlaceholder ? "" : escapeHtml(value)}" aria-label="${escapeHtml(value)}">
        <td>${index + 1}</td>
        <td class="historySearchText">${formatHistorySearchHtml(value)}</td>
      </tr>
    `;
  }).join("");

  document.querySelectorAll("#historyFileBody tr").forEach(row => {
    const activate = () => {
      if (!row.dataset.path) return;
      openCode(row.dataset.path);
    };
    row.addEventListener("click", activate);
    if (row.dataset.path) {
      bindFullWidthHoverBandToRow(row, formatRecentTabFullPathBandText(row.dataset.path), activate);
    }
  });
  document.querySelectorAll("#historySearchBody tr").forEach(row => {
    const activate = () => {
      if (!row.dataset.keyword) return;
      openSearchFromHistory(row.dataset.keyword);
    };
    row.addEventListener("click", activate);
    if (row.dataset.keyword) {
      bindFullWidthHoverBandToRow(row, createHistorySearchBandText(row.dataset.keyword), activate);
    }
  });
}

function setActiveTab(viewName) {
  document.querySelectorAll(".tabBtn").forEach(button => button.classList.remove("isActive"));
  if (viewName !== "code") {
    document.querySelectorAll(".tabTime").forEach(button => button.classList.remove("isActive"));
  }
  const target = document.querySelector(`.tabBtn[data-view="${viewName}"]:not(.tabFile)`);
  if (target) target.classList.add("isActive"); }

function showView(viewName, options = {}) {
  if ((viewName === "home" || viewName === "search") && options.recordNavigation !== false) {
    recordTabNavigation(createViewTabNavigationEntry(viewName));
  }

  // コード取得中にホーム・検索結果へ戻った場合、遅れて返った/source結果で状態を上書きさせない。
  if (viewName !== "code") sourceOpenRequestSequence += 1;

  currentView = viewName;
  document.body.classList.toggle("isCodeScreen", viewName === "code");
  document.querySelectorAll(".viewBlock").forEach(view => view.classList.remove("isVisible"));
  const targetView = $(`${viewName}View`);
  if (targetView) targetView.classList.add("isVisible");
  setActiveTab(viewName);
  if (viewName === "home") renderHistory();
  if (viewName === "code") renderCode();
}

function getDirectoryGroup(path) {
  return extractDirectoryGroupFromPath(path);
}

async function runSearch(saveHistory = true, mode = "normal", options = {}) {
  const startedAt = new Date();
  const params = options && options.paramsOverride
    ? Object.assign({}, options.paramsOverride)
    : buildSearchParams(mode);
  lastSearchMode = mode;
  lastSearchParams = params;

  if (saveHistory) {
    addHistory(SEARCH_HISTORY_STORAGE_KEY, `${params.rawKeyword} | ${params.projectText || params.project} | ${params.languageText || params.language}`, []);
    renderKeywordHistoryDatalist();
  }

  setSummaryFromParams(params, startedAt, null, "検索中");
  const body = $("resultBody");
  if (body) body.innerHTML = `<tr><td colspan="5">検索中...</td></tr>`;

  if (USE_SAMPLE_DATA) {
    const endedAt = new Date(startedAt.getTime() + 1000);
    lastSearchResults = sortSearchResultsForDisplay(sampleResults);
    setSummaryFromParams(params, startedAt, endedAt, lastSearchResults.length);
    // 2026-08-04 サイト修正2: 検索実行だけでは、検索結果を閲覧履歴・ヘッダー数字タブへ登録しない。
    // 実際に検索結果行をクリック、またはEnterで開いたときだけ openCode() 経由で登録する。
    renderSearchRows(lastSearchResults);
    return;
  }

  try {
    const data = await fetchJson("/search", {
      path_output_format: "PATH",
      keyword: params.keyword,
      project: params.project,
      language: params.languageForApi,
      findin: params.findin,
      clone: params.clone,
      source_disp: params.source_disp
    });
    const endedAt = new Date();
    const serverRows = Array.isArray(data.rows) ? data.rows : data.results;
    lastSearchResults = sortSearchResultsForDisplay(serverRows);
    setSummaryFromServer(data.summary, params, startedAt, endedAt, lastSearchResults.length);
    // 2026-08-04 サイト修正2: 検索実行だけでは、検索結果を閲覧履歴・ヘッダー数字タブへ登録しない。
    // 実際に検索結果行をクリック、またはEnterで開いたときだけ openCode() 経由で登録する。
    // 2026-08-03 サイト修正4: 検索結果はクライアント側で優先順に並び替えるため、
    // サーバー生成HTMLではなく、並び替え後の行データから再描画する。
    renderSearchRows(lastSearchResults);
  } catch (e) {
    console.error(e);
    lastSearchResults = [];
    setSummaryFromParams(params, startedAt, new Date(), 0);
    if (body) body.innerHTML = `<tr><td colspan="5">/search 接続失敗：${escapeHtml(e.message)}</td></tr>`;
    showCopyFeedback("/search 接続失敗");
  }
}

function applyInitialSearchCondition() {
  const keywordInput = $("keywordInput");
  const groupSelect = $("groupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  if (keywordInput) keywordInput.value = INITIAL_SEARCH_CONDITION.keyword;
  setSelectValueByTextOrValue(groupSelect, INITIAL_SEARCH_CONDITION.project, "ALL");
  setSelectValueByTextOrValue(languageSelect, INITIAL_SEARCH_CONDITION.language, "ALL");

  // 添付画面と同じく「Clone 非表示」は未チェック。APIには clone=YES を渡す。
  if (cloneCheck) cloneCheck.checked = false;

  // カスタム移行グループ表示が存在する場合も、選択文字を同期する。
  refreshGroupCombo({ resetFilter: true });
}

async function loadInitialSearchResult() {
  // 初回表示のMock/初期検索は、検索条件入力欄へ値を入れない。
  // 表示結果だけ KYF1940 / NIKKO.nkCCIS / Java 条件で取得する。
  clearInitialSearchForm();
  await runSearch(false, INITIAL_SEARCH_CONDITION.mode, {
    paramsOverride: buildSearchParamsFromCondition(INITIAL_SEARCH_CONDITION, INITIAL_SEARCH_CONDITION.mode),
    // 初期表示用の52件を、閲覧履歴・ヘッダー履歴へ自動登録しない。
    addResultsToFileHistory: false
  });
  clearInitialSearchForm();
}

async function openCode(path, options = {}) {
  const requestId = ++sourceOpenRequestSequence;
  currentCodePath = getHistoryEntryPath(path || currentCodePath);
  const requestedPath = currentCodePath;
  currentCodeMeta = options.row ? Object.assign({}, options.row) : { path: currentCodePath };
  currentCodeMeta.path = currentCodePath;
  currentSourceText = "読み込み中...";
  currentSourceLanguage = inferLanguageFromPath(currentCodePath, currentCodeMeta.language || "java");
  activeCodePanel = "source";
  resetTableInfoState();

  let openedRecentItem = null;
  if (options.addRecent === false && options.recentItem) {
    openedRecentItem = normalizeRecentTab(options.recentItem, 0);
    setActiveRecentTabId(options.recentTabId || findRecentTabInstanceIdForItem(openedRecentItem));
    renderRecentTabs();
  } else {
    openedRecentItem = addRecentTab(currentCodePath, currentCodeMeta || {});
  }

  if (openedRecentItem && options.recordNavigation !== false) {
    recordTabNavigation(createRecentTabNavigationEntry(openedRecentItem, currentCodeMeta || {}));
  }

  // 開いた直後の最新履歴を、ホーム左側と同じ件数・並び・列データで右側にも反映する。
  renderGlobalHistoryMini(
    getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT)
  );

  showView("code", { recordNavigation: false });

  if (USE_SAMPLE_DATA) {
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    setCurrentTableNames(["MST_CUSTOMER", "KYF1940", "RPS_TABLE_LIST"]);
    currentSourceText = sampleCode;
    mergeCurrentTableNames(extractJavaTableNamesFromSource(currentSourceText));
    renderCode(currentSourceText, currentSourceLanguage);
    return;
  }

  const sourceParams = {
    path: currentCodeMeta.path || currentCodePath,
    fullPath: currentCodeMeta.path || currentCodePath,
    filePath: currentCodeMeta.path || currentCodePath,
    project: currentCodeMeta.project || "",
    href: currentCodeMeta.href || "",
    sourceUrl: currentCodeMeta.sourceUrl || "",
    language: currentSourceLanguage,
    source_disp: "YES"
  };

  // 2026-08-03 サイト修正9:
  // Javaクラス名ハイライトから開く場合は、フロントでは全パスを推測しきらず、
  // クラス名 + 遷移元情報をServletへ渡し、AI_FILE1のFULLPATH/FILEPATH解決をServlet側へ任せる。
  const sourceEndpoint = currentCodeMeta.javaClassName ? "/source-by-class" : "/source";
  if (currentCodeMeta.javaClassName) {
    sourceParams.className = currentCodeMeta.javaClassName;
    sourceParams.javaClassName = currentCodeMeta.javaClassName;
    sourceParams.originPath = currentCodeMeta.originPath || currentCodeMeta.originFullPath || "";
    sourceParams.originFullPath = currentCodeMeta.originFullPath || currentCodeMeta.originPath || "";
    sourceParams.originProject = currentCodeMeta.originProject || "";
    sourceParams.originGroup = currentCodeMeta.originGroup || "";
    sourceParams.originDirectoryGroup = currentCodeMeta.originDirectoryGroup || "";
    sourceParams.originPackage = currentCodeMeta.originPackage || "";
  }
  const directUrl = `${apiPath(sourceEndpoint)}?${buildQueryString(sourceParams)}`;

  try {
    // sourceはGETで呼ぶ。ブラウザで直接URL確認もしやすくする。
    const data = await fetchJson(sourceEndpoint, sourceParams, { method: "GET" });
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    if (data.resolvedPath || data.fullPath || data.path) {
      const resolvedPath = data.resolvedPath || data.fullPath || data.path;
      currentCodePath = getHistoryEntryPath(resolvedPath);
      currentCodeMeta.path = currentCodePath;
      currentCodeMeta.fullPath = currentCodePath;
      currentCodeMeta.fileName = getRecentTabFileName(currentCodePath);
      currentCodeMeta.project = data.project || extractProjectFromPath(currentCodePath) || currentCodeMeta.project || "";
      currentCodeMeta.group = data.group || extractMigrationGroupFromPath(currentCodePath) || currentCodeMeta.group || "";
      currentCodeMeta.directoryGroup = data.directoryGroup || getRawDirectoryGroupFromPath(currentCodePath) || currentCodeMeta.directoryGroup || "";
    }
    currentSourceText = stripKrugleMockSourceBanner(data.source || data.text || "");
    currentSourceLanguage = data.language || currentSourceLanguage;
    // Servletがソース本文とRPS辞書を照合して選定した対象だけをハイライトする。
    // 旧Servletとの互換性のためtableNamesもフォールバックとして受け付ける。
    setCurrentTableNames(data.tableHighlightTargets || data.tableNames || []);
    if (isJavaSourceForTableHighlight(currentSourceLanguage, currentCodePath)) {
      mergeCurrentTableNames(extractJavaTableNamesFromSource(currentSourceText));
    }
    if (data.tableListError) {
      console.warn("table list load failed:", data.tableListError);
    }
    renderCode(currentSourceText, currentSourceLanguage);
  } catch (e) {
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    console.error(e);
    currentSourceText = `/source 接続失敗

${e.message}

直接確認URL:
${directUrl}

確認ポイント:
1. krugleapi.war がCORS対応版か
2. /krugleapi/source が404にならないか
3. Chrome DevToolsのNetworkでAccess-Control-Allow-Originが返っているか`;
    renderCode(currentSourceText, "plaintext");
    showCopyFeedback("/source 接続失敗");
  }
}

function stripKrugleMockSourceBanner(sourceText) {
  const source = String(sourceText || "").replace(/^\uFEFF/, "");

  // 旧WARが付加していたMock説明コメントは、表示・Copy・Downloadの対象から除外する。
  return source
    .replace(/^[ \t]*\/\*[ \t]*Krugle Mock: embedded template=[\s\S]*?\*\/[ \t]*(?:\r?\n)?/, "")
    .replace(/^--[ \t]*Krugle Mock: embedded template=.*(?:\r?\n)?/, "")
    .replace(/^--[ \t]*Krugle Mock SQL[ \t]*(?:\r?\n)?/, "");
}

function renderCode(sourceText = currentSourceText, language = currentSourceLanguage) {
  const codeView = $("codeView");
  const codeBlock = $("codeBlock");
  const tableInfoPanel = $("tableInfoPanel");
  const codeBodyFrame = codeView ? codeView.querySelector(".codeBodyFrame") : null;
  const tableMode = isTableInfoPanel(activeCodePanel);
  if (tableMode) {
    activeTableInfoTabId = getTableInfoTabIdFromPanel(activeCodePanel) || activeTableInfoTabId;
    tableInfoState = getActiveTableInfoState();
  }

  if (codeView) codeView.classList.toggle("isTableInfoMode", tableMode);
  if (tableInfoPanel) tableInfoPanel.hidden = !tableMode;
  if (codeBodyFrame) codeBodyFrame.hidden = tableMode;

  document.querySelectorAll(".codeModeTab").forEach(button => {
    button.classList.toggle("isActive", button.dataset.codePanel === activeCodePanel);
  });

  if (tableMode) {
    $("codeTitle").textContent = getTableInfoTitle();
    renderTableInfoPanel();
    renderRecentTabs();
    return;
  }

  const source = stripKrugleMockSourceBanner(sourceText || (USE_SAMPLE_DATA ? sampleCode : ""));
  let displayText = source;
  let displayLanguage = language || inferLanguageFromPath(currentCodePath, "java");

  if (activeCodePanel === "ai") {
    displayText = sampleAiCode;
    displayLanguage = "java";
  } else if (activeCodePanel === "summary") {
    displayText = sampleSummaryText;
    displayLanguage = "plaintext";
  }

  $("codeTitle").textContent = currentCodePath || "";

  codeBlock.removeAttribute("data-highlighted");
  delete codeBlock.dataset.highlighted;

  codeBlock.className = `language-${displayLanguage}`;
  codeBlock.textContent = displayText || "";
  setCodeFontSize(codeFontSize);

  if (window.hljs) {
    window.hljs.highlightElement(codeBlock);
  }

  if (activeCodePanel === "source") {
    enhanceSourceHighlights(codeBlock, {
      language: displayLanguage,
      path: currentCodePath
    });
  }

  renderRecentTabs();
}

function updateHighlightToggleButton() {
  const button = $("highlightToggleBtn");
  if (!button) return;

  const enabled = codeHighlightBackgroundEnabled === true;
  const nextState = enabled ? "OFF" : "ON";

  button.classList.toggle("isOn", enabled);
  button.classList.toggle("isOff", !enabled);
  button.setAttribute("aria-pressed", enabled ? "true" : "false");
  button.setAttribute(
    "aria-label",
    `ハイライト表示は現在${enabled ? "ON" : "OFF"}です。クリックすると${nextState}になります。`
  );
  button.title = `ハイライト表示: ${enabled ? "ON" : "OFF"}（背景色のみ切替）`;

  const label = document.createElement("span");
  label.className = "highlightToggleLabel";
  label.textContent = "ハイライト表示";

  const off = document.createElement("span");
  off.className = "highlightToggleChoice highlightToggleChoiceOff" + (!enabled ? " isActive" : "");
  off.textContent = "OFF";
  off.setAttribute("aria-hidden", "true");

  const on = document.createElement("span");
  on.className = "highlightToggleChoice highlightToggleChoiceOn" + (enabled ? " isActive" : "");
  on.textContent = "ON";
  on.setAttribute("aria-hidden", "true");

  button.replaceChildren(label, off, on);
}

function setCodeHighlightBackgroundEnabled(enabled) {
  codeHighlightBackgroundEnabled = enabled === true;

  const codeView = $("codeView");
  if (codeView) {
    codeView.classList.toggle("isHighlightBackgroundOn", codeHighlightBackgroundEnabled);
    codeView.classList.toggle("isHighlightBackgroundOff", !codeHighlightBackgroundEnabled);
  }

  updateHighlightToggleButton();
}

function toggleCodeHighlightBackground() {
  setCodeHighlightBackgroundEnabled(!codeHighlightBackgroundEnabled);
}

function normalizeTableNames(tableNames) {
  const out = [];
  const seen = new Set();
  (Array.isArray(tableNames) ? tableNames : []).forEach(value => {
    const name = String(value == null ? "" : value).trim();
    // 2026-07-31 修正2: テーブル名は大文字小文字を区別する。
    // KYF0010 と Kyf0010 は別物として扱い、登録時も大文字化しない。
    if (!name || seen.has(name)) return;
    seen.add(name);
    out.push(name);
  });
  return out;
}

function setCurrentTableNames(tableNames) {
  currentTableNames = normalizeTableNames(tableNames);
  currentTableNameSet = new Set(currentTableNames);
}

function mergeCurrentTableNames(tableNames) {
  if (!Array.isArray(tableNames) || tableNames.length === 0) return;
  setCurrentTableNames((currentTableNames || []).concat(tableNames));
}

function isJavaSourceForTableHighlight(language, path) {
  const normalized = normalizeHighlightLanguage(language);
  return normalized === "java" || /\.java(?:$|[?#])/i.test(String(path || ""));
}

function extractJavaTableNamesFromSource(sourceText) {
  const source = String(sourceText || "");
  const out = [];
  const seen = new Set();
  const pattern = /\b([A-Z][A-Za-z0-9_$]*?)Table(?:Accessor|Record(?:Value|PKey)?|Record|Data)?\b/g;
  let match;

  while ((match = pattern.exec(source)) !== null) {
    const rawName = String(match[1] || "").replace(/[$_#]+$/g, "");
    if (!rawName || !/[0-9]/.test(rawName)) continue;

    const normalized = rawName.toUpperCase();
    if (normalized.length < 4 || seen.has(normalized)) continue;
    seen.add(normalized);
    out.push(normalized);
  }

  return out;
}

function normalizeHighlightLanguage(language) {
  const value = String(language || "").toLowerCase();
  if (value === "java" || value === "language-java") return "java";
  if (value === "sql" || value === "language-sql") return "sql";
  return value;
}

function enhanceSourceHighlights(codeBlock, options = {}) {
  if (!codeBlock || !codeBlock.textContent) return;

  const language = normalizeHighlightLanguage(options.language || inferLanguageFromPath(options.path || currentCodePath, "plaintext"));
  const path = String(options.path || currentCodePath || "");
  const isJava = language === "java" || /\.java(?:$|[?#])/i.test(path);
  const javaSourceClassName = isJava ? getJavaSourceClassName(path) : "";
  const tableSet = currentTableNameSet || new Set();
  // 2026-07-31 修正2: KYF0010Accessor のような識別子内部のテーブル名はハイライトしない。
  // テーブル名は、前後が半角スペースの完全一致だけを対象にする。
  const javaEmbeddedTableNames = [];
  const fullText = codeBlock.textContent || "";

  // フレームワーク側（package に appfw を含む .java）は、テーブル名・Javaクラス名ともに自前ハイライトしない。
  const javaCommentRanges = isJava ? findJavaCommentRanges(fullText) : [];
  const javaLiteralRanges = isJava ? findJavaLiteralRanges(fullText) : [];
  const javaImportExclusions = isJava ? buildJavaImportHighlightExclusions(fullText) : new Set();
  const javaPublicClassLineRanges = isJava ? findJavaPublicClassLineRanges(fullText) : [];
  const javaExtendsClauseRanges = isJava
    ? findJavaExtendsClauseRanges(fullText, javaCommentRanges, javaLiteralRanges)
    : [];

  const textNodes = collectHighlightTargetTextNodes(codeBlock, isJava);
  textNodes.forEach(item => replaceTextNodeWithCodeHighlights(item, {
    isJava,
    tableSet,
    fullText,
    javaCommentRanges,
    javaLiteralRanges,
    javaImportExclusions,
    javaPublicClassLineRanges,
    javaExtendsClauseRanges,
    javaSourceClassName,
    javaEmbeddedTableNames
  }));
}

function collectHighlightTargetTextNodes(root, isJava) {
  const result = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let offset = 0;

  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue || "";
    const start = offset;
    offset += text.length;

    if (!text || !CODE_IDENTIFIER_PATTERN.test(text)) {
      CODE_IDENTIFIER_PATTERN.lastIndex = 0;
      continue;
    }
    CODE_IDENTIFIER_PATTERN.lastIndex = 0;

    const parent = node.parentElement;
    if (!parent) continue;
    if (parent.closest && parent.closest(".codeKeywordLink")) continue;

    // .java でもテーブル名はコメント・文字列・Accessor名の中に出るため、
    // ここではコメントを除外しない。Javaクラス名側の除外は classifyCodeKeyword で行う。

    result.push({ node, text, start });
  }
  return result;
}

function replaceTextNodeWithCodeHighlights(item, context) {
  const node = item.node;
  const text = item.text;
  const start = item.start;
  const fragment = document.createDocumentFragment();
  let lastIndex = 0;
  CODE_IDENTIFIER_PATTERN.lastIndex = 0;
  let match;

  while ((match = CODE_IDENTIFIER_PATTERN.exec(text)) !== null) {
    const keyword = match[0];
    const index = match.index;
    const globalIndex = start + index;
    const embeddedTable = findJavaEmbeddedTableNameMatch(keyword, globalIndex, context);
    const highlight = embeddedTable ? null : classifyCodeKeyword(keyword, globalIndex, context);

    if (index > lastIndex) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex, index)));
    }

    if (embeddedTable) {
      if (embeddedTable.start > 0) {
        fragment.appendChild(document.createTextNode(keyword.slice(0, embeddedTable.start)));
      }

      const tableText = keyword.slice(embeddedTable.start, embeddedTable.end);
      fragment.appendChild(createCodeKeywordLink(tableText, {
        type: "table",
        className: "codeTableKeyword",
        title: embeddedTable.tableName + " テーブル名"
      }, embeddedTable.tableName));

      if (embeddedTable.end < keyword.length) {
        fragment.appendChild(document.createTextNode(keyword.slice(embeddedTable.end)));
      }
    } else if (highlight) {
      fragment.appendChild(createCodeKeywordLink(keyword, highlight, keyword));
    } else {
      fragment.appendChild(document.createTextNode(keyword));
    }

    lastIndex = index + keyword.length;
  }

  if (lastIndex < text.length) {
    fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
  }

  if (node.parentNode) node.parentNode.replaceChild(fragment, node);
}

function createCodeKeywordLink(keyword, highlight, datasetKeyword) {
  const link = document.createElement("button");
  link.type = "button";
  link.className = "codeKeywordLink " + highlight.className;
  link.dataset.keyword = datasetKeyword || keyword;
  link.dataset.keywordType = highlight.type;
  link.style.setProperty("--keyword-hit-width", "calc(" + keyword.length + "ch + 1.7em)");
  link.textContent = keyword;
  link.title = highlight.title;
  return link;
}

function buildJavaEmbeddedTableNameCandidates(tableNames) {
  return normalizeTableNames(tableNames)
    .filter(name => /^[A-Z0-9_#$]+$/i.test(name) && /[0-9_]/.test(name) && name.length >= 4)
    .sort((a, b) => b.length - a.length);
}

function findJavaEmbeddedTableNameMatch(keyword, globalIndex, context) {
  // 2026-07-31 修正2:
  // テーブル名は大文字小文字を区別し、かつ前後が半角スペースの完全一致のみハイライトする。
  // そのため KYF0010Accessor / Kyf0010TableAccessor のような識別子内部の部分一致は対象外。
  return null;
}

function isTableKeywordHighlightTarget(keyword, globalIndex, context) {
  const tableSet = context && context.tableSet;
  if (!keyword || !tableSet || !tableSet.has(keyword)) return false;

  const source = String(context && context.fullText || "");
  const start = Number(globalIndex) || 0;
  const end = start + String(keyword).length;
  const before = start > 0 ? source.charAt(start - 1) : "";
  const after = end < source.length ? source.charAt(end) : "";

  // 2026-08-03 サイト修正5:
  // テーブル名の大文字小文字は区別したまま、判定時だけ前後の区切り記号を半角スペース扱いにする。
  // 例: ="KYF0010" / {KYF0010} / (KYF0010) / タブや全角スペース前後は対象。
  // 例: KYF0010Accessor / KYF0010_TABLE のように英数字・_・$・# と連続するものは対象外。
  return isTableHighlightSeparator(before) && isTableHighlightSeparator(after);
}

function isTableHighlightSeparator(value) {
  if (value == null || value === "") return true;
  const ch = String(value).charAt(0);
  if (/\s/.test(ch) || ch === "　") return true;

  // テーブル名・Java/SQL識別子の一部として扱う文字は、半角スペースへ置換しない。
  // それ以外の半角記号・全角記号は、ハイライト判定上は半角スペース扱いにする。
  return !/[A-Za-z0-9_$#]/.test(ch);
}

function classifyCodeKeyword(keyword, globalIndex, context) {
  const isJava = context.isJava;
  const tableSet = context.tableSet;
  const fullText = context.fullText;
  const javaCommentRanges = context.javaCommentRanges || [];
  const javaLiteralRanges = context.javaLiteralRanges || [];
  const javaImportExclusions = context.javaImportExclusions || new Set();
  const javaPublicClassLineRanges = context.javaPublicClassLineRanges || [];
  const javaExtendsClauseRanges = context.javaExtendsClauseRanges || [];
  const javaSourceClassName = String(context.javaSourceClassName || "");

  // 2026-08-03 サイト修正5:
  // テーブル名は .java / .sql などファイル種別にかかわらず、以下の同一ルールでハイライトする。
  // - 大文字小文字を区別する
  // - 前後のタブ・全角スペース・記号を半角スペース扱いにした上で、独立したテーブル名だけ対象にする
  if (isTableKeywordHighlightTarget(keyword, globalIndex, context)) {
    return {
      type: "table",
      className: "codeTableKeyword",
      title: keyword + " テーブル名"
    };
  }

  // 表示中の .java ファイル自身のクラス名は、自前ハイライトの対象外にする。
  // 例: KakzJohoSyutkQueryAccessor.java -> KakzJohoSyutkQueryAccessor は強調しない。
  if (isJava && javaSourceClassName && keyword === javaSourceClassName) {
    return null;
  }

  if (isJava && (
    isJavaPackageOrImportLineAt(fullText, globalIndex) ||
    isIndexInRanges(globalIndex, javaCommentRanges) ||
    isIndexInRanges(globalIndex, javaLiteralRanges) ||
    isIndexInRanges(globalIndex, javaPublicClassLineRanges) ||
    isIndexInRanges(globalIndex, javaExtendsClauseRanges)
  )) {
    return null;
  }

  // java.sql/java.util などの標準パッケージ、com.cm.com.、appfw 由来のクラスはハイライトしない。
  if (isJava && (
    javaImportExclusions.has(keyword) ||
    isJavaOrFrameworkQualifiedIdentifierAt(fullText, globalIndex)
  )) {
    return null;
  }

  if (isJava && isJavaClassNameCandidate(keyword)) {
    return {
      type: "java-class",
      className: "codeJavaClassKeyword",
      title: keyword + " Javaクラス名"
    };
  }

  return null;
}

function getJavaSourceClassName(path) {
  const cleanPath = String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/");
  const fileName = cleanPath.substring(cleanPath.lastIndexOf("/") + 1);
  return /\.java$/i.test(fileName) ? fileName.slice(0, -5) : "";
}


// 2026-08-03 サイト修正8:
// Javaクラス名ハイライトをクリックした場合、現在表示中ソースのimport/packageと
// 現在のKrugleフルパスから、Servlet /source に渡せるフルパスへ解決する。
function escapeRegExp(text) {
  return String(text || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function getCleanSourcePath(path) {
  return String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/")
    .replace(/\/+/g, "/");
}

function getDirectoryPath(path) {
  const cleanPath = getCleanSourcePath(path).replace(/\/+$/, "");
  const slash = cleanPath.lastIndexOf("/");
  return slash >= 0 ? cleanPath.substring(0, slash) : "";
}

function getJavaPackageRootPrefixFromPath(path) {
  const directory = getDirectoryPath(path);
  const lower = directory.toLowerCase();
  const roots = ["/jp/", "/com/", "/org/", "/net/"];
  let best = -1;

  roots.forEach(root => {
    const index = lower.lastIndexOf(root);
    if (index > best) best = index;
  });

  if (best >= 0) return directory.substring(0, best + 1);
  if (/^(?:jp|com|org|net)\//i.test(directory)) return "";
  return directory ? directory + "/" : "";
}

function getCurrentJavaPackageName() {
  const match = String(currentSourceText || "").match(/^\s*package\s+([A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)*)\s*;/m);
  return match ? match[1] : "";
}

function findImportedJavaClassQualifiedName(className) {
  const name = String(className || "").trim();
  if (!name) return "";

  const pattern = new RegExp(
    "^\\s*import\\s+(?:static\\s+)?([A-Za-z_$][A-Za-z0-9_$]*(?:\\.[A-Za-z_$][A-Za-z0-9_$]*)*\\." +
      escapeRegExp(name) +
      ")\\s*;",
    "m"
  );
  const match = String(currentSourceText || "").match(pattern);
  return match ? match[1] : "";
}

function qualifiedJavaNameToFullPath(qualifiedName) {
  const qName = String(qualifiedName || "").trim();
  if (!qName) return "";
  const root = getJavaPackageRootPrefixFromPath(currentCodePath);
  return root + qName.replace(/\./g, "/") + ".java";
}

function buildSiblingJavaClassFullPath(className) {
  const directory = getDirectoryPath(currentCodePath);
  return (directory ? directory + "/" : "") + String(className || "").trim() + ".java";
}

function resolveJavaClassKeywordFullPath(className) {
  const name = String(className || "").trim();
  if (!name) return "";

  const imported = findImportedJavaClassQualifiedName(name);
  if (imported) return qualifiedJavaNameToFullPath(imported);

  const packageName = getCurrentJavaPackageName();
  if (packageName) return qualifiedJavaNameToFullPath(packageName + "." + name);

  return buildSiblingJavaClassFullPath(name);
}

function openJavaClassKeywordSource(className) {
  const name = String(className || "").trim();
  if (!name) return;

  // 2026-08-03 サイト修正9:
  // 全パス推測はServlet側のAI_FILE1検索へ寄せる。
  // フロントは画面遷移用の仮パスと、候補絞り込み用の遷移元情報だけを渡す。
  const fallbackPath = buildSiblingJavaClassFullPath(name);
  const originPath = currentCodePath;
  openCode(fallbackPath, {
    row: {
      fileName: name + ".java",
      path: fallbackPath,
      fullPath: fallbackPath,
      project: extractProjectFromPath(originPath) || "",
      group: extractMigrationGroupFromPath(originPath) || "",
      directoryGroup: getRawDirectoryGroupFromPath(originPath) || "",
      language: "java",
      javaClassName: name,
      originPath,
      originFullPath: originPath,
      originProject: extractProjectFromPath(originPath) || "",
      originGroup: extractMigrationGroupFromPath(originPath) || "",
      originDirectoryGroup: getRawDirectoryGroupFromPath(originPath) || "",
      originPackage: getCurrentJavaPackageName()
    }
  });
}

function isJavaPackageOrImportLineAt(fullText, index) {
  const source = String(fullText || "");
  const lineStart = source.lastIndexOf("\n", Math.max(0, index - 1)) + 1;
  let lineEnd = source.indexOf("\n", index);
  if (lineEnd < 0) lineEnd = source.length;
  const line = source.slice(lineStart, lineEnd);
  return /^\s*(?:package|import\s+(?:static\s+)?)\b/.test(line);
}


function isAppfwJavaSource(sourceText, path) {
  const source = String(sourceText || "");
  const packageMatch = source.match(/^\s*package\s+([^;]+);/m);
  const packageName = packageMatch ? packageMatch[1].trim() : "";
  const pathText = String(path || "");

  return /(^|\.)appfw(\.|$)/i.test(packageName) ||
    /(?:^|[\\/._-])appfw(?:[\\/._-]|$)/i.test(pathText) ||
    /\.appfw\./i.test(pathText);
}

function buildJavaImportHighlightExclusions(sourceText) {
  const excludes = new Set();
  const source = String(sourceText || "");
  const importPattern = /^\s*import\s+(?:static\s+)?([^;]+);/gm;
  let match;

  while ((match = importPattern.exec(source)) !== null) {
    const importPath = String(match[1] || "").trim();
    if (!importPath || !isIgnoredJavaImportPackage(importPath)) continue;

    if (isComTaskWildcardImport(importPath)) {
      excludes.add("Task");
      excludes.add("TaskResult");
    }

    const className = extractImportedClassName(importPath);
    if (className) excludes.add(className);
  }

  return excludes;
}

function isComTaskImportPackage(importPath) {
  const value = String(importPath || "").trim().toLowerCase();
  return value.startsWith("com.task.") || value.includes(".com.task.");
}

function isComTaskWildcardImport(importPath) {
  const value = String(importPath || "").trim().toLowerCase();
  return value.endsWith(".*") && (value === "com.task.*" || value.endsWith(".com.task.*"));
}

function isIgnoredJavaImportPackage(importPath) {
  const value = String(importPath || "").trim().toLowerCase();
  return value.startsWith("java.") ||
    value.startsWith("javax.") ||
    value.startsWith("jdk.") ||
    value.startsWith("sun.") ||
    value.startsWith("com.sun.") ||
    value.startsWith("org.w3c.") ||
    value.startsWith("org.xml.sax.") ||
    value.includes("com.cm.com.") ||
    isComTaskImportPackage(value) ||
    /(^|\.)[^.]*fw[^.]*(\.|$)/i.test(value);
}

function extractImportedClassName(importPath) {
  const cleaned = String(importPath || "").trim();
  if (!cleaned || cleaned.endsWith(".*")) return "";

  const parts = cleaned.split(".").filter(Boolean);
  for (let i = parts.length - 1; i >= 0; i--) {
    if (/^[A-Z_$]/.test(parts[i])) return parts[i];
  }
  return "";
}

function isJavaOrFrameworkQualifiedIdentifierAt(sourceText, index) {
  const source = String(sourceText || "");
  const prefix = source.slice(Math.max(0, index - 220), index);
  const qualifiedPrefixMatch = prefix.match(/(?:[$A-Za-z_][_$A-Za-z0-9]*\.)+$/);
  if (!qualifiedPrefixMatch) return false;

  const qualifiedPrefix = qualifiedPrefixMatch[0].toLowerCase();
  return qualifiedPrefix.startsWith("java.") ||
    qualifiedPrefix.startsWith("javax.") ||
    qualifiedPrefix.startsWith("jdk.") ||
    qualifiedPrefix.startsWith("sun.") ||
    qualifiedPrefix.startsWith("com.sun.") ||
    qualifiedPrefix.startsWith("org.w3c.") ||
    qualifiedPrefix.startsWith("org.xml.sax.") ||
    qualifiedPrefix.includes("com.cm.com.") ||
    qualifiedPrefix.startsWith("com.task.") ||
    qualifiedPrefix.includes(".com.task.") ||
    /(^|\.)[^.]*fw[^.]*\./i.test(qualifiedPrefix);
}

function findJavaPublicClassLineRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  let lineStart = 0;

  while (lineStart <= source.length) {
    let lineEnd = source.indexOf("\n", lineStart);
    if (lineEnd < 0) lineEnd = source.length;

    const line = source.slice(lineStart, lineEnd);
    const classKeywordIndex = line.search(/\bclass\b/);
    if (classKeywordIndex >= 0) {
      const beforeClass = line.slice(0, classKeywordIndex);
      const modifierOnlyPrefix = /^\s*(?:@[A-Za-z0-9_.$]+(?:\([^)]*\))?\s*)*(?:(?:public|protected|private|abstract|final|static|strictfp|sealed|non-sealed)\s+)*$/;

      if (/\bpublic\b/.test(beforeClass) && modifierOnlyPrefix.test(beforeClass)) {
        ranges.push({ start: lineStart, end: lineEnd });
      }
    }

    if (lineEnd >= source.length) break;
    lineStart = lineEnd + 1;
  }

  return ranges;
}

function findJavaExtendsClauseRanges(sourceText, commentRanges = [], literalRanges = []) {
  const source = String(sourceText || "");
  if (!source) return [];

  // コメント・文字列内の class / extends を宣言として誤認しないよう、文字数を変えずに空白化する。
  const masked = source.split("");
  const ignoredRanges = (commentRanges || []).concat(literalRanges || [])
    .slice()
    .sort((a, b) => a.start - b.start);

  ignoredRanges.forEach(range => {
    const start = Math.max(0, Number(range.start) || 0);
    const end = Math.min(masked.length, Number(range.end) || 0);
    for (let i = start; i < end; i++) {
      if (masked[i] !== "\n" && masked[i] !== "\r") masked[i] = " ";
    }
  });

  const maskedSource = masked.join("");
  const ranges = [];
  const classPattern = /\bclass\s+[A-Za-z_$][_$A-Za-z0-9]*/g;
  let match;

  while ((match = classPattern.exec(maskedSource)) !== null) {
    const declarationBodyStart = match.index + match[0].length;
    let declarationEnd = maskedSource.length;

    for (let i = declarationBodyStart; i < maskedSource.length; i++) {
      const ch = maskedSource.charAt(i);
      if (ch === "{" || ch === ";") {
        declarationEnd = i;
        break;
      }
    }

    const declarationTail = maskedSource.slice(declarationBodyStart, declarationEnd);
    const extendsMatch = /\bextends\b/.exec(declarationTail);
    if (!extendsMatch) {
      classPattern.lastIndex = Math.max(classPattern.lastIndex, declarationEnd + 1);
      continue;
    }

    const extendsStart = declarationBodyStart + extendsMatch.index + extendsMatch[0].length;
    const afterExtends = maskedSource.slice(extendsStart, declarationEnd);
    const clauseEndMatch = /\b(?:implements|permits)\b/.exec(afterExtends);
    const extendsEnd = clauseEndMatch
      ? extendsStart + clauseEndMatch.index
      : declarationEnd;

    if (extendsEnd > extendsStart) {
      ranges.push({ start: extendsStart, end: extendsEnd });
    }

    classPattern.lastIndex = Math.max(classPattern.lastIndex, declarationEnd + 1);
  }

  return ranges;
}

function findJavaLiteralRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  let i = 0;

  while (i < source.length) {
    const ch = source.charAt(i);
    const next = source.charAt(i + 1);

    // コメント内の引用符を文字列開始と誤認しないよう、コメントは読み飛ばす。
    if (ch === "/" && next === "/") {
      const lineEnd = source.indexOf("\n", i + 2);
      i = lineEnd < 0 ? source.length : lineEnd + 1;
      continue;
    }
    if (ch === "/" && next === "*") {
      const commentEnd = source.indexOf("*/", i + 2);
      i = commentEnd < 0 ? source.length : commentEnd + 2;
      continue;
    }

    if (ch !== "\"" && ch !== "'") {
      i++;
      continue;
    }

    const quote = ch;
    const start = i;
    let escaped = false;
    i++;

    while (i < source.length) {
      const current = source.charAt(i);
      if (escaped) {
        escaped = false;
      } else if (current === "\\") {
        escaped = true;
      } else if (current === quote) {
        i++;
        break;
      }
      i++;
    }

    ranges.push({ start, end: i });
  }

  return ranges;
}

function findJavaCommentRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  let quote = "";
  let escaped = false;

  for (let i = 0; i < source.length; i++) {
    const ch = source.charAt(i);
    const next = source.charAt(i + 1);

    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === quote) {
        quote = "";
      }
      continue;
    }

    if (ch === "\"" || ch === "'") {
      quote = ch;
      continue;
    }

    if (ch === "/" && next === "/") {
      const start = i;
      let end = source.indexOf("\n", i + 2);
      if (end < 0) end = source.length;
      ranges.push({ start, end });
      i = end;
      continue;
    }

    if (ch === "/" && next === "*") {
      const start = i;
      let end = source.indexOf("*/", i + 2);
      end = end < 0 ? source.length : end + 2;
      ranges.push({ start, end });
      i = end - 1;
    }
  }
  return ranges;
}

function isIndexInRanges(index, ranges) {
  for (let i = 0; i < ranges.length; i++) {
    if (index >= ranges[i].start && index < ranges[i].end) return true;
    if (index < ranges[i].start) return false;
  }
  return false;
}

function isJavaClassNameCandidate(keyword) {
  if (!keyword) return false;
  if (JAVA_STANDARD_CLASS_EXCLUDES.has(keyword)) return false;
  if (JAVA_RESERVED_WORD_EXCLUDES.has(keyword)) return false;
  if (!/^[A-Z][A-Za-z0-9_$]*$/.test(keyword)) return false;
  if (/Exception/i.test(keyword)) return false;

  // IAppContext のような I 始まりのインターフェース名は除外する。
  if (/^I[A-Za-z0-9_$]*$/.test(keyword)) return false;

  // Command / Task / Context のように大文字が先頭1文字だけの単語型クラス名は除外する。
  const upperCaseCount = (keyword.match(/[A-Z]/g) || []).length;
  if (upperCaseCount <= 1) return false;

  // SELECT_FOR_UPDATE や DB_UPDJI1 などの定数・カラム名は、クラス名としては除外する。
  if (/^[A-Z0-9_$]+$/.test(keyword)) return false;

  return true;
}

const CODE_IDENTIFIER_PATTERN = /[$#A-Za-z_][_$#A-Za-z0-9]*/g;


function getTableInfoTabTemplate() {
  return document.querySelector(".codeTableInfoTab:not(.codeTableInfoDynamicTab)");
}

function getTableInfoTabContainer() {
  const template = getTableInfoTabTemplate();
  return template ? template.parentElement : document.querySelector(".codeModeTabs");
}

function getTableInfoPanelId(tabId) {
  return tabId ? `table:${tabId}` : "table";
}

function isTableInfoPanel(panelId) {
  const value = String(panelId || "");
  return value === "table" || value.indexOf("table:") === 0;
}

function getTableInfoTabIdFromPanel(panelId) {
  const value = String(panelId || "");
  if (value.indexOf("table:") === 0) return value.slice(6);
  return activeTableInfoTabId || "";
}

function createDefaultTableInfoState(values = {}) {
  return Object.assign({
    id: "",
    status: "idle",
    tableName: "",
    candidates: [],
    selected: null,
    tableMeta: null,
    columns: [],
    unique: false,
    error: "",
    requestKey: 0
  }, values || {});
}

function createTableInfoTabId(tableName) {
  tableInfoTabSequence += 1;
  const safeName = String(tableName || "table").replace(/[^A-Za-z0-9_]+/g, "_").replace(/^_+|_+$/g, "") || "table";
  return `${safeName}_${tableInfoTabSequence}`;
}

function getTableInfoStateById(tabId) {
  const id = String(tabId || "");
  return tableInfoStates.find(state => state && state.id === id) || null;
}

function getActiveTableInfoState() {
  return getTableInfoStateById(activeTableInfoTabId) || tableInfoStates[0] || tableInfoState || createDefaultTableInfoState();
}

function getTableInfoTabLabel(state) {
  const current = state || {};
  const selected = current.selected || {};
  const detailName = current.status === "detail" && selected.name ? String(selected.name).trim() : "";
  return detailName || String(current.tableName || "テーブル情報").trim() || "テーブル情報";
}

function upsertTableInfoState(nextState) {
  const state = createDefaultTableInfoState(nextState || {});
  if (!state.id) state.id = createTableInfoTabId(state.tableName);
  const index = tableInfoStates.findIndex(item => item && item.id === state.id);
  if (index >= 0) {
    tableInfoStates[index] = state;
  } else {
    tableInfoStates.push(state);
  }
  if (!activeTableInfoTabId) activeTableInfoTabId = state.id;
  tableInfoState = getActiveTableInfoState();
  return state;
}

function updateTableInfoTabsFromState() {
  const container = getTableInfoTabContainer();
  const template = getTableInfoTabTemplate();
  if (!container) return;

  if (template) {
    template.hidden = true;
    template.setAttribute("aria-hidden", "true");
  }

  container.querySelectorAll(".codeTableInfoDynamicTab").forEach(tab => tab.remove());

  tableInfoStates.forEach(state => {
    const button = document.createElement("button");
    button.className = "codeModeTab codeTableInfoTab codeTableInfoDynamicTab";
    button.type = "button";
    button.dataset.codePanel = getTableInfoPanelId(state.id);
    button.dataset.tableInfoTabId = state.id;
    button.textContent = getTableInfoTabLabel(state);
    button.title = getTableInfoTabLabel(state);
    button.setAttribute("aria-hidden", "false");
    button.setAttribute("aria-label", `${getTableInfoTabLabel(state)} のテーブル情報`);
    button.classList.toggle("isActive", activeCodePanel === button.dataset.codePanel);
    container.appendChild(button);
  });
}

function getTableInfoTab() {
  if (activeTableInfoTabId) {
    return document.querySelector(`.codeTableInfoDynamicTab[data-table-info-tab-id="${cssEscapeValue(activeTableInfoTabId)}"]`);
  }
  return getTableInfoTabTemplate();
}

function setTableInfoTabVisible(visible, label) {
  if (!visible) {
    tableInfoStates = [];
    activeTableInfoTabId = "";
    if (isTableInfoPanel(activeCodePanel)) activeCodePanel = "source";
  } else if (label && activeTableInfoTabId) {
    const state = getTableInfoStateById(activeTableInfoTabId);
    if (state && !state.tableName) state.tableName = String(label || "");
  }
  updateTableInfoTabsFromState();
}

function updateTableInfoTabFromState() {
  updateTableInfoTabsFromState();
}

function resetTableInfoState() {
  tableInfoRequestSequence++;
  tableInfoStates = [];
  activeTableInfoTabId = "";
  tableInfoState = createDefaultTableInfoState();
  setTableInfoTabVisible(false, "テーブル情報");
  renderTableInfoPanel();
}

function normalizeTableCandidate(value) {
  const source = value && typeof value === "object" ? value : {};
  return {
    name: String(source.name || source.tableName || "").trim(),
    dbtype: String(source.dbtype || source.dbType || "").trim(),
    schema: String(source.schema || "").trim()
  };
}

function normalizeTableMeta(value, fallbackCandidate) {
  const source = value && typeof value === "object" ? value : {};
  const candidate = normalizeTableCandidate(fallbackCandidate || source);
  return {
    id: source.id == null ? "" : String(source.id),
    name: String(source.name || source.tableName || candidate.name || "").trim(),
    dbtype: String(source.dbtype || source.dbType || candidate.dbtype || "").trim(),
    schema: String(source.schema || candidate.schema || "").trim(),
    dbAlias: String(source.dbAlias || source.dbName || source.dbIdentifier || source.dbtype || candidate.dbtype || "").trim(),
    version: String(source.version || source.ver || "").trim(),
    displayName: String(source.displayName || source.logicalName || source.description || "").trim()
  };
}

function getTableInfoTitle() {
  const state = getActiveTableInfoState();
  const selected = state.selected || {};
  if (state.status === "detail" && state.unique === true && selected.name) {
    return selected.name;
  }
  return getTableInfoTabLabel(state);
}

function setTableInfoState(nextState, tabId = activeTableInfoTabId, renderAfterUpdate = true) {
  const id = String(tabId || activeTableInfoTabId || (nextState && nextState.id) || createTableInfoTabId(nextState && nextState.tableName));
  const current = getTableInfoStateById(id) || createDefaultTableInfoState({ id });
  const merged = createDefaultTableInfoState(Object.assign({}, current, nextState || {}, { id }));
  upsertTableInfoState(merged);
  if (activeTableInfoTabId === id) tableInfoState = merged;
  updateTableInfoTabFromState();
  if (renderAfterUpdate && isTableInfoPanel(activeCodePanel) && getTableInfoTabIdFromPanel(activeCodePanel) === id) renderCode();
  return merged;
}

function tableApiError(data, fallback) {
  if (data && data.ok === false) return new Error(String(data.error || fallback || "テーブル情報を取得できませんでした。"));
  return null;
}

function applyTableInfoResponse(data, fallbackName, fallbackCandidates, tabId = activeTableInfoTabId) {
  const mode = String(data && data.mode || "").trim();
  const candidates = (Array.isArray(data && data.candidates) ? data.candidates : (fallbackCandidates || []))
    .map(normalizeTableCandidate)
    .filter(item => item.name);

  if (mode === "detail" || data && data.unique === true && data.table) {
    const selected = normalizeTableCandidate(data.table || {});
    const tableMeta = normalizeTableMeta(data.table || {}, selected);
    setTableInfoState({
      status: "detail",
      tableName: selected.name || fallbackName,
      candidates,
      selected,
      tableMeta,
      columns: Array.isArray(data.columns) ? data.columns : [],
      unique: true,
      error: ""
    }, tabId);
    return;
  }

  if (mode === "candidates" || candidates.length > 1) {
    setTableInfoState({
      status: "candidates",
      tableName: String(data && data.tableName || fallbackName || "").trim(),
      candidates,
      selected: null,
      tableMeta: null,
      columns: [],
      unique: false,
      error: ""
    }, tabId);
    return;
  }

  setTableInfoState({
    status: "empty",
    tableName: String(data && data.tableName || fallbackName || "").trim(),
    candidates,
    selected: null,
    tableMeta: null,
    columns: [],
    unique: false,
    error: ""
  }, tabId);
}

async function openTableInformation(tableName) {
  const name = String(tableName || "").trim();
  if (!name) return;

  const tabId = createTableInfoTabId(name);
  const requestKey = ++tableInfoRequestSequence;
  activeTableInfoTabId = tabId;
  activeCodePanel = getTableInfoPanelId(tabId);
  setTableInfoState({
    id: tabId,
    status: "loadingCandidates",
    tableName: name,
    candidates: [],
    selected: null,
    tableMeta: null,
    columns: [],
    unique: false,
    error: "",
    requestKey
  }, tabId, false);
  updateTableInfoTabsFromState();
  renderCode();

  try {
    const data = await fetchJson(TABLE_INFO_MOCK_ENDPOINT, { tableName: name }, {
      method: "GET",
      timeoutMs: API_ACCESS_TIMEOUT_MS
    });
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    const apiError = tableApiError(data, `${name} のMockテーブル情報を取得できませんでした。`);
    if (apiError) throw apiError;
    applyTableInfoResponse(data, name, [], tabId);
  } catch (error) {
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    setTableInfoState({
      status: "error",
      tableName: name,
      candidates: [],
      selected: null,
      tableMeta: null,
      columns: [],
      unique: false,
      error: String(error && error.message ? error.message : error),
      requestKey
    }, tabId);
  }
}

async function loadTableInformationDetail(candidateValue) {
  const candidate = normalizeTableCandidate(candidateValue);
  if (!candidate.name) return;

  const tabId = activeTableInfoTabId;
  const currentState = getTableInfoStateById(tabId) || getActiveTableInfoState();
  const currentCandidates = Array.isArray(currentState.candidates) ? currentState.candidates.slice() : [];
  const requestKey = ++tableInfoRequestSequence;
  activeCodePanel = getTableInfoPanelId(tabId);
  setTableInfoState({
    status: "loadingDetail",
    tableName: candidate.name,
    candidates: currentCandidates,
    selected: candidate,
    tableMeta: null,
    columns: [],
    unique: false,
    error: "",
    requestKey
  }, tabId, false);
  updateTableInfoTabsFromState();
  renderCode();

  try {
    const data = await fetchJson(TABLE_INFO_MOCK_ENDPOINT, {
      tableName: candidate.name,
      dbtype: candidate.dbtype,
      schema: candidate.schema
    }, {
      method: "GET",
      timeoutMs: API_ACCESS_TIMEOUT_MS
    });
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    const apiError = tableApiError(data, `${candidate.name} のMockテーブル定義を取得できませんでした。`);
    if (apiError) throw apiError;
    applyTableInfoResponse(data, candidate.name, currentCandidates, tabId);
  } catch (error) {
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    setTableInfoState({
      status: "error",
      tableName: candidate.name,
      candidates: currentCandidates,
      selected: candidate,
      tableMeta: null,
      columns: [],
      unique: false,
      error: String(error && error.message ? error.message : error),
      requestKey
    }, tabId);
  }
}

function tableCell(value) {
  return escapeHtml(value == null ? "" : String(value));
}

function renderTableInfoPanel() {
  const panel = $("tableInfoPanel");
  const status = $("tableInfoStatus");
  const content = $("tableInfoContent");
  if (!panel || !status || !content) return;

  const state = getActiveTableInfoState();
  tableInfoState = state;
  content.innerHTML = "";

  if (state.status === "loadingCandidates") {
    status.textContent = `${state.tableName} のMock候補をServletから取得しています…`;
    return;
  }
  if (state.status === "loadingDetail") {
    const selected = state.selected || {};
    status.textContent = `${selected.name || state.tableName} のMock項目定義をServletから取得しています…`;
    return;
  }
  if (state.status === "empty") {
    status.textContent = `${state.tableName} に一致するMockテーブル情報がありません。`;
    return;
  }
  if (state.status === "error") {
    status.textContent = "テーブル情報の取得に失敗しました。";
    content.innerHTML = `<div class="tableInfoError">${escapeHtml(state.error || "不明なエラー")}</div>`;
    return;
  }
  if (state.status === "candidates") {
    status.textContent = `${state.tableName} は複数件あります。表示する name／dbtype／schema の行を選択してください。`;
    content.innerHTML = `
      <div class="tableInfoTableWrap tableCandidateTableWrap">
        <table class="tableInfoTable tableCandidateTable">
          <thead><tr><th>No</th><th>name</th><th>dbtype</th><th>schema</th></tr></thead>
          <tbody>${state.candidates.map((item, index) => `
            <tr class="tableCandidateRow" data-table-candidate-index="${index}" tabindex="0" role="button" aria-label="${tableCell(item.name)} ${tableCell(item.dbtype)} ${tableCell(item.schema)} を表示">
              <td>${index + 1}</td>
              <td>${tableCell(item.name)}</td>
              <td>${tableCell(item.dbtype)}</td>
              <td>${tableCell(item.schema)}</td>
            </tr>`).join("")}</tbody>
        </table>
      </div>`;
    return;
  }
  if (state.status === "detail") {
    const selected = state.selected || {};
    const meta = state.tableMeta || {};
    const rows = Array.isArray(state.columns) ? state.columns : [];
    const tableName = selected.name || state.tableName || "-";
    const dbAlias = meta.dbAlias || selected.dbtype || "-";
    const version = meta.version || "-";
    const displayName = meta.displayName || "テーブル定義情報";

    status.textContent = `SCHEMA：${selected.schema || "-"}　DBTYPE：${selected.dbtype || "-"}　TABLENAME：${tableName}　項目数：${rows.length}　（Servlet Mock）`;
    content.innerHTML = `
      <div class="tableInfoHeading" role="heading" aria-level="2">
        <span>DB識別名：${tableCell(dbAlias)}</span>
        <span>Ver:${tableCell(version)}</span>
        <span>テーブル名:${tableCell(tableName)}</span>
        <span class="tableInfoLogicalName">＜ ${tableCell(displayName)} ＞</span>
        <span class="tableInfoMockBadge">Mock</span>
      </div>
      <div class="tableInfoTableWrap tableDefinitionTableWrap">
        <table class="tableInfoTable tableDefinitionTable">
          <thead>
            <tr>
              <th>No.</th><th>項目名</th><th>キー</th><th>Par</th><th>データ型</th><th>データ長</th>
              <th>NULL制約</th><th>日本語名称</th><th>項目説明</th><th>外部参照</th>
              <th>省略時値</th><th>CHECK制約</th>
            </tr>
          </thead>
          <tbody>${rows.map(row => `
            <tr>
              <td>${tableCell(row.no)}</td>
              <td>${tableCell(row.name)}</td>
              <td>${tableCell(row.pkkey)}</td>
              <td>${tableCell(row.part)}</td>
              <td>${tableCell(row.kata)}</td>
              <td>${tableCell(row.columnSize)}</td>
              <td>${tableCell(row.nullConst)}</td>
              <td>${tableCell(row.name2)}</td>
              <td>${tableCell(row.description)}</td>
              <td>${tableCell(row.reference)}</td>
              <td>${tableCell(row.defaultValue)}</td>
              <td>${tableCell(row.checkConst)}</td>
            </tr>`).join("") || `<tr><td colspan="12">RPS_TABLE_DATAに項目がありません。</td></tr>`}</tbody>
        </table>
      </div>
      <button class="tableExtentInfoBtn" type="button" disabled aria-disabled="true">エクステント情報</button>`;
    return;
  }

  status.textContent = "ソースコード内で下線表示されたテーブル名をクリックしてください。";
}

function selectTableCandidateFromElement(element) {
  const index = Number(element && element.dataset ? element.dataset.tableCandidateIndex : -1);
  const state = getActiveTableInfoState();
  const candidate = Array.isArray(state.candidates) ? state.candidates[index] : null;
  if (candidate) loadTableInformationDetail(candidate);
}

const JAVA_RESERVED_WORD_EXCLUDES = new Set([
  "Abstract", "Assert", "Boolean", "Break", "Byte", "Case", "Catch", "Char", "Class", "Const",
  "Continue", "Default", "Do", "Double", "Else", "Enum", "Extends", "Final", "Finally", "Float",
  "For", "Goto", "If", "Implements", "Import", "Instanceof", "Int", "Interface", "Long", "Native",
  "New", "Package", "Private", "Protected", "Public", "Return", "Short", "Static", "Strictfp", "Super",
  "Switch", "Synchronized", "This", "Throw", "Throws", "Transient", "Try", "Void", "Volatile", "While"
]);

const JAVA_STANDARD_CLASS_EXCLUDES = new Set([
  "Appendable", "AutoCloseable", "Boolean", "Byte", "Character", "CharSequence", "Class", "ClassLoader",
  "Cloneable", "Comparable", "Compiler", "Double", "Enum", "Exception", "Float", "Integer", "Iterable",
  "Long", "Math", "Number", "Object", "Package", "Process", "ProcessBuilder", "Readable", "Runtime",
  "RuntimeException", "SecurityManager", "Short", "StackTraceElement", "StrictMath", "String", "StringBuffer",
  "StringBuilder", "System", "Thread", "ThreadGroup", "ThreadLocal", "Throwable", "Void",
  "BigDecimal", "BigInteger", "Date", "Calendar", "GregorianCalendar", "Locale", "TimeZone", "Optional",
  "List", "ArrayList", "LinkedList", "Map", "HashMap", "LinkedHashMap", "TreeMap", "Set", "HashSet",
  "LinkedHashSet", "TreeSet", "Collection", "Collections", "Arrays", "Iterator", "Enumeration", "Objects",
  "Comparator", "Queue", "Deque", "ArrayDeque", "Properties", "Random", "UUID", "Timer", "TimerTask",
  "File", "InputStream", "OutputStream", "Reader", "Writer", "BufferedReader", "BufferedWriter",
  "InputStreamReader", "OutputStreamWriter", "IOException", "FileInputStream", "FileOutputStream", "PrintWriter",
  "PrintStream", "Serializable", "Externalizable",
  "Charset", "StandardCharsets", "ByteBuffer", "Path", "Paths", "Files", "URL", "URI", "URLConnection",
  "HttpURLConnection", "URLEncoder", "URLDecoder",
  "Connection", "DriverManager", "PreparedStatement", "CallableStatement", "Statement", "ResultSet", "SQLException",
  "SQLWarning", "Savepoint", "DatabaseMetaData", "ResultSetMetaData", "ParameterMetaData", "Types",
  "Timestamp", "Time", "Blob", "Clob", "NClob", "SQLXML", "Array", "Ref", "RowId", "Struct"
]);

document.addEventListener("click", event => {
  const candidateRow = event.target.closest ? event.target.closest("[data-table-candidate-index]") : null;
  if (candidateRow) {
    event.preventDefault();
    selectTableCandidateFromElement(candidateRow);
    return;
  }

  const keywordButton = event.target.closest ? event.target.closest(".codeKeywordLink") : null;
  if (!keywordButton) return;

  const keyword = keywordButton.dataset.keyword || keywordButton.textContent || "";
  if (!keyword) return;

  if (keywordButton.dataset.keywordType === "table") {
    event.preventDefault();
    openTableInformation(keyword);
    return;
  }

  if (keywordButton.dataset.keywordType === "java-class") {
    event.preventDefault();
    openJavaClassKeywordSource(keyword);
    return;
  }
});

document.addEventListener("keydown", event => {
  if (event.key !== "Enter" && event.key !== " ") return;
  const candidateRow = event.target.closest ? event.target.closest("[data-table-candidate-index]") : null;
  if (!candidateRow) return;
  event.preventDefault();
  selectTableCandidateFromElement(candidateRow);
});


function setCodeFontSize(nextSize) {
  const next = Number(nextSize);
  codeFontSize = Math.min(CODE_FONT_MAX, Math.max(CODE_FONT_MIN, Number.isFinite(next) ? next : 14));

  const codeView = $("codeView");
  if (codeView) {
    codeView.style.setProperty("--code-font-size", `${codeFontSize}px`);
  }

  const codeBlock = $("codeBlock");
  if (codeBlock) {
    codeBlock.style.setProperty("font-size", `${codeFontSize}px`, "important");
  }
}

function getActionFeedbackTextTarget(button) {
  if (!button) return null;
  return button.querySelector(".sideActionText") || button;
}

function getActionFeedbackButtons(action) {
  const ids = action === "download"
    ? ["downloadBtn", "codeDownloadBtn"]
    : ["copyBtn", "codeCopyBtn"];
  return ids.map(id => $(id)).filter(Boolean);
}

function getActionFeedbackSourceButton(source) {
  if (!source) return null;
  const target = source.currentTarget || source.target || source;
  return target && target.closest ? target.closest("button") : target;
}

function isActionFeedbackSource(source, action) {
  const button = getActionFeedbackSourceButton(source);
  if (!button) return false;
  const validIds = action === "download"
    ? ["downloadBtn", "codeDownloadBtn"]
    : ["copyBtn", "codeCopyBtn"];
  return validIds.includes(button.id);
}

function showSynchronizedActionButtonFeedback(action, feedbackText, fallbackText, stateClass) {
  const buttons = getActionFeedbackButtons(action);
  if (!buttons.length) return;

  if (!showSynchronizedActionButtonFeedback.buttonTimers) {
    showSynchronizedActionButtonFeedback.buttonTimers = new WeakMap();
  }

  buttons.forEach(button => {
    const textTarget = getActionFeedbackTextTarget(button);
    if (!textTarget) return;

    const originalKey = action === "download" ? "originalDownloadText" : "originalCopyText";
    const originalText = button.dataset[originalKey] || textTarget.textContent || fallbackText;
    button.dataset[originalKey] = originalText;
    textTarget.textContent = feedbackText;
    button.classList.add(stateClass);

    window.clearTimeout(showSynchronizedActionButtonFeedback.buttonTimers.get(button));
    showSynchronizedActionButtonFeedback.buttonTimers.set(button, window.setTimeout(() => {
      textTarget.textContent = button.dataset[originalKey] || fallbackText;
      button.classList.remove(stateClass);
    }, 1400));
  });
}

function showToastFeedback(message = "コピーしました") {
  let toast = $("copyToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "copyToast";
    toast.className = "copyToast";
    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.classList.add("isVisible");
  window.clearTimeout(showToastFeedback.timer);
  showToastFeedback.timer = window.setTimeout(() => {
    toast.classList.remove("isVisible");
  }, 1400);
}

function showCopyFeedback(message = "コピーしました", source) {
  showToastFeedback(message);
  if (message === "コピーしました" && isActionFeedbackSource(source, "copy")) {
    showSynchronizedActionButtonFeedback("copy", "コピー済", "Copy", "isCopied");
  }
}

function showDownloadFeedback(message = "ダウンロードしました", source) {
  showToastFeedback(message);
  if (isActionFeedbackSource(source, "download")) {
    showSynchronizedActionButtonFeedback("download", "ダウンロード済", "Download", "isDownloaded");
  }
}

function fallbackCopyText(text) {
  const area = document.createElement("textarea");
  area.value = text;
  area.setAttribute("readonly", "readonly");
  area.style.position = "fixed";
  area.style.left = "-9999px";
  area.style.top = "0";
  document.body.appendChild(area);
  area.focus();
  area.select();

  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch (e) {
    ok = false;
  }

  document.body.removeChild(area);
  return ok;
}

async function downloadCurrent(event) {
  if (currentView === "search") {
    const params = lastSearchParams || buildSearchParams(lastSearchMode || "normal");
    try {
      await resolveApiBaseOnce();
      submitDownload("/download", {
        path_output_format: "PATH",
        keyword: params.keyword,
        project: params.project,
        language: params.languageForApi,
        findin: params.findin,
        clone: params.clone
      });
      showDownloadFeedback("ダウンロードしました", event);
    } catch (e) {
      console.error(e);
      showCopyFeedback("/download 接続失敗");
    }
    return;
  }

  let filename = "krugle.txt";
  let text = "";
  if (currentView === "code") {
    filename = safeDownloadFileName(currentCodePath, "code.txt");
    text = $("codeBlock").textContent;
  } else {
    filename = "history.csv";
    text = readFileHistoryValues().map((value, index) => `${index + 1},${csv(value)}`).join("\n");
  }
  const blob = new Blob([new Uint8Array([0xef, 0xbb, 0xbf]), text], { type: "text/plain;charset=utf-8" });
  const link = document.createElement("a");
  link.download = filename;
  link.href = URL.createObjectURL(blob);
  link.click();
  URL.revokeObjectURL(link.href);
  showDownloadFeedback("ダウンロードしました", event);
}

async function copyCurrent(event) {
  const visibleView = document.querySelector(".viewBlock.isVisible");
  const text = currentView === "code" ? $("codeBlock").textContent : (visibleView ? visibleView.innerText : "");

  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
    } else if (!fallbackCopyText(text)) {
      throw new Error("fallback copy failed");
    }
    showCopyFeedback("コピーしました", event);
  } catch (e) {
    if (fallbackCopyText(text)) {
      showCopyFeedback("コピーしました", event);
    } else {
      showCopyFeedback("コピーできませんでした", event);
    }
  }
}

function csv(value) {
  return `"${String(value).replaceAll('"', '""')}"`; }

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}



const QUICK_LINK_CSV_PATH = "images/links.csv";
const QUICK_LINK_ICON_PATH = "images/quick-link.svg";
const QUICK_LINK_FALLBACK_ROWS = [
  { label: "CRUD", url: "http://10.202.6.34/BatchSupportSiteManager/crud/crudInit" },
  { label: "HULFT", url: "http://10.202.6.36/cgi-bin/si/index.cgi?controller=HulftList" },
  { label: "RPS", url: "http://10.202.168.238:19001/" },
  { label: "本番RPS", url: "http://10.202.168.238:13010/" },
  { label: "jpmon", url: "http://jpmon.dc/app_index.html" },
  { label: "Desknets", url: "http://d9grphonv01.nss.nksol.co.jp/scripts/dneo/dneo.exe" }
];

function splitQuickLinkCsvLine(line) {
  const cells = [];
  let value = "";
  let inQuote = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line.charAt(i);
    const next = line.charAt(i + 1);
    if (ch === '"' && inQuote && next === '"') {
      value += '"';
      i += 1;
    } else if (ch === '"') {
      inQuote = !inQuote;
    } else if (ch === "," && !inQuote) {
      cells.push(value.trim());
      value = "";
    } else {
      value += ch;
    }
  }
  cells.push(value.trim());
  return cells;
}

function normalizeQuickLinkUrl(url) {
  const value = String(url || "").trim();
  if (!value) return "#";
  if (/^(https?:|mailto:|file:|\/|#)/i.test(value)) return value;
  return `http://${value}`;
}

function parseQuickLinkCsv(text) {
  const rows = [];
  String(text || "")
    .replace(/^\uFEFF/, "")
    .split(/\r?\n/)
    .forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) return;
      const cells = splitQuickLinkCsvLine(line);
      const label = (cells.shift() || "").trim();
      const url = cells.join(",").trim();
      if (!label || !url) return;
      rows.push({ label, url: normalizeQuickLinkUrl(url) });
    });
  return rows;
}

function decodeQuickLinkCsvBuffer(buffer) {
  let text = new TextDecoder("utf-8").decode(buffer);
  if (text.includes("・・")) {
    try {
      const sjisText = new TextDecoder("shift_jis").decode(buffer);
      if (!sjisText.includes("・・")) text = sjisText;
    } catch (ignore) {
      // Edge/Chrome では shift_jis を利用できる。失敗した場合は UTF-8 の結果を使う。
    }
  }
  return text;
}

function orderQuickLinkRows(rows, listElement) {
  const map = new Map();
  rows.forEach(row => {
    if (row && row.label) map.set(row.label, row);
  });

  const currentOrder = Array.from(listElement.querySelectorAll(".quickLinkItem"))
    .map(item => item.dataset.linkName || item.textContent.trim())
    .filter(Boolean);

  const ordered = [];
  currentOrder.forEach(label => {
    if (map.has(label)) {
      ordered.push(map.get(label));
      map.delete(label);
    }
  });

  rows.forEach(row => {
    if (map.has(row.label)) {
      ordered.push(row);
      map.delete(row.label);
    }
  });

  return ordered;
}

function createQuickLinkItem(row) {
  const link = document.createElement("a");
  link.className = "quickLinkItem";
  link.href = normalizeQuickLinkUrl(row.url);
  link.dataset.linkName = row.label;
  if (link.href && link.getAttribute("href") !== "#") {
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  }

  const icon = document.createElement("img");
  icon.className = "quickLinkIconImg";
  icon.src = QUICK_LINK_ICON_PATH;
  icon.alt = "";
  icon.setAttribute("aria-hidden", "true");
  icon.addEventListener("error", () => {
    icon.style.display = "none";
  }, { once: true });

  const text = document.createElement("span");
  text.textContent = row.label;

  link.appendChild(icon);
  link.appendChild(text);
  return link;
}

function renderQuickLinks(rows) {
  const list = $("quickLinkList");
  if (!list) return;

  const orderedRows = orderQuickLinkRows(rows, list);
  list.innerHTML = "";

  if (!orderedRows.length) {
    const empty = document.createElement("div");
    empty.className = "quickLinkItem quickLinkItemEmpty";
    empty.textContent = "links.csv にリンクがありません";
    list.appendChild(empty);
    return;
  }

  orderedRows.forEach(row => {
    list.appendChild(createQuickLinkItem(row));
  });
}

async function loadQuickLinksFromCsv() {
  const list = $("quickLinkList");
  if (!list) return;

  // file://ではローカルCSVへのfetch自体がブラウザ仕様でCORSエラーになる。
  // そのため通信を発生させず、同内容の埋め込み初期値を使用する。
  if (window.location.protocol === "file:") {
    renderQuickLinks(QUICK_LINK_FALLBACK_ROWS);
    return;
  }

  const csvPath = list.dataset.linksCsv || QUICK_LINK_CSV_PATH;
  try {
    const response = await fetch(csvPath, { cache: "no-store", credentials: "same-origin" });
    if (!response.ok) throw new Error(`links.csv load failed: ${response.status}`);
    const buffer = await response.arrayBuffer();
    const rows = parseQuickLinkCsv(decodeQuickLinkCsvBuffer(buffer));
    renderQuickLinks(rows.length ? rows : QUICK_LINK_FALLBACK_ROWS);
  } catch (error) {
    console.warn("links.csvを読み込めないため、埋め込み初期値を使用します。", error);
    renderQuickLinks(QUICK_LINK_FALLBACK_ROWS);
  }
}

function bindEvents() {
  const on = (id, eventName, handler) => {
    const element = $(id);
    if (element) element.addEventListener(eventName, handler);
  };

  document.querySelectorAll(".tabBtn").forEach(button => {
    button.addEventListener("click", () => {
      if (button.classList.contains("tabFile")) {
        const index = Number(button.dataset.code || 0);
        openCode(sampleFiles[index] || sampleFiles[0]);
        document.querySelectorAll(".tabBtn").forEach(item => item.classList.remove("isActive"));
        button.classList.add("isActive");
      } else {
        showView(button.dataset.view);
      }
    });
  });
  on("searchBtn", "click", () => {
    showView("search");
    runSearch(true, "normal");
  });
  on("sampleBtn", "click", () => {
    showView("search");
    runSearch(true, "fuzzy");
  });
  on("downloadBtn", "click", downloadCurrent);
  on("copyBtn", "click", copyCurrent);
  on("krugleBadge", "click", () => {
    showView("home");
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
  on("historyClearBtn", "click", resetStoredHistories);

  // 通常のネイティブ select に戻す。カスタム検索コンボは初期化しない。

  const quickLinkDock = $("quickLinkDock");
  const quickLinkTrigger = $("quickLinkTrigger");
  const quickLinkOverlay = $("quickLinkOverlay");
  const quickLinkPanel = $("quickLinkPanel");
  const quickLinkClose = $("quickLinkClose");

  // 白いリンクパネルに一度でもマウスが入ったかを保持する。
  // パネルに入る前（Linksからパネルへ移動中など）は閉じず、
  // 一度入った後にパネル外へ出た時だけ閉じる。
  let quickLinkPanelHoverActivated = false;

  const setQuickLinkExpanded = expanded => {
    const wasExpanded = Boolean(quickLinkOverlay && quickLinkOverlay.classList.contains("isOpen"));
    if (expanded && !wasExpanded) quickLinkPanelHoverActivated = false;
    if (!expanded) quickLinkPanelHoverActivated = false;

    if (quickLinkTrigger) quickLinkTrigger.setAttribute("aria-expanded", expanded ? "true" : "false");
    if (quickLinkOverlay) {
      quickLinkOverlay.classList.toggle("isOpen", expanded);
      quickLinkOverlay.setAttribute("aria-hidden", expanded ? "false" : "true");

      // 閉じた後の透明な前面要素が、背面の履歴テーブル hover を邪魔しないようにする。
      if (expanded) {
        quickLinkOverlay.removeAttribute("hidden");
        quickLinkOverlay.style.display = "flex";
        quickLinkOverlay.style.pointerEvents = "auto";
        quickLinkOverlay.style.visibility = "visible";
        quickLinkOverlay.style.zIndex = "900";
      } else {
        quickLinkOverlay.setAttribute("hidden", "hidden");
        quickLinkOverlay.style.display = "none";
        quickLinkOverlay.style.pointerEvents = "none";
        quickLinkOverlay.style.visibility = "hidden";
        quickLinkOverlay.style.zIndex = "-1";
      }
    }
    document.body.classList.toggle("quickLinksOpen", expanded);
  };
  const openQuickLinks = () => setQuickLinkExpanded(true);
  const closeQuickLinks = () => {
    setQuickLinkExpanded(false);
  };
  if (quickLinkOverlay) setQuickLinkExpanded(false);

  if (quickLinkDock && quickLinkTrigger && quickLinkOverlay) {
    quickLinkDock.addEventListener("mouseenter", openQuickLinks);
    quickLinkTrigger.addEventListener("focus", openQuickLinks);
    quickLinkTrigger.addEventListener("click", event => {
      event.preventDefault();
      openQuickLinks();
      if (quickLinkPanel) quickLinkPanel.focus({ preventScroll: true });
    });
    if (quickLinkClose) {
      quickLinkClose.addEventListener("click", event => {
        event.preventDefault();
        closeQuickLinks();
      });
    }
    quickLinkOverlay.addEventListener("click", event => {
      if (event.target === quickLinkOverlay) closeQuickLinks();
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape" && quickLinkOverlay.classList.contains("isOpen")) {
        event.preventDefault();
        closeQuickLinks();
      }
    });
  }


  if (quickLinkPanel) {
    quickLinkPanel.addEventListener("mouseenter", () => {
      if (quickLinkOverlay && quickLinkOverlay.classList.contains("isOpen")) {
        quickLinkPanelHoverActivated = true;
      }
    });

    quickLinkPanel.addEventListener("mouseleave", () => {
      if (!quickLinkPanelHoverActivated) return;
      quickLinkPanelHoverActivated = false;
      closeQuickLinks();
    });

    quickLinkPanel.addEventListener("click", event => {
      const link = event.target.closest ? event.target.closest(".quickLinkItem") : null;
      if (!link || link.tagName.toLowerCase() !== "a") return;
      if (!link.getAttribute("href") || link.getAttribute("href") === "#") {
        event.preventDefault();
        const label = link.textContent.trim() || "リンク";
        showCopyFeedback(`${label} のURLは未設定です`);
      }
    });
  }
  // 2026-08-03 サイト修正2: 右/左タブ移動ボタンはホーム・検索結果でも常時表示するため、
  // ソースタブだけではなくヘッダー全体（ホーム → 検索結果 → 数字タブ...）を循環移動する。
  on("codePrevBtn", "click", () => moveMainTabByKeyboard(-1));
  on("codeNextBtn", "click", () => moveMainTabByKeyboard(1));
  on("codeCopyBtn", "click", copyCurrent);
  on("codeDownloadBtn", "click", downloadCurrent);
  const codeModeTabs = document.querySelector(".codeModeTabs");
  if (codeModeTabs) {
    codeModeTabs.addEventListener("click", event => {
      const button = event.target.closest ? event.target.closest(".codeModeTab") : null;
      if (!button || !codeModeTabs.contains(button)) return;
      if (button.disabled || button.getAttribute("aria-disabled") === "true") return;
      activeCodePanel = button.dataset.codePanel || "source";
      if (isTableInfoPanel(activeCodePanel)) {
        activeTableInfoTabId = getTableInfoTabIdFromPanel(activeCodePanel);
        tableInfoState = getActiveTableInfoState();
      }
      renderCode();
    });
  }
  on("smallBtn", "click", () => setCodeFontSize(codeFontSize - CODE_FONT_STEP));
  on("largeBtn", "click", () => setCodeFontSize(codeFontSize + CODE_FONT_STEP));
  on("highlightToggleBtn", "click", toggleCodeHighlightBackground);

  // ページを開いた直後は必ずOFF。下線はCSSで常時表示し、背景色だけを無効にする。
  setCodeHighlightBackgroundEnabled(false);

  on("keywordInput", "focus", () => renderKeywordHistoryDatalist());
  on("keywordInput", "input", () => renderKeywordHistoryDatalist());

  on("keywordInput", "keydown", event => {
    if (event.key === "Enter") {
      showView("search");
      runSearch(true, "normal");
    }
  });

  // captureフェーズで受け取り、ブラウザ標準の履歴戻りより先にサイト内タブ履歴へ割り当てる。
  document.addEventListener("keydown", handleBackspaceTabNavigation, true);

  document.addEventListener("keydown", event => {
    activateFullWidthHoverBandActionByEnter(event);
  }, true);

  // 2026-08-04 サイト修正3: 全幅グレー帯が出ている状態でクリック遷移する場合も、
  // 遷移直後の別hover帯の即時再表示を防ぐ。
  document.addEventListener("click", () => {
    if (document.body && document.body.classList.contains("isRecentTabFullPathBandVisible")) {
      suppressFullWidthHoverBandTemporarily();
    }
  }, true);

  document.addEventListener("keydown", event => {
    if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
    const tagName = event.target && event.target.tagName ? event.target.tagName.toLowerCase() : "";
    if (["input", "select", "textarea"].includes(tagName)) return;
    event.preventDefault();
    moveMainTabByKeyboard(event.key === "ArrowRight" ? 1 : -1);
  });

  const stalker = $("mouseStalker");
  const hoverTargetSelector = [
    "button",
    "#historyFileBody tr",
    "#historySearchBody tr",
    ".tabTime",
    ".recentNavArrow",
    ".krugleBadge",
    ".quickLinkDock",
    ".quickLinkTrigger",
    ".quickLinkOverlay",
    ".quickLinkClose",
    ".quickLinkItem",
    ".searchPanel input",
    ".searchPanel select",
    ".groupCombo",
    ".groupComboItem",
    ".groupComboSearch",
    ".searchPanel .cloneField",
    ".globalHistoryMini tr"
  ].join(",");

  document.addEventListener("mousemove", event => {
    stalker.style.transform = `translate(${event.clientX}px, ${event.clientY}px)`;
    if (event.target.closest && event.target.closest(hoverTargetSelector)) {
      stalker.classList.add("isActive");
    } else {
      stalker.classList.remove("isActive");
    }
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  initializeTabNavigationHistory();
  bindEvents();
  await loadQuickLinksFromCsv();
  resetInitialSearchSummary();
  renderInitialResultPlaceholders();
  renderRecentTabs();
  await loadInitialData();
  await loadInitialSearchResult();
  renderHistory();
});


