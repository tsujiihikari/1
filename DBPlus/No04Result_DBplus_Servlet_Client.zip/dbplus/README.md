# DB+ Servlet / Client 統合修正版

添付の dbplus(1).zip を基に、クライアントとServletを同じAPI仕様で作り直した一式です。
RPSログイン・Cookie・CSRF・文字コード判定・一覧/項目定義の解析は元ソースを再利用しています。
画面は添付 Krugle+.png の背景色、角丸カード、緑系の検索ボタン、横並びタブ、左右の縦ボタンに寄せています。

## 配置と起動

1. src/main/webapp/WEB-INF/config.properties のRPS URLを確認します。
2. src/main/webapp/WEB-INF/DBSchema.csv の接続先を確認します。添付の77接続を変換済みです。
3. 設定を変更した場合は build.bat で再ビルドします。変更しない場合は同梱 dist/dbplus.war をそのまま使用できます。
4. WARを **Java 8以降・javax.servlet 3.x対応コンテナ** に配置します。Tomcat 8.5 / 9系の名前空間に対応します。Tomcat 10以降のjakarta.servletにはそのまま配置できません。
5. コンテキスト名が dbplus の場合、http://サーバー:ポート/dbplus/ を開きます。
6. ドメイン・ログインID・パスワードを入力し、「接続を確認」を押します。
7. DBTYPE・環境・スキーマ / 接続先を選びます。初期取得で4種類の一覧を各50件取得します。

HTMLをファイルとして直接開くとAPIへ接続できません。HTML・JS・CSSとServletは同じWARで配信してください。
RPSとOracleへの通信はServletサーバーから行います。ブラウザーから社内RPS・Oracleへ直接通信しません。

**検証範囲：** Java 17でJava 8向けコンパイル、実HTML解析、模擬RPS/JDBCと実ServletのHTTP結合テスト、
Node DOMハーネスによる実クライアントJSの結合テストを実施しています。
この環境から社内RPS・Oracleへの実接続はできないため未検証です。実Tomcat上の起動・実ブラウザーの外観は現地確認が必要です。

## 同梱物

| パス | 内容 |
| --- | --- |
| src/main/java/jp/dbplus/ | Servlet・RPS処理・Oracle参照・接続定義・JSONのJavaソース |
| src/main/webapp/index.html | 統合画面 |
| src/main/webapp/app.js | ログイン・一覧・検索・ページング・詳細・仮想スクロール |
| src/main/webapp/app.css | Krugle＋に寄せた画面デザイン |
| src/main/webapp/fonts/ | 添付Krugle＋の日本語フォントを再利用 |
| src/main/webapp/WEB-INF/DBSchema.csv | Oracle接続定義。こちらを優先して読み込み |
| src/main/webapp/WEB-INF/DBSchema.properties | 元の77接続のTSV。CSVが存在しない場合の互換用 |
| src/main/webapp/WEB-INF/config.properties | RPS接続先・タイムアウト |
| src/main/webapp/WEB-INF/web.xml | Servlet 3.0 / 4つのURLマッピング |
| src/main/webapp/WEB-INF/lib/ojdbc6.jar | 元ZIPのOracle JDBCドライバー |
| build-tools/servlet-api.jar | 元ZIPのコンパイル用Servlet API。WARには含めません |
| dist/dbplus.war | クライアント・Servletを含むコンパイル済みWAR |
| docs/api.md | 4つのURLと送受信パラメーターの詳細 |
| docs/changes.md | 元ソースからの変更点 |
| docs/verification.md | 実施した検証と現地確認項目 |
| src/test/, qa/ | 実HTMLのテスト、模擬RPS/JDBC、クライアント結合テスト |

元ZIPと同じプレーンJavaScript / CSSの構成です。ランタイムにNode.js、npm、CDN、フロントエンドフレームワークは不要です。
Krugle+.zip の画面資材からはフォントだけを再利用し、Krugle用のJS・Servletは組み込みません。

## Servletの4つのURL

すべて **POST**、同一オリジン、UTF-8フォーム形式、X-DBPlus-Request: 1 ヘッダーを使います。
以下のURLはアプリのコンテキストパスからの相対パスです。

| URL | 用途 | 主な返却内容 |
| --- | --- | --- |
| /api/login | RPSログイン検証 | ok, status: "接続OK"、接続先一覧。失敗は ok: false |
| /api/initial | 初回表示・接続先切替 | テーブル・インデックス・シノニム・ビューをそれぞれ page=1、最大50件 |
| /api/search | 絞り込み・ページ送り | 指定種別と条件の該当ページ、件数、総ページ数 |
| /api/detail | 行を指定した詳細取得 | テーブル定義・DDL・Oracle最大5,000件。非テーブルはDDL |

ログイン情報の共通名は **domain, loginID, loginPass** に統一しています。
RPSへ接続するときだけ、元コードと同じ domain, shain_cd, pass に変換します。
接続先は **connectionId, schema, dbtype** の3項目で一意に決定します。

/api/login の operation=logout でRPS状態を破棄します。ログアウト専用URLを増やしていません。
旧 /api + action=... のインターフェースは廃止しています。旧クライアントと新Servletを混在させないでください。

## 初回一覧と検索

- ログイン後は既定の接続先を選択して、4種類の一覧を各50件取得します。
- 元ソースと同じく、保存した接続先、KYKDB / KYKOWNER / JH、先頭の接続先、の順に初期値を選びます。
- タブ切替は取得済みの一覧を使います。取得に失敗したタブは単独で再取得します。
- 「検索」は前方一致 TYPE=prefix、「曖昧検索」は部分一致 TYPE=contains です。
- 物理名は object_name、日本語名称は description としてServletへ送ります。両方の入力をRPSへ渡します。
- RPSへは物理名を keyword_object_name、日本語名称を keyword_description へ変換します。
- シノニムは元RPSに合わせて物理名を keyword_name、第2条件を keyword_obj_name として渡します。画面の第2条件も「参照先オブジェクト名」へ切り替えます。
- 前方一致は末尾に %、曖昧検索は前後に % を付けます。空欄には % を付けません。
- 入力の先頭・末尾の % は正規化します。内部の % や _ はRPS側の検索仕様に従います。
- 「条件クリア」は空条件で1ページ目を再取得します。「ホーム」はテーブルタブに戻って4種類を再取得します。
- ページ送りは最後に実行した検索条件を使います。入力欄を途中まで書き換えても、検索ボタンを押すまではページ送り条件を変えません。
- 取得中はスピナーと「しばらくお待ちください」を最前面に表示し、二重送信を防ぎます。
- 一覧はRPSから取得します。Oracle接続はテーブル詳細取得時に行います。元ソースの一覧時のOracle辞書照合は呼び出しません。
- RPS側が返す件数・ページ情報をそのまま使用します。全ページの自動巡回は行いません。
- 全項目チェックでRPSの全一覧列を表示できます。

## 詳細ボタン

テーブルの「定義・データ」、テーブル名、一覧のDDLボタンはすべて同じ /api/detail を呼びます。
押したボタンに応じて、取得後にDBデータ・テーブル定義・DDLのいずれかのタブを開きます。
詳細内のタブ切替ではネットワークへの再問い合わせは行いません。

詳細では次の順に取得します。

1. RPSの /column/show_table でテーブル定義を取得します。
2. RPSの /table/show_ddl でDDL本文を取得します。非テーブルはそれぞれの種別の show_ddl を使います。
3. DBSchema.csv から接続先を解決してOracleに接続し、SELECT * FROM "スキーマ"."テーブル" WHERE ROWNUM <= ? のパラメーターに **5,000** を設定して取得します。

OracleのALL_OBJECTSで、対象所有者のTABLEとして存在することを確認してからSELECTします。
RPSの「項目名」とResultSetのカラム名で照合し、データヘッダーへ日本語名を表示します。
名前・バージョンだけを固定値で作らず、一覧の実データから詳細を特定します。

一覧行にはサーバーが recordId を発行します。詳細時には、同じセッションに発行した行かどうかと、
connectionId / schema / dbtype / kind / object_name / version を照合します。
行の説明文はサーバーに保存した値を使います。画面の接続先変更や、同名の別バージョンで取り違えません。
1セッションの登録上限は2,000行です。古い行が失効した場合は一覧を再取得してください。

### 取得上限と失敗時の動作

- Oracleへ発行するSQL自体を ROWNUM <= 5000 相当に制限します。JDBCの最大行数も5,000です。
- 5,001件目の確認クエリーは実行しません。ちょうど5,000件のときは、続きがあるとは断定せず「続きの有無は確認していません」と表示します。
- データの表示は仮想スクロールです。画面付近の行だけをDOMへ展開します。
- Oracleの数値は文字列で返し、JavaScriptの桁落ちを防ぎます。NULLは明示します。
- RPSのバージョンは**定義のバージョン**です。Oracleから取得するデータは**接続先の現在の実データ**です。過去バージョンのデータを再現する機能はありません。
- ORDER BYは付けません。取得順・毎回同じ5,000行になることは保証しません。
- 元ソースのメモリ保護を維持し、値の概算32MiB、1セルの文字値4,096文字、バイナリ4,096バイトを上限にします。上限による省略は表示します。
- テーブル定義・DDL・Oracleデータの失敗は個別に返します。取得できた内容は参照できます。
- 定義だけが失敗した場合、Oracleデータの日本語ヘッダーは空欄となり、失敗を明示します。
- RPS認証が切れた場合は一覧と詳細を破棄し、ログイン画面を再表示します。
- RPSのHTMLは文字列として解析し、ブラウザーでは取得元のスクリプトを実行しません。

## コピー・保存

左右の縦ボタンは、一覧コピー、一覧CSV保存、ページ送りに接続しています。
一覧のコピー・CSVには現在ページの全RPS項目を含めます。全ページのエクスポートではありません。
詳細のコピー・保存は現在の詳細タブが対象で、DBデータは取得済みの最大5,000件を対象にします。
データCSVは物理名・日本語名の2行ヘッダー、DDLは .sql として保存します。
CSVはUTF-8 BOM付き、NULLは文字列 NULL として出力します。

## DBSchema.csv

元ZIPの DBSchema.properties はProperties構文ではなく、ヘッダー付きタブ区切りデータでした。
値と接続順序を維持してCSVへ変換しています。

| 列名 | 用途 |
| --- | --- |
| type | 環境選択 |
| db_type | RPSのDBTYPE |
| rps_schema_name | RPSのset_schema、Oracleの対象所有者 |
| host, port | Oracle接続先 |
| service_name | Oracleサービス名 |
| sid | service_nameが空の場合のSID |
| user_name, password | Oracle認証 |
| id, source_db_version | 元の列を維持。接続解決には使用しません |

CSVが存在すればCSVを優先します。従来TSVだけを使うときはCSVを削除してください。
**両方のファイルを同時に編集する必要はありません。CSVを編集すれば反映されます。**
CSV形式不正の場合に、古いTSVへ黙って切り替えることはありません。
UTF-8 BOM付き/なし、CRLF、引用符付きカンマ・改行・二重引用符に対応します。
従来TSVは文字コード判定によりWindows-31Jにも対応します。

RPSスキーマ名と接続ユーザーは別項目です。同じDBTYPE・スキーマに複数接続がある場合も、画面の connectionId を必須にして一意に選びます。
service_name があれば jdbc:oracle:thin:@//host:port/service_name、空なら jdbc:oracle:thin:@host:port:sid を組み立てます。
DB認証情報は WEB-INF 内に置き、APIの接続先一覧には返しません。

## ログイン情報とセッション

保存チェックを入れた場合、元版と同じ dbplus.rps.credentials.v1 キーのlocalStorageにログイン情報を保存します。
チェックを外した場合、今回のページ内だけで保持します。元版の shain_cd / pass 形式の保存情報も読み込みます。
「保存情報を削除」で端末内の情報を消し、同じログインURLの operation=logout でサーバー状態も破棄します。

サーバーは平文パスワードをセッションに保存せず、照合用ハッシュとRPS Cookieを保持します。
Cookieは利用者のHttpSession単位に分離し、同一セッションのset_schemaと取得を直列化します。
コンテナ再起動やRPS認証期限切れの場合は再ログインしてください。セッション期限は30分です。

## タイムアウト

| 設定 | 既定値 |
| --- | --- |
| http.connect.timeout.ms | 15,000 |
| http.read.timeout.ms | 30,000 |
| jdbc.query.timeout.seconds | 60 |
| jdbc.read.timeout.ms | 30,000 |
| total.timeout.seconds | 540（最大540） |

ブラウザー側の待機上限は550秒です。リバースプロキシ等がある場合は、処理時間より短く切断しないよう現地設定を確認してください。
RPS通信は元版どおり直接接続し、JVM全体のCookie・Proxy設定を変更しません。

## 再ビルド

WindowsではJDKをPATHへ登録して、dbplus フォルダーの build.bat を実行します。管理者権限やMaven、インターネット接続は不要です。
出力は dist/dbplus.war です。JavaソースとWeb資材の両方が同じWARへ入ります。

Python 3とJDKがある場合：

~~~text
python build.py --test
~~~

結合テストも実行する場合はJava 17とPython 3を使用します。--client を付ける場合はNode.js 18以降も使用します。

~~~text
python qa/run-integration.py --client
~~~

結合テストはループバック上の一時ポートで動きます。RPS接続設定はテストプロセス内だけで置き換え、社内RPSやOracleへ接続しません。
模擬JDBCドライバーやテスト用HTTPブリッジは、配布WARには入りません。
