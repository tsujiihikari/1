#!/usr/bin/env python3
"""Python 3とJDKのみで再ビルドする。Maven・インターネット接続は不要。"""
from pathlib import Path
import shutil, subprocess, sys, zipfile

root = Path(__file__).resolve().parent
java = shutil.which('java')
if not java:
    raise SystemExit('JDK 8以降のjavaをPATHへ登録してください。')
compiler = [shutil.which('javac')] if shutil.which('javac') else [java, 'com.sun.tools.javac.Main']
version = subprocess.run([java, '-version'], stderr=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
is8 = '"1.8.' in version.stderr
classes = root / 'build/classes'
if classes.exists(): shutil.rmtree(classes)
classes.mkdir(parents=True)
sources = sorted(str(p) for p in (root/'src/main/java').rglob('*.java'))
target = ['-source', '8', '-target', '8'] if is8 else ['--release', '8']
subprocess.run(compiler + target + ['-encoding','UTF-8','-cp',str(root/'build-tools/servlet-api.jar'),'-d',str(classes)] + sources, check=True)
dist = root/'dist'
dist.mkdir(exist_ok=True)
war = dist/'dbplus.war'
with zipfile.ZipFile(war, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted((root/'src/main/webapp').rglob('*')):
        if p.is_file(): z.write(p, p.relative_to(root/'src/main/webapp').as_posix())
    for p in sorted(classes.rglob('*.class')): z.write(p, 'WEB-INF/classes/'+p.relative_to(classes).as_posix())
if '--test' in sys.argv:
    testclasses=root/'build/test-classes'
    testclasses.mkdir(parents=True,exist_ok=True)
    cp=str(classes)+__import__('os').pathsep+str(root/'build-tools/servlet-api.jar')
    tests=sorted(str(p) for p in (root/'src/test/java').rglob('*.java'))
    subprocess.run(compiler+target+['-encoding','UTF-8','-cp',cp,'-d',str(testclasses)]+tests,check=True)
    subprocess.run([java,'-cp',cp+__import__('os').pathsep+str(testclasses),'jp.dbplus.ContractTest',str(root)],check=True)
print('WAR: '+str(war))
