import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.lang.reflect.*;
import java.util.concurrent.atomic.AtomicInteger;
import com.sun.net.httpserver.*;

/** ローカルHTTPとJDBCモックで接続制御・全ページ取得・辞書突合を検証。実環境には接続しない。 */
public class IntegrationTest {
    static final AtomicInteger requests=new AtomicInteger(), sqlCount=new AtomicInteger();
    static boolean failIndex;
    public static void main(String[] args) throws Exception {
        DriverManager.registerDriver(new MockDriver());
        HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        server.createContext("/", e->{try{serve(e);}catch(Throwable ex){ex.printStackTrace();e.sendResponseHeaders(500,-1);e.close();}});
        server.start();
        Path cfg=Files.createTempFile("dbplus-test-",".properties");
        try {
            String conf="mode=live\nrps.login.enabled=true\nschema=KYKOWNER\ndbtype=KYKDB\nrps.base.url=http://127.0.0.1:"+server.getAddress().getPort()+"\nrps.user=test\nrps.domain=test\nrps.password=test\nrps.interval.ms=1\njdbc.url=jdbc:dbplus:test\njdbc.user=test\njdbc.password=test\n";
            Files.write(cfg,conf.getBytes(StandardCharsets.UTF_8));
            Main.Config c=new Main.Config(cfg);Main.Report r=Main.collect(c);
            Main.check(!r.failed,"正常系取得完了");
            for(Main.Kind k:Main.Kind.values()){
                Main.Part p=r.parts.get(k);Main.check(p.rows.size()==3,"RPS2件とDB追加1件: "+k);
                Main.check(p.rows.stream().anyMatch(x->x.rps&&x.oracle&&x.name.equals("A")),"RPSとOracle一致: "+k);
                Main.check(p.rows.stream().anyMatch(x->x.rps&&!x.oracle&&x.name.equals("B")),"2ページ目取得: "+k);
                Main.check(p.rows.stream().anyMatch(x->!x.rps&&x.oracle&&x.name.equals("DB_ONLY")),"DB単独行: "+k);
            }
            Main.Row ix=r.parts.get(Main.Kind.INDEX).rows.stream().filter(x->x.name.equals("A")).findFirst().get();
            Main.check(ix.db.get("COLUMNS").equals("COL1 ASC, COL2 DESC"),"索引列の順序");
            Main.check(requests.get()==11,"ログイン・リダイレクト・POST・8ページ");Main.check(sqlCount.get()==5,"4辞書と索引列SQL");
            failIndex=true;Main.Report partial=Main.collect(new Main.Config(cfg));
            Main.check(partial.failed&&partial.parts.get(Main.Kind.INDEX).rpsState.contains("失敗"),"取得失敗を空一覧と誤認しない");
            Main.check(partial.parts.get(Main.Kind.TABLE).dbState.equals("辞書取得完了"),"RPS部分失敗でもDB取得継続");
            Path out=Files.createTempFile("dbplus-report-",".html");Main.writeHtml(out,c,partial);Main.check(Files.size(out)>1000,"部分失敗HTML出力");Files.delete(out);
            System.out.println("INTEGRATION TEST OK: Cookie/302/CSRF/POST/4種ページング/JDBCバインド/索引列/和集合/部分失敗");
        } finally {server.stop(0);Files.deleteIfExists(cfg);}
    }
    static void serve(HttpExchange e) throws Exception {
        requests.incrementAndGet();String path=e.getRequestURI().getPath();String response;
        if(path.equals("/login/login")) {e.getResponseHeaders().add("Set-Cookie","sid=test-session; Path=/");e.getResponseHeaders().add("Location","/welcome");e.sendResponseHeaders(302,-1);e.close();return;}
        if(!String.valueOf(e.getRequestHeaders().getFirst("Cookie")).contains("sid=test-session"))throw new AssertionError("Cookieなし: "+e.getRequestHeaders().getFirst("Cookie"));
        if(path.equals("/welcome"))response="<input name='authenticity_token' value='token&amp;value'><input name='schema' value=''>";
        else if(path.equals("/schema/set_schema")) {
            Main.check(e.getRequestMethod().equals("POST"),"POST");ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[1024];int n;while((n=e.getRequestBody().read(buf))!=-1)b.write(buf,0,n);
            String body=new String(b.toByteArray(),StandardCharsets.UTF_8);Main.check(body.contains("schema=KYKOWNER")&&body.contains("authenticity_token=token%26value")&&body.contains("utf8=%E2%9C%93"),"POST本文");response="<input name='schema' value='KYKOWNER'>";
        } else {
            Main.Kind kind=null;for(Main.Kind k:Main.Kind.values())if(path.equals("/"+k.path+"/list"))kind=k;
            if(kind==null)throw new AssertionError("想定外URL");if(failIndex&&kind==Main.Kind.INDEX){e.sendResponseHeaders(401,-1);e.close();return;}
            boolean second=e.getRequestURI().getRawQuery().contains("page=2");
            if(!second)Main.check(e.getRequestURI().getRawQuery().contains("keyword_db=KYKDB"),"DBTYPE検索");
            response="<input name='schema' value='KYKOWNER'><table class='std_hover'><tr>";
            for(String h:kind.headers)response+="<td>"+h+"</td>";
            response+="</tr><tr>";
            for(int i=0;i<kind.headers.length;i++)response+="<td>"+(i==0?"KYKDB":i==1?(second?"B":"A"):i==2?"1.0":i==kind.name2Index()?"日本語名称":kind==Main.Kind.SYNONYM&&i==8?"N":"")+"</td>";
            response+="</tr></table>";if(!second)response+="<a href='/"+kind.path+"/list?pm=ent&amp;page=2' rel='next'>次</a>";
        }
        byte[] bytes=response.getBytes(StandardCharsets.UTF_8);e.getResponseHeaders().add("Content-Type","text/html; charset=UTF-8");e.sendResponseHeaders(200,bytes.length);e.getResponseBody().write(bytes);e.close();
    }
    static Object proxy(Class<?> type,InvocationHandler h){return java.lang.reflect.Proxy.newProxyInstance(IntegrationTest.class.getClassLoader(),new Class<?>[]{type},h);}
    static Object def(Class<?> t){if(t==boolean.class)return false;if(t==int.class)return 0;if(t==long.class)return 0L;return null;}
    static Connection connection(){return (Connection)proxy(Connection.class,(p,m,a)->{if(m.getName().equals("prepareStatement"))return statement((String)a[0]);return def(m.getReturnType());});}
    static PreparedStatement statement(String sql){Map<Integer,String> binds=new HashMap<>();return (PreparedStatement)proxy(PreparedStatement.class,(p,m,a)->{
        if(m.getName().equals("setString")){binds.put((Integer)a[0],(String)a[1]);return null;}
        if(m.getName().equals("executeQuery")){Main.check("KYKOWNER".equals(binds.get(1)),"OWNERはバインド変数");Main.check(!sql.contains("KYKOWNER")&&sql.startsWith("SELECT "),"SELECTのみ");sqlCount.incrementAndGet();return result(sql);}
        return def(m.getReturnType());});}
    static ResultSet result(String sql){
        final String[] columns;final String[][] values;
        if(sql.contains("_IND_COLUMNS")){columns=new String[]{"INDEX_NAME","COLUMN_NAME","COLUMN_POSITION","DESCEND"};values=new String[][]{{"A","COL1","1","ASC"},{"A","COL2","2","DESC"}};}
        else {columns=new String[]{"OWNER","NAME","COMMENTS","TABLE_NAME","TABLE_OWNER"};values=new String[][]{{"KYKOWNER","A","Oracle日本語名","BASE_T","OTHER"},{"KYKOWNER","DB_ONLY","DBのみ","BASE_T","OTHER"}};}
        final int[] idx={-1};return (ResultSet)proxy(ResultSet.class,(p,m,a)->{
            if(m.getName().equals("next"))return ++idx[0]<values.length;
            if(m.getName().equals("getString")){int col=a[0] instanceof Integer?(Integer)a[0]-1:Arrays.asList(columns).indexOf((String)a[0]);return values[idx[0]][col];}
            if(m.getName().equals("getMetaData"))return proxy(ResultSetMetaData.class,(pp,mm,aa)->{if(mm.getName().equals("getColumnCount"))return columns.length;if(mm.getName().equals("getColumnLabel"))return columns[(Integer)aa[0]-1];return def(mm.getReturnType());});
            return def(m.getReturnType());});
    }
    static class MockDriver implements Driver {
        public boolean acceptsURL(String u){return u.startsWith("jdbc:dbplus:");}
        public Connection connect(String u,Properties p){return acceptsURL(u)?connection():null;}
        public DriverPropertyInfo[] getPropertyInfo(String u,Properties p){return new DriverPropertyInfo[0];}
        public int getMajorVersion(){return 1;}public int getMinorVersion(){return 0;}public boolean jdbcCompliant(){return false;}
        public java.util.logging.Logger getParentLogger(){return java.util.logging.Logger.getGlobal();}
    }
}
