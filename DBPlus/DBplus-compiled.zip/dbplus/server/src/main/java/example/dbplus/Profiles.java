package example.dbplus;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** 接続資格情報はコンテナのJNDIへ外出し。ブラウザからJDBC URLを受け取らない。 */
final class Profiles {
    final Map<String,Profile> items = new LinkedHashMap<>();
    Profiles(String path) throws IOException {
        if(path==null||path.trim().isEmpty()) return; // 未設定は空の許可リスト。架空接続は作らない。
        Properties p=new Properties(); try(InputStream in=Files.newInputStream(Paths.get(path))) {p.load(new InputStreamReader(in,"UTF-8"));}
        for(String id:split(p.getProperty("profiles",""))) {
            String prefix="profile."+id+".";
            Profile x=new Profile(id,p.getProperty(prefix+"label",id),p.getProperty(prefix+"dialect",""),p.getProperty(prefix+"jndi",""),split(p.getProperty(prefix+"schemas","")),split(p.getProperty(prefix+"tables","")),p.getProperty(prefix+"definitionSource","catalog"),p.getProperty(prefix+"rpsJndi",""),p.getProperty(prefix+"rpsDbType",""),p.getProperty(prefix+"rpsVersion",""));
            if(!Arrays.asList("postgresql","oracle11g").contains(x.dialect)||!x.jndi.startsWith("java:comp/env/")||x.schemas.isEmpty()||x.tables.isEmpty()||!Arrays.asList("catalog","rps","none").contains(x.definitionSource)) throw new IOException("接続プロファイルの設定が不正です: "+id);
            if("rps".equals(x.definitionSource)&&(!x.rpsJndi.startsWith("java:comp/env/")||x.rpsDbType.isEmpty()||x.rpsVersion.isEmpty())) throw new IOException("RPS対応設定が不足しています: "+id);
            if(items.put(id,x)!=null) throw new IOException("接続IDの重複");
        }
    }
    private static List<String> split(String s) {List<String> out=new ArrayList<>();for(String v:s.split(","))if(!v.trim().isEmpty())out.add(v.trim());return out;}
    Profile get(String id) throws Api.Problem {Profile p=items.get(id);if(p==null)throw new Api.Problem(403,"CONNECTION_DENIED","この接続先は許可されていません。");return p;}
    static final class Profile {
        final String id,label,dialect,jndi,definitionSource,rpsJndi,rpsDbType,rpsVersion;
        final List<String> schemas,tables;
        Profile(String id,String label,String dialect,String jndi,List<String> schemas,List<String> tables,String source,String rpsJndi,String dbType,String version){this.id=id;this.label=label;this.dialect=dialect;this.jndi=jndi;this.schemas=schemas;this.tables=tables;this.definitionSource=source;this.rpsJndi=rpsJndi;this.rpsDbType=dbType;this.rpsVersion=version;}
        void allowSchema(String schema) throws Api.Problem {if(!schemas.contains(schema))throw new Api.Problem(403,"SCHEMA_DENIED","このスキーマは許可されていません。");}
        boolean allowsTable(String name) {return tables.contains("*")||tables.contains(name);}
        DataSource source() throws NamingException {return (DataSource)new InitialContext().lookup(jndi);}
        DataSource rpsSource() throws NamingException {return (DataSource)new InitialContext().lookup(rpsJndi);}
    }
}
