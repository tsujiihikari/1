import java.nio.file.*;
import java.util.*;
/** 添付の保存HTMLを使い、旧レイアウトの名前・バージョンの列順を確認する。 */
public class RpsFixtureTest {
    public static void main(String[] args) throws Exception {
        Path dir=Paths.get(args.length==0?".":args[0]);
        Main.Config c=new Main.Config(Paths.get("__test_defaults__"));
        for(String f:new String[]{"_debug_table_list.html","_debug_table_list_page1.html"}) {
            List<Main.Row> rows=Main.parse(Main.readLocal(dir.resolve(f),"auto"),Main.Kind.TABLE,c);
            Main.check(rows.size()>1000,"大規模一覧の読み取り");
            Main.Row a=rows.stream().filter(r->r.name.equals("AGENT_DETAIL")).findFirst().get();
            Main.check(Main.cell(a,2).equals("1.2")&&Main.cell(a,4).equals("取次明細"),"旧形式の列順・日本語名称");
            System.out.println(f+": "+rows.size()+"件 OK");
        }
    }
}
