#!/usr/bin/env python3
"""コンパイル済みクライアント資産のみをServletのwebappへ配置する。"""
from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
out=root/'server/src/main/webapp'
shutil.copy2(root/'index.html',out/'index.html')
for folder,suffixes in [('js',['.js']),('css',['.css']),('images',['.svg']),('config',['.json'])]:
    target=out/folder
    if target.exists(): shutil.rmtree(target)
    target.mkdir(parents=True)
    for path in (root/folder).iterdir():
        if path.suffix in suffixes: shutil.copy2(path,target/path.name)
print('Servlet webapp資産を更新しました。')
