"use strict";

// Servlet APIへ接続する。Tomcat側は krugleapi.war -> /krugleapi 固定。
// index.html を file:// で直接開く検証のため、APIはTomcatの絶対URLに固定する。
const USE_SAMPLE_DATA = false;
const KRUGLE_CONTEXT_PATH = "/krugleapi";
const KRUGLE_API_ABSOLUTE_BASE = "http://kruglecodex.com:8080/krugleapi";
const API_BASE = window.KRUGLE_API_BASE || KRUGLE_API_ABSOLUTE_BASE;

const sampleFiles = [
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.8jjj8jjeJEjeeTableAccessor",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand002",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask003",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor004",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor008",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand009",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask010",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor011",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor012",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor015",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand016",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask017",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor018",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor019",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor022",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand023",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask024",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor025",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor026",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor029",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand030",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask031",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor032",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor033",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor036",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand037",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask038",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor039",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor040",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor043",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand044",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask045",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor046",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor047",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor050",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand051",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask052",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor053",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor054",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor057",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand058",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask059",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor060",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor061",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor064",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand065",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask066",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor067",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor068",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor071",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand072",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask073",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor074",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor075",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor078",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand079",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask080",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor081",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor082",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor085",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand086",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask087",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor088",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor089",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor092",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand093",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask094",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor095",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor096",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor099",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand100",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask101",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor102",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor103",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor106",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand107",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask108",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor109",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor110",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor113",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand114",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask115",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor116",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor117",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor120",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand121",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask122",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor123",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor124",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor127",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand128",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask129",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor130",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor131",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor134",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand135",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask136",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor137",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor138",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor141",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand142",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask143",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor144",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor145",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor148",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand149",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask150",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor151",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor152",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor155",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand156",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask157",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor158",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor159",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor162",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand163",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask164",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor165",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor166",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor169",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand170",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask171",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor172",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor173",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor176",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand177",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask178",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor179",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor180",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor183",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand184",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask185",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor186",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor187",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor190",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand191",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask192",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor193",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor194",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor197",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand198",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask199",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor200",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor201",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor204",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand205",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask206",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor207",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor208",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor211",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand212",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask213",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor214",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor215",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor218",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand219",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask220",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor221",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor222",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor225",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand226",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask227",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor228",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor229",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor232",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand233",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask234",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor235",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor236",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor239",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand240",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask241",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor242",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor243",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor246",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand247",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask248",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor249",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor250",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor253",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand254",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask255",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor256",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor257",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor260",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand261",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask262",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor263",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor264",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor267",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand268",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask269",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor270",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor271",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor274",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand275",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask276",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor277",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor278",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor281",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand282",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask283",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor284",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor285",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor288",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand289",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask290",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor291",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor292",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql",
  "nikkoEZ.nikkoEZ/ez/config/application-context.xml",
  "NewNikko.nkCCIS/kayk.online/lib/KjCTMYYYYYY.jar/jp.com.xxx.xxx.xxx.KYF1940TableAccessor295",
  "NewNikko.nkCCIS/business-java/lib/KjCommand.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchCommand296",
  "NewNikko.nkCCIS/business-java/lib/KjTask.jar/jp.com.xxx.xxx.xxx.KjCustomerSearchTask297",
  "BPNet.BPNet/bpnet_dbac/lib/OrderDbac.jar/jp.com.xxx.xxx.xxx.ORD0100QueryAccessor298",
  "SMBC.SMBC/smbc_dbac/lib/AccountDbac.jar/jp.com.xxx.xxx.xxx.AccountUpdateTableAccessor299",
  "fast2024.fast2024/fast/sql/customer/customer-search.sql"
];
const RECENT_TAB_STORE_LIMIT = 100;
const RECENT_TAB_VISIBLE_LIMIT = 21;
const RECENT_TAB_MIN_COUNT = 35;
const INITIAL_HISTORY_SAMPLE_COUNT = 20;
const HISTORY_PLACEHOLDER_VALUE = "-";
const INITIAL_RESULT_PLACEHOLDER_COUNT = 30;
let recentWindowStart = 0;
let activeRecentTabKey = "";
let manualRecentWindowShift = false;

function buildSampleRecentTabs() {
  // 時間タブのサンプルデータは100件用意する。表示は renderRecentTabs() 側で21件だけに絞る。
  const base = new Date("2026-06-11T13:08:00");
  const result = [];
  for (let index = 0; index < RECENT_TAB_STORE_LIMIT; index += 1) {
    const openedAt = new Date(base.getTime() - (index * 47 * 60 * 1000));
    result.push({
      path: sampleFiles[index % sampleFiles.length],
      openedAt: openedAt.toISOString()
    });
  }
  return result;
}

const sampleRecentTabs = buildSampleRecentTabs();
let sessionRecentTabs = null;

const sampleSearchWords = [
  "TableAccessor | ALL | ALL",
  "CUSTOMER_ID | nkCCIS | java",
  "Command Task Accessor | BPNet | Java",
  "MST_CUSTOMER | SMBC | SQL",
  "QueryAccessor | fast2024 | XML",
  "AccountUpdate | nikkoEZ | ALL",
  "KYF1940 | ALL | java",
  "8jjj8jjeJEjee | nkCCIS | Java",
  "TableAccessor009 | BPNet | SQL",
  "CUSTOMER_ID010 | SMBC | XML",
  "Command Task Accessor011 | fast2024 | ALL",
  "MST_CUSTOMER012 | nikkoEZ | java",
  "QueryAccessor013 | ALL | Java",
  "AccountUpdate014 | nkCCIS | SQL",
  "KYF1940015 | BPNet | XML",
  "8jjj8jjeJEjee016 | SMBC | ALL",
  "TableAccessor017 | fast2024 | java",
  "CUSTOMER_ID018 | nikkoEZ | Java",
  "Command Task Accessor019 | ALL | SQL",
  "MST_CUSTOMER020 | nkCCIS | XML",
  "QueryAccessor021 | BPNet | ALL",
  "AccountUpdate022 | SMBC | java",
  "KYF1940023 | fast2024 | Java",
  "8jjj8jjeJEjee024 | nikkoEZ | SQL",
  "TableAccessor025 | ALL | XML",
  "CUSTOMER_ID026 | nkCCIS | ALL",
  "Command Task Accessor027 | BPNet | java",
  "MST_CUSTOMER028 | SMBC | Java",
  "QueryAccessor029 | fast2024 | SQL",
  "AccountUpdate030 | nikkoEZ | XML",
  "KYF1940031 | ALL | ALL",
  "8jjj8jjeJEjee032 | nkCCIS | java",
  "TableAccessor033 | BPNet | Java",
  "CUSTOMER_ID034 | SMBC | SQL",
  "Command Task Accessor035 | fast2024 | XML",
  "MST_CUSTOMER036 | nikkoEZ | ALL",
  "QueryAccessor037 | ALL | java",
  "AccountUpdate038 | nkCCIS | Java",
  "KYF1940039 | BPNet | SQL",
  "8jjj8jjeJEjee040 | SMBC | XML",
  "TableAccessor041 | fast2024 | ALL",
  "CUSTOMER_ID042 | nikkoEZ | java",
  "Command Task Accessor043 | ALL | Java",
  "MST_CUSTOMER044 | nkCCIS | SQL",
  "QueryAccessor045 | BPNet | XML",
  "AccountUpdate046 | SMBC | ALL",
  "KYF1940047 | fast2024 | java",
  "8jjj8jjeJEjee048 | nikkoEZ | Java",
  "TableAccessor049 | ALL | SQL",
  "CUSTOMER_ID050 | nkCCIS | XML",
  "Command Task Accessor051 | BPNet | ALL",
  "MST_CUSTOMER052 | SMBC | java",
  "QueryAccessor053 | fast2024 | Java",
  "AccountUpdate054 | nikkoEZ | SQL",
  "KYF1940055 | ALL | XML",
  "8jjj8jjeJEjee056 | nkCCIS | ALL",
  "TableAccessor057 | BPNet | java",
  "CUSTOMER_ID058 | SMBC | Java",
  "Command Task Accessor059 | fast2024 | SQL",
  "MST_CUSTOMER060 | nikkoEZ | XML",
  "QueryAccessor061 | ALL | ALL",
  "AccountUpdate062 | nkCCIS | java",
  "KYF1940063 | BPNet | Java",
  "8jjj8jjeJEjee064 | SMBC | SQL",
  "TableAccessor065 | fast2024 | XML",
  "CUSTOMER_ID066 | nikkoEZ | ALL",
  "Command Task Accessor067 | ALL | java",
  "MST_CUSTOMER068 | nkCCIS | Java",
  "QueryAccessor069 | BPNet | SQL",
  "AccountUpdate070 | SMBC | XML",
  "KYF1940071 | fast2024 | ALL",
  "8jjj8jjeJEjee072 | nikkoEZ | java",
  "TableAccessor073 | ALL | Java",
  "CUSTOMER_ID074 | nkCCIS | SQL",
  "Command Task Accessor075 | BPNet | XML",
  "MST_CUSTOMER076 | SMBC | ALL",
  "QueryAccessor077 | fast2024 | java",
  "AccountUpdate078 | nikkoEZ | Java",
  "KYF1940079 | ALL | SQL",
  "8jjj8jjeJEjee080 | nkCCIS | XML"
];

const sampleResults = [
  { file: "KYF1940TableAccessor.java", line: 128, project: "NewNikko", group: "nkCCIS", path: "kayk.online/lib/KjCTMYYYYYY.jar/jp/com/xxx/xxx/xxx/KYF1940TableAccessor.java" },
  { file: "KYF1950TableAccessor.java", line: 82, project: "NewNikko", group: "nkCCIS", path: "kayk.online/lib/KjCTMYYYYYY.jar/jp/com/xxx/xxx/xxx/KYF1950TableAccessor.java" },
  { file: "KjCustomerSearchCommand.java", line: 45, project: "NewNikko", group: "nkCCIS", path: "business-java/lib/KjCommand.jar/jp/com/xxx/command/KjCustomerSearchCommand.java" },
  { file: "KjCustomerSearchTask.java", line: 211, project: "NewNikko", group: "nkCCIS", path: "business-java/lib/KjTask.jar/jp/com/xxx/task/KjCustomerSearchTask.java" },
  { file: "ORD0100QueryAccessor.java", line: 67, project: "BPNet", group: "BPNet", path: "bpnet_dbac/lib/OrderDbac.jar/jp/com/xxx/dbac/ORD0100QueryAccessor.java" },
  { file: "AccountUpdateTableAccessor.java", line: 159, project: "SMBC", group: "SMBC", path: "smbc_dbac/lib/AccountDbac.jar/jp/com/xxx/dbac/AccountUpdateTableAccessor.java" },
  { file: "customer-search.sql", line: 14, project: "fast2024", group: "fast2024", path: "fast/sql/customer/customer-search.sql" },
  { file: "application-context.xml", line: 33, project: "nikkoEZ", group: "nikkoEZ", path: "ez/config/application-context.xml" } ];

const sampleCode = `package jp.com.xxx.xxx.xxx;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class KYF1940TableAccessor {
    private static final String SQL_SELECT =
        "SELECT CUSTOMER_ID, CUSTOMER_NAME, STATUS " +
        "FROM MST_CUSTOMER " +
        "WHERE CUSTOMER_ID = ?";

    public List<CustomerDto> selectCustomer(Connection con, String customerId) throws Exception {
        List<CustomerDto> result = new ArrayList<CustomerDto>();
        try (PreparedStatement ps = con.prepareStatement(SQL_SELECT)) {
            ps.setString(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    CustomerDto dto = new CustomerDto();
                    dto.setCustomerId(rs.getString("CUSTOMER_ID"));
                    dto.setCustomerName(rs.getString("CUSTOMER_NAME"));
                    dto.setStatus(rs.getString("STATUS"));
                    result.add(dto);
                }
            }
        }
        return result;
    }
}`;

const sampleAiCode = `// AIによる解説コード
// このAccessorは、CUSTOMER_IDを条件にMST_CUSTOMERを検索するサンプルです。
// SQL_SELECTで取得項目を定義し、PreparedStatementでバインド変数を設定します。
// ResultSetを1行ずつDTOへ詰め替えて、呼び出し元へListで返却します。

public List<CustomerDto> selectCustomer(Connection con, String customerId) throws Exception {
    // 1. 戻り値用のリストを作成
    List<CustomerDto> result = new ArrayList<CustomerDto>();

    // 2. CUSTOMER_IDを条件に検索
    try (PreparedStatement ps = con.prepareStatement(SQL_SELECT)) {
        ps.setString(1, customerId);

        // 3. 検索結果をDTOへ変換
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                CustomerDto dto = new CustomerDto();
                dto.setCustomerId(rs.getString("CUSTOMER_ID"));
                dto.setCustomerName(rs.getString("CUSTOMER_NAME"));
                dto.setStatus(rs.getString("STATUS"));
                result.add(dto);
            }
        }
    }
    return result;
}`;

const sampleSummaryText = `要約説明

・MST_CUSTOMERを検索するTableAccessorです。
・CUSTOMER_IDを検索条件としてPreparedStatementに設定します。
・取得したCUSTOMER_ID、CUSTOMER_NAME、STATUSをCustomerDtoへ詰め替えます。
・検索結果はList<CustomerDto>として返却します。`;

let currentView = "home";
let currentCodePath = USE_SAMPLE_DATA ? sampleFiles[1] : "";
let codeFontSize = 14;
const CODE_FONT_MIN = 9;
const CODE_FONT_MAX = 24;
const CODE_FONT_STEP = 1;
let activeCodePanel = "source";
let lastSearchParams = null;
let lastSearchMode = "prefix";
let lastSearchResults = [];
let currentCodeMeta = null;
let currentSourceText = "";
let currentSourceLanguage = "java";

function $(id) {
  return document.getElementById(id);
}

function formatDateTime(value) {
  const date = toSafeDate(value);
  const pad = value => String(value).padStart(2, "0");
  const week = ["日", "月", "火", "水", "木", "金", "土"][date.getDay()];
  return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())}(${week}) ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function formatSummaryDateTimeValue(value, fallbackDate) {
  const text = String(value == null ? "" : value).trim();
  if (text && text !== "-") {
    if (/^\d{4}\/\d{2}\/\d{2}\([日月火水木金土]\)\s+\d{2}:\d{2}:\d{2}$/.test(text)) {
      return text;
    }
    return formatDateTime(text);
  }
  return fallbackDate ? formatDateTime(fallbackDate) : "-";
}


function apiPath(path) {
  const cleanPath = String(path || "").replace(/^\/+/, "");
  const base = String(API_BASE || "").trim();
  if (base) {
    if (/^https?:\/\//i.test(base)) {
      const normalizedBase = base.endsWith("/") ? base : `${base}/`;
      return new URL(cleanPath, normalizedBase).toString();
    }
    const normalizedBase = base.endsWith("/") ? base.slice(0, -1) : base;
    return `${normalizedBase}/${cleanPath}`;
  }
  // 念のためフォールバック。通常は /krugleapi/search の絶対パスになる。
  return `${KRUGLE_CONTEXT_PATH}/${cleanPath}`;
}

function formBody(params) {
  const body = new URLSearchParams();
  Object.keys(params || {}).forEach(key => {
    const value = params[key];
    if (value !== undefined && value !== null) body.append(key, String(value));
  });
  return body;
}

function buildQueryString(params) {
  return formBody(params).toString();
}

async function fetchJson(path, params = {}, options = {}) {
  const method = String(options.method || "POST").toUpperCase();
  let url = apiPath(path);

  const requestOptions = {
    method,
    headers: {
      "Accept": "application/json"
    },
    cache: "no-store",
    mode: "cors",
    credentials: "omit"
  };

  if (method === "GET") {
    const query = buildQueryString(params);
    if (query) url += (url.indexOf("?") >= 0 ? "&" : "?") + query;
  } else {
    // file:// から呼ぶため、不要なプリフライトを増やさない。
    // charset 付き Content-Type は避け、単純な x-www-form-urlencoded にする。
    requestOptions.headers["Content-Type"] = "application/x-www-form-urlencoded";
    requestOptions.body = formBody(params);
  }

  let response;
  try {
    response = await fetch(url, requestOptions);
  } catch (e) {
    throw new Error(`通信失敗: ${e.message}
URL: ${url}
※ file:// から呼ぶ場合、Servlet側のCORSヘッダが必要です。`);
  }

  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (e) {
      throw new Error(`JSON解析失敗 HTTP ${response.status}: ${text.substring(0, 300)}
URL: ${url}`);
    }
  } else {
    data = {};
  }

  if (!response.ok) {
    throw new Error((data && data.error) ? `${data.error}
URL: ${url}` : `HTTP ${response.status}
URL: ${url}`);
  }
  return data;
}

function submitDownload(path, params = {}) {
  const form = document.createElement("form");
  form.method = "POST";
  form.action = apiPath(path);
  form.style.display = "none";

  Object.keys(params || {}).forEach(key => {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = key;
    input.value = params[key] == null ? "" : String(params[key]);
    form.appendChild(input);
  });

  document.body.appendChild(form);
  form.submit();
  setTimeout(() => form.remove(), 1000);
}

function optionText(selectElement) {
  if (!selectElement) return "";
  const option = selectElement.options[selectElement.selectedIndex];
  return option ? option.textContent.trim() : "";
}

function normalizeKeywordForMode(rawKeyword, mode) {
  const base = String(rawKeyword || "").trim().replace(/^\*+/, "").replace(/\*+$/, "");
  if (mode === "fuzzy") return `*${base}*`;
  return `${base}*`;
}

function buildSearchParams(mode = "prefix") {
  const keywordInput = $("keywordInput");
  const projectSelect = $("groupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  const rawKeyword = keywordInput ? keywordInput.value.trim() : "";
  const project = projectSelect ? projectSelect.value : "ALL";
  const language = languageSelect ? languageSelect.value : "ALL";
  const languageForApi = language === "ALL" ? "ALL" : String(language).toLowerCase();

  return {
    rawKeyword,
    keyword: normalizeKeywordForMode(rawKeyword, mode),
    project,
    projectText: optionText(projectSelect) || project,
    language,
    languageText: optionText(languageSelect) || language,
    languageForApi,
    findin: "ALL",
    clone: cloneCheck && cloneCheck.checked ? "YES" : "NO",
    source_disp: "NO"
  };
}

function normalizeSearchRow(row, index = 0) {
  const source = row || {};
  const fileName = source.fileName || source.file || source.name || "";
  const path = source.path || source.fullPath || source.filePath || fileName;
  const project = source.project || source.group || "";
  const projectParts = String(project).split(".");
  const group = source.group || (projectParts.length > 1 ? projectParts[1] : projectParts[0]) || "";

  return {
    no: source.no || String(index + 1),
    fileName,
    lineNo: source.lineNo || source.line || "",
    project,
    group,
    directoryGroup: source.directoryGroup || getDirectoryGroup(path),
    path,
    href: source.href || "",
    sourceUrl: source.sourceUrl || "",
    preview: source.preview || "",
    language: source.language || inferLanguageFromPath(path, "java")
  };
}

function setText(id, value) {
  const element = $(id);
  if (element) element.textContent = value == null ? "" : String(value);
}

function setSummaryFromParams(params, startedAt, endedAt, hitCount) {
  setText("summaryCount", hitCount == null ? "-" : hitCount);
  setText("summaryKeyword", params ? params.rawKeyword : "");
  setText("summaryProject", params ? (params.projectText || params.project) : "");
  setText("summaryLanguage", params ? (params.languageText || params.language) : "");
  setText("summaryStart", startedAt ? formatDateTime(startedAt) : "-");
  setText("summaryEnd", endedAt ? formatDateTime(endedAt) : "-");
  setText("summaryClone", params && params.clone === "YES" ? "表示" : "非表示");
}

function setSummaryFromServer(summary, params, startedAt, endedAt, fallbackCount) {
  const source = summary || {};
  setText("summaryCount", source.hitCount || source.count || fallbackCount || 0);
  setText("summaryKeyword", source.keyword || (params ? params.rawKeyword : ""));
  setText("summaryProject", source.project || (params ? (params.projectText || params.project) : ""));
  setText("summaryLanguage", source.language || (params ? (params.languageText || params.language) : ""));
  setText("summaryStart", formatSummaryDateTimeValue(source.startTime, startedAt));
  setText("summaryEnd", formatSummaryDateTimeValue(source.endTime, endedAt));
  setText("summaryClone", source.clone || (params && params.clone === "YES" ? "表示" : "非表示"));
}

function buildInitialResultPlaceholderRows(count = INITIAL_RESULT_PLACEHOLDER_COUNT) {
  return Array.from({ length: count }, (_, index) => ({
    no: String(index + 1),
    fileName: HISTORY_PLACEHOLDER_VALUE,
    group: HISTORY_PLACEHOLDER_VALUE,
    directoryGroup: HISTORY_PLACEHOLDER_VALUE,
    path: HISTORY_PLACEHOLDER_VALUE,
    placeholder: true
  }));
}

function renderInitialResultPlaceholders() {
  renderSearchInitialEmptyState();
}

function renderSearchInitialEmptyState() {
  const body = $("resultBody");
  if (!body) return;
  const card = document.querySelector("#searchView .resultCard");
  if (card) {
    card.classList.add("isInitialEmptyResultCard");
    card.classList.remove("hasSearchResultRows");
  }
  body.innerHTML = `
    <tr class="resultEmptyStateRow">
      <td colspan="5">
        <div class="resultEmptyStateMessage">検索結果がここに表示されます</div>
      </td>
    </tr>
  `;
}

function resetInitialSearchSummary() {
  setText("summaryCount", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryKeyword", "");
  setText("summaryProject", "ALL");
  setText("summaryLanguage", "ALL");
  setText("summaryStart", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryEnd", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryClone", "非表示");
}

function renderSearchRows(rows, options = {}) {
  const body = $("resultBody");
  if (!body) return;

  const isPlaceholderMode = options && options.placeholder === true;
  const normalizedRows = Array.isArray(rows) ? (isPlaceholderMode ? rows : rows.map(normalizeSearchRow)) : [];
  const card = document.querySelector("#searchView .resultCard");
  if (card) {
    card.classList.remove("isInitialEmptyResultCard");
    card.classList.toggle("hasSearchResultRows", normalizedRows.length > 0);
  }
  if (!normalizedRows.length) {
    body.innerHTML = `
      <tr class="resultNoDataRow">
        <td colspan="5">検索結果がありません</td>
      </tr>
    `;
    return;
  }

  body.innerHTML = normalizedRows.map((row, index) => `
    <tr class="${row.placeholder ? "isPlaceholderResultRow" : ""}" data-index="${index}" title="${escapeHtml(row.placeholder ? "" : (row.preview || row.path))}">
      <td>${escapeHtml(row.no || String(index + 1))}</td>
      <td>${escapeHtml(row.fileName || row.path)}</td>
      <td>${escapeHtml(row.group || row.project)}</td>
      <td>${escapeHtml(row.directoryGroup || "")}</td>
      <td>${escapeHtml(row.path || "")}</td>
    </tr>
  `).join("");

  body.querySelectorAll("tr[data-index]").forEach(rowElement => {
    rowElement.addEventListener("click", () => {
      const row = normalizedRows[Number(rowElement.dataset.index)];
      if (row && !row.placeholder) openCode(row.path, { row });
    });
  });
}

function inferLanguageFromPath(path, fallback = "plaintext") {
  const value = String(path || "").toLowerCase();
  if (value.endsWith(".java")) return "java";
  if (value.endsWith(".sql")) return "sql";
  if (value.endsWith(".xml")) return "xml";
  if (value.endsWith(".jsp")) return "xml";
  if (value.endsWith(".html") || value.endsWith(".htm")) return "xml";
  if (value.endsWith(".js")) return "javascript";
  if (value.endsWith(".css")) return "css";
  if (value.endsWith(".sh")) return "bash";
  return fallback;
}

async function loadInitialData() {
  if (USE_SAMPLE_DATA) return;

  try {
    const data = await fetchJson("/init", {}, { method: "GET" });
    const projects = Array.isArray(data.projects) ? data.projects : [];
    const select = $("groupSelect");
    if (!select || !projects.length) return;

    const current = select.value || "ALL";
    const options = [`<option value="ALL">すべて</option>`].concat(projects.map(project => {
      const value = typeof project === "string" ? project : (project.value || project.text || "");
      const text = typeof project === "string" ? project : (project.text || project.value || "");
      const selected = project && project.selected ? " selected" : "";
      return `<option value="${escapeHtml(value)}"${selected}>${escapeHtml(text)}</option>`;
    }));
    select.innerHTML = options.join("");
    if (Array.from(select.options).some(option => option.value === current)) {
      select.value = current;
    }
  } catch (e) {
    console.error(e);
    showCopyFeedback("/init 接続失敗");
  }
}

function readArray(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) && value.length > 0 ? value : fallback;
  } catch (e) {
    return fallback;
  }
}

function saveArray(key, value) {
  localStorage.setItem(key, JSON.stringify(value.slice(0, key === "krugle.history.files" ? 300 : 100))); }

function isAutoFilledRecentTab(item) {
  return Boolean(item && (item.autoFilled === true || item.__autoFilled === true));
}

function createAutoFilledRecentTab(path, openedAt) {
  return {
    path: path || currentCodePath || sampleFiles[0],
    openedAt: toSafeDate(openedAt).toISOString(),
    autoFilled: true
  };
}

function ensureMinimumRecentTabs(tabs) {
  const base = (Array.isArray(tabs) ? tabs : [])
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (base.length === 0) {
    base.push(createAutoFilledRecentTab(currentCodePath || sampleFiles[0], new Date()));
  }

  // 実履歴が35件未満の場合は、画面右端にある最後の時刻から1分ずつ戻して35件まで補完する。
  // 補完行は localStorage へ保存しない。実際に閲覧された履歴と混ざらないよう autoFilled を付ける。
  let cursor = toSafeDate(base[base.length - 1].openedAt);
  const fillerPath = base[base.length - 1].path || currentCodePath || sampleFiles[0];
  while (base.length < RECENT_TAB_MIN_COUNT) {
    cursor = new Date(cursor.getTime() - 60 * 1000);
    base.push(createAutoFilledRecentTab(fillerPath, cursor));
  }

  return base.slice(0, RECENT_TAB_STORE_LIMIT);
}

function readRecentTabs() {
  // サンプルモードでも、履歴行クリックで追加した「現在日時タブ」は画面上に反映する。
  if (USE_SAMPLE_DATA) {
    const source = Array.isArray(sessionRecentTabs) && sessionRecentTabs.length > 0 ? sessionRecentTabs : sampleRecentTabs;
    return ensureMinimumRecentTabs(source.map(normalizeRecentTab));
  }
  try {
    const value = JSON.parse(localStorage.getItem("krugle.history.recentTabs"));
    const normalized = Array.isArray(value) ? value
      .slice(0, RECENT_TAB_STORE_LIMIT)
      .filter(item => !isAutoFilledRecentTab(item))
      .map(normalizeRecentTab)
      .filter(item => item.path && item.openedAt) : [];

    return ensureMinimumRecentTabs(normalized);
  } catch (e) {
    return ensureMinimumRecentTabs([]);
  }
}

function saveRecentTabs(value) {
  const next = (Array.isArray(value) ? value : [])
    .filter(item => !isAutoFilledRecentTab(item))
    .map(normalizeRecentTab)
    .filter(item => item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);
  if (USE_SAMPLE_DATA) {
    sessionRecentTabs = next;
    return;
  }
  localStorage.setItem("krugle.history.recentTabs", JSON.stringify(next));
}

function recentTabKey(item) {
  if (!item) return "";
  return `${item.openedAt || ""}::${item.path || ""}`;
}

function ensureActiveRecentVisible(tabs) {
  if (!Array.isArray(tabs) || !tabs.length) {
    recentWindowStart = 0;
    return;
  }

  const activeIndex = tabs.findIndex(item => recentTabKey(item) === activeRecentTabKey);
  if (activeIndex < 0) {
    recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
    return;
  }

  if (activeIndex < recentWindowStart) {
    recentWindowStart = activeIndex;
  } else if (activeIndex >= recentWindowStart + RECENT_TAB_VISIBLE_LIMIT) {
    recentWindowStart = activeIndex - RECENT_TAB_VISIBLE_LIMIT + 1;
  }

  recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
}

function addRecentTab(path) {
  if (!path) return null;
  const item = { path, openedAt: new Date().toISOString() };
  const next = [item].concat(readRecentTabs());
  saveRecentTabs(next);
  activeRecentTabKey = recentTabKey(item);
  recentWindowStart = 0;
  renderRecentTabs();
  return item;
}

function toSafeDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? new Date() : date;
}

function normalizeRecentTab(item, index) {
  const fallback = sampleRecentTabs[index % sampleRecentTabs.length] || sampleRecentTabs[0];
  const path = item && item.path ? item.path : (fallback ? fallback.path : sampleFiles[0]);
  const openedAtValue = item && item.openedAt ? item.openedAt : (fallback ? fallback.openedAt : new Date().toISOString());
  const openedAt = toSafeDate(openedAtValue).toISOString();
  return { path, openedAt, autoFilled: isAutoFilledRecentTab(item) };
}

function formatTabDate(isoText) {
  const date = toSafeDate(isoText);
  const week = ["日", "月", "火", "水", "木", "金", "土"][date.getDay()];
  const pad = value => String(value).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())}(${week})`;
}

function formatTabTime(isoText) {
  const date = toSafeDate(isoText);
  const pad = value => String(value).padStart(2, "0");
  return `${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function dateKey(isoText) {
  const date = toSafeDate(isoText);
  const pad = value => String(value).padStart(2, "0");
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}`;
}

function shiftRecentWindow(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!tabs.length) return;

  const maxStart = Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT);
  recentWindowStart = Math.max(0, Math.min(maxStart, recentWindowStart + offset));
  manualRecentWindowShift = true;
  renderRecentTabs();
}

function renderRecentTabs() {
  const area = $("recentTabArea");
  if (!area) return;

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!activeRecentTabKey && tabs.length) {
    const fallbackActive = tabs.find(item => item.path === currentCodePath) || tabs[0];
    activeRecentTabKey = recentTabKey(fallbackActive);
  }

  if (manualRecentWindowShift) {
    recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
    manualRecentWindowShift = false;
  } else {
    ensureActiveRecentVisible(tabs);
  }

  area.classList.toggle("hasMoreLeft", recentWindowStart > 0);
  area.classList.toggle("hasMoreRight", recentWindowStart + RECENT_TAB_VISIBLE_LIMIT < tabs.length);

  const visibleTabs = tabs.slice(recentWindowStart, recentWindowStart + RECENT_TAB_VISIBLE_LIMIT);
  const groups = [];
  visibleTabs.forEach(item => {
    const key = dateKey(item.openedAt);
    const last = groups[groups.length - 1];
    if (!last || last.key !== key) {
      groups.push({ key, label: formatTabDate(item.openedAt), count: 1 });
    } else {
      last.count += 1;
    }
  });

  area.innerHTML = `
    <button class="recentNavArrow recentNavArrowLeft" type="button" aria-label="左のタブへ移動" title="左のタブへ移動">
      <svg class="recentNavIconSvg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M14.2 4.8L8.3 12l5.9 7.2" />
      </svg>
    </button>
    <div class="recentDateRow">
      ${groups.map((group, index) => {
        const prevGroup = groups[index - 1];
        const afterNarrowDateGroup = !!prevGroup && prevGroup.count <= 2;
        const className = afterNarrowDateGroup ? "recentDateGroup isAfterNarrowDateGroup" : "recentDateGroup";
        const shiftPx = 0;
        const extraWidthPx = group.count <= 2 && index < groups.length - 1 ? (group.count === 1 ? 70 : 44) : 0;
        return `
        <div class="${className}" style="--tab-count:${group.count}; --date-shift-x:${shiftPx}px; --date-extra-width:${extraWidthPx}px">
          ${escapeHtml(group.label)}
        </div>
      `;
      }).join("")}
    </div>
    <div class="recentTimeRow">
      ${visibleTabs.map((item, index) => {
        const key = recentTabKey(item);
        return `
          <button class="tabTime${key === activeRecentTabKey ? " isActive" : ""}" type="button"
                  data-path="${escapeHtml(item.path)}"
                  data-opened-at="${escapeHtml(item.openedAt)}"
                  data-recent-index="${recentWindowStart + index}"
                  title="${escapeHtml(item.path)}">
            ${escapeHtml(formatTabTime(item.openedAt))}
          </button>
        `;
      }).join("")}
    </div>
    <button class="recentNavArrow recentNavArrowRight" type="button" aria-label="右のタブへ移動" title="右のタブへ移動">
      <svg class="recentNavIconSvg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M9.8 4.8L15.7 12l-5.9 7.2" />
      </svg>
    </button>
  `;

  area.querySelectorAll(".tabTime").forEach(button => {
    button.addEventListener("click", () => {
      const index = Number(button.dataset.recentIndex);
      const item = tabs[index];
      if (item) openCode(item.path, { addRecent: false, recentItem: item });
    });
  });

  const recentPrevButton = area.querySelector(".recentNavArrowLeft");
  const recentNextButton = area.querySelector(".recentNavArrowRight");
  if (recentPrevButton) {
    recentPrevButton.addEventListener("click", event => {
      event.preventDefault();
      // ページ送りではなく、表示ウィンドウを1タブ分だけ左へずらす。
      shiftRecentWindow(-1);
    });
  }
  if (recentNextButton) {
    recentNextButton.addEventListener("click", event => {
      event.preventDefault();
      // ページ送りではなく、表示ウィンドウを1タブ分だけ右へずらす。
      shiftRecentWindow(1);
    });
  }
}

function openRelativeRecentTab(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!tabs.length) return;

  let index = tabs.findIndex(item => recentTabKey(item) === activeRecentTabKey);
  if (index < 0) index = tabs.findIndex(item => item.path === currentCodePath);
  if (index < 0) index = 0;

  const nextIndex = (index + offset + tabs.length) % tabs.length;
  const next = tabs[nextIndex];
  if (next && next.path) openCode(next.path, { addRecent: false, recentItem: next });
}

function moveMainTabByKeyboard(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  const total = 2 + tabs.length;
  if (total <= 0) return;

  let index = 0;
  if (currentView === "search") {
    index = 1;
  } else if (currentView === "code") {
    const activeIndex = tabs.findIndex(item => recentTabKey(item) === activeRecentTabKey);
    const pathIndex = tabs.findIndex(item => item.path === currentCodePath);
    index = 2 + (activeIndex >= 0 ? activeIndex : Math.max(0, pathIndex));
  }

  const nextIndex = (index + offset + total) % total;
  if (nextIndex === 0) {
    showView("home");
    return;
  }
  if (nextIndex === 1) {
    showView("search");
    return;
  }

  const recentItem = tabs[nextIndex - 2];
  if (recentItem && recentItem.path) {
    openCode(recentItem.path, { addRecent: false, recentItem });
  }
}

function addHistory(key, value, fallback) {
  if (!value) return;
  const next = readArray(key, fallback).filter(item => item !== value);
  next.unshift(value);
  saveArray(key, next);
}

function buildPlaceholderHistory(count = INITIAL_HISTORY_SAMPLE_COUNT) {
  return Array.from({ length: count }, () => HISTORY_PLACEHOLDER_VALUE);
}

function isPlaceholderHistoryValue(value) {
  return String(value || "").trim() === HISTORY_PLACEHOLDER_VALUE;
}

function normalizeHistoryValues(values) {
  const result = [];
  const used = new Set();
  (Array.isArray(values) ? values : []).forEach(value => {
    const text = String(value || "").trim();
    if (!text || isPlaceholderHistoryValue(text) || used.has(text)) return;
    used.add(text);
    result.push(text);
  });
  return result;
}

function seedHistoryStorage(key, values, sampleValues, count = INITIAL_HISTORY_SAMPLE_COUNT) {
  const original = normalizeHistoryValues(values);
  const result = original.slice();
  const used = new Set(result);

  (Array.isArray(sampleValues) ? sampleValues : []).forEach(value => {
    if (result.length >= count) return;
    const text = String(value || "").trim();
    if (!text || isPlaceholderHistoryValue(text) || used.has(text)) return;
    used.add(text);
    result.push(text);
  });

  // 初回表示や履歴20件未満の環境では、サンプルを含めて20件までlocalStorageへ保存する。
  // 後で固定サンプル値に差し替えるだけで、全ユーザーの初回起動時に20件入った状態を再現できる。
  // 過去版で入った「-」補完も、保存し直すことで履歴データから除去する。
  const rawLength = Array.isArray(values) ? values.length : 0;
  const hasStorageDifference = rawLength !== original.length || result.join("") !== original.join("");
  if (!USE_SAMPLE_DATA && hasStorageDifference) {
    saveArray(key, result);
  }
  return result;
}

function getDisplayHistoryRows(values, count = INITIAL_HISTORY_SAMPLE_COUNT) {
  return normalizeHistoryValues(values).slice(0, count);
}

function formatHistoryFileParts(value) {
  const original = String(value || "");
  if (isPlaceholderHistoryValue(original)) {
    return [HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE];
  }
  const slashIndex = original.indexOf("/");
  const head = slashIndex >= 0 ? original.substring(0, slashIndex) : original;
  const body = slashIndex >= 0 ? original.substring(slashIndex + 1) : "";
  const dotIndex = head.indexOf(".");
  const project = dotIndex >= 0 ? head.substring(0, dotIndex) : head;
  const group = dotIndex >= 0 ? head.substring(dotIndex + 1) : "";
  const bodyParts = body.split("/");
  const area = bodyParts[0] || "";
  const lastPath = original.split(/[\/]/).pop() || original;
  const className = lastPath.split(".").pop() || lastPath;
  return [className, group, area, project].filter(Boolean);
}

function formatHistoryFileHtml(value) {
  const parts = formatHistoryFileParts(value);
  const names = ["name", "group", "area", "project"];
  return parts.map((part, index) =>
    `<span class="historyToken historyToken-${names[index] || index}">${escapeHtml(part)}</span>`
  ).join("");
}


function renderGlobalHistoryMini(files) {
  const body = $("globalHistoryMiniBody");
  if (!body) return;

  // ソースコード画面右側の履歴も、初回・20件未満ならサンプルで20件まで埋める。
  // 「-」補完ではなく、ユーザーが初回表示時の見た目を把握できるサンプル行として扱う。
  const source = normalizeHistoryValues(files).slice(0, INITIAL_HISTORY_SAMPLE_COUNT);

  body.innerHTML = source.map((value, index) => {
    const isPlaceholder = isPlaceholderHistoryValue(value);
    return `
      <tr class="globalHistoryMiniRow${isPlaceholder ? " isPlaceholderHistoryRow" : ""}" data-path="${isPlaceholder ? "" : escapeHtml(value)}" title="${escapeHtml(value)}">
        <td class="globalHistoryMiniNoCell">${index + 1}</td>
        <td class="globalHistoryMiniFileText">${formatHistoryFileHtml(value)}</td>
      </tr>
    `;
  }).join("");

  body.querySelectorAll("tr").forEach(row => {
    row.addEventListener("click", () => {
      if (!row.dataset.path) return;
      openCode(row.dataset.path);
    });
  });
}

function formatHistorySearchHtml(value) {
  if (isPlaceholderHistoryValue(value)) {
    return [HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE]
      .map((part, index) =>
        `<span class="historySearchToken historySearchToken-${index}">${escapeHtml(part)}</span>`
      )
      .join("");
  }

  return String(value || "")
    .split("|")
    .map(part => part.trim())
    .filter(Boolean)
    .map((part, index) =>
      `<span class="historySearchToken historySearchToken-${index}">${escapeHtml(part)}</span>`
    )
    .join("");
}

function setSelectValueByTextOrValue(selectElement, value, fallback = "ALL") {
  if (!selectElement) return;
  const target = String(value || fallback).trim();
  const normalizedTarget = target.toLowerCase();
  const option = Array.from(selectElement.options).find(item => {
    const optionValue = String(item.value || "").trim().toLowerCase();
    const optionText = String(item.textContent || "").trim().toLowerCase();
    return optionValue === normalizedTarget || optionText === normalizedTarget;
  });
  selectElement.value = option ? option.value : fallback;
}

function fillSearchFormFromHistory(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim());

  const keyword = parts[0] || "";
  const group = parts[1] || "ALL";
  const language = parts[2] || "ALL";

  const keywordInput = $("keywordInput");
  if (keywordInput) keywordInput.value = keyword;

  setSelectValueByTextOrValue($("groupSelect"), group, "ALL");
  setSelectValueByTextOrValue($("languageSelect"), language, "ALL");
}

function openSearchFromHistory(value) {
  fillSearchFormFromHistory(value);
  showView("search");
  runSearch(true, "prefix");
}

function renderHistory() {
  let files = USE_SAMPLE_DATA ? sampleFiles : readArray("krugle.history.files", []);
  let words = USE_SAMPLE_DATA ? sampleSearchWords : readArray("krugle.history.words", []);

  if (!USE_SAMPLE_DATA) {
    files = seedHistoryStorage("krugle.history.files", files, sampleFiles, INITIAL_HISTORY_SAMPLE_COUNT);
    words = seedHistoryStorage("krugle.history.words", words, sampleSearchWords, INITIAL_HISTORY_SAMPLE_COUNT);
  }

  const displayFiles = getDisplayHistoryRows(files, INITIAL_HISTORY_SAMPLE_COUNT);
  const displayWords = getDisplayHistoryRows(words, INITIAL_HISTORY_SAMPLE_COUNT);

  renderGlobalHistoryMini(files);

  $("historyFileBody").innerHTML = displayFiles.map((value, index) => {
    const isPlaceholder = isPlaceholderHistoryValue(value);
    return `
      <tr class="${isPlaceholder ? "isPlaceholderHistoryRow" : ""}" data-path="${isPlaceholder ? "" : escapeHtml(value)}" title="${escapeHtml(value)}">
        <td>${index + 1}</td>
        <td class="historyFileText">${formatHistoryFileHtml(value)}</td>
      </tr>
    `;
  }).join("");

  $("historySearchBody").innerHTML = displayWords.map((value, index) => {
    const isPlaceholder = isPlaceholderHistoryValue(value);
    return `
      <tr class="${isPlaceholder ? "isPlaceholderHistoryRow" : ""}" data-keyword="${isPlaceholder ? "" : escapeHtml(value)}" title="${escapeHtml(value)}">
        <td>${index + 1}</td>
        <td class="historySearchText">${formatHistorySearchHtml(value)}</td>
      </tr>
    `;
  }).join("");

  document.querySelectorAll("#historyFileBody tr").forEach(row => {
    row.addEventListener("click", () => {
      if (!row.dataset.path) return;
      openCode(row.dataset.path);
    });
  });
  document.querySelectorAll("#historySearchBody tr").forEach(row => {
    row.addEventListener("click", () => {
      if (!row.dataset.keyword) return;
      openSearchFromHistory(row.dataset.keyword);
    });
  });
}

function setActiveTab(viewName) {
  document.querySelectorAll(".tabBtn").forEach(button => button.classList.remove("isActive"));
  if (viewName !== "code") {
    document.querySelectorAll(".tabTime").forEach(button => button.classList.remove("isActive"));
  }
  const target = document.querySelector(`.tabBtn[data-view="${viewName}"]:not(.tabFile)`);
  if (target) target.classList.add("isActive"); }

function showView(viewName) {
  currentView = viewName;
  document.body.classList.toggle("isCodeScreen", viewName === "code");
  document.querySelectorAll(".viewBlock").forEach(view => view.classList.remove("isVisible"));
  $(`${viewName}View`).classList.add("isVisible");
  setActiveTab(viewName);
  if (viewName === "home") renderHistory();
  if (viewName === "code") renderCode(); }

function getDirectoryGroup(path) {
  const value = String(path || "");
  return value.split("/")[0] || "";
}

async function runSearch(saveHistory = true, mode = "prefix") {
  const startedAt = new Date();
  const params = buildSearchParams(mode);
  lastSearchMode = mode;
  lastSearchParams = params;

  if (saveHistory) {
    addHistory("krugle.history.words", `${params.rawKeyword} | ${params.projectText || params.project} | ${params.languageText || params.language}`, []);
  }

  setSummaryFromParams(params, startedAt, null, "検索中");
  const body = $("resultBody");
  if (body) body.innerHTML = `<tr><td colspan="5">検索中...</td></tr>`;

  if (USE_SAMPLE_DATA) {
    const endedAt = new Date(startedAt.getTime() + 1000);
    lastSearchResults = sampleResults.map(normalizeSearchRow);
    setSummaryFromParams(params, startedAt, endedAt, lastSearchResults.length);
    renderSearchRows(lastSearchResults);
    return;
  }

  try {
    const data = await fetchJson("/search", {
      keyword: params.keyword,
      project: params.project,
      language: params.languageForApi,
      findin: params.findin,
      clone: params.clone,
      source_disp: params.source_disp
    });
    const endedAt = new Date();
    lastSearchResults = Array.isArray(data.results) ? data.results.map(normalizeSearchRow) : [];
    setSummaryFromServer(data.summary, params, startedAt, endedAt, lastSearchResults.length);
    renderSearchRows(lastSearchResults);
  } catch (e) {
    console.error(e);
    lastSearchResults = [];
    setSummaryFromParams(params, startedAt, new Date(), 0);
    if (body) body.innerHTML = `<tr><td colspan="5">/search 接続失敗：${escapeHtml(e.message)}</td></tr>`;
    showCopyFeedback("/search 接続失敗");
  }
}

async function openCode(path, options = {}) {
  currentCodePath = path || currentCodePath;
  currentCodeMeta = options.row || currentCodeMeta || { path: currentCodePath };
  currentCodeMeta.path = currentCodePath;
  currentSourceText = "読み込み中...";
  currentSourceLanguage = inferLanguageFromPath(currentCodePath, currentCodeMeta.language || "java");
  activeCodePanel = "source";

  addHistory("krugle.history.files", currentCodePath, []);

  if (options.addRecent === false && options.recentItem) {
    activeRecentTabKey = recentTabKey(normalizeRecentTab(options.recentItem, 0));
    renderRecentTabs();
  } else {
    addRecentTab(currentCodePath);
  }

  showView("code");

  if (USE_SAMPLE_DATA) {
    currentSourceText = sampleCode;
    renderCode(currentSourceText, currentSourceLanguage);
    return;
  }

  const sourceParams = {
    path: currentCodeMeta.path || currentCodePath,
    project: currentCodeMeta.project || "",
    href: currentCodeMeta.href || "",
    sourceUrl: currentCodeMeta.sourceUrl || "",
    language: currentSourceLanguage
  };
  const directUrl = `${apiPath("/source")}?${buildQueryString(sourceParams)}`;

  try {
    // sourceはGETで呼ぶ。ブラウザで直接URL確認もしやすくする。
    const data = await fetchJson("/source", sourceParams, { method: "GET" });
    currentSourceText = data.source || data.text || "";
    currentSourceLanguage = data.language || currentSourceLanguage;
    renderCode(currentSourceText, currentSourceLanguage);
  } catch (e) {
    console.error(e);
    currentSourceText = `/source 接続失敗

${e.message}

直接確認URL:
${directUrl}

確認ポイント:
1. krugleapi.war がCORS対応版か
2. http://kruglecodex.com:8080/krugleapi/source が404にならないか
3. Chrome DevToolsのNetworkでAccess-Control-Allow-Originが返っているか`;
    renderCode(currentSourceText, "plaintext");
    showCopyFeedback("/source 接続失敗");
  }
}

function renderCode(sourceText = currentSourceText, language = currentSourceLanguage) {
  const codeBlock = $("codeBlock");
  const source = sourceText || (USE_SAMPLE_DATA ? sampleCode : "");
  let displayText = source;
  let displayLanguage = language || inferLanguageFromPath(currentCodePath, "java");

  if (activeCodePanel === "ai") {
    displayText = sampleAiCode;
    displayLanguage = "java";
  } else if (activeCodePanel === "summary") {
    displayText = sampleSummaryText;
    displayLanguage = "plaintext";
  }

  $("codeTitle").textContent = currentCodePath || "";

  document.querySelectorAll(".codeModeTab").forEach(button => {
    button.classList.toggle("isActive", button.dataset.codePanel === activeCodePanel);
  });

  codeBlock.removeAttribute("data-highlighted");
  delete codeBlock.dataset.highlighted;

  codeBlock.className = `language-${displayLanguage}`;
  codeBlock.textContent = displayText || "";
  setCodeFontSize(codeFontSize);

  if (window.hljs) {
    window.hljs.highlightElement(codeBlock);
  }

  if (activeCodePanel === "source") {
    enhanceCodeKeywordLinks(codeBlock);
  }

  renderRecentTabs();
}

function enhanceCodeKeywordLinks(codeBlock) {
  if (!codeBlock || !codeBlock.textContent) return;

  const walker = document.createTreeWalker(codeBlock, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const parent = node.parentElement;
      if (!parent) return NodeFilter.FILTER_REJECT;
      if (parent.closest && parent.closest(".codeKeywordLink")) return NodeFilter.FILTER_REJECT;
      if (!node.nodeValue || !CODE_KEYWORD_PATTERN.test(node.nodeValue)) {
        CODE_KEYWORD_PATTERN.lastIndex = 0;
        return NodeFilter.FILTER_REJECT;
      }
      CODE_KEYWORD_PATTERN.lastIndex = 0;
      return NodeFilter.FILTER_ACCEPT;
    }
  });

  const textNodes = [];
  while (walker.nextNode()) textNodes.push(walker.currentNode);

  textNodes.forEach(node => {
    const text = node.nodeValue || "";
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    CODE_KEYWORD_PATTERN.lastIndex = 0;
    let match;

    while ((match = CODE_KEYWORD_PATTERN.exec(text)) !== null) {
      const keyword = match[0];
      const index = match.index;

      if (index > lastIndex) {
        fragment.appendChild(document.createTextNode(text.slice(lastIndex, index)));
      }

      if (isCodeKeywordCandidate(keyword)) {
        const link = document.createElement("button");
        link.type = "button";
        link.className = "codeKeywordLink";
        link.dataset.keyword = keyword;
        link.style.setProperty("--keyword-hit-width", `calc(${keyword.length}ch + 1.7em)`);
        link.textContent = keyword;
        link.title = `${keyword} のソースを開く`;
        fragment.appendChild(link);
      } else {
        fragment.appendChild(document.createTextNode(keyword));
      }

      lastIndex = index + keyword.length;
    }

    if (lastIndex < text.length) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    }

    if (node.parentNode) node.parentNode.replaceChild(fragment, node);
  });
}

const CODE_KEYWORD_PATTERN = /\b(?:[A-Z][A-Za-z0-9_]*(?:Command|Task|Accessor|Query|Record|Service|Controller|Factory|Table|Bean|Input|Output|Exception|Util|Helper|Manager|Repository|Dao|DAO|Dto|DTO)|[A-Z][A-Z0-9_]{2,})\b/g;

const JAVA_STANDARD_KEYWORD_EXCLUDES = new Set([
  "String", "Integer", "Long", "Double", "Float", "Boolean", "Byte", "Short", "Character",
  "Object", "Class", "System", "Math", "Thread", "Runnable", "Exception", "RuntimeException",
  "Connection", "PreparedStatement", "Statement", "ResultSet", "SQLException", "BigDecimal", "Date",
  "List", "ArrayList", "Map", "HashMap", "Set", "HashSet", "Collection", "Collections",
  "SELECT", "FROM", "WHERE", "AND", "OR", "NOT", "NULL", "TRUE", "FALSE", "ORDER", "GROUP",
  "BY", "INNER", "LEFT", "RIGHT", "JOIN", "ON", "INSERT", "UPDATE", "DELETE", "VALUES",
  "INTO", "CREATE", "ALTER", "DROP", "TABLE", "VIEW", "INDEX", "DUAL"
]);

function isCodeKeywordCandidate(keyword) {
  if (!keyword || JAVA_STANDARD_KEYWORD_EXCLUDES.has(keyword)) return false;
  if (/^\d+$/.test(keyword)) return false;
  if (/^[A-Z][A-Z0-9_]{2,}$/.test(keyword)) return keyword.indexOf("_") >= 0 || keyword.length >= 5;
  return /^[A-Z][A-Za-z0-9_]*(?:Command|Task|Accessor|Query|Record|Service|Controller|Factory|Table|Bean|Input|Output|Exception|Util|Helper|Manager|Repository|Dao|DAO|Dto|DTO)$/.test(keyword);
}

document.addEventListener("click", event => {
  const keywordButton = event.target.closest ? event.target.closest(".codeKeywordLink") : null;
  if (!keywordButton) return;

  const keyword = keywordButton.dataset.keyword || keywordButton.textContent || "";
  if (!keyword) return;

  alert(`ソースを開く予定です：${keyword}`);
});


function setCodeFontSize(nextSize) {
  const next = Number(nextSize);
  codeFontSize = Math.min(CODE_FONT_MAX, Math.max(CODE_FONT_MIN, Number.isFinite(next) ? next : 14));

  const codeView = $("codeView");
  if (codeView) {
    codeView.style.setProperty("--code-font-size", `${codeFontSize}px`);
  }

  const codeBlock = $("codeBlock");
  if (codeBlock) {
    codeBlock.style.setProperty("font-size", `${codeFontSize}px`, "important");
  }
}

function showCopyFeedback(message = "コピーしました") {
  let toast = $("copyToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "copyToast";
    toast.className = "copyToast";
    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.classList.add("isVisible");
  window.clearTimeout(showCopyFeedback.timer);
  showCopyFeedback.timer = window.setTimeout(() => {
    toast.classList.remove("isVisible");
  }, 1400);

  const button = $("codeCopyBtn");
  if (button) {
    const originalText = button.dataset.originalText || button.textContent;
    button.dataset.originalText = originalText;
    button.textContent = "✓";
    button.classList.add("isCopied");
    window.clearTimeout(showCopyFeedback.buttonTimer);
    showCopyFeedback.buttonTimer = window.setTimeout(() => {
      button.textContent = button.dataset.originalText || "Copy";
      button.classList.remove("isCopied");
    }, 1400);
  }
}

function fallbackCopyText(text) {
  const area = document.createElement("textarea");
  area.value = text;
  area.setAttribute("readonly", "readonly");
  area.style.position = "fixed";
  area.style.left = "-9999px";
  area.style.top = "0";
  document.body.appendChild(area);
  area.focus();
  area.select();

  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch (e) {
    ok = false;
  }

  document.body.removeChild(area);
  return ok;
}

function downloadCurrent() {
  if (currentView === "search") {
    const params = lastSearchParams || buildSearchParams(lastSearchMode || "prefix");
    submitDownload("/download", {
      path_output_format: "PATH",
      keyword: params.keyword,
      project: params.project,
      language: params.languageForApi,
      findin: params.findin,
      clone: params.clone
    });
    return;
  }

  let filename = "krugle.txt";
  let text = "";
  if (currentView === "code") {
    filename = safeDownloadFileName(currentCodePath, "code.txt");
    text = $("codeBlock").textContent;
  } else {
    filename = "history.csv";
    text = readArray("krugle.history.files", []).map((value, index) => `${index + 1},${csv(value)}`).join("\n");
  }
  const blob = new Blob([new Uint8Array([0xef, 0xbb, 0xbf]), text], { type: "text/plain;charset=utf-8" });
  const link = document.createElement("a");
  link.download = filename;
  link.href = URL.createObjectURL(blob);
  link.click();
  URL.revokeObjectURL(link.href);
}

async function copyCurrent() {
  const visibleView = document.querySelector(".viewBlock.isVisible");
  const text = currentView === "code" ? $("codeBlock").textContent : (visibleView ? visibleView.innerText : "");

  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
    } else if (!fallbackCopyText(text)) {
      throw new Error("fallback copy failed");
    }
    showCopyFeedback("コピーしました");
  } catch (e) {
    if (fallbackCopyText(text)) {
      showCopyFeedback("コピーしました");
    } else {
      showCopyFeedback("コピーできませんでした");
    }
  }
}

function csv(value) {
  return `"${String(value).replaceAll('"', '""')}"`; }

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function bindEvents() {
  const on = (id, eventName, handler) => {
    const element = $(id);
    if (element) element.addEventListener(eventName, handler);
  };

  document.querySelectorAll(".tabBtn").forEach(button => {
    button.addEventListener("click", () => {
      if (button.classList.contains("tabFile")) {
        const index = Number(button.dataset.code || 0);
        openCode(sampleFiles[index] || sampleFiles[0]);
        document.querySelectorAll(".tabBtn").forEach(item => item.classList.remove("isActive"));
        button.classList.add("isActive");
      } else {
        showView(button.dataset.view);
      }
    });
  });
  on("searchBtn", "click", () => {
    showView("search");
    runSearch(true, "prefix");
  });
  on("sampleBtn", "click", () => {
    showView("search");
    runSearch(true, "fuzzy");
  });
  on("downloadBtn", "click", downloadCurrent);
  on("copyBtn", "click", copyCurrent);
  on("krugleBadge", "click", () => {
    window.location.href = "index.html";
  });

  const quickLinkDock = $("quickLinkDock");
  const quickLinkTrigger = $("quickLinkTrigger");
  const quickLinkOverlay = $("quickLinkOverlay");
  const quickLinkPanel = $("quickLinkPanel");
  const quickLinkClose = $("quickLinkClose");
  const setQuickLinkExpanded = expanded => {
    if (quickLinkTrigger) quickLinkTrigger.setAttribute("aria-expanded", expanded ? "true" : "false");
    if (quickLinkOverlay) {
      quickLinkOverlay.classList.toggle("isOpen", expanded);
      quickLinkOverlay.setAttribute("aria-hidden", expanded ? "false" : "true");
    }
    document.body.classList.toggle("quickLinksOpen", expanded);
  };
  const openQuickLinks = () => setQuickLinkExpanded(true);
  const closeQuickLinks = () => {
    setQuickLinkExpanded(false);
  };
  if (quickLinkDock && quickLinkTrigger && quickLinkOverlay) {
    quickLinkDock.addEventListener("mouseenter", openQuickLinks);
    quickLinkTrigger.addEventListener("focus", openQuickLinks);
    quickLinkTrigger.addEventListener("click", event => {
      event.preventDefault();
      openQuickLinks();
      if (quickLinkPanel) quickLinkPanel.focus({ preventScroll: true });
    });
    if (quickLinkClose) {
      quickLinkClose.addEventListener("click", event => {
        event.preventDefault();
        closeQuickLinks();
      });
    }
    quickLinkOverlay.addEventListener("click", event => {
      if (event.target === quickLinkOverlay) closeQuickLinks();
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape" && quickLinkOverlay.classList.contains("isOpen")) {
        event.preventDefault();
        closeQuickLinks();
      }
    });
  }

  document.querySelectorAll(".quickLinkItem[data-link-placeholder='true']").forEach(link => {
    link.addEventListener("click", event => {
      event.preventDefault();
      const label = link.textContent.trim() || "リンク";
      showCopyFeedback(`${label} のURLは未設定です`);
    });
  });
  on("codePrevBtn", "click", () => openRelativeRecentTab(-1));
  on("codeNextBtn", "click", () => openRelativeRecentTab(1));
  on("codeCopyBtn", "click", copyCurrent);
  on("codeDownloadBtn", "click", downloadCurrent);
  document.querySelectorAll(".codeModeTab").forEach(button => {
    button.addEventListener("click", () => {
      if (button.disabled || button.getAttribute("aria-disabled") === "true") return;
      activeCodePanel = button.dataset.codePanel || "source";
      renderCode();
    });
  });
  on("smallBtn", "click", () => setCodeFontSize(codeFontSize - CODE_FONT_STEP));
  on("largeBtn", "click", () => setCodeFontSize(codeFontSize + CODE_FONT_STEP));
  on("keywordInput", "keydown", event => {
    if (event.key === "Enter") {
      showView("search");
      runSearch(true, "prefix");
    }
  });

  document.addEventListener("keydown", event => {
    if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
    const tagName = event.target && event.target.tagName ? event.target.tagName.toLowerCase() : "";
    if (["input", "select", "textarea"].includes(tagName)) return;
    event.preventDefault();
    moveMainTabByKeyboard(event.key === "ArrowRight" ? 1 : -1);
  });

  const stalker = $("mouseStalker");
  const hoverTargetSelector = [
    "button",
    "#historyFileBody tr",
    "#historySearchBody tr",
    ".tabTime",
    ".recentNavArrow",
    ".krugleBadge",
    ".quickLinkDock",
    ".quickLinkTrigger",
    ".quickLinkOverlay",
    ".quickLinkClose",
    ".quickLinkItem",
    ".searchPanel input",
    ".searchPanel select",
    ".searchPanel .cloneField",
    ".globalHistoryMini tr"
  ].join(",");

  document.addEventListener("mousemove", event => {
    stalker.style.transform = `translate(${event.clientX}px, ${event.clientY}px)`;
    if (event.target.closest && event.target.closest(hoverTargetSelector)) {
      stalker.classList.add("isActive");
    } else {
      stalker.classList.remove("isActive");
    }
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  bindEvents();
  resetInitialSearchSummary();
  renderInitialResultPlaceholders();
  renderRecentTabs();
  await loadInitialData();
  renderHistory();
});


