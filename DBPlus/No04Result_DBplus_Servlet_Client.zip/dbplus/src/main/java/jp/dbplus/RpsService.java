package jp.dbplus;

import java.io.*;
import java.util.*;
import java.util.regex.*;

final class RpsService {
    static final int PAGE_SIZE=50;
    static final class Page {
        List<Rps.Row> rows;int total,totalPages,page;final List<String> warnings=new ArrayList<>();
    }
    /** 入力済みの境界%を正規化し、空条件には%を付けない。内部の%はRPSのワイルドカード。 */
    static String keyword(String value,String mode){
        String s=value.trim().replaceAll("^%+|%+$","");
        return s.isEmpty()?"":("contains".equals(mode)?"%":"")+s+"%";
    }
    static String listUrl(Rps.Kind k,Config c,int page,String name,String description,String target,String mode) throws Exception {
        if(page<1||page>1000000)throw new IllegalArgumentException("ページ番号が不正です。");
        if(!Arrays.asList("prefix","contains").contains(mode))throw new IllegalArgumentException("検索種別はprefixまたはcontainsです。");
        String q="/"+k.path+"/list?utf8="+Rps.enc("\u2713")+"&pm=ent&keyword_db="+Rps.enc(c.dbtype)+"&keyword_group_name=";
        if(k==Rps.Kind.SYNONYM){
            if(!description.isEmpty())throw new IllegalArgumentException("RPSのシノニム検索は物理名・参照先名を指定してください。");
            q+="&keyword_name="+Rps.enc(keyword(name,mode))+"&keyword_obj_name="+Rps.enc(keyword(target,mode));
        }else{
            q+="&keyword_object_name="+Rps.enc(keyword(name,mode))+"&keyword_description="+Rps.enc(keyword(description,mode));
            if(k==Rps.Kind.INDEX)q+="&keyword_table_name=";
        }
        return q+"&page="+page+"&submit="+Rps.enc("検索");
    }
    static Page readPage(Rps.Http h,Config c,Rps.Kind kind,int requested,String name,String jp,String target,String mode) throws Exception {
        String html=h.request(listUrl(kind,c,requested,name,jp,target,mode),null);
        Rps.validateListSchema(html,c);
        return parsePage(html,c,kind,requested);
    }
    static Page parsePage(String html,Config c,Rps.Kind kind,int requested) throws Exception {
        Page p=new Page();p.total=totalCount(html);p.page=requested;
        Matcher current=Pattern.compile("(?is)<(?:em|span)\\b[^>]*class\\s*=\\s*['\"][^'\"]*\\bcurrent\\b[^'\"]*['\"][^>]*>\\s*(\\d+)").matcher(html);
        if(current.find())p.page=Integer.parseInt(current.group(1));
        if(p.page!=requested)throw new Rps.RpsException("RPSが指定ページと異なるページを返しました。検索し直してください。");
        p.rows=p.total==0&&!html.contains("std_hover")?new ArrayList<Rps.Row>():Rps.parse(html,kind,c);
        if(p.rows.size()>PAGE_SIZE)throw new Rps.RpsException("50件を超える一覧が返されました。RPSのページング仕様を確認してください。");
        int last=1;Matcher a=Pattern.compile("(?is)<a\\b([^>]*)>").matcher(html);
        while(a.find()){
            String href=Rps.attr(a.group(1),"href");
            if(!href.startsWith("/"+kind.path+"/list?"))continue;
            String n=Rps.query(href).get("page");
            if(n!=null&&n.matches("\\d{1,7}"))last=Math.max(last,Integer.parseInt(n));
        }
        if(p.total<0)throw new Rps.RpsException("RPSの全件数を取得できませんでした。HTML形式を確認してください。");
        p.totalPages=Math.max(Math.max(last,p.page),Math.max(1,(p.total+PAGE_SIZE-1)/PAGE_SIZE));
        return p;
    }
    static int totalCount(String html){
        Matcher m=Pattern.compile("全\\s*([0-9,]+)\\s*件").matcher(Rps.clean(html));
        return m.find()?Integer.parseInt(m.group(1).replace(",","")):-1;
    }
    static final class Definition {
        final List<List<String>> rows=new ArrayList<>();final List<String> headers=new ArrayList<>();
        final Map<String,String> names=new LinkedHashMap<>();
        Map<String,Object> json(){return Json.obj("headers",headers,"rows",rows);}
    }
    /** DDL本文は文字列として返す。RPSから取得したHTMLをクライアントで実行しない。 */
    static String ddl(Rps.Http h,Config c,Rps.Kind kind,String name,String version) throws Exception {
        String html=h.request("/"+kind.path+"/show_ddl?utf8="+Rps.enc("\u2713")
            +"&instance="+Rps.enc(c.dbtype)+"&schema="+Rps.enc(c.schema)
            +"&version="+Rps.enc(version)+"&object_name="+Rps.enc(name),null);
        if(Rps.loginForm(html))throw new Rps.AuthException("RPSの認証期限が切れました。");
        if(Rps.hasSchemaField(html)&&!c.schema.equals(Rps.schemaValue(html)))
            throw new Rps.RpsException("DDLのスキーマが要求と一致しません。");
        Matcher pre=Pattern.compile("(?is)<(pre|textarea)\\b[^>]*>(.*?)</\\1\\s*>").matcher(html);
        String text=pre.find()?Rps.entities(pre.group(2).replaceAll("(?is)<br\\s*/?>","\n").replaceAll("(?is)<[^>]*>","")):Rps.clean(html);
        if(text.trim().isEmpty())throw new Rps.RpsException("RPSのDDL本文が空です。");
        return text;
    }
    /** ユーザーのいうDDLはshow_tableの項目定義画面。日本語ヘッダーは項目名で照合する。 */
    static Definition definition(Rps.Http h,Config c,String table,String version,String description) throws Exception {
        if(table.isEmpty()||version.isEmpty())throw new IllegalArgumentException("テーブル名とRPSバージョンが必要です。");
        String html=h.request("/column/show_table?instance="+Rps.enc(c.dbtype)+"&schema="+Rps.enc(c.schema)+"&table_name="+Rps.enc(table)+"&version="+Rps.enc(version)+"&pm=ent&description="+Rps.enc(description),null);
        Rps.validateListSchema(html,c);
        String actual=Rps.input(html,"table_name");
        if(!actual.isEmpty()&&!actual.equals(table))throw new Rps.RpsException("項目定義のテーブル名が一致しません。");
        return parseDefinition(html);
    }
    static Definition parseDefinition(String html) throws Exception {
        Definition d=new Definition();
        Matcher table=Pattern.compile("(?is)<table\\b[^>]*class\\s*=\\s*['\"][^'\"]*\\bstd_hover\\b[^'\"]*['\"][^>]*>(.*?)</table\\s*>").matcher(html);
        int physical=-1,japanese=-1;
        while(table.find()){
            Matcher tr=Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr\\s*>").matcher(table.group(1));
            while(tr.find()){
                List<String> cells=new ArrayList<>();Matcher td=Pattern.compile("(?is)<t[dh]\\b[^>]*>(.*?)</t[dh]\\s*>").matcher(tr.group(1));
                while(td.find())cells.add(Rps.clean(td.group(1)));
                if(cells.contains("項目名")&&cells.contains("日本語名称")){
                    d.headers.clear();d.headers.addAll(cells);physical=cells.indexOf("項目名");japanese=cells.indexOf("日本語名称");continue;
                }
                if(physical>=0&&cells.size()>Math.max(physical,japanese)&&!cells.get(physical).isEmpty()){
                    d.rows.add(cells);d.names.put(cells.get(physical),cells.get(japanese));
                }
            }
            if(physical>=0)break;
        }
        if(physical<0)throw new Rps.RpsException("項目定義の項目名・日本語名称ヘッダーを取得できませんでした。");
        return d;
    }
}
