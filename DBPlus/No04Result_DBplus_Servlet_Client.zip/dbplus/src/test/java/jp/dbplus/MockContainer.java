package jp.dbplus;

import com.sun.net.httpserver.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Logger;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * テスト専用のServlet APIブリッジ。製品WARへは含めない。
 * 実Servlet・実RPS HTTP処理を通し、JDBCだけをこのDriverへ置き換える。
 */
public final class MockContainer {
    static final Map<String,HttpSession> sessions=new ConcurrentHashMap<>();
    static final class TestDriver implements Driver {
        public boolean acceptsURL(String url){return url.startsWith("jdbc:oracle:thin:");}
        public Connection connect(String url,Properties info) throws SQLException {
            if(!acceptsURL(url))return null;
            return ContractTest.proxy(Connection.class,(p,m,a)->{
                if(m.getName().equals("prepareStatement")){
                    String sql=(String)a[0];boolean metadata=sql.contains("ALL_OBJECTS");
                    if(!metadata&&sql.contains("\"KYF0002\""))throw new SQLException("simulated unavailable table","42000",942);
                    Map<Integer,Object> binds=new HashMap<>();int[] maxRows={0};
                    return ContractTest.proxy(PreparedStatement.class,(ps,method,values)->{
                        if(method.getName().startsWith("set")&&values!=null){
                            if(method.getName().equals("setInt")||method.getName().equals("setString"))binds.put((Integer)values[0],values[1]);
                            if(method.getName().equals("setMaxRows"))maxRows[0]=(Integer)values[0];
                        }
                        if(method.getName().equals("executeQuery")){
                            if(!metadata&&(!Integer.valueOf(5000).equals(binds.get(1))||maxRows[0]!=5000))
                                throw new SQLException("invalid row limit");
                            int[] cursor={0};int total=metadata?1:sql.contains("\"KYF0003\"")?0:5000;
                            String[] labels={"DB_UPDJI1","CUSTOMER_ID","CUSTOMER_NAME","BALANCE","NOTES"};
                            return ContractTest.proxy(ResultSet.class,(rs,rm,ra)->{
                                if(rm.getName().equals("next"))return ++cursor[0]<=total;
                                if(rm.getName().equals("getMetaData"))return ContractTest.proxy(ResultSetMetaData.class,(md,mm,ma)->{
                                    switch(mm.getName()){
                                        case "getColumnCount":return labels.length;
                                        case "getColumnLabel":return labels[(Integer)ma[0]-1];
                                        case "getColumnTypeName":return (Integer)ma[0]==4?"NUMBER":"VARCHAR2";
                                        case "getColumnType":return (Integer)ma[0]==4?Types.NUMERIC:Types.VARCHAR;
                                        default:return ContractTest.defaultValue(mm.getReturnType());
                                    }
                                });
                                if(rm.getName().equals("getString")){
                                    int column=(Integer)ra[0];
                                    switch(column){
                                        case 1:return "2026-10-21";
                                        case 2:return "C"+String.format("%06d",cursor[0]);
                                        case 3:return "顧客サンプル "+cursor[0];
                                        case 4:return "9007199254740993";
                                        default:return cursor[0]==1?"<script>window.__xss=1</script>":cursor[0]%3==0?null:"確認済み";
                                    }
                                }
                                return ContractTest.defaultValue(rm.getReturnType());
                            });
                        }
                        return ContractTest.defaultValue(method.getReturnType());
                    });
                }
                return ContractTest.defaultValue(m.getReturnType());
            });
        }
        public DriverPropertyInfo[] getPropertyInfo(String u,Properties p){return new DriverPropertyInfo[0];}
        public int getMajorVersion(){return 1;}public int getMinorVersion(){return 0;}
        public boolean jdbcCompliant(){return false;}public Logger getParentLogger(){return Logger.getGlobal();}
    }
    public static void main(String[] args) throws Exception {
        Path webapp=Paths.get(args[0]).resolve("src/main/webapp").toAbsolutePath();
        Properties properties=new Properties();
        try(Reader r=Files.newBufferedReader(webapp.resolve("WEB-INF/config.properties"),StandardCharsets.UTF_8)){properties.load(r);}
        properties.setProperty("rps.base.url",args[1]);
        StringWriter settings=new StringWriter();properties.store(settings,null);
        ServletContext context=ContractTest.proxy(ServletContext.class,(p,m,a)->{
            if(m.getName().equals("getResourceAsStream")){
                if(a[0].equals("/WEB-INF/config.properties"))return new ByteArrayInputStream(settings.toString().getBytes(StandardCharsets.UTF_8));
                Path path=webapp.resolve(((String)a[0]).replaceFirst("^/",""));
                return Files.exists(path)?Files.newInputStream(path):null;
            }return ContractTest.defaultValue(m.getReturnType());
        });
        ServletConfig config=ContractTest.proxy(ServletConfig.class,(p,m,a)->m.getName().equals("getServletContext")?context:ContractTest.defaultValue(m.getReturnType()));
        DriverManager.registerDriver(new TestDriver());
        DbplusServlet servlet=new DbplusServlet();servlet.init(config);
        HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        server.setExecutor(Executors.newCachedThreadPool());
        server.createContext("/dbplus",ex->{
            try{
                String path=ex.getRequestURI().getPath().substring("/dbplus".length());
                if(path.startsWith("/api/")){
                    if(!Arrays.asList("/api/login","/api/initial","/api/search","/api/detail").contains(path)){
                        ex.sendResponseHeaders(404,-1);return;
                    }
                    Map<String,String> params=new HashMap<>();
                    String body=new String(read(ex.getRequestBody()),StandardCharsets.UTF_8);
                    for(String pair:body.split("&")){String[] kv=pair.split("=",2);if(kv.length==2)params.put(URLDecoder.decode(kv[0],"UTF-8"),URLDecoder.decode(kv[1],"UTF-8"));}
                    String cookie=ex.getRequestHeaders().getFirst("Cookie"),id=null;
                    if(cookie!=null)for(String item:cookie.split(";"))if(item.trim().startsWith("JSESSIONID="))id=item.trim().substring(11);
                    if(id==null||!sessions.containsKey(id)){
                        id=UUID.randomUUID().toString();Map<String,Object> attrs=new ConcurrentHashMap<>();
                        HttpSession s=ContractTest.proxy(HttpSession.class,(p,m,a)->{
                            switch(m.getName()){
                                case "getAttribute":return attrs.get(a[0]);
                                case "setAttribute":attrs.put((String)a[0],a[1]);return null;
                                case "removeAttribute":attrs.remove(a[0]);return null;
                                default:return ContractTest.defaultValue(m.getReturnType());
                            }
                        });
                        sessions.put(id,s);ex.getResponseHeaders().add("Set-Cookie","JSESSIONID="+id+"; Path=/dbplus; HttpOnly; SameSite=Lax");
                    }
                    final HttpSession session=sessions.get(id);
                    final String servletPath=path;
                    HttpServletRequest req=ContractTest.proxy(HttpServletRequest.class,(p,m,a)->{
                        switch(m.getName()){
                            case "getParameter":return params.get(a[0]);
                            case "getHeader":return ex.getRequestHeaders().getFirst((String)a[0]);
                            case "getSession":return session;
                            case "getServletPath":return servletPath;
                            default:return ContractTest.defaultValue(m.getReturnType());
                        }
                    });
                    ByteArrayOutputStream buffer=new ByteArrayOutputStream();PrintWriter writer=new PrintWriter(new OutputStreamWriter(buffer,StandardCharsets.UTF_8));int[] status={200};
                    HttpServletResponse res=ContractTest.proxy(HttpServletResponse.class,(p,m,a)->{
                        switch(m.getName()){
                            case "setStatus":status[0]=(Integer)a[0];return null;
                            case "setHeader":ex.getResponseHeaders().set((String)a[0],(String)a[1]);return null;
                            case "setContentType":ex.getResponseHeaders().set("Content-Type",(String)a[0]);return null;
                            case "getWriter":return writer;
                            default:return ContractTest.defaultValue(m.getReturnType());
                        }
                    });
                    if(ex.getRequestMethod().equals("POST"))servlet.doPost(req,res);else servlet.doGet(req,res);
                    writer.flush();byte[] bytes=buffer.toByteArray();ex.sendResponseHeaders(status[0],bytes.length);ex.getResponseBody().write(bytes);
                }else{
                    if(path.isEmpty()||path.equals("/"))path="/index.html";
                    Path file=webapp.resolve(path.substring(1)).normalize();
                    if(!file.startsWith(webapp)||path.startsWith("/WEB-INF")||!Files.isRegularFile(file)){ex.sendResponseHeaders(404,-1);return;}
                    String type=path.endsWith(".js")?"application/javascript":path.endsWith(".css")?"text/css":path.endsWith(".woff")?"font/woff":"text/html";
                    ex.getResponseHeaders().set("Content-Type",type+"; charset=UTF-8");
                    byte[] bytes=Files.readAllBytes(file);ex.sendResponseHeaders(200,bytes.length);ex.getResponseBody().write(bytes);
                }
            }catch(Exception e){e.printStackTrace(System.err);try{ex.sendResponseHeaders(500,-1);}catch(Exception ignored){}}
            finally{ex.close();}
        });
        server.start();System.out.println("READY "+server.getAddress().getPort());System.out.flush();
    }
    static byte[] read(InputStream in) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();
    }
}
