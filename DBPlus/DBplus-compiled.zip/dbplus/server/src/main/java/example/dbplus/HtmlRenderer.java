package example.dbplus;

import java.io.*;
import java.util.*;

/** 固定タグ＋エスケープ済みテキストのみを生成する。外部画像・イベント属性は作らない。 */
public final class HtmlRenderer {
    public static final String[] DEFINITION = {"No.","項目名","キー","Par","データ型","データ長","NULL制約","日本語名称","項目説明","外部参照","省略時値","CHECK制約"};
    public static final String[] INDEXES = {"No.","インデックススキーマ","インデックス名","UNIQUE","種別","列位置","列名・式","昇順／降順","対応制約","状態・補足"};
    public static final String[] SYNONYMS = {"No.","シノニム所有者","シノニム名","参照先スキーマ","参照先オブジェクト","DBリンク","区分","補足"};
    private HtmlRenderer() {}
    public static String escape(String s) {
        if (s==null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");
    }
    /** UTF-16サロゲートペアを切断せず、プレビュー範囲＋超過判定1文字だけを読む。 */
    public static Preview preview(Reader reader,int limit) throws IOException {
        if (reader==null) return new Preview(null,false);
        StringBuilder b=new StringBuilder(limit+1); char[] buffer=new char[256];
        while(b.length()<=limit) {int n=reader.read(buffer,0,Math.min(buffer.length,limit+1-b.length())); if(n<0) break; b.append(buffer,0,n);}
        boolean truncated=b.length()>limit;
        int end=Math.min(limit,b.length());
        if(end>0 && end<b.length() && Character.isHighSurrogate(b.charAt(end-1)) && Character.isLowSurrogate(b.charAt(end))) end--;
        return new Preview(b.substring(0,end),truncated);
    }
    public static final class Preview { final String text; final boolean truncated; Preview(String text,boolean truncated){this.text=text;this.truncated=truncated;} }
    static String header(List<Map<String,Object>> columns) {
        StringBuilder b=new StringBuilder("<tr>");
        for(Map<String,Object> col:columns) b.append("<th scope=\"col\">").append(escape((String)col.get("name"))).append("</th>");
        return b.append("</tr>").toString();
    }
    static String row(int index,List<Preview> values) {
        StringBuilder b=new StringBuilder("<tr data-row-index=\"").append(index).append("\" aria-rowindex=\"").append(index+2).append("\">");
        for(Preview v:values) {
            b.append("<td><span class=\"dbp-cell").append(v.text==null?" dbp-null":"").append("\"");
            if(v.truncated) b.append(" data-truncated=\"true\"");
            b.append(">").append(v.text==null?"NULL":escape(v.text)).append("</span></td>");
        }
        return b.append("</tr>").toString();
    }
    static Map<String,Object> table(String[] head,List<List<String>> rows,String css,String empty) {
        StringBuilder b=new StringBuilder("<div class=\"tableInfoTableWrap tableDefinitionTableWrap\"><table class=\"tableInfoTable ").append(css).append("\"><thead><tr>");
        for(String s:head) b.append("<th scope=\"col\">").append(escape(s)).append("</th>");
        b.append("</tr></thead><tbody>");
        for(List<String> row:rows) {if(row.size()!=head.length) throw new IllegalArgumentException("列数不一致");b.append("<tr>"); for(String s:row)b.append("<td>").append(escape(s)).append("</td>");b.append("</tr>");}
        if(rows.isEmpty()) b.append("<tr><td colspan=\"").append(head.length).append("\">").append(escape(empty)).append("</td></tr>");
        b.append("</tbody></table></div>");
        return Api.map("status",rows.isEmpty()?"empty":"ready","recordCount",rows.size(),"html",b.toString(),"warnings",new ArrayList<String>());
    }
}
