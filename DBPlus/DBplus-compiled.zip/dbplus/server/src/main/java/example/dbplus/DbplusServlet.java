package example.dbplus;

import javax.servlet.*;
import javax.servlet.http.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;

/** Java 8 / javax.servlet 3.1。配布元WARの接続値・既存サービスは流用しない。 */
public final class DbplusServlet extends HttpServlet {
    private static final long serialVersionUID=1L;
    private static final int MAX_RESPONSE=16*1024*1024;
    private transient Profiles profiles;
    private final Gson gson=new GsonBuilder().serializeNulls().create();
    private final TableService service=new TableService();
    @Override public void init() throws ServletException {
        try{profiles=new Profiles(System.getProperty("dbplus.config"));}
        catch(IOException e){throw new ServletException("DB+プロファイル設定を読み込めません。",e);}
    }
    private String required(HttpServletRequest req,String key) throws Api.Problem {
        String[] all=req.getParameterValues(key);if(all==null||all.length!=1||all[0].isEmpty()||all[0].length()>512||all[0].chars().anyMatch(x->x<32))throw new Api.Problem(400,"INVALID_PARAMETER","パラメータが不正です: "+key);return all[0];
    }
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException {
        String requestId=UUID.randomUUID().toString(); long start=System.nanoTime();Map<String,Object> body=Api.envelope(requestId);int http=200;
        try{
            req.setCharacterEncoding("UTF-8");String path=req.getPathInfo();
            if("/connections".equals(path)){
                List<Map<String,Object>> items=new ArrayList<>();for(Profiles.Profile p:profiles.items.values())items.add(Api.map("connectionId",p.id,"label",p.label,"dbProduct",p.dialect));body.put("items",items);
            }else if(Arrays.asList("/schemas","/tables","/table-detail").contains(path)){
                Profiles.Profile p=profiles.get(required(req,"connectionId"));
                if("/schemas".equals(path)){List<Map<String,Object>> schemas=new ArrayList<>();for(String s:p.schemas)schemas.add(Api.map("schemaName",s,"label",s));body.put("connectionId",p.id);body.put("items",schemas);}
                else{String schema=required(req,"schemaName");p.allowSchema(schema);Deadline deadline=new Deadline();
                    if("/tables".equals(path))body.putAll(service.tables(p,schema,deadline));
                    else body.putAll(service.detail(p,schema,required(req,"tableName"),deadline,requestId));}
            }else throw new Api.Problem(404,"API_NOT_FOUND","APIが見つかりません。");
        }catch(Api.Problem e){http=e.http;body=error(requestId,e.code,e.getMessage());}
        catch(SQLTimeoutException e){http=504;body=error(requestId,"QUERY_TIMEOUT","取得処理が期限を超えました。");}
        catch(SQLException e){http=503;body=error(requestId,"DB_UNAVAILABLE","接続先を利用できません。");log("DB+ requestId="+requestId+" SQLState="+e.getSQLState()+" code="+e.getErrorCode());}
        catch(Exception e){http=503;body=error(requestId,"SOURCE_UNAVAILABLE","サービスを利用できません。設定・接続状態を確認してください。");log("DB+ requestId="+requestId+" exception="+e.getClass().getSimpleName());}
        byte[] bytes=gson.toJson(body).getBytes(StandardCharsets.UTF_8);
        // dataが原因でJSON上限に達した場合、そのタブだけ失敗へ変更し他の情報を残す。
        if(bytes.length>MAX_RESPONSE&&body.containsKey("data")){body.put("data",Api.failure("error","RESULT_TOO_LARGE","データ結果が応答サイズ上限を超えました。"));body.put("partial",true);bytes=gson.toJson(body).getBytes(StandardCharsets.UTF_8);}
        if(bytes.length>MAX_RESPONSE){http=413;bytes=gson.toJson(error(requestId,"RESULT_TOO_LARGE","応答が16MiBの上限を超えました。")).getBytes(StandardCharsets.UTF_8);}
        res.setStatus(http);res.setContentType("application/json");res.setCharacterEncoding("UTF-8");res.setHeader("Cache-Control","no-store");res.setHeader("X-Content-Type-Options","nosniff");res.setContentLength(bytes.length);res.getOutputStream().write(bytes);
        log("DB+ requestId="+requestId+" http="+http+" elapsedMs="+(System.nanoTime()-start)/1_000_000+" bytes="+bytes.length);
    }
    private Map<String,Object> error(String requestId,String code,String message){Map<String,Object>b=Api.envelope(requestId);b.put("error",Api.map("code",code,"message",message));return b;}
}
