@echo off
setlocal

rem BAT自身に埋め込まれたPowerShell部分を実行する
set "SELF=%~f0"

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
 "$s=[System.IO.File]::ReadAllText($env:SELF);" ^
 "$tag='#__POWERSHELL_BELOW__';" ^
 "$p=$s.LastIndexOf($tag);" ^
 "if($p -lt 0){throw 'PowerShell section was not found.'};" ^
 "Invoke-Expression $s.Substring($p+$tag.Length)"

set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
    echo.
    echo [ERROR] Split failed.
    pause
    exit /b %RC%
)

echo.
echo [OK] Files were restored into split_output.
pause
exit /b 0


#__POWERSHELL_BELOW__

$ErrorActionPreference = "Stop"

$bundleFile = Join-Path (Get-Location) "combined_sources.txt"
$outputDirectory = Join-Path (Get-Location) "split_output"

# けつごう.batと同じ値
$marker = "A73F2C91D85E4B26B1349E57C04268FA"

if (-not (Test-Path -LiteralPath $bundleFile -PathType Leaf)) {
    throw "combined_sources.txt was not found."
}

# 前回の分割結果を削除して作り直す
if (Test-Path -LiteralPath $outputDirectory) {
    Remove-Item -LiteralPath $outputDirectory -Recurse -Force
}

New-Item `
    -ItemType Directory `
    -Path $outputDirectory `
    -Force | Out-Null

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

$bundleText = [System.IO.File]::ReadAllText(
    $bundleFile,
    $utf8NoBom
)

$escapedMarker = [System.Text.RegularExpressions.Regex]::Escape($marker)

$headerPattern =
    "(?m)^@@@__FILE_START__" +
    $escapedMarker +
    "__(?<name>[A-Za-z0-9+/=]+)" +
    "__(?<encoding>utf8bom|utf8|utf16le|utf16be|cp932)" +
    "__(?<length>[0-9]+)@@@\r?\n"

$headerRegex = New-Object System.Text.RegularExpressions.Regex(
    $headerPattern
)

$endPattern =
    "^\r?\n@@@__FILE_END__" +
    $escapedMarker +
    "@@@(?:\r?\n|\z)"

$endRegex = New-Object System.Text.RegularExpressions.Regex(
    $endPattern
)

function Write-SourceFile {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path,

        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string] $Text,

        [Parameter(Mandatory = $true)]
        [string] $EncodingName
    )

    switch ($EncodingName) {
        "utf8bom" {
            $encoding = New-Object System.Text.UTF8Encoding($true)
        }

        "utf8" {
            $encoding = New-Object System.Text.UTF8Encoding($false)
        }

        "utf16le" {
            $encoding = [System.Text.Encoding]::Unicode
        }

        "utf16be" {
            $encoding = [System.Text.Encoding]::BigEndianUnicode
        }

        "cp932" {
            $encoding = [System.Text.Encoding]::GetEncoding(932)
        }

        default {
            throw "Unsupported encoding: $EncodingName"
        }
    }

    [System.IO.File]::WriteAllText(
        $Path,
        $Text,
        $encoding
    )
}

$position = 0
$fileCount = 0

while ($position -lt $bundleText.Length) {
    $headerMatch = $headerRegex.Match(
        $bundleText,
        $position
    )

    if (-not $headerMatch.Success) {
        # 最後に改行だけ残っている場合は正常終了
        if ($bundleText.Substring($position).Trim().Length -eq 0) {
            break
        }

        throw "Invalid bundle format near character position $position."
    }

    if ($headerMatch.Index -ne $position) {
        throw "Unexpected text near character position $position."
    }

    $name64 = $headerMatch.Groups["name"].Value
    $encodingName = $headerMatch.Groups["encoding"].Value
    $contentLength = [int]$headerMatch.Groups["length"].Value

    $fileNameBytes = [System.Convert]::FromBase64String($name64)
    $fileName = [System.Text.Encoding]::UTF8.GetString($fileNameBytes)

    # 不正なパスや親ディレクトリ指定を防止
    if ([System.IO.Path]::GetFileName($fileName) -ne $fileName) {
        throw "Invalid file name in bundle: $fileName"
    }

    $contentStart = $headerMatch.Index + $headerMatch.Length
    $contentEnd = $contentStart + $contentLength

    if ($contentEnd -gt $bundleText.Length) {
        throw "Content is truncated: $fileName"
    }

    $content = $bundleText.Substring(
        $contentStart,
        $contentLength
    )

    $remainingText = $bundleText.Substring($contentEnd)
    $endMatch = $endRegex.Match($remainingText)

    if (-not $endMatch.Success -or $endMatch.Index -ne 0) {
        throw "End marker was not found: $fileName"
    }

    $destinationFile = Join-Path $outputDirectory $fileName

    Write-SourceFile `
        -Path $destinationFile `
        -Text $content `
        -EncodingName $encodingName

    Write-Host "Restored: $fileName"

    $fileCount++
    $position = $contentEnd + $endMatch.Length
}

if ($fileCount -eq 0) {
    throw "No files were found in combined_sources.txt."
}

Write-Host ""
Write-Host "Output directory : $outputDirectory"
Write-Host "Restored files   : $fileCount"

@pause