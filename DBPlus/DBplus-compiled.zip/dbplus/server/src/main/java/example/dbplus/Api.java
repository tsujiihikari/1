package example.dbplus;

import java.util.*;
import java.time.Instant;

/** JSONはGsonでシリアライズ。値と表示HTMLを手書きJSONへ埋め込まない。 */
final class Api {
    private Api() {}
    static Map<String,Object> map(Object... pairs) {
        Map<String,Object> result = new LinkedHashMap<>();
        for (int i=0;i<pairs.length;i+=2) result.put((String)pairs[i],pairs[i+1]);
        return result;
    }
    static Map<String,Object> envelope(String requestId) { return map("protocolVersion",1,"requestId",requestId); }
    static String now() { return Instant.now().toString(); }
    static Map<String,Object> failure(String status,String code,String message) {
        if ("unsupported".equals(status)||"unavailable".equals(status)) return map("status",status,"message",message,"warnings",Collections.emptyList());
        return map("status",status,"error",map("code",code,"message",message),"warnings",Collections.emptyList());
    }
    static final class Problem extends Exception {
        private static final long serialVersionUID=1L;
        final int http; final String code;
        Problem(int http,String code,String message) { super(message);this.http=http;this.code=code; }
    }
}
