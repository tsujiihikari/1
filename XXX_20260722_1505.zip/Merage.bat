@echo off
setlocal

rem BAT自身に埋め込まれたPowerShell部分を実行する
set "SELF=%~f0"

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
 "$s=[System.IO.File]::ReadAllText($env:SELF);" ^
 "$tag='#__POWERSHELL_BELOW__';" ^
 "$p=$s.LastIndexOf($tag);" ^
 "if($p -lt 0){throw 'PowerShell section was not found.'};" ^
 "Invoke-Expression $s.Substring($p+$tag.Length)"

set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
    echo.
    echo [ERROR] Merge failed.
    pause
    exit /b %RC%
)

echo.
echo [OK] combined_sources.txt was created.
pause
exit /b 0


#__POWERSHELL_BELOW__

$ErrorActionPreference = "Stop"

$bundleFile = Join-Path (Get-Location) "combined_sources.txt"

# 結合ファイル内の識別用固定文字列
$marker = "A73F2C91D85E4B26B1349E57C04268FA"

function Read-SourceFile {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path
    )

    $bytes = [System.IO.File]::ReadAllBytes($Path)

    # UTF-8 BOM
    if (
        $bytes.Length -ge 3 -and
        $bytes[0] -eq 0xEF -and
        $bytes[1] -eq 0xBB -and
        $bytes[2] -eq 0xBF
    ) {
        return [PSCustomObject]@{
            Text     = [System.Text.Encoding]::UTF8.GetString(
                $bytes, 3, $bytes.Length - 3
            )
            Encoding = "utf8bom"
        }
    }

    # UTF-16 Little Endian
    if (
        $bytes.Length -ge 2 -and
        $bytes[0] -eq 0xFF -and
        $bytes[1] -eq 0xFE
    ) {
        return [PSCustomObject]@{
            Text     = [System.Text.Encoding]::Unicode.GetString(
                $bytes, 2, $bytes.Length - 2
            )
            Encoding = "utf16le"
        }
    }

    # UTF-16 Big Endian
    if (
        $bytes.Length -ge 2 -and
        $bytes[0] -eq 0xFE -and
        $bytes[1] -eq 0xFF
    ) {
        return [PSCustomObject]@{
            Text     = [System.Text.Encoding]::BigEndianUnicode.GetString(
                $bytes, 2, $bytes.Length - 2
            )
            Encoding = "utf16be"
        }
    }

    # BOMなしUTF-8として厳密に読み込む
    $strictUtf8 = New-Object System.Text.UTF8Encoding($false, $true)

    try {
        return [PSCustomObject]@{
            Text     = $strictUtf8.GetString($bytes)
            Encoding = "utf8"
        }
    }
    catch {
        # UTF-8でなければShift-JIS／Windows-31Jとして扱う
        $cp932 = [System.Text.Encoding]::GetEncoding(932)

        return [PSCustomObject]@{
            Text     = $cp932.GetString($bytes)
            Encoding = "cp932"
        }
    }
}

$files = @(
    Get-ChildItem -LiteralPath . -File |
        Where-Object {
            $_.Extension -ieq ".java" -or
            $_.Extension -ieq ".sql"
        } |
        Sort-Object Name
)

if ($files.Count -eq 0) {
    throw "No .java or .sql files were found in the current directory."
}

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$writer = New-Object System.IO.StreamWriter(
    $bundleFile,
    $false,
    $utf8NoBom
)

# 結合ファイル自体の改行コードはCRLF
$writer.NewLine = "`r`n"

try {
    foreach ($file in $files) {
        $source = Read-SourceFile -Path $file.FullName

        # ファイル名を安全に格納するためBase64化
        $nameBytes = [System.Text.Encoding]::UTF8.GetBytes($file.Name)
        $name64 = [System.Convert]::ToBase64String($nameBytes)

        # 文字数を保存することで、内容中に似た区切り文字があっても分割可能
        $length = $source.Text.Length

        $writer.WriteLine(
            "@@@__FILE_START__${marker}__${name64}__$($source.Encoding)__${length}@@@"
        )

        $writer.Write($source.Text)

        # ソース本文とは別の区切り用改行
        $writer.WriteLine()

        $writer.WriteLine(
            "@@@__FILE_END__${marker}@@@"
        )
    }
}
finally {
    $writer.Dispose()
}

Write-Host ""
Write-Host "Merged file : $bundleFile"
Write-Host "File count  : $($files.Count)"

@pause