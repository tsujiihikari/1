# DB+ RPS・Oracleオブジェクト一覧取得

`Main.java` のmainメソッドから、指定したスキーマ・DBTYPEについてRPSとOracleの情報を収集し、実行時のカレントディレクトリに `result.html` を出力します。ServletやWebサーバーは不要です。

## 同梱ファイル

- `Main.java`：取得・スクレイピング・辞書検索・HTML生成の全処理。
- `classes/Main*.class`：Java 8互換でコンパイルした本体。
- `ojdbc6.jar`：今回添付されたJDBCドライバーをそのまま同梱。
- `config.properties`：実接続用設定。認証情報とJDBC接続先は空欄。
- `config-offline.properties`：保存済みHTML確認用。
- `run.bat`：コンパイルして実行（JDK 8以降）。
- `run-compiled.bat`：コンパイル済み本体を実行（Java 8以降）。
- `result-preview.html`：添付の「RPSサイトのHTML一覧.txt」から生成した結果サンプル。
- `tests/`：ネットワーク制御・辞書照合などの検証コード。

`result-preview.html` は4種類それぞれ保存済み1ページ分の50件です。全件取得済みではなく、Oracleの列は未接続として空欄です。サンプルに実在する名称・担当者を含みます。

## Windowsでの実行

1. ZIPを任意のディレクトリに展開します。
2. `config.properties` をUTF-8のテキストとして編集します。
3. コマンドプロンプトで展開先に移動し、`run.bat` を実行します。
4. 同じディレクトリの `result.html` をブラウザーで開きます。

```bat
cd /d "展開したディレクトリ\DBPlusMetadata"
run.bat
```

認証済みのブラウザーを起動しておく必要はありません。RPSへのログインはJava自身が行います。ブラウザーのCookieは共有しません。

### 必須設定

```properties
mode=live
schema=KYKOWNER
dbtype=KYKDB
rps.base.url=http://10.202.168.238:19001
rps.login.enabled=true
rps.domain=nss.nksol.co.jp
rps.user=自分の社員番号
rps.password=RPSのパスワード
jdbc.url=jdbc:oracle:thin:@//DBホスト:ポート/サービス名
jdbc.user=DB接続ユーザー
jdbc.password=DBパスワード
```

RPSのログインは添付Javaと同じ `/login/login?domain=...&shain_cd=...&pass=...` のGET方式です。今回指定の19001番を初期値とし、添付Javaの13010番には接続しません。環境でログイン方式が異なる場合は `Http.loginAndSetSchema()` を調整してください。

パスワードは設定ファイルの代わりに `DBPLUS_RPS_PASSWORD` / `DBPLUS_JDBC_PASSWORD` 環境変数でも指定できます。環境変数が存在すれば設定ファイルより優先します。添付の認証情報やCSRFトークンは転記していません。

設定はJava Properties形式です。パスを記載する場合、Windowsでも `Z:/folder/file.txt` のように `/` を使うとエスケープを避けられます。パスワード等のバックスラッシュは `\\` として記載するか、環境変数を利用してください。

`schema` はオブジェクト所有者、`dbtype` はRPSの「DB識別名」です。DBTYPEを指定しても接続先Oracleが自動選択されるわけではありません。対応するDBのURLを `jdbc.url` に設定してください。スキーマ名は辞書のOWNERと一致する表記で指定してください（通常のOracle所有者名は大文字）。

### コマンドで直接実行

```bat
javac -encoding UTF-8 -source 8 -target 8 -d classes Main.java
java -cp "classes;ojdbc6.jar" Main config.properties
```

設定ファイルのパスはmainの第1引数です。引数なしでは `config.properties` を読みます。バッチは最初に自身のフォルダーへ移動するため、そのフォルダーがカレントになります。Javaを直接起動する場合は呼び出し元のカレントが基準です。出力先は `output.html` でも変更できます。

JREだけの環境では `run-compiled.bat` を利用できます。実運用のJava・Oracleバージョンと添付ojdbc6の組み合わせは社内環境で確認してください。

## 保存HTMLを使う実行

今回の添付 `RPSサイトのHTML一覧.txt` を、展開した `Main.java` と同じ場所へコピーします。

```bat
run.bat config-offline.properties
```

このモードではRPSにもOracleにも接続しません。保存されたページだけを表示し、「保存ページ分のみ」「Oracle未接続」を明示します。添付元HTMLには認証トークン等が含まれるため、元HTMLはZIPに同梱していません。

文字コード `auto` はUTF-8の厳密検査に失敗するとWindows-31Jに切り替えます。今回の添付HTMLはmetaのUTF-8宣言と異なり、Windows-31Jで保存されていました。実HTTPは設定による文字コード指定、HTTPのcharset、実バイトによる判別の順で処理します。HTTP charsetで復号に失敗した場合も再判別します。

## 取得と突き合わせ

### RPS

1. ログインし、Cookieを取得・保持。
2. 応答HTMLのhiddenフィールドから、そのセッションのCSRFトークンを取得。
3. `/schema/set_schema` にschema、UTF-8チェックマーク、トークンをPOST。
4. スキーマ欄の実値を確認。
5. `/table/list`、`/index/list`、`/view/list`、`/synonym/list` をGET。
6. `rel=next` または `next_page` のリンクがなくなるまでページング。

最初の検索は `pm=ent`、`keyword_db=DBTYPE`、`search_condition[type]=ALL` です。DB識別名は受信行でも完全一致で確認します。次ページはサーバーが生成した検索条件付きリンクをそのまま利用します。別ホストへの遷移、ページ循環、ページ数上限超過はエラーにします。

`std_hover` の一覧表を対象に解析します。今回添付された新旧テーブル一覧の、物理名とVerの列順の違い、`テーブル名称` / `日本語名称`、`Partition` / `Par` の違いに対応しました。シノニムの複数段ヘッダーはデータ行と区別しています。将来RPSの列構成が変わった場合はパーサーの調整が必要です。

### Oracle

参照する辞書は次のとおりです。SELECTだけを実行し、RPS・DBへの登録・更新処理はありません。

|種類|参照辞書|主な項目|
|---|---|---|
|テーブル|ALL_TABLES、ALL_TAB_COMMENTS|所有者、物理名、COMMENTS、表領域、統計上の件数、パーティション、一時表、最終統計取得日時|
|インデックス|ALL_INDEXES、ALL_IND_COLUMNS|所有者、索引名、対象表、種別、一意性、構成列の順序・昇降順、状態、表領域|
|ビュー|ALL_VIEWS、ALL_TAB_COMMENTS|所有者、ビュー名、COMMENTS、定義文字数|
|シノニム|ALL_SYNONYMS、ALL_TAB_COMMENTS|所有者、シノニム名、参照先所有者・名前、DBリンク、参照先COMMENTS|

`dictionary.scope=DBA` を明示した場合は対応するDBA_*辞書を使用します。参照権限が必要です。ALL_*で0件でも、権限上見えていない可能性があります。完全な所有者一覧が必要な場合は対象所有者で接続するか、DBA_*辞書の参照権限を用意してください。

テーブル・索引・ビュー・シノニムは指定スキーマの所有物を取得します。索引は対象表の所有者ではなく、索引自体のOWNERを条件とします。PUBLICシノニムは初期状態でOracle取得対象に含めません。必要なら `synonym.include.public=true` としてください。この設定では参照可能なPUBLICシノニム全体も追加されるため、件数が増えます。RPSに表示されるPUBLIC行はRPS側の定義として保持します。

シノニムのコメントは、DBリンクなしの直近参照先の表・ビューのコメントだけを取得します。シノニムを再帰的に解決したり、リモートDBへ接続したりはしません。インデックスには表のCOMMENTSを日本語索引名として流用しません。関数索引の構成列にSYS_NC...が表示される場合があります。式そのものの抽出は今回の対象外です。ビュー定義本文・DDLのOracle抽出も対象外です。

### 結果のルール

- 種類・スキーマ所有者・物理名を一致させ、RPSとOracleの和集合を表示。
- RPSのバージョン違いは保持。同名で複数バージョンがあれば各行にOracle現在情報を表示。
- RPSの日本語名称を優先し、空欄ならOracleのCOMMENTSで補完。RPS原文とOracleコメントも別列に保持。
- RPSのみ、Oracleのみ、双方取得の区別を表示。未接続・参照権限不足もあり得るため、不在・不整合とは断定しない。
- 物理名自体が日本語でも、そのまま保持し、照合に利用。
- OracleのNUM_ROWSは統計情報であり、COUNT(*)による現在の実件数ではない。
- HTMLの「DDL参照」は対応するRPSのDDL画面へのリンク。ブラウザー側で別途RPSへのログインが必要。
- RPSの「情報」「状況」列等は取得した表示文字を掲載。今回のツール独自の関連情報画面は作成しない。

## HTMLの操作

赤いヘッダー、色別タブ、黄色い見出し、罫線付き一覧を画面キャプチャに合わせた構成にしています。4つのタブ、文字列絞り込み、50/100/500件のページ切り替えに対応します。外部CSS・JavaScript・CDNへのアクセスはありません。JavaScriptが無効な場合も全種類の表を表示します。

## タイムアウト・終了コード

- 接続15秒、HTTP読取30秒、JDBC読取30秒、SQL60秒、全体目安540秒を初期値にしています。
- ページ取得・行読取の間にも全体期限を確認します。OS・JDBCによる待機中の厳密な即時停止までは保証しません。
- `0`：取得処理完了（オフラインの場合は保存済みページ分の完了）。
- `2`：取得の一部または全部が失敗。取得済み情報と失敗状態をHTMLへ出力。
- `1`：設定／入力ファイル／出力先等の問題で処理自体を完了できなかった。

一部失敗時はHTMLの注意欄と各タブの取得状況を確認してください。パスワード、トークン、ログインURLのクエリ、SQL例外本文はログ・HTMLへ出力しません。

## 検証

今回の環境ではJava 17のコンパイラーでJava 8互換のビルドを確認しました。実Oracle・社内RPSへは接続していません。

```bat
java -cp classes Main --self-test
javac -encoding UTF-8 -source 8 -target 8 -cp classes -d classes tests\IntegrationTest.java
java -cp "classes;ojdbc6.jar" IntegrationTest
javac -encoding UTF-8 -source 8 -target 8 -cp classes -d classes tests\RpsFixtureTest.java
java -cp classes RpsFixtureTest "添付HTMLのあるフォルダー"
```

確認済み：日本語物理名・文字コード・HTMLエスケープ・所有者を含む和集合、Cookie/302/CSRF/POST、4種類の2ページ取得、SQLバインド、索引構成列順序、部分失敗時のHTML出力。添付の大型一覧は旧列順で3,254件／3,252件を読み取り、AGENT_DETAILのVer=1.2・日本語名称=取次明細を確認。結果サンプルは各50件、表の列数整合とJavaScript構文を確認しました。ブラウザー実機での表示・操作と実DBのSQL実行は社内環境での確認事項です。

## 将来Servlet化する場合

`collect(Config)` が情報取得、`writeHtml(Path, Config, Report)` がHTML生成です。CookieはHTTPクライアントごとに保持し、JVM全体のCookieHandlerを変更しません。ServletではConfigの入力・認証情報の管理、リクエストごとの実行、HTMLのWriter出力への変更などを行ってください。

## 参照

- 提供された RPSScripingSample.java、RPSサイトのHTML一覧.txt、各debug HTML、画面キャプチャ。
- Oracle公式：[ALL_INDEXES](https://docs.oracle.com/en/database/oracle/oracle-database/18/refrn/ALL_INDEXES.html)
- Java公式：[HttpURLConnection](https://docs.oracle.com/javase/jp/8/docs/api/java/net/HttpURLConnection.html)
