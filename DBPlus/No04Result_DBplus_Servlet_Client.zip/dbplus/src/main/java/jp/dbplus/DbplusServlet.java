package jp.dbplus;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * 画面と共通の4つのURLだけを公開する。javax.servlet 3.x / Java 8。
 * RPSのCookie・選択スキーマ・一覧の識別情報はHttpSession単位で管理する。
 */
public final class DbplusServlet extends HttpServlet {
    private static final long serialVersionUID=2L;
    private final Properties common=new Properties();
    private Catalog catalog;
    static final class ObjectRef {
        final String id=UUID.randomUUID().toString();
        final Catalog.Entry entry;
        final Rps.Kind kind;
        final String name,version,description;
        ObjectRef(Catalog.Entry entry,Rps.Kind kind,Rps.Row row){
            this.entry=entry;this.kind=kind;name=row.name;version=Rps.cell(row,2);
            description=Rps.cell(row,kind.name2Index());
        }
    }
    static final class State {
        final CookieManager cookies=new CookieManager(null,CookiePolicy.ACCEPT_ALL);
        final byte[] credentialHash;
        final Map<String,ObjectRef> objects=new LinkedHashMap<>();
        State(byte[] hash){credentialHash=hash;}
        void add(ObjectRef ref){
            objects.put(ref.id,ref);
            while(objects.size()>2000)objects.remove(objects.keySet().iterator().next());
        }
    }
    @Override public void init() throws ServletException {
        try{
            common.load(new StringReader(resource("/WEB-INF/config.properties")));
            Config c=new Config(common);
            if(c.number("total.timeout.seconds",540)>540)throw new IOException("処理時間は540秒以内で設定してください。");
            // CSVを優先。既存のTSV設定だけを置いた環境にも対応する。
            String csv=optionalResource("/WEB-INF/DBSchema.csv");
            catalog=new Catalog(csv==null?resource("/WEB-INF/DBSchema.properties"):csv);
            Class.forName("oracle.jdbc.OracleDriver");
        }catch(Exception e){
            throw new ServletException("DB+の設定・DBSchema.csv・ojdbc6.jarを確認してください。例外種別: "+e.getClass().getSimpleName());
        }
    }
    private String optionalResource(String path) throws Exception {
        try(InputStream in=getServletContext().getResourceAsStream(path)){
            if(in==null)return null;
            ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
            while((n=in.read(buf))!=-1)b.write(buf,0,n);
            return Rps.decode(b.toByteArray(),"auto");
        }
    }
    private String resource(String path) throws Exception {
        String value=optionalResource(path);
        if(value==null)throw new IOException("必須ファイルがありません。");
        return value;
    }
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException {
        res.setHeader("Allow","POST");
        reply(res,405,Json.obj("ok",false,"error","POSTで呼び出してください。"));
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException {
        req.setCharacterEncoding("UTF-8");
        if(!"1".equals(req.getHeader("X-DBPlus-Request"))){
            reply(res,403,Json.obj("ok",false,"error","DB+の画面から操作してください。"));return;
        }
        String path=req.getServletPath();
        if(!Arrays.asList("/api/login","/api/initial","/api/search","/api/detail").contains(path)){
            reply(res,404,Json.obj("ok",false,"error","対象のURLがありません。"));return;
        }
        HttpSession session=req.getSession(true);
        // RPS側のset_schemaはCookieに紐付く。同じセッションの操作を必ず直列化する。
        synchronized(session){
            try{
                if("/api/login".equals(path)&&"logout".equals(param(req,"operation",16))){
                    session.removeAttribute("rpsState");
                    reply(res,200,Json.obj("ok",true,"status","ログアウトしました。"));return;
                }
                Config c=new Config(common);
                c.domain=required(req,"domain",255);
                c.user=required(req,"loginID",128);
                c.password=requiredRaw(req,"loginPass",1024);
                byte[] hash=hash(c);
                State state=(State)session.getAttribute("rpsState");
                if("/api/login".equals(path)){
                    // 再認証に失敗しても以前のRPSセッションを使い続けない。
                    session.removeAttribute("rpsState");state=new State(hash);
                    new Rps.Http(c,state.cookies).login();session.setAttribute("rpsState",state);
                    reply(res,200,Json.obj("ok",true,"status","接続OK","connections",catalog.publicEntries()));return;
                }
                if(state==null||!MessageDigest.isEqual(hash,state.credentialHash))
                    throw new Rps.AuthException("ログインを確認してください。再認証が必要です。");
                c.schema=required(req,"schema",128);c.dbtype=required(req,"dbtype",128);
                Catalog.Entry entry=catalog.resolve(required(req,"connectionId",64),c.dbtype,c.schema);
                ObjectRef ref="/api/detail".equals(path)?resolveObject(req,state,entry):null;
                Rps.Http h=new Rps.Http(c,state.cookies);h.setSchema();
                if("/api/initial".equals(path)){
                    Map<String,Object> lists=new LinkedHashMap<>();List<String> warnings=new ArrayList<>();
                    // 初回・接続先変更時は4種類を各page=1で取得。次ページは自動取得しない。
                    for(Rps.Kind k:Rps.Kind.values()){
                        try{lists.put(k.path,page(h,c,state,entry,k,1,"","","","prefix"));}
                        catch(Rps.AuthException e){throw e;}
                        catch(Exception e){
                            String msg=k.title+"の初期一覧を取得できませんでした。"+rpsFailure(e);
                            lists.put(k.path,Json.obj("ok",false,"error",msg));warnings.add(msg);
                        }
                    }
                    reply(res,200,Json.obj("ok",true,"lists",lists,"partial",!warnings.isEmpty(),"warnings",warnings));return;
                }
                if("/api/search".equals(path)){
                    Rps.Kind k=kind(required(req,"kind",16));
                    String mode=required(req,"TYPE",16).toLowerCase(Locale.ROOT);
                    int number=Integer.parseInt(required(req,"page",7));
                    reply(res,200,page(h,c,state,entry,k,number,param(req,"object_name",256),
                        param(req,"description",256),param(req,"target_object_name",256),mode));return;
                }
                reply(res,200,detail(h,c,entry,ref));
            }catch(Rps.AuthException e){
                session.removeAttribute("rpsState");
                reply(res,401,Json.obj("ok",false,"status","失敗","error",e.getMessage(),"code","AUTH_REQUIRED"));
            }catch(IllegalArgumentException e){reply(res,400,Json.obj("ok",false,"error",e.getMessage()));}
            catch(SQLException e){reply(res,502,Json.obj("ok",false,"error",dbFailure(e)));}
            catch(Rps.RpsException e){reply(res,502,Json.obj("ok",false,"error",e.getMessage()));}
            catch(Exception e){reply(res,502,Json.obj("ok",false,"status","失敗","error",rpsFailure(e)));}
        }
    }
    private Map<String,Object> page(Rps.Http h,Config c,State state,Catalog.Entry entry,Rps.Kind k,int number,
            String name,String description,String target,String mode) throws Exception {
        RpsService.Page result=RpsService.readPage(h,c,k,number,name,description,target,mode);
        List<Object> rows=new ArrayList<>();
        // 一覧はRPSの50件のみ。Oracleへの接続はテーブル詳細ボタンを押したときに行う。
        for(Rps.Row r:result.rows){
            ObjectRef ref=new ObjectRef(entry,k,r);state.add(ref);
            rows.add(Json.obj("recordId",ref.id,"connectionId",entry.key,"schema",c.schema,
                "dbtype",c.dbtype,"kind",k.path,"name",r.name,"owner",r.owner,
                "version",ref.version,"description",ref.description,"cells",r.cells));
        }
        return Json.obj("ok",true,"kind",k.path,"headers",k.headers,"rows",rows,
            "page",result.page,"pageSize",50,"totalCount",result.total,"totalPages",result.totalPages,
            "query",Json.obj("object_name",name,"description",description,"target_object_name",target,"TYPE",mode),
            "warnings",result.warnings);
    }
    /** 行に発行したrecordIdと全識別子を照合し、別スキーマや別バージョンの取り違えを防ぐ。 */
    private static ObjectRef resolveObject(HttpServletRequest req,State state,Catalog.Entry entry){
        ObjectRef ref=state.objects.get(required(req,"recordId",64));
        if(ref==null)throw new IllegalArgumentException("選択した一覧情報の有効期限が切れました。一覧を再取得してください。");
        if(!ref.entry.key.equals(entry.key)||!ref.kind.path.equals(required(req,"kind",16))
            ||!ref.name.equals(required(req,"object_name",128))||!ref.version.equals(required(req,"version",64)))
            throw new IllegalArgumentException("選択した行と詳細の識別情報が一致しません。一覧を再取得してください。");
        return ref;
    }
    private Map<String,Object> detail(Rps.Http h,Config c,Catalog.Entry entry,ObjectRef ref) throws Exception {
        Map<String,Object> definition=null,ddl,data=null;
        RpsService.Definition parsed=null;List<String> warnings=new ArrayList<>();
        if(ref.kind==Rps.Kind.TABLE){
            try{parsed=RpsService.definition(h,c,ref.name,ref.version,ref.description);definition=parsed.json();definition.put("ok",true);}
            catch(Rps.AuthException e){throw e;}
            catch(Exception e){String msg="RPSの項目定義を取得できませんでした。"+rpsFailure(e);definition=Json.obj("ok",false,"error",msg);warnings.add(msg);}
        }
        try{ddl=Json.obj("ok",true,"text",RpsService.ddl(h,c,ref.kind,ref.name,ref.version));}
        catch(Rps.AuthException e){throw e;}
        catch(Exception e){String msg="RPSのDDLを取得できませんでした。"+rpsFailure(e);ddl=Json.obj("ok",false,"error",msg);warnings.add(msg);}
        if(ref.kind==Rps.Kind.TABLE){
            try(Connection conn=OracleReader.connect(entry,c)){
                data=OracleReader.data(conn,c,ref.name,parsed==null?Collections.<String,String>emptyMap():parsed.names);
                data.put("ok",true);
            }catch(Exception e){
                String msg=dbFailure(e);data=Json.obj("ok",false,"error",msg);warnings.add(msg);
            }
        }
        return Json.obj("ok",true,"kind",ref.kind.path,"name",ref.name,"schema",c.schema,"dbtype",c.dbtype,
            "connectionId",entry.key,"version",ref.version,"description",ref.description,
            "definition",definition,"ddl",ddl,"data",data,"partial",!warnings.isEmpty(),"warnings",warnings);
    }
    static Rps.Kind kind(String value){
        for(Rps.Kind k:Rps.Kind.values())if(k.path.equals(value))return k;
        throw new IllegalArgumentException("オブジェクト種別が不正です。");
    }
    static String param(HttpServletRequest req,String name,int max){
        String v=req.getParameter(name);if(v==null)return "";
        if(v.length()>max)throw new IllegalArgumentException(name+"が長すぎます。");return v.trim();
    }
    static String required(HttpServletRequest req,String name,int max){
        String v=param(req,name,max);if(v.isEmpty())throw new IllegalArgumentException(name+"を指定してください。");return v;
    }
    static String requiredRaw(HttpServletRequest req,String name,int max){
        String v=req.getParameter(name);
        if(v==null||v.isEmpty()||v.length()>max)throw new IllegalArgumentException(name+"を指定してください。");return v;
    }
    static byte[] hash(Config c) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        for(String s:Arrays.asList(c.domain,c.user,c.password)){
            byte[] b=s.getBytes(StandardCharsets.UTF_8);
            md.update((byte)(b.length>>>24));md.update((byte)(b.length>>>16));md.update((byte)(b.length>>>8));md.update((byte)b.length);md.update(b);
        }
        return md.digest();
    }
    static String rpsFailure(Exception e){
        return e instanceof Rps.RpsException?e.getMessage():
            "取得先への接続・設定・応答時間を確認してください（"+e.getClass().getSimpleName()+"）。";
    }
    static String dbFailure(Exception e){
        return "Oracleの接続・参照に失敗しました（"+(e instanceof SQLException?"SQLエラー "+((SQLException)e).getErrorCode():e.getClass().getSimpleName())+"）。DBSchema.csvと参照権限を確認してください。";
    }
    static void reply(HttpServletResponse res,int status,Object value) throws IOException {
        res.setStatus(status);res.setCharacterEncoding("UTF-8");res.setContentType("application/json; charset=UTF-8");
        res.setHeader("Cache-Control","no-store");res.setHeader("X-Content-Type-Options","nosniff");
        res.getWriter().write(Json.write(value));
    }
    @Override public void destroy(){
        Enumeration<Driver> drivers=DriverManager.getDrivers();
        while(drivers.hasMoreElements()){Driver d=drivers.nextElement();if(d.getClass().getClassLoader()==getClass().getClassLoader())
            try{DriverManager.deregisterDriver(d);}catch(SQLException ignored){}}
    }
}
