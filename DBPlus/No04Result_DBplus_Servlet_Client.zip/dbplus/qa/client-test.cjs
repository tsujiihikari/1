/* 実app.jsをNodeの小さなDOMハーネスで実行する。レイアウトの検証用ではない。 */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm'), assert = require('assert');
const root = path.resolve(__dirname, '..'), base = process.argv[2];
const html = fs.readFileSync(path.join(root, 'src/main/webapp/index.html'), 'utf8');
let checks = 0, cookie = '', copied = '', downloaded = '', failAuth = false;
const requests = [], storage = new Map(), listeners = {}, blobUrls = new Map();
function check(ok, label) { assert(ok, label); checks++; }
class Node {
  constructor(tag = '', text = '') {
    this.tagName = tag.toLowerCase(); this.children = []; this.parentNode = null; this.attrs = {};
    this._text = text; this.value = ''; this.checked = false; this.disabled = false; this.hidden = false;
    this.open = false; this.dataset = {}; this.style = {}; this.events = {}; this.scrollTop = this.scrollLeft = 0;
    this.clientHeight = 480; this.clientWidth = 1000;
    this.classList = {
      toggle: (name, force) => {
        const list = new Set(this.className.split(/\s+/).filter(Boolean)), yes = force ?? !list.has(name);
        yes ? list.add(name) : list.delete(name); this.className = [...list].join(' '); return yes;
      },
      add: name => this.classList.toggle(name, true), remove: name => this.classList.toggle(name, false)
    };
  }
  get className() { return this.attrs.class || ''; } set className(v) { this.attrs.class = v; }
  get textContent() { return this._text + this.children.map(c => c.textContent).join(''); }
  set textContent(v) { this.children = []; this._text = String(v ?? ''); }
  setAttribute(name, value) {
    this.attrs[name] = String(value);
    if (name.startsWith('data-')) this.dataset[name.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = String(value);
    if (name === 'id') this.id = value;
    if (name === 'value') this.value = String(value);
    if (['checked', 'hidden', 'disabled'].includes(name)) this[name] = true;
  }
  getAttribute(name) { return this.attrs[name]; }
  append(...nodes) {
    for (let node of nodes) {
      if (!(node instanceof Node)) node = new Node('#text', String(node));
      if (node.tagName === '#fragment') this.append(...node.children.slice());
      else { node.parentNode = this; this.children.push(node); }
      if (this.tagName === 'select' && !this.value && node.tagName === 'option') this.value = node.value;
    }
  }
  replaceChildren(...nodes) { this.children = []; this._text = ''; if (this.tagName === 'select') this.value = ''; this.append(...nodes); }
  remove() { if (this.parentNode) this.parentNode.children = this.parentNode.children.filter(c => c !== this); }
  add(node) { this.append(node); }
  matches(selector) {
    if (selector.startsWith('[')) return Object.hasOwn(this.attrs, selector.slice(1, -1));
    if (selector.startsWith('.')) return this.className.split(/\s+/).includes(selector.slice(1));
    if (selector.startsWith('#')) return this.id === selector.slice(1);
    return this.tagName === selector;
  }
  querySelectorAll(selector) {
    const parts = selector.split(' '), out = [];
    function visit(node) {
      for (const c of node.children) {
        if (c.matches(parts.at(-1))) {
          let p = c.parentNode, n = parts.length - 2;
          while (p && n >= 0) { if (p.matches(parts[n])) n--; p = p.parentNode; }
          if (n < 0) out.push(c);
        }
        visit(c);
      }
    }
    visit(this); return out;
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  get tHead() { return this.children.find(c => c.tagName === 'thead'); }
  get tBodies() { return this.children.filter(c => c.tagName === 'tbody'); }
  showModal() { this.open = true; } close() { this.open = false; this.emit('close', {}); }
  addEventListener(name, fn) { (this.events[name] ||= []).push(fn); }
  emit(name, e) { (this.events[name] || []).forEach(fn => fn(e)); }
  click() { if (this.disabled) return; if (this.tagName === 'a') downloaded = this.download; if (this.onclick) return this.onclick({ preventDefault() {} }); }
  focus() {} select() {}
}
function parse(text) {
  const doc = new Node('document'), stack = [doc], voids = new Set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']);
  for (const token of text.match(/<!--[\s\S]*?-->|<![^>]*>|<[^>]*>|[^<]+/g) || []) {
    if (token.startsWith('<!')) continue;
    if (token.startsWith('</')) { if (stack.length > 1) stack.pop(); continue; }
    if (token.startsWith('<')) {
      const tag = token.match(/^<([\w-]+)/)[1], el = new Node(tag);
      const attrs = token.slice(tag.length + 1, -1);
      for (const m of attrs.matchAll(/([-\w]+)(?:="([^"]*)")?/g)) el.setAttribute(m[1], m[2] || '');
      stack.at(-1).append(el); if (!voids.has(tag)) stack.push(el);
    } else stack.at(-1).append(new Node('#text', token));
  }
  return doc;
}
const doc = parse(html), $ = id => doc.querySelector('#' + id);
doc.getElementById = $; doc.createElement = tag => new Node(tag); doc.createTextNode = text => new Node('#text', text);
doc.createDocumentFragment = () => new Node('#fragment'); doc.body = doc.querySelector('body'); doc.execCommand = () => true;
const sandbox = {
  document: doc, window: { addEventListener: (n, f) => { listeners[n] = f; } },
  navigator: { clipboard: { writeText: async text => { copied = text; } } },
  localStorage: { getItem: key => storage.get(key), setItem: (k,v) => storage.set(k,v), removeItem: k => storage.delete(k) },
  Option: function(label, value) { const n = new Node('option', label); n.value = value; return n; },
  URLSearchParams, AbortController, Blob, console,
  URL: { createObjectURL: blob => { const id = 'blob:' + blobUrls.size; blobUrls.set(id, blob); return id; }, revokeObjectURL: id => blobUrls.delete(id) },
  setTimeout, clearTimeout, requestAnimationFrame: fn => setTimeout(fn, 0),
  fetch: async (target, options) => {
    const fields = Object.fromEntries(options.body);
    requests.push({ target, fields });
    if (failAuth && target.endsWith('/search')) {
      failAuth = false; return new Response(JSON.stringify({ ok:false, error:'RPSの認証期限が切れました。', code:'AUTH_REQUIRED' }), { status:401, headers:{'content-type':'application/json'} });
    }
    const response = await fetch(new URL(target, base), { ...options, headers: { ...options.headers, ...(cookie ? { Cookie:cookie } : {}) } });
    const header = response.headers.get('set-cookie'); if (header) cookie = header.split(';')[0];
    return response;
  }
};
vm.runInNewContext(fs.readFileSync(path.join(root, 'src/main/webapp/app.js'), 'utf8'), sandbox, { filename:'app.js' });
const waitFor = async (predicate, label) => {
  const deadline = Date.now() + 15000;
  while (!predicate()) { if (Date.now() > deadline) throw new Error('Timeout: '+label); await new Promise(r => setTimeout(r, 5)); }
};
const done = async () => { await waitFor(() => !$('wait-dialog').open, 'wait dialog'); await new Promise(r => setTimeout(r, 5)); };
const rows = () => $('objects').tBodies[0].children;
const firstDataButton = index => rows()[index].querySelectorAll('button').find(b => b.textContent === '定義・データ');
(async () => {
  check($('auth-dialog').open && $('prefix').disabled, '初回ログインと未認証操作制御');
  $('domain').value='example.local';$('employee').value='demo';$('password').value='wrong';
  $('auth-form').onsubmit({ preventDefault(){} });
  check($('wait-dialog').open && $('auth-submit').disabled, '接続確認中のスピナーと操作抑止');
  await done(); check($('auth-dialog').open && $('auth-message').textContent.includes('確認できません'), '認証失敗を表示');
  $('password').value='demo-pass';$('auth-form').onsubmit({ preventDefault(){} });
  await done(); await waitFor(() => rows().length === 50, 'initial rows'); await done();
  check(!$('auth-dialog').open && $('identity').textContent.includes('接続OK'), '接続成功');
  check(requests.filter(r => r.target.endsWith('/initial')).length === 1, '初回APIは1回');
  check(doc.querySelectorAll('.tab-count').every(n => n.textContent === '123'), '4種類の件数表示');
  check(storage.has('dbplus.rps.credentials.v1'), 'ログイン情報の保存');
  const count = requests.length;
  $('tab-index').click();
  check(requests.length === count && rows()[0].textContent.includes('IX_0001'), '初期一覧をタブで切り替える');
  rows()[0].querySelector('.row-button').click(); check($('wait-dialog').open, 'DDL取得中スピナー');
  await done(); check($('ddl-text').textContent.includes('IX_0001') && $('detail-tab-data').hidden, '索引のDDL詳細');
  $('detail-close').click(); $('tab-table').click();
  $('physical').value='KYF';$('japanese').value='顧客';
  $('search-form').onsubmit({ preventDefault(){} });
  check($('wait-dialog').open && $('next').disabled && $('connection').disabled, '検索中の待機表示と操作制御');
  await done();
  let req = requests.filter(r => r.target.endsWith('/search')).at(-1);
  check(req.fields.TYPE==='prefix' && req.fields.object_name==='KYF' && req.fields.description==='顧客', '画面の検索値をAPIと統一');
  $('physical').value='未確定の入力';$('next').click();await done();
  req=requests.filter(r => r.target.endsWith('/search')).at(-1);
  check(req.fields.page==='2' && req.fields.object_name==='KYF' && rows().length===25, 'ページ送りでは確定済み条件を維持');
  $('physical').value='KYF';$('contains').click();await done();
  check(requests.at(-1).fields.TYPE==='contains' && $('query-summary').textContent.includes('曖昧検索'), '曖昧検索フラグと画面表示');
  $('clear').click();await done();
  check($('physical').value==='' && $('japanese').value==='' && $('summary').textContent.includes('123'), '条件クリアはサーバー再取得');
  $('page').value='9999';const old=requests.length;$('go').click();
  check(requests.length===old && $('message').textContent.includes('ページ番号'), '範囲外ページを送らない');
  $('all-columns').checked=true;$('all-columns').onchange();
  check($('objects').tHead.children[0].children.length===15, 'RPS全項目表示');
  await $('copy').click();check(copied.includes('テーブル名') && copied.includes('KYF0001'), '一覧コピー');
  $('download').click();check(downloaded.endsWith('.csv'), '一覧CSV保存');
  firstDataButton(0).click();
  check($('detail-dialog').open && $('wait-dialog').open && $('wait-description').textContent.includes('5,000'), '一括詳細取得中の待機表示');
  await done();
  check($('data-count').textContent==='5,000 件', '5000件取得の表示');
  check($('data-table').tBodies[0].children.length<100, '仮想スクロールのDOM件数');
  check($('data-table').tHead.textContent.includes('更新日'), 'データの日本語ヘッダー');
  check($('data-table').textContent.includes('9007199254740993'), '数値の桁を維持');
  $('data-scroll').scrollTop=180000;$('data-scroll').emit('scroll',{});
  await new Promise(r => setTimeout(r,10));
  check($('data-table').tBodies[0].textContent.includes('C005000'), '仮想スクロール最終5000行');
  const before=requests.length;$('detail-tab-definition').click();
  check($('definition-table').textContent.includes('顧客番号') && !$('definition-panel').hidden, 'テーブル定義表示');
  $('detail-tab-ddl').click();
  check($('ddl-text').textContent.includes('CREATE TABLE') && requests.length===before, 'タブ切替では再取得しない');
  await $('detail-copy').click();check(copied.includes('CREATE TABLE'), 'DDLコピー');
  $('detail-download').click();check(downloaded.endsWith('.sql'), 'DDL保存');
  $('detail-close').click();
  firstDataButton(1).click();await done();
  check(!$('detail-warning').hidden && $('detail-status').textContent.includes('Oracle'), 'DB取得失敗を表示');
  $('detail-tab-definition').click();check($('detail-status').textContent.includes('5 項目'), '部分失敗でも定義を利用');
  $('detail-close').click();
  $('physical').value='ZZZ';$('search-form').onsubmit({preventDefault(){}});await done();
  check(rows().length===0 && !$('empty').hidden && $('empty-title').textContent.includes('ありません'), '検索0件の表示');
  failAuth=true;$('clear').click();await done();
  check($('auth-dialog').open && $('prefix').disabled && rows().length===0, '認証期限切れで再認証、一覧を破棄');
  check(requests.every(r => /^api\/(login|initial|search|detail)$/.test(r.target)), 'クライアントのURLは4種類だけ');
  const report={ checks, result:'passed', mode:'Node DOM harness + real Servlet API bridge', requests:requests.length };
  fs.writeFileSync(path.join(root,'docs/client-results.json'),JSON.stringify(report,null,2)+'\n');
  console.log('Client integration:',report);
})().catch(e => { console.error(e);process.exitCode=1; });
