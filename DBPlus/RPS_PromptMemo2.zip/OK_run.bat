@echo off
setlocal
cd /d "%~dp0"
if not exist classes mkdir classes
C:\Users\8045984\Tsujii\01.Download\jdk8_Java_64bit\jdk1.8.0_181\bin\javac -encoding UTF-8 -source 8 -target 8 -d classes Main.java
if errorlevel 1 exit /b 1
C:\Users\8045984\Tsujii\01.Download\jdk8_Java_64bit\jdk1.8.0_181\bin\java -cp "classes;ojdbc6.jar" Main %*
exit /b %errorlevel%
