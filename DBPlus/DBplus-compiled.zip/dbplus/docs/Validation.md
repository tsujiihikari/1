# 検証結果 — 2026-10-07

## 実施済み

| 検証 | 結果・対象 |
| --- | --- |
| TypeScript strict | `tsc --noEmit` 成功。discriminated unionで成功／失敗の項目を区別 |
| フロント生成 | TypeScript 5.9.3、Dart Sass 1.93.2でJS/CSS生成成功 |
| Python契約テスト | 6件成功。3000件、超過、0件、HTMLエスケープ、精度文字列、NULL、12/10/8列、部分失敗、長文、一覧4001件内部判定 |
| Javaコンパイル | Java 17実行環境＋ECJ 3.33.0 `--release 8` でJava 8標準API互換・Servlet 3.1依存としてコンパイル成功 |
| Java契約テスト | 0/1/2999/3000/3001件、SQL LIMITパラメータ3001、setMaxRows3001、ResultSet/Statement解放、HTMLエスケープ、Unicode境界、定義12列を検証 |
| DOM契約テスト | jsdom 26.1.0で一覧／データの可視DOM行数、3000行目、4タブ、サブタブの追加通信なし、縦スクロール復元、0件、部分失敗、セルプレビュー、Links、軽量履歴、遅延A→B、別スキーマ同名、キャッシュ期限、起動時の履歴のみ復元を検証 |
| 静的構成 | 固定ID重複なし、生成CSSとSCSSにimportant宣言なし、外部script/stylesheet依存なし |
| WAR構成 | アプリクラスmajor version 52、Servlet API未同梱、Gson JARあり、静的JS/CSSがルート生成物と一致 |
| ZIP構成 | 指定のindex.html、js/main.ts、css/main.scss、ReadMe.mdを含む。node_modules・参考WAR・JDBC資格情報なし |

DOMテストでは枠の高さ・スクロール座標をテスト側で制御しています。実ブラウザで32pxの行高、stickyヘッダー、画面の見た目や性能を測定したという意味ではありません。TypeScriptのモジュールは生成と静的パスを確認していますが、実ブラウザのmoduleロードは未確認です。

## 未実施／環境確定後

- 実DBの製品／バージョン／JDBCドライバを用いたSELECT・カタログ・LOB・実行計画検証。
- 実JNDI DataSource、接続プール、借用待ち、socket/read timeout、認証との連携。
- RPS実DBの候補解決、スキーマ／版対応、業務定義の実表示。
- OracleのALL_SYNONYMS、複合／式インデックス等の実カタログ確認。
- JDK 8実機＋Mavenによる再ビルド、Servletコンテナへの配置／起動。
- 最新版EdgeとChromeの両方での視覚・操作・アクセシビリティ確認。
- 1920×1080、1366×768、1280×720、ズーム125%／150%の行高／スクロール確認。
- 実環境の描画200ms目標、ネットワーク／DB期限、応答16MiB境界、同時利用時の性能。

実ブラウザの確認用環境をこの作業では使用できないため、ブラウザ／視覚検証は実施していません。架空データでの成功を実DB接続成功として報告していません。
