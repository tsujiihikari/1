"use strict";

// Servlet API接続先は、このタブの最初の1回だけ判定する。
// 1) 社内Tomcat  2) 予備Tomcat の順に /init を確認し、成功したURLをsessionStorageへ保存する。
const USE_SAMPLE_DATA = false;
const KRUGLE_CONTEXT_PATH = "/krugleapi";
const KRUGLE_API_PRIMARY_BASE = "http://10.205.7.19:8080/krugleapi/";
const KRUGLE_API_SECONDARY_BASE = "http://133.18.42.50:8080/krugleapi/";
const API_SESSION_STORAGE_KEY = "krugle.api.base.url";
const API_SESSION_VERSION_KEY = "krugle.api.base.version";
const API_SESSION_VERSION = "20260814_fix93_recent_arrow_cursor_band_v1";
const API_PROBE_TIMEOUT_PRIMARY_MS = 1000;
const API_PROBE_TIMEOUT_SECONDARY_MS = 1500;
const API_ACCESS_TIMEOUT_MS = 20000;
const SOURCE_FAST_TIMEOUT_MS = 15000;
const SOURCE_RESPONSE_CACHE_LIMIT = 40;
const SOURCE_RESPONSE_CACHE_MAX_AGE_MS = 10 * 60 * 1000;
// 2026-08-12 fix63: 検索結果100件超の体感速度改善。
// 最初の100行だけ即時描画し、残りは小分けで追加してメインスレッドの長時間ブロックを避ける。
const SEARCH_RENDER_INITIAL_ROWS = 100;
const SEARCH_RENDER_CHUNK_ROWS = 150;
const TABLE_INFO_ENDPOINT = "/table-info";
const TABLE_HIGHLIGHT_ENDPOINT = "/table-highlight-targets";
const DIRECTORY_GROUP_ENDPOINT = "/directory-groups";
const directoryGroupOptionsCache = new Map();
let directoryGroupLoadSequence = 0;

// 2026-07-28 修正2: 検索結果タブの初期表示条件。
// ServletはKrugleへ接続できる場合は実検索し、接続できない場合は
// WEB-INF/classes/mock-search/KrugleSearchResult.csv の52件を返す。
const INITIAL_SEARCH_CONDITION = Object.freeze({
  keyword: "KYF1940",
  project: "NIKKO.nkCCIS",
  language: "java",
  mode: "normal"
});

// 同一ブラウザタブ内で開いたサイト内タブを、一意IDでたどるためのSessionStorage履歴。
// 表示位置（何番目）には依存せず、ホーム・検索結果は固定ID、時刻タブは「日時＋完全パス」をIDにする。
const TAB_NAVIGATION_STORAGE_KEY = "krugle.session.tab.navigation.state";
const TAB_NAVIGATION_VERSION_KEY = "krugle.session.tab.navigation.version";
const TAB_NAVIGATION_VERSION = "20260722_backspace_unique_tab_v9";
const TAB_NAVIGATION_CURRENT_ID_KEY = "krugle.session.tab.navigation.currentId";
const TAB_NAVIGATION_LIMIT = 300;
let restoringTabNavigation = false;
let sourceOpenRequestSequence = 0;
const sourceResponseCache = new Map();
let searchRenderSequence = 0;
let currentRenderedSearchRows = [];

let activeApiBase = readSessionStorage(API_SESSION_VERSION_KEY) === API_SESSION_VERSION
  ? normalizeApiBase(readSessionStorage(API_SESSION_STORAGE_KEY))
  : "";
let resolvedApiInitData = null;
let apiResolvePromise = null;

const FILE_HISTORY_STORAGE_KEY = "krugle.history.files";
const SEARCH_HISTORY_STORAGE_KEY = "krugle.history.words";
const FILE_HISTORY_INITIALIZED_VERSION_KEY = "krugle.history.files.initialized.version";
const FILE_HISTORY_INITIAL_VERSION = "20260722_full_path_v1";
const FILE_HISTORY_INITIAL_SEED_MARKER = "INITIAL_FILE_STORAGE_VALUES_20260708_home_history_seed_width_fix2";
const INITIAL_FILE_STORAGE_VALUES = [
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzNys_java.jar/jp/co/fnt/stp1/app/apptier/back/az/nys/model/KyakJkyKjnHjnSyutkTask.java,2026/07/01_12:30:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtt_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctt/model/KjoYmdSyutkTask.java,2026/07/01_12:20:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtt_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctt/model/KjoYmdUpdTask.java,2026/07/01_12:10:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjEdd_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/edd/model/KjEddHojnJohoTask.java,2026/07/01_12:00:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjEdd_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/edd/model/KjEddKabunusiYakuinTorkTask.java,2026/07/01_11:50:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzKzt_java.jar/jp/co/fnt/stp1/app/apptier/back/az/kzt/model/SaknRyuhoGKjo1K2KMainTask.java,2026/07/01_11:40:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjUhk_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/uhk/model/KjUhkDelTask.java,2026/07/01_11:30:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjUhk_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/uhk/model/KjUhkJohoSearchTask.java,2026/07/01_11:20:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtc_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctc/model/KysJohoKjnSyutkTask.java,2026/07/01_11:10:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzJky_java.jar/jp/co/fnt/stp1/app/apptier/back/az/jky/model/SaknRyuhoGKjoInqTask.java,2026/07/01_11:00:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzJky_java.jar/jp/co/fnt/stp1/app/apptier/back/az/jky/model/SaknRyuhoGKjoTask.java,2026/07/01_10:50:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYK5470_upd.sql,2026/07/01_12:30:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF9800_Ikan.sql,2026/07/01_12:20:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF6510_INS.sql,2026/07/01_12:10:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4410_spool.sql,2026/07/01_12:00:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF3030upd_From_CC.sql,2026/07/01_11:50:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISD0607_KYK5300_02_SPOOL.sql,2026/07/01_11:40:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF3030spool_To_CC.sql,2026/07/01_11:30:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4400_BZN_spool.sql,2026/07/01_11:20:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISALTD218.sql,2026/07/01_11:10:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4301_PL_SEL.sql,2026/07/01_11:00:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISALTD078.sql,2026/07/01_10:50:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/meigara/MeigaraIchiran.java,2026/07/01_12:30:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiApplication.java,2026/07/01_12:20:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiApplicationCommand.java,2026/07/01_12:10:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiBbApplication.java,2026/07/01_12:00:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiBbApplicationCommand.java,2026/07/01_11:50:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiPoApplication.java,2026/07/01_11:40:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_po/meigara/MeigaraIchiran.java,2026/07/01_11:30:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_po/sinkoku_jyokyo/KbSnkokMeisaiBbPOApplication.java,2026/07/01_11:20:00"
];
const sampleFiles = INITIAL_FILE_STORAGE_VALUES;
const RECENT_TAB_STORE_LIMIT = 100;
const RECENT_TAB_VISIBLE_LIMIT = 25;
const RECENT_TAB_MIN_COUNT = 0;
const FILE_HISTORY_HOME_DISPLAY_LIMIT = 300;
const FILE_HISTORY_MINI_DISPLAY_LIMIT = 20;
const INITIAL_HISTORY_SAMPLE_COUNT = 30;
const HISTORY_PLACEHOLDER_VALUE = "-";
const INITIAL_RESULT_PLACEHOLDER_COUNT = 30;
let recentWindowStart = 0;
// 2026-07-31 修正6: ヘッダー数字タブのactive/visitedは、Pathではなく画面上のタブIDで揮発的に管理する。
// SessionStorageには保存しないため、サイトを開き直すと初期状態に戻る。
let activeRecentTabKey = "";
const volatileVisitedRecentTabIds = new Set();
let manualRecentWindowShift = false;
// 2026-08-07 修正17: ArrowLeft/ArrowRightのプレビュー状態を保持する。
// 2026-08-07 fix29: 右/左タブ移動ボタンは通常ボタン化し、click/Enterで即時移動する。
let activeRecentTabPreviewTabId = "";
let activeCodeSideNavigationPreviewOffset = 0;
let activeCodeSideNavigationHoverOffset = 0;
// 2026-08-12 fix45: ヘッダー左右矢印上にマウスがある状態のEnterをArrowLeft/ArrowRightと同じプレビューにする。
let activeRecentNavArrowHoverOffset = 0;


function splitHistoryStorageValue(value) {
  if (value && typeof value === "object") {
    const path = String(value.path || value.fullPath || value.filePath || value.filePathName || value.file || value.name || "").trim();
    const openedAt = value.openedAt || value.time || value.updateTime || value.dateTime || value.timestamp || "";
    const fileName = value.fileName || value.file || value.name || "";
    const project = value.project || value.projectName || value.projectValue || value.fullProject || "";
    const group = value.group || value.migrationGroup || value.ikogroup || value.ikoGroup || value.projectGroup || "";
    const directoryGroup = value.directoryGroup || value.dirGroup || value.directory || value.dir || "";
    return {
      path,
      openedAtRaw: String(openedAt || "").trim(),
      fileName: String(fileName || "").trim(),
      project: String(project || "").trim(),
      group: String(group || "").trim(),
      directoryGroup: String(directoryGroup || "").trim(),
      initialSeed: value.__initialFileHistorySeed === true || value.initialSeed === true,
      seedMarker: String(value.__initialFileHistorySeedMarker || value.seedMarker || "").trim(),
      raw: value
    };
  }

  const text = String(value || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) {
    return { path: text, openedAtRaw: "", fileName: "", project: "", group: "", directoryGroup: "", initialSeed: false, seedMarker: "", raw: text };
  }

  const commaIndex = text.lastIndexOf(",");
  if (commaIndex > 0) {
    return {
      path: text.substring(0, commaIndex).trim(),
      openedAtRaw: text.substring(commaIndex + 1).trim(),
      fileName: "",
      project: "",
      group: "",
      directoryGroup: "",
      initialSeed: false,
      seedMarker: "",
      raw: text
    };
  }

  return { path: text, openedAtRaw: "", fileName: "", project: "", group: "", directoryGroup: "", initialSeed: false, seedMarker: "", raw: text };
}

function parseHistoryOpenedAt(value, fallbackDate) {
  const raw = String(value || "").trim();
  const fallback = fallbackDate ? toSafeDate(fallbackDate) : new Date();
  if (!raw) return fallback.toISOString();

  const normalized = raw
    .replace(/_/g, "T")
    .replace(/\//g, "-")
    .replace(/\s+/g, "T");
  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? fallback.toISOString() : date.toISOString();
}

function formatHistoryStorageDate(value) {
  const date = toSafeDate(value || new Date());
  const pad = number => String(number).padStart(2, "0");
  return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())}_${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function createHistoryStorageValue(path, openedAt, meta = {}) {
  const pathEntry = splitHistoryStorageValue(path);
  const project = normalizeProjectValue(meta.project || meta.projectName || meta.projectValue || pathEntry.project || "");
  const rawGroup = meta.group || meta.migrationGroup || meta.ikogroup || meta.ikoGroup || pathEntry.group || "";
  const group = normalizeMigrationGroupName(rawGroup);
  const fullPath = buildCompleteKruglePath(pathEntry.path, project, rawGroup);
  if (!fullPath || isPlaceholderHistoryValue(fullPath)) return fullPath;

  const result = {
    path: fullPath,
    openedAt: formatHistoryStorageDate(openedAt || new Date())
  };

  const fileName = String(meta.fileName || meta.file || meta.name || pathEntry.fileName || "").trim();
  const directoryGroup = cleanDirectoryGroupName(meta.directoryGroup || meta.dirGroup || meta.directory || pathEntry.directoryGroup || "");
  const initialSeed = meta.initialSeed === true || meta.__initialFileHistorySeed === true;
  const seedMarker = String(meta.seedMarker || meta.__initialFileHistorySeedMarker || (initialSeed ? FILE_HISTORY_INITIAL_SEED_MARKER : "")).trim();

  if (fileName) result.fileName = fileName;
  if (project) result.project = project;
  if (group) result.group = group;
  if (directoryGroup) result.directoryGroup = directoryGroup;
  if (initialSeed) {
    result.__initialFileHistorySeed = true;
    result.__initialFileHistorySeedMarker = seedMarker || FILE_HISTORY_INITIAL_SEED_MARKER;
  }
  return result;
}

function getHistoryEntryPath(value) {
  const entry = splitHistoryStorageValue(value);
  return buildCompleteKruglePath(entry.path, entry.project, entry.group);
}

function getHistoryEntryOpenedAt(value, fallbackDate) {
  const entry = splitHistoryStorageValue(value);
  return parseHistoryOpenedAt(entry.openedAtRaw, fallbackDate);
}

function buildRecentTabFromHistoryValue(value, fallbackDate) {
  const path = getHistoryEntryPath(value);
  if (!path || isPlaceholderHistoryValue(path)) return null;
  return {
    path,
    openedAt: getHistoryEntryOpenedAt(value, fallbackDate)
  };
}


function readStoredArray(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) ? value : [];
  } catch (e) {
    return [];
  }
}

function createInitialFileHistorySeedValues() {
  return normalizeFileHistoryValues((Array.isArray(INITIAL_FILE_STORAGE_VALUES) ? INITIAL_FILE_STORAGE_VALUES : [])
    .map((value, index) => {
      const entry = splitHistoryStorageValue(value);
      const path = entry.path;
      if (!isValidFileHistoryPath(path)) return null;
      const openedAt = parseHistoryOpenedAt(entry.openedAtRaw, new Date(Date.now() - index * 60 * 1000));
      return createHistoryStorageValue(path, openedAt, {
        fileName: entry.fileName,
        project: entry.project,
        group: entry.group,
        directoryGroup: entry.directoryGroup,
        initialSeed: true,
        seedMarker: FILE_HISTORY_INITIAL_SEED_MARKER
      });
    })
    .filter(Boolean));
}

function isCurrentInitialFileHistorySeed(value) {
  const entry = splitHistoryStorageValue(value);
  return entry.initialSeed === true && entry.seedMarker === FILE_HISTORY_INITIAL_SEED_MARKER;
}

function isAnyInitialFileHistorySeed(value) {
  const entry = splitHistoryStorageValue(value);
  return entry.initialSeed === true || Boolean(entry.seedMarker);
}

function createInitialFileHistoryCompareSet(seedValues) {
  return new Set((Array.isArray(seedValues) ? seedValues : [])
    .map(stringifyHistoryValueForCompare)
    .filter(Boolean));
}

function initializeFileHistoryStorageIfNeeded() {
  if (USE_SAMPLE_DATA) return;
  try {
    const seedValues = createInitialFileHistorySeedValues();
    const seedCompareSet = createInitialFileHistoryCompareSet(seedValues);
    const storedValues = readStoredArray(FILE_HISTORY_STORAGE_KEY);
    const hasCurrentSeed = storedValues.some(isCurrentInitialFileHistorySeed);

    // INITIAL_FILE_STORAGE_VALUES 由来の旧データだけを先にクリーンする。
    // ただし、現在のマーカー付き seed は残し、ユーザーが実際に開いた同一ファイルの別日時履歴は消さない。
    const cleanedValues = storedValues.filter(value => {
      if (isCurrentInitialFileHistorySeed(value)) return true;
      if (isAnyInitialFileHistorySeed(value)) return false;
      return !seedCompareSet.has(stringifyHistoryValueForCompare(value));
    });

    const nextValues = hasCurrentSeed
      ? normalizeFileHistoryValues(cleanedValues)
      : normalizeFileHistoryValues(seedValues.concat(cleanedValues));

    const before = storedValues.map(stringifyHistoryValueForCompare).join("\u0001");
    const after = nextValues.map(stringifyHistoryValueForCompare).join("\u0001");
    if (before !== after || !hasCurrentSeed) {
      saveArray(FILE_HISTORY_STORAGE_KEY, nextValues);
    }
    localStorage.setItem(FILE_HISTORY_INITIALIZED_VERSION_KEY, FILE_HISTORY_INITIAL_VERSION);
  } catch (e) {
    console.warn("file history storage initialize failed", e);
  }
}

function readFileHistoryValues() {
  const fallback = createInitialFileHistorySeedValues();
  if (USE_SAMPLE_DATA) return normalizeFileHistoryValues(fallback);
  initializeFileHistoryStorageIfNeeded();
  const values = readArray(FILE_HISTORY_STORAGE_KEY, fallback);
  return seedFileHistoryStorage(FILE_HISTORY_STORAGE_KEY, values, fallback);
}

function buildSampleRecentTabs() {
  // 時間タブも、ホーム履歴・右側履歴と同じ「フルパス,日時」の元データから作る。
  const result = [];
  const base = new Date("2026-07-07T10:01:04");
  sampleFiles.forEach((value, index) => {
    const fallback = new Date(base.getTime() - (index * 60 * 1000));
    const item = buildRecentTabFromHistoryValue(value, fallback);
    if (item) result.push(item);
  });
  return result;
}

const sampleRecentTabs = buildSampleRecentTabs();
let sessionRecentTabs = null;

const sampleSearchWords = [
  "TableAccessor | ALL | ALL",
  "CUSTOMER_ID | nkCCIS | java",
  "Command Task Accessor | BPNet | Java",
  "MST_CUSTOMER | SMBC | SQL",
  "QueryAccessor | fast2024 | XML",
  "AccountUpdate | nikkoEZ | ALL",
  "KYF1940 | ALL | java",
  "8jjj8jjeJEjee | nkCCIS | Java",
  "TableAccessor009 | BPNet | SQL",
  "CUSTOMER_ID010 | SMBC | XML",
  "Command Task Accessor011 | fast2024 | ALL",
  "MST_CUSTOMER012 | nikkoEZ | java",
  "QueryAccessor013 | ALL | Java",
  "AccountUpdate014 | nkCCIS | SQL",
  "KYF1940015 | BPNet | XML",
  "8jjj8jjeJEjee016 | SMBC | ALL",
  "TableAccessor017 | fast2024 | java",
  "CUSTOMER_ID018 | nikkoEZ | Java",
  "Command Task Accessor019 | ALL | SQL",
  "MST_CUSTOMER020 | nkCCIS | XML",
  "QueryAccessor021 | BPNet | ALL",
  "AccountUpdate022 | SMBC | java",
  "KYF1940023 | fast2024 | Java",
  "8jjj8jjeJEjee024 | nikkoEZ | SQL",
  "TableAccessor025 | ALL | XML",
  "CUSTOMER_ID026 | nkCCIS | ALL",
  "Command Task Accessor027 | BPNet | java",
  "MST_CUSTOMER028 | SMBC | Java",
  "QueryAccessor029 | fast2024 | SQL",
  "AccountUpdate030 | nikkoEZ | XML",
  "KYF1940031 | ALL | ALL",
  "8jjj8jjeJEjee032 | nkCCIS | java",
  "TableAccessor033 | BPNet | Java",
  "CUSTOMER_ID034 | SMBC | SQL",
  "Command Task Accessor035 | fast2024 | XML",
  "MST_CUSTOMER036 | nikkoEZ | ALL",
  "QueryAccessor037 | ALL | java",
  "AccountUpdate038 | nkCCIS | Java",
  "KYF1940039 | BPNet | SQL",
  "8jjj8jjeJEjee040 | SMBC | XML",
  "TableAccessor041 | fast2024 | ALL",
  "CUSTOMER_ID042 | nikkoEZ | java",
  "Command Task Accessor043 | ALL | Java",
  "MST_CUSTOMER044 | nkCCIS | SQL",
  "QueryAccessor045 | BPNet | XML",
  "AccountUpdate046 | SMBC | ALL",
  "KYF1940047 | fast2024 | java",
  "8jjj8jjeJEjee048 | nikkoEZ | Java",
  "TableAccessor049 | ALL | SQL",
  "CUSTOMER_ID050 | nkCCIS | XML",
  "Command Task Accessor051 | BPNet | ALL",
  "MST_CUSTOMER052 | SMBC | java",
  "QueryAccessor053 | fast2024 | Java",
  "AccountUpdate054 | nikkoEZ | SQL",
  "KYF1940055 | ALL | XML",
  "8jjj8jjeJEjee056 | nkCCIS | ALL",
  "TableAccessor057 | BPNet | java",
  "CUSTOMER_ID058 | SMBC | Java",
  "Command Task Accessor059 | fast2024 | SQL",
  "MST_CUSTOMER060 | nikkoEZ | XML",
  "QueryAccessor061 | ALL | ALL",
  "AccountUpdate062 | nkCCIS | java",
  "KYF1940063 | BPNet | Java",
  "8jjj8jjeJEjee064 | SMBC | SQL",
  "TableAccessor065 | fast2024 | XML",
  "CUSTOMER_ID066 | nikkoEZ | ALL",
  "Command Task Accessor067 | ALL | java",
  "MST_CUSTOMER068 | nkCCIS | Java",
  "QueryAccessor069 | BPNet | SQL",
  "AccountUpdate070 | SMBC | XML",
  "KYF1940071 | fast2024 | ALL",
  "8jjj8jjeJEjee072 | nikkoEZ | java",
  "TableAccessor073 | ALL | Java",
  "CUSTOMER_ID074 | nkCCIS | SQL",
  "Command Task Accessor075 | BPNet | XML",
  "MST_CUSTOMER076 | SMBC | ALL",
  "QueryAccessor077 | fast2024 | java",
  "AccountUpdate078 | nikkoEZ | Java",
  "KYF1940079 | ALL | SQL",
  "8jjj8jjeJEjee080 | nkCCIS | XML"
];

const sampleResults = [
  { file: "KYF1940TableAccessor.java", line: 128, project: "NewNikko", group: "nkCCIS", path: "kayk.online/lib/KjCTMYYYYYY.jar/jp/com/xxx/xxx/xxx/KYF1940TableAccessor.java" },
  { file: "KYF1950TableAccessor.java", line: 82, project: "NewNikko", group: "nkCCIS", path: "kayk.online/lib/KjCTMYYYYYY.jar/jp/com/xxx/xxx/xxx/KYF1950TableAccessor.java" },
  { file: "KjCustomerSearchCommand.java", line: 45, project: "NewNikko", group: "nkCCIS", path: "business-java/lib/KjCommand.jar/jp/com/xxx/command/KjCustomerSearchCommand.java" },
  { file: "KjCustomerSearchTask.java", line: 211, project: "NewNikko", group: "nkCCIS", path: "business-java/lib/KjTask.jar/jp/com/xxx/task/KjCustomerSearchTask.java" },
  { file: "ORD0100QueryAccessor.java", line: 67, project: "BPNet", group: "BPNet", path: "bpnet_dbac/lib/OrderDbac.jar/jp/com/xxx/dbac/ORD0100QueryAccessor.java" },
  { file: "AccountUpdateTableAccessor.java", line: 159, project: "SMBC", group: "SMBC", path: "smbc_dbac/lib/AccountDbac.jar/jp/com/xxx/dbac/AccountUpdateTableAccessor.java" },
  { file: "customer-search.sql", line: 14, project: "fast2024", group: "fast2024", path: "fast/sql/customer/customer-search.sql" },
  { file: "application-context.xml", line: 33, project: "nikkoEZ", group: "nikkoEZ", path: "ez/config/application-context.xml" } ];

const sampleCode = `NIKKO.nkCCIS/efront.online.jar/lib/ApFrKjFtf_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ftf/model/KyakRiskKakzJohoSyutkTask.java


package jp.co.fnt.stp1.app.apptier.front.kj.ftf.model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.fnt.stp1.app.apptier.com.cm.com.exception.SoteiGaSQLException;
import jp.co.fnt.stp1.app.apptier.com.cm.com.task.Task;
import jp.co.fnt.stp1.app.apptier.com.cm.com.task.TaskResult;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.constants.KjFtfAppSymbols;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.constants.KjFtfGyomConst;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.ctrl.param.KakudukeJoho;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.ctrl.param.RiskItem;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1940TableAccessor;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1940TableRecord;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1950TableAccessor;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1950TableRecord;
import jp.co.fnt.stp1.appfw.basefw.APBFWException;
import jp.co.fnt.stp1.appfw.basefw.CommandContext;
import jp.co.fnt.stp1.appfw.basefw.CommandException;
import jp.co.fnt.stp1.appfw.basefw.MsgInfo;

/**
 * <strong>格付算出情報取得タスク</strong>
 * <BR>
 * @author ACC
**/

public class KyakRiskKakzJohoSyutkTask implements Task{
	public static final Map<String,String> KAKUDUKE_KBN_MAP = new HashMap<>();
	static{
		KAKUDUKE_KBN_MAP.put("EH", "00");
		KAKUDUKE_KBN_MAP.put("H", "00");
		KAKUDUKE_KBN_MAP.put("M", "01");
		KAKUDUKE_KBN_MAP.put("L-", "02");
		KAKUDUKE_KBN_MAP.put("L", "02");
	}

    /**
    *  <B>格付算出情報取得する </B>
    * @param CommandContext                コマンドコンテキスト
    * @param kyakCifC                      顧客CIFコード
    * @param coHyjunC                     会社標準コード
    * @exception CommandException          アプリケーションが送出する例外の抽象クラス
    * @exception APBFWException            APBFWが送出する例外の抽象クラス
    **/

    public static TaskResult getKakzJoho(CommandContext context, 
            String kyakCifC, String coHyjunC) throws CommandException, APBFWException {
        // タスクリザルト
        TaskResult taskResult = new TaskResult();

        // 結果格納
		ArrayList<KakudukeJoho> kakudukeJohoList = new ArrayList<KakudukeJoho>();
		String expertJudgement = "";
		String total = "";
		String kakuduke = "";
		String kakudukeKbn = "";

		// DB Accessor
        Kyf1940TableAccessor kyf1940Accessor = new Kyf1940TableAccessor();
        Kyf1950TableAccessor kyf1950Accessor = new Kyf1950TableAccessor();
    	
        Kyf1940TableRecord kyf1940Record = new Kyf1940TableRecord();
        Kyf1950TableRecord kyf1950Record = new Kyf1950TableRecord();
		
        try{
        	// 格付算出根拠情報を取得する
        	kyf1940Accessor.executeQueryKyakRiskKakzJoho(
        			context.getConnectionManager().getConnection(), 
        			coHyjunC, 
        			kyakCifC, 
        			KjFtfGyomConst.RONR_MASY_K_0);
        	
        	// 格付項目名情報を取得する
        	kyf1950Accessor.executeQueryKyakRiskKakzKomkNmJoho(
        			context.getConnectionManager().getConnection(), 
        			coHyjunC, 
        			KjFtfGyomConst.RONR_MASY_K_0);
			
			if ((kyf1940Record = kyf1940Accessor.nextRecord()) != null) {
				// 顧客リスク格付項目名情報
				kyf1950Record = kyf1950Accessor.nextRecord();
				
				// 格付情報_基本項目
				KakudukeJoho basicJoho = editKakudukeJoho(kyf1940Record,kyf1950Record,1,4,"基本項目","10");
				kakudukeJohoList.add(basicJoho);
				
				// 格付情報_加点項目
				KakudukeJoho addJoho = editKakudukeJoho(kyf1940Record,kyf1950Record,5,15,"加点項目","11");
				kakudukeJohoList.add(addJoho);
				
				expertJudgement = kyf1940Record.getExpJuge();
				total = kyf1940Record.getRiskScoreGokei();
				kakuduke = kyf1940Record.getRiskKakzCnd();
				kakudukeKbn = KAKUDUKE_KBN_MAP.get(kakuduke);
				
			} else {
				// データ存在しない場合
				taskResult.setMsgInfo(new MsgInfo("AFKJFTF112001"));
			}
        } catch(SQLException e){
            throw new SoteiGaSQLException(e.getMessage(), e);
        } catch(APBFWException e) {
            throw e;
        } finally{
        		try {
        			kyf1940Accessor.closeStatement();
        			kyf1950Accessor.closeStatement();
    			} catch( SQLException e) {
    				throw new SoteiGaSQLException(e.getMessage(), e);
    			}
        }
        // タスク結果設定
		// 格付情報リストをタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE_LIST, kakudukeJohoList);
		// ExpertJudgementをタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.EXPERT_JUDGEMENT, expertJudgement);
		// 合計をタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.TOTAL, total);
		// 顧客リスク格付をタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE, kakuduke);
		// 顧客リスク格付区分をタスク出力にセットする
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE_KBN, kakudukeKbn);
		
		// タスクリザルト
        taskResult.setEndJtai(TaskResult.OK);
        return taskResult;
    }
    
    /**
     * 格付情報作成
     * @param kyf1940Record KYF1940から取得した情報
     * @param kyf1950Record　KYF1950から取得した情報
     * @param start 情報取得開始位置
     * @param end　情報取得終了位置
     * @param riskNm　リスク要素名
     * @param riskKbn　リスク要素区分
     */
	private static KakudukeJoho editKakudukeJoho(
			Kyf1940TableRecord kyf1940Record, Kyf1950TableRecord kyf1950Record,
			int start, int end, String riskNm, String riskKbn) {
		// リスク格付け情報
		KakudukeJoho joho = new KakudukeJoho();
		// リスク内容リスト
		List<RiskItem> riskItems = new ArrayList<>();
		
		for(int i = start; i <= end; i++){
			RiskItem item = new RiskItem();
			if(kyf1950Record!=null){
				item.setLabel(getItemValue(kyf1950Record,"getKyakAtr"+ String.format("%02d", i)+"nm"));
			}else{
				item.setLabel("");
			}
			item.setPoint(getItemValue(kyf1940Record,"getKyakAtr"+ String.format("%02d", i)+"Pt"));
			riskItems.add(item);
		}
		
		joho.setRiskElementKbn(riskKbn);
		joho.setRiskElementNm(riskNm);
		joho.setRiskItems(riskItems);
		return joho;
	}
	
	/**
     * 項目名によりレコードから項目値を取得
     */
    public static String getItemValue(Object ob, String getName) {
    	String rt = "";
    	try {
    		rt = (String)ob.getClass().getDeclaredMethod(getName).invoke(ob);
    	} catch (Exception e){}
    	return rt;
    }
}`;

const sampleAiCode = `// AIによる解説コード
// このAccessorは、CUSTOMER_IDを条件にMST_CUSTOMERを検索するサンプルです。
// SQL_SELECTで取得項目を定義し、PreparedStatementでバインド変数を設定します。
// ResultSetを1行ずつDTOへ詰め替えて、呼び出し元へListで返却します。

public List<CustomerDto> selectCustomer(Connection con, String customerId) throws Exception {
    // 1. 戻り値用のリストを作成
    List<CustomerDto> result = new ArrayList<CustomerDto>();

    // 2. CUSTOMER_IDを条件に検索
    try (PreparedStatement ps = con.prepareStatement(SQL_SELECT)) {
        ps.setString(1, customerId);

        // 3. 検索結果をDTOへ変換
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                CustomerDto dto = new CustomerDto();
                dto.setCustomerId(rs.getString("CUSTOMER_ID"));
                dto.setCustomerName(rs.getString("CUSTOMER_NAME"));
                dto.setStatus(rs.getString("STATUS"));
                result.add(dto);
            }
        }
    }
    return result;
}`;

const sampleSummaryText = `要約説明

・MST_CUSTOMERを検索するTableAccessorです。
・CUSTOMER_IDを検索条件としてPreparedStatementに設定します。
・取得したCUSTOMER_ID、CUSTOMER_NAME、STATUSをCustomerDtoへ詰め替えます。
・検索結果はList<CustomerDto>として返却します。`;

let currentView = "home";
let currentCodePath = USE_SAMPLE_DATA ? sampleFiles[1] : "";
let codeFontSize = 12;
const CODE_FONT_MIN = 9;
const CODE_FONT_MAX = 24;
const CODE_FONT_STEP = 1;
let activeCodePanel = "source";
let lastSearchParams = null;
let lastSearchMode = "normal";
let lastSearchResults = [];
let currentCodeMeta = null;
let currentSourceText = "";
let currentSourceLanguage = "java";
let currentTableNames = [];
let currentTableNameSet = new Set();
let tableInfoRequestSequence = 0;
let tableInfoState = {
  status: "idle",
  tableName: "",
  candidates: [],
  selected: null,
  tableMeta: null,
  columns: [],
  unique: false,
  error: ""
};
// 2026-08-04 サイト修正6: テーブル情報は1タブ上書きではなく、クリックごとに独立タブとして保持する。
let tableInfoTabSequence = 0;
let tableInfoStates = [];
let activeTableInfoTabId = "";

// コード中のJavaクラス名・テーブル名は、下線を常時表示する。
// このフラグは背景色だけを切り替える。初期状態は必ずOFF。
let codeHighlightBackgroundEnabled = false;

function $(id) {
  return document.getElementById(id);
}

function cssEscapeValue(value) {
  if (window.CSS && typeof window.CSS.escape === "function") {
    return window.CSS.escape(String(value || ""));
  }
  return String(value || "").replace(/["\\]/g, "\\$&");
}

function formatDateTime(value) {
  const date = toSafeDate(value);
  const pad = value => String(value).padStart(2, "0");
  const week = ["日", "月", "火", "水", "木", "金", "土"][date.getDay()];
  return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())}(${week}) ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function formatSummaryDateTimeValue(value, fallbackDate) {
  const text = String(value == null ? "" : value).trim();
  if (text && text !== "-") {
    if (/^\d{4}\/\d{2}\/\d{2}\([日月火水木金土]\)\s+\d{2}:\d{2}:\d{2}$/.test(text)) {
      return text;
    }
    return formatDateTime(text);
  }
  return fallbackDate ? formatDateTime(fallbackDate) : "-";
}


function readSessionStorage(key) {
  try {
    return String(sessionStorage.getItem(key) || "").trim();
  } catch (e) {
    return "";
  }
}

function writeSessionStorage(key, value) {
  try {
    sessionStorage.setItem(key, String(value == null ? "" : value));
  } catch (e) {
    console.warn("sessionStorage write failed", e);
  }
}

function removeSessionStorage(key) {
  try {
    sessionStorage.removeItem(key);
  } catch (e) {
    // sessionStorageが無効でも画面処理は継続する。
  }
}

function normalizeTabNavigationEntry(value) {
  if (!value || typeof value !== "object") return null;

  const type = String(value.type || "").trim();
  if (type === "view") {
    const view = String(value.view || "").trim();
    if (view !== "home" && view !== "search") return null;
    return {
      id: `view:${view}`,
      type: "view",
      view
    };
  }

  if (type === "recent") {
    const path = getHistoryEntryPath(value.path || value.fullPath || value.filePath || "");
    if (!path) return null;

    const openedTime = new Date(value.openedAt || "");
    if (Number.isNaN(openedTime.getTime())) return null;
    const openedAt = openedTime.toISOString();
    const item = { path, openedAt };

    const entry = {
      id: `recent:${recentTabKey(item)}`,
      type: "recent",
      path,
      openedAt
    };

    ["fileName", "project", "group", "directoryGroup", "href", "sourceUrl", "language"].forEach(key => {
      const text = String(value[key] == null ? "" : value[key]).trim();
      if (text) entry[key] = text;
    });
    return entry;
  }

  return null;
}

function createViewTabNavigationEntry(viewName) {
  return normalizeTabNavigationEntry({ type: "view", view: viewName });
}

function createRecentTabNavigationEntry(item, meta = {}) {
  return normalizeTabNavigationEntry(Object.assign({}, meta || {}, {
    type: "recent",
    path: item && item.path,
    openedAt: item && item.openedAt
  }));
}

function readTabNavigationState() {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(TAB_NAVIGATION_STORAGE_KEY) || "{}");
    const entries = Array.isArray(parsed.entries)
      ? parsed.entries.map(normalizeTabNavigationEntry).filter(Boolean).slice(-TAB_NAVIGATION_LIMIT)
      : [];
    const currentId = entries.length ? entries[entries.length - 1].id : "";
    return {
      version: TAB_NAVIGATION_VERSION,
      entries,
      currentId
    };
  } catch (e) {
    return { version: TAB_NAVIGATION_VERSION, entries: [], currentId: "" };
  }
}

function writeTabNavigationState(state) {
  try {
    const entries = (state && Array.isArray(state.entries) ? state.entries : [])
      .map(normalizeTabNavigationEntry)
      .filter(Boolean)
      .slice(-TAB_NAVIGATION_LIMIT);
    const currentId = entries.length ? entries[entries.length - 1].id : "";
    const payload = {
      version: TAB_NAVIGATION_VERSION,
      entries,
      currentId
    };
    sessionStorage.setItem(TAB_NAVIGATION_STORAGE_KEY, JSON.stringify(payload));
    sessionStorage.setItem(TAB_NAVIGATION_CURRENT_ID_KEY, currentId);
    if (document && document.documentElement) {
      document.documentElement.dataset.activeTabId = currentId;
    }
    updateRecentTabVisitedStyles();
  } catch (e) {
    console.warn("tab navigation history write failed", e);
  }
}

function recordTabNavigation(entry) {
  if (restoringTabNavigation) return;
  const normalized = normalizeTabNavigationEntry(entry);
  if (!normalized) return;

  const state = readTabNavigationState();
  const last = state.entries[state.entries.length - 1];
  if (!last || last.id !== normalized.id) {
    state.entries.push(normalized);
  }
  writeTabNavigationState(state);
}

function initializeTabNavigationHistory() {
  const storedVersion = readSessionStorage(TAB_NAVIGATION_VERSION_KEY);
  if (storedVersion !== TAB_NAVIGATION_VERSION) {
    removeSessionStorage(TAB_NAVIGATION_STORAGE_KEY);
    removeSessionStorage(TAB_NAVIGATION_CURRENT_ID_KEY);
    // 旧実装のSessionStorageも消して、壊れた履歴を引き継がない。
    removeSessionStorage("krugle.session.tab.navigation.history");
    removeSessionStorage("krugle.session.tab.navigation.version");
    writeSessionStorage(TAB_NAVIGATION_VERSION_KEY, TAB_NAVIGATION_VERSION);
  }

  // 初期画面はホームなので、サイトを開いた時点から必ず履歴へ入れる。
  recordTabNavigation(createViewTabNavigationEntry("home"));
}

function isBackspaceEditingTarget(target) {
  if (!target) return false;
  const element = target.nodeType === 1 ? target : target.parentElement;
  if (!element) return false;
  if (element.isContentEditable) return true;
  if (element.closest && element.closest('[contenteditable="true"], [contenteditable=""]')) return true;

  const tagName = String(element.tagName || "").toLowerCase();
  if (tagName === "textarea" || tagName === "select") {
    return !element.disabled && !element.readOnly;
  }
  if (tagName === "input") {
    const type = String(element.type || "text").toLowerCase();
    const nonTextTypes = new Set(["button", "checkbox", "color", "file", "hidden", "image", "radio", "range", "reset", "submit"]);
    return !nonTextTypes.has(type) && !element.disabled && !element.readOnly;
  }
  return false;
}

function findRecentTabForNavigation(entry) {
  const normalized = normalizeTabNavigationEntry(entry);
  if (!normalized || normalized.type !== "recent") return null;

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  const exact = tabs.find(item => `recent:${recentTabKey(item)}` === normalized.id);
  if (exact) return exact;

  // 履歴クリアや上限超過で同一IDが消えた場合も、保存済みの完全パスでソースを復元する。
  // 同じパスの最新タブが残っていれば、その実在タブをアクティブにする。
  return tabs.find(item => item.path === normalized.path) || {
    path: normalized.path,
    openedAt: normalized.openedAt
  };
}

function openTabNavigationEntry(entry) {
  const normalized = normalizeTabNavigationEntry(entry);
  if (!normalized) return false;

  restoringTabNavigation = true;
  try {
    if (normalized.type === "view") {
      showView(normalized.view, { recordNavigation: false });
      return true;
    }

    if (normalized.type === "recent") {
      const recentItem = findRecentTabForNavigation(normalized);
      const row = {
        path: normalized.path,
        fileName: normalized.fileName || "",
        project: normalized.project || "",
        group: normalized.group || "",
        directoryGroup: normalized.directoryGroup || "",
        href: normalized.href || "",
        sourceUrl: normalized.sourceUrl || "",
        language: normalized.language || ""
      };
      openCode(normalized.path, {
        addRecent: false,
        recentItem,
        row,
        recordNavigation: false
      });
      return true;
    }
  } finally {
    // openCodeは最初のawaitより前にタブ表示を切り替えるため、ここで解除してよい。
    restoringTabNavigation = false;
  }
  return false;
}

function navigateToPreviousOpenedTab() {
  const state = readTabNavigationState();
  if (state.entries.length <= 1) return false;

  // 最後の要素が現在のタブ。これを取り除き、その直前の一意IDへ戻る。
  state.entries.pop();
  while (state.entries.length) {
    const previous = state.entries[state.entries.length - 1];
    writeTabNavigationState(state);
    if (openTabNavigationEntry(previous)) return true;
    state.entries.pop();
  }

  writeTabNavigationState(state);
  return false;
}

function handleBackspaceTabNavigation(event) {
  const isBackspace = event.key === "Backspace" || event.keyCode === 8;
  if (!isBackspace || event.defaultPrevented || event.isComposing || event.keyCode === 229) return;
  if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || event.repeat) return;
  if (isBackspaceEditingTarget(event.target)) return;

  // ブラウザの「前のページへ戻る」を止め、サイト内タブ履歴だけを1件戻す。
  event.preventDefault();
  event.stopPropagation();
  navigateToPreviousOpenedTab();
}

// 2026-08-12 fix59: 右側縦ボタンの「前のタブへ戻る」はBackSpaceと同じサイト内タブ戻り処理に統一する。
let activeCodeBackTabButtonHover = false;

function activatePreviousOpenedTabButton(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  navigateToPreviousOpenedTab();
}

function bindCodeBackTabButton() {
  const button = $("codeBackTabBtn");
  if (!button) return;

  button.addEventListener("click", activatePreviousOpenedTabButton);
  button.addEventListener("keydown", event => {
    if (event.key !== "Enter" && event.key !== " ") return;
    activatePreviousOpenedTabButton(event);
  });
  button.addEventListener("mouseenter", () => {
    activeCodeBackTabButtonHover = true;
  });
  button.addEventListener("mouseleave", () => {
    activeCodeBackTabButtonHover = false;
  });
  button.addEventListener("pointerenter", () => {
    activeCodeBackTabButtonHover = true;
  });
  button.addEventListener("pointerleave", () => {
    activeCodeBackTabButtonHover = false;
  });
}

function normalizeApiBase(base) {
  const value = String(base || "").trim();
  if (!value) return "";
  return value.endsWith("/") ? value : `${value}/`;
}

function apiPathForBase(base, path) {
  const cleanPath = String(path || "").replace(/^\/+/, "");
  const normalizedBase = normalizeApiBase(base);
  if (/^https?:\/\//i.test(normalizedBase)) {
    return new URL(cleanPath, normalizedBase).toString();
  }
  if (normalizedBase) return `${normalizedBase.replace(/\/$/, "")}/${cleanPath}`;
  return `${KRUGLE_CONTEXT_PATH}/${cleanPath}`;
}

function apiPath(path) {
  return apiPathForBase(activeApiBase || KRUGLE_API_PRIMARY_BASE, path);
}

function formBody(params) {
  const body = new URLSearchParams();
  Object.keys(params || {}).forEach(key => {
    const value = params[key];
    if (value !== undefined && value !== null) body.append(key, String(value));
  });
  return body;
}

function buildQueryString(params) {
  return formBody(params).toString();
}

function appendQuery(url, params) {
  const query = buildQueryString(params);
  if (!query) return url;
  return url + (url.indexOf("?") >= 0 ? "&" : "?") + query;
}

function createApiError(message, properties = {}) {
  const error = new Error(message);
  Object.keys(properties).forEach(key => {
    error[key] = properties[key];
  });
  return error;
}

function shouldUseJsonpTransport(options = {}) {
  if (options.transport === "fetch") return false;
  if (options.transport === "jsonp") return true;
  // file://直開きでは通常fetchのCORS判定より先にJSONPを使う。
  // Servlet側がcallbackを処理するため、Origin:nullやPNA制約を受けない。
  return window.location.protocol === "file:";
}

async function fetchJsonViaCors(base, path, params = {}, options = {}) {
  const method = String(options.method || "POST").toUpperCase();
  let url = apiPathForBase(base, path);
  const requestOptions = {
    method,
    headers: { "Accept": "application/json" },
    cache: "no-store",
    mode: "cors",
    credentials: "omit",
    redirect: "follow"
  };

  if (method === "GET") {
    url = appendQuery(url, params);
  } else {
    requestOptions.headers["Content-Type"] = "application/x-www-form-urlencoded;charset=UTF-8";
    requestOptions.body = formBody(params);
  }

  let timeoutId = null;
  let controller = null;
  const timeoutMs = Number(options.timeoutMs || 0);
  if (timeoutMs > 0 && typeof AbortController !== "undefined") {
    controller = new AbortController();
    requestOptions.signal = controller.signal;
    timeoutId = window.setTimeout(() => controller.abort(), timeoutMs);
  }

  let response;
  try {
    response = await fetch(url, requestOptions);
  } catch (e) {
    const timedOut = Boolean(e && e.name === "AbortError");
    const detail = timedOut ? `タイムアウト(${timeoutMs}ms)` : String((e && e.message) || e || "Failed to fetch");
    throw createApiError(`通信失敗: ${detail}\nURL: ${url}`, {
      apiUnavailable: true,
      timedOut,
      url,
      cause: e
    });
  } finally {
    if (timeoutId !== null) window.clearTimeout(timeoutId);
  }

  const text = await response.text();
  let data = {};
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (e) {
      throw createApiError(`JSON解析失敗 HTTP ${response.status}: ${text.substring(0, 300)}\nURL: ${url}`, {
        apiUnavailable: true,
        status: response.status,
        url,
        cause: e
      });
    }
  }

  if (!response.ok) {
    const message = data && data.error ? data.error : `HTTP ${response.status}`;
    throw createApiError(`${message}\nURL: ${url}`, {
      apiUnavailable: response.status === 404 || response.status >= 500,
      status: response.status,
      url,
      responseData: data
    });
  }
  return data;
}

function fetchJsonViaJsonp(base, path, params = {}, options = {}) {
  return new Promise((resolve, reject) => {
    const timeoutMs = Math.max(1, Number(options.timeoutMs || API_ACCESS_TIMEOUT_MS));
    const callbackName = `__krugleJsonp_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const query = Object.assign({}, params, {
      callback: callbackName,
      _: Date.now()
    });
    const url = appendQuery(apiPathForBase(base, path), query);
    const script = document.createElement("script");
    let settled = false;
    let timerId = null;

    const cleanup = () => {
      if (timerId !== null) window.clearTimeout(timerId);
      try { delete window[callbackName]; } catch (e) { window[callbackName] = undefined; }
      if (script.parentNode) script.parentNode.removeChild(script);
    };
    const finish = (handler, value) => {
      if (settled) return;
      settled = true;
      cleanup();
      handler(value);
    };

    window[callbackName] = data => finish(resolve, data || {});
    script.async = true;
    script.src = url;
    script.onerror = () => finish(reject, createApiError(`JSONP通信失敗\nURL: ${url}`, {
      apiUnavailable: true,
      url
    }));
    timerId = window.setTimeout(() => finish(reject, createApiError(`タイムアウト(${timeoutMs}ms)\nURL: ${url}`, {
      apiUnavailable: true,
      timedOut: true,
      url
    })), timeoutMs);
    document.head.appendChild(script);
  });
}

async function fetchJsonAtBase(base, path, params = {}, options = {}) {
  if (shouldUseJsonpTransport(options)) {
    // JSONPはscript GETだけを利用するため、POST指定でもGETクエリへ安全に変換する。
    return fetchJsonViaJsonp(base, path, params, options);
  }
  return fetchJsonViaCors(base, path, params, options);
}

function isMixedContentCandidate(base) {
  return window.location.protocol === "https:" && /^http:\/\//i.test(normalizeApiBase(base));
}

function clearApiBaseSelection() {
  activeApiBase = "";
  resolvedApiInitData = null;
  apiResolvePromise = null;
  removeSessionStorage(API_SESSION_STORAGE_KEY);
  removeSessionStorage(API_SESSION_VERSION_KEY);
  // 旧版が保存した失敗フラグも削除する。
  removeSessionStorage("krugle.api.base.resolved");
  removeSessionStorage("krugle.api.base.error");
}

function saveApiBaseSelection(base) {
  activeApiBase = normalizeApiBase(base);
  writeSessionStorage(API_SESSION_STORAGE_KEY, activeApiBase);
  writeSessionStorage(API_SESSION_VERSION_KEY, API_SESSION_VERSION);
  removeSessionStorage("krugle.api.base.resolved");
  removeSessionStorage("krugle.api.base.error");
}

function validateProbeResponse(data, base) {
  if (!data || data.ok !== true) {
    throw createApiError(`疎通確認の応答形式が不正です。\nURL: ${apiPathForBase(base, "/init")}`, {
      apiUnavailable: true
    });
  }
}

function validateInitResponse(data, base) {
  if (!data || !Array.isArray(data.projects)) {
    throw createApiError(`Servlet /init の応答形式が不正です。\nURL: ${apiPathForBase(base, "/init")}`, {
      apiUnavailable: true
    });
  }
}

async function resolveApiBaseOnce(options = {}) {
  const forceCheck = options.forceCheck === true;
  if (!forceCheck && activeApiBase) {
    return { base: normalizeApiBase(activeApiBase), initData: resolvedApiInitData, cached: true };
  }
  if (!forceCheck && apiResolvePromise) return apiResolvePromise;

  const candidates = [
    { base: KRUGLE_API_PRIMARY_BASE, timeoutMs: API_PROBE_TIMEOUT_PRIMARY_MS },
    { base: KRUGLE_API_SECONDARY_BASE, timeoutMs: API_PROBE_TIMEOUT_SECONDARY_MS }
  ].filter(candidate => !isMixedContentCandidate(candidate.base));

  const promise = (async () => {
    const errors = [];
    for (const candidate of candidates) {
      const base = normalizeApiBase(candidate.base);
      try {
        // 第1段階: Servletだけを短時間確認。Krugle CGIには接続しない。
        const probeData = await fetchJsonAtBase(base, "/init", { probe: "1" }, {
          method: "GET",
          timeoutMs: candidate.timeoutMs
        });
        validateProbeResponse(probeData, base);

        // 第2段階: 同じServletへ本アクセス。この成功後だけSessionStorageへ保存する。
        const initData = await fetchJsonAtBase(base, "/init", {}, {
          method: "GET",
          timeoutMs: API_ACCESS_TIMEOUT_MS
        });
        validateInitResponse(initData, base);

        resolvedApiInitData = initData;
        saveApiBaseSelection(base);
        console.info(`Krugle Servlet API接続OK: ${activeApiBase}`);
        return { base: activeApiBase, initData, cached: false };
      } catch (e) {
        errors.push(`${base} -> ${String(e && e.message ? e.message : e)}`);
      }
    }

    throw createApiError(`Servlet APIへ接続できませんでした。\n${errors.join("\n\n")}`, {
      apiUnavailable: true,
      candidateErrors: errors
    });
  })();

  apiResolvePromise = promise;
  promise.catch(() => {
    if (apiResolvePromise === promise) apiResolvePromise = null;
  });
  return promise;
}

async function fetchJson(path, params = {}, options = {}) {
  const resolved = await resolveApiBaseOnce();
  try {
    return await fetchJsonAtBase(resolved.base, path, params, options);
  } catch (e) {
    if (options.disableFailover === true || !e || e.apiUnavailable !== true) throw e;

    const failedBase = normalizeApiBase(resolved.base);
    clearApiBaseSelection();
    console.warn(`Servlet接続先を再判定します: ${failedBase}`);
    const retryResolved = await resolveApiBaseOnce({ forceCheck: true });
    return fetchJsonAtBase(retryResolved.base, path, params, Object.assign({}, options, { disableFailover: true }));
  }
}

function buildSourceResponseCacheKey(endpoint, params = {}) {
  const stable = [
    endpoint,
    params.path || "",
    params.fullPath || "",
    params.filePath || "",
    params.project || "",
    params.href || "",
    params.sourceUrl || "",
    params.language || "",
    params.className || params.javaClassName || "",
    params.qualifiedClassName || params.javaQualifiedClassName || params.importQualifiedClassName || "",
    params.originPath || "",
    params.originFullPath || "",
    params.originProject || "",
    params.originGroup || "",
    params.originDirectoryGroup || "",
    params.originPackage || ""
  ];
  return stable.map(value => String(value == null ? "" : value)).join("");
}

function cloneSourceResponseData(data) {
  if (!data || typeof data !== "object") return data;
  try {
    return JSON.parse(JSON.stringify(data));
  } catch (e) {
    return Object.assign({}, data);
  }
}

function readSourceResponseCache(cacheKey) {
  if (!cacheKey || !sourceResponseCache.has(cacheKey)) return null;
  const entry = sourceResponseCache.get(cacheKey);
  if (!entry || Date.now() - entry.loadedAt > SOURCE_RESPONSE_CACHE_MAX_AGE_MS) {
    sourceResponseCache.delete(cacheKey);
    return null;
  }
  // Mapは挿入順を保持するため、読み出した項目を末尾へ回して簡易LRUにする。
  sourceResponseCache.delete(cacheKey);
  sourceResponseCache.set(cacheKey, entry);
  return cloneSourceResponseData(entry.data);
}

function writeSourceResponseCache(cacheKey, data) {
  if (!cacheKey || !data || typeof data !== "object") return;
  sourceResponseCache.set(cacheKey, {
    loadedAt: Date.now(),
    data: cloneSourceResponseData(data)
  });
  while (sourceResponseCache.size > SOURCE_RESPONSE_CACHE_LIMIT) {
    const firstKey = sourceResponseCache.keys().next().value;
    if (firstKey === undefined) break;
    sourceResponseCache.delete(firstKey);
  }
}

async function fetchSourceJsonFast(endpoint, params = {}) {
  const preferredBase = normalizeApiBase(activeApiBase || KRUGLE_API_PRIMARY_BASE);
  if (!preferredBase || isMixedContentCandidate(preferredBase)) {
    return fetchJson(endpoint, params, { method: "GET", timeoutMs: SOURCE_FAST_TIMEOUT_MS });
  }

  try {
    const data = await fetchJsonAtBase(preferredBase, endpoint, params, {
      method: "GET",
      timeoutMs: SOURCE_FAST_TIMEOUT_MS
    });
    if (!activeApiBase) saveApiBaseSelection(preferredBase);
    return data;
  } catch (e) {
    if (!e || e.apiUnavailable !== true) throw e;
    if (activeApiBase && normalizeApiBase(activeApiBase) === preferredBase) {
      clearApiBaseSelection();
    }
    console.warn(`ソース取得の直接接続に失敗したためServlet接続先を再判定します: ${preferredBase}`, e);
    const retryResolved = await resolveApiBaseOnce({ forceCheck: true });
    return fetchJsonAtBase(retryResolved.base, endpoint, params, {
      method: "GET",
      timeoutMs: SOURCE_FAST_TIMEOUT_MS
    });
  }
}

function submitDownload(path, params = {}) {
  const form = document.createElement("form");
  form.method = "POST";
  form.action = apiPath(path);
  form.style.display = "none";
  form.target = "_self";

  Object.keys(params || {}).forEach(key => {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = key;
    input.value = params[key] == null ? "" : String(params[key]);
    form.appendChild(input);
  });

  document.body.appendChild(form);
  form.submit();
  window.setTimeout(() => form.remove(), 1000);
}

function optionText(selectElement) {
  if (!selectElement) return "";
  const option = selectElement.options[selectElement.selectedIndex];
  return option ? option.textContent.trim() : "";
}

function normalizeKeywordForMode(rawKeyword, mode) {
  const keyword = String(rawKeyword || "").trim();

  // 通常検索では入力値を一切加工しない。
  if (mode !== "fuzzy" || !keyword) return keyword;

  // 曖昧検索の場合だけ、存在しない側の * を補う。
  // 既に入力されている先頭・末尾の * はそのまま尊重する。
  const leadingWildcard = keyword.startsWith("*") ? "" : "*";
  const trailingWildcard = keyword.endsWith("*") ? "" : "*";
  return `${leadingWildcard}${keyword}${trailingWildcard}`;
}

function hasExecutableSearchKeyword(rawKeyword) {
  // 2026-08-12 fix47:
  // 空文字、半角/全角スペースだけ、タブだけ、*だけ、半角記号だけの検索では
  // Servlet / Krugle API へREST呼び出ししない。
  const text = String(rawKeyword || "");
  if (!text.replace(/[\s\u3000]+/g, "")) return false;

  // 英数字・全角英数字・ひらがな・カタカナ・漢字のいずれかを含む場合だけ検索可能とする。
  // 記号だけの入力（例: *, ***, --, /, @@@）は無効扱いにする。
  return /[0-9A-Za-z\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A\u3040-\u309F\u30A0-\u30FF\u3400-\u9FFF]/.test(text);
}

const KRUGLE_LANGUAGE_VALUE_ALIASES = Object.freeze({
  "java": "java",
  "sql": "sql",
  "xml": "xml",
  "jsp": "jsp",
  "shell": "shell",
  "shell script": "shell",
  "javascript": "javascript",
  "html": "html",
  "c#": "csharp",
  "csharp": "csharp",
  "c++": "cpp",
  "cpp": "cpp",
  "visual basic": "vb",
  "vb": "vb",
  "vb.net": "vb.net",
  "asp.net": "asp.net",
  "objective c": "objectivec",
  "common lisp": "lisp",
  "lex/flex": "lex",
  "pascal/delphi": "pascal",
  "s/r": "s",
  "yacc/bison": "yacc"
});

function normalizeLanguageValueForKrugle(value) {
  const raw = String(value == null ? "" : value).trim();
  if (!raw) return "ALL";
  if (raw.toUpperCase() === "ALL" || raw === "すべて") return "ALL";
  const key = raw.toLowerCase();
  return KRUGLE_LANGUAGE_VALUE_ALIASES[key] || key;
}

function getLanguageDisplayTextForSearch(selectElement, languageValue) {
  const text = optionText(selectElement);
  if (text) return text;
  const normalized = normalizeLanguageValueForKrugle(languageValue);
  if (normalized === "ALL") return "すべて";
  const option = selectElement
    ? Array.from(selectElement.options).find(item => normalizeLanguageValueForKrugle(item.value) === normalized)
    : null;
  return option ? String(option.textContent || "").trim() : languageValue;
}


function runSearchFromCurrentInput(mode = "normal") {
  const params = buildSearchParams(mode);
  if (!hasExecutableSearchKeyword(params.rawKeyword)) return false;
  showView("search");
  runSearch(true, mode, { paramsOverride: params });
  return true;
}

function buildSearchParams(mode = "normal") {
  const keywordInput = $("keywordInput");
  const projectSelect = $("groupSelect");
  const directoryGroupSelect = $("directoryGroupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  const rawKeyword = keywordInput ? keywordInput.value.trim() : "";
  // 0行目相当の「選択なし」は、検索条件としては全件扱いにする。
  const project = projectSelect && projectSelect.value ? projectSelect.value : "ALL";
  const directoryGroup = normalizeDirectoryGroupFilterValue(
    directoryGroupSelect && directoryGroupSelect.value ? directoryGroupSelect.value : "ALL"
  );
  const language = normalizeLanguageValueForKrugle(languageSelect && languageSelect.value ? languageSelect.value : "ALL");
  const languageForApi = language;
  const projectText = optionText(projectSelect) || (project === "ALL" ? "すべて" : project);
  const directoryGroupText = optionText(directoryGroupSelect) || (directoryGroup === "ALL" ? "すべて" : directoryGroup);
  const languageText = getLanguageDisplayTextForSearch(languageSelect, language);

  return {
    rawKeyword,
    keyword: normalizeKeywordForMode(rawKeyword, mode),
    project,
    projectText,
    directoryGroup,
    directoryGroupText,
    language,
    languageText,
    languageForApi,
    findin: "ALL",
    clone: cloneCheck && cloneCheck.checked ? "NO" : "YES",
    source_disp: "NO"
  };
}


function buildSearchParamsFromCondition(condition, mode = "normal") {
  const source = condition || {};
  const rawKeyword = String(source.keyword || "").trim();
  const project = String(source.project || "ALL").trim() || "ALL";
  const directoryGroup = normalizeDirectoryGroupFilterValue(String(source.directoryGroup || "ALL").trim() || "ALL");
  const language = normalizeLanguageValueForKrugle(String(source.language || "ALL").trim() || "ALL");
  const languageForApi = language;
  const projectText = project === "ALL" ? "すべて" : normalizeMigrationGroupName(project) || project;
  const directoryGroupText = directoryGroup === "ALL" ? "すべて" : directoryGroup;
  const languageText = language === "ALL" ? "すべて" : language;

  return {
    rawKeyword,
    keyword: normalizeKeywordForMode(rawKeyword, mode),
    project,
    projectText,
    directoryGroup,
    directoryGroupText,
    language,
    languageText,
    languageForApi,
    findin: String(source.findin || "ALL").trim() || "ALL",
    clone: source.clone || "YES",
    source_disp: source.source_disp || "NO"
  };
}


function normalizeDirectoryGroupFilterValue(value) {
  const text = String(value == null ? "" : value).trim();
  if (!text || text.toUpperCase() === "ALL" || text === "すべて") return "ALL";
  return cleanDirectoryGroupName(text) || text;
}

function getDirectoryGroupLookupMigrationGroup(projectValue) {
  const normalized = normalizeMigrationGroupName(projectValue);
  if (!normalized) return "";
  // nikkoEZ.java17 はAI_FILE1に直接レコードがないため、既存のJavaクラス解決と同様にnikkoEZを参照する。
  return /^nikkoEZ\.java17$/i.test(normalized) ? "nikkoEZ" : normalized;
}

function getRecentDirectoryGroupsForMigrationGroup(projectValue) {
  const selectedGroup = normalizeMigrationGroupName(projectValue).toLowerCase();
  const lookupGroup = getDirectoryGroupLookupMigrationGroup(projectValue).toLowerCase();
  const result = [];
  const used = new Set();

  getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT).forEach(value => {
    const parts = formatHistoryFileParts(value);
    const historyGroup = normalizeMigrationGroupName(parts[1]).toLowerCase();
    if (historyGroup !== selectedGroup && historyGroup !== lookupGroup) return;

    const directoryGroup = normalizeDirectoryGroupFilterValue(parts[2]);
    if (directoryGroup === "ALL" || isPlaceholderHistoryValue(directoryGroup)) return;
    const key = directoryGroup.toLowerCase();
    if (used.has(key)) return;
    used.add(key);
    result.push(directoryGroup);
  });

  return result;
}

function resetDirectoryGroupSelect(message = "") {
  const select = $("directoryGroupSelect");
  if (!select) return;
  select.innerHTML = "";
  const all = document.createElement("option");
  all.value = "ALL";
  all.textContent = "すべて";
  select.appendChild(all);

  if (message) {
    const note = document.createElement("option");
    note.value = "";
    note.disabled = true;
    note.textContent = message;
    select.appendChild(note);
  }
  select.value = "ALL";
}

function renderDirectoryGroupSelectOptions(projectValue, rows, preserveValue = "ALL") {
  const select = $("directoryGroupSelect");
  if (!select) return;

  const values = [];
  const used = new Set();
  (Array.isArray(rows) ? rows : []).forEach(row => {
    const value = normalizeDirectoryGroupFilterValue(
      row && typeof row === "object" ? (row.directoryGroup || row.dirGroup || row.DIRGROUP || "") : row
    );
    if (!value || value === "ALL" || isPlaceholderHistoryValue(value)) return;
    const key = value.toLowerCase();
    if (used.has(key)) return;
    used.add(key);
    values.push(value);
  });

  const recent = getRecentDirectoryGroupsForMigrationGroup(projectValue)
    .filter(value => used.has(value.toLowerCase()));
  const recentSet = new Set(recent.map(value => value.toLowerCase()));
  const others = values
    .filter(value => !recentSet.has(value.toLowerCase()))
    .sort((a, b) => a.localeCompare(b, "ja", { numeric: true, sensitivity: "variant" }));

  select.innerHTML = "";
  const all = document.createElement("option");
  all.value = "ALL";
  all.textContent = "すべて";
  select.appendChild(all);

  const appendGroup = (label, items) => {
    if (!items.length) return;
    const group = document.createElement("optgroup");
    group.label = label;
    items.forEach(value => {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value;
      group.appendChild(option);
    });
    select.appendChild(group);
  };

  appendGroup("最近閲覧", recent);
  appendGroup("ディレクトリグループ", others);

  const desired = normalizeDirectoryGroupFilterValue(preserveValue);
  select.value = Array.from(select.options).some(option => option.value === desired) ? desired : "ALL";
}

async function loadDirectoryGroupsForSelectedMigrationGroup(options = {}) {
  const projectSelect = $("groupSelect");
  const directorySelect = $("directoryGroupSelect");
  if (!directorySelect) return;

  const selectedProject = projectSelect && projectSelect.value ? projectSelect.value : "ALL";
  const preserveValue = options.preserveValue !== false ? directorySelect.value || "ALL" : "ALL";
  if (!selectedProject || selectedProject === "ALL") {
    resetDirectoryGroupSelect();
    return;
  }

  const lookupGroup = getDirectoryGroupLookupMigrationGroup(selectedProject);
  if (!lookupGroup) {
    resetDirectoryGroupSelect();
    return;
  }

  const cacheKey = lookupGroup.toLowerCase();
  const loadId = ++directoryGroupLoadSequence;
  if (directoryGroupOptionsCache.has(cacheKey)) {
    renderDirectoryGroupSelectOptions(selectedProject, directoryGroupOptionsCache.get(cacheKey), preserveValue);
    return;
  }

  resetDirectoryGroupSelect("読込中...");
  try {
    const data = await fetchJson(DIRECTORY_GROUP_ENDPOINT, { group: lookupGroup }, {
      method: "GET",
      timeoutMs: API_ACCESS_TIMEOUT_MS
    });
    if (loadId !== directoryGroupLoadSequence) return;
    const rows = Array.isArray(data && data.rows) ? data.rows : [];
    directoryGroupOptionsCache.set(cacheKey, rows);
    renderDirectoryGroupSelectOptions(selectedProject, rows, preserveValue);
  } catch (e) {
    if (loadId !== directoryGroupLoadSequence) return;
    console.warn("ディレクトリグループ取得失敗", e);
    resetDirectoryGroupSelect("取得できませんでした");
  }
}

function filterSearchResultsByDirectoryGroup(rows, directoryGroup) {
  const target = normalizeDirectoryGroupFilterValue(directoryGroup);
  const source = Array.isArray(rows) ? rows : [];
  if (target === "ALL") {
    return source.map((row, index) => Object.assign({}, row, { no: String(index + 1) }));
  }

  const targetKey = target.toLowerCase();
  return source
    .filter(row => normalizeDirectoryGroupFilterValue(row && row.directoryGroup).toLowerCase() === targetKey)
    .map((row, index) => Object.assign({}, row, { no: String(index + 1) }));
}

function clearInitialSearchForm() {
  const keywordInput = $("keywordInput");
  const groupSelect = $("groupSelect");
  const directoryGroupSelect = $("directoryGroupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  if (keywordInput) keywordInput.value = "";
  setSelectValueByTextOrValue(groupSelect, "ALL", "ALL");
  if (directoryGroupSelect) resetDirectoryGroupSelect();
  setSelectValueByTextOrValue(languageSelect, "ALL", "ALL");
  if (cloneCheck) cloneCheck.checked = false;
  refreshGroupCombo({ resetFilter: true });
}

function normalizeSearchRow(row, index = 0) {
  const source = row || {};
  const fileName = source.fileName || source.file || source.name || "";
  const project = normalizeProjectValue(source.project || source.projectName || source.projectValue || "");
  const rawPath = source.fullPath || source.filePath || source.path || fileName;
  const path = buildCompleteKruglePath(rawPath, project, source.group || source.migrationGroup || source.ikogroup || source.ikoGroup || "");
  const projectParts = String(project).split(".");
  const sourceGroup = normalizeMigrationGroupName(source.group || source.migrationGroup || source.ikogroup || source.ikoGroup || "");
  const pathGroup = normalizeMigrationGroupName(extractMigrationGroupFromPath(path));
  const projectGroup = normalizeMigrationGroupName(project);
  const legacyProjectGroup = normalizeMigrationGroupName(projectParts.length > 1 ? projectParts.slice(1).join(".") : projectParts[0]);
  // 完全パス/Projectは移行グループ名の正本として扱い、旧Servletが java17 のように
  // 末尾だけ返した場合でも nikkoEZ.java17 へ自己修復できるようにする。
  const group = pathGroup || projectGroup || sourceGroup || legacyProjectGroup || "";
  const directoryGroup = cleanDirectoryGroupName(source.directoryGroup || source.dirGroup || source.directory || extractDirectoryGroupFromPath(path));

  return {
    no: source.no || String(index + 1),
    fileName,
    lineNo: source.lineNo || source.line || "",
    project,
    group,
    directoryGroup,
    path,
    href: source.href || "",
    sourceUrl: source.sourceUrl || "",
    preview: source.preview || "",
    language: source.language || inferLanguageFromPath(path, "java")
  };
}

function normalizeSearchResultSortKey(value) {
  return String(value || "").trim().toLowerCase();
}

function addPriorityRank(map, value) {
  const key = normalizeSearchResultSortKey(value);
  if (!key || isPlaceholderHistoryValue(key) || map.has(key)) return;
  map.set(key, map.size);
}

function buildSearchResultPriorityMapsFromHistory() {
  const groupRank = new Map();
  const directoryGroupRank = new Map();
  const values = getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT);

  values.forEach(value => {
    const parts = formatHistoryFileParts(value);
    addPriorityRank(groupRank, parts[1]);
    addPriorityRank(directoryGroupRank, parts[2]);
  });

  return { groupRank, directoryGroupRank };
}

function getPriorityRank(map, value) {
  const key = normalizeSearchResultSortKey(value);
  return map && map.has(key) ? map.get(key) : Number.MAX_SAFE_INTEGER;
}

function getSearchResultLanguageRank(row) {
  const language = String(row && (row.language || inferLanguageFromPath(row.path, "")) || "").trim().toLowerCase();
  if (language === "java") return 0;
  if (language === "sql") return 1;

  const pathLanguage = inferLanguageFromPath(row && row.path, "").toLowerCase();
  if (pathLanguage === "java") return 0;
  if (pathLanguage === "sql") return 1;
  return 2;
}

function compareSearchResultRowsByHistoryPriority(a, b, priorityMaps) {
  const groupDiff = getPriorityRank(priorityMaps.groupRank, a.group) - getPriorityRank(priorityMaps.groupRank, b.group);
  if (groupDiff !== 0) return groupDiff;

  const directoryDiff = getPriorityRank(priorityMaps.directoryGroupRank, a.directoryGroup) - getPriorityRank(priorityMaps.directoryGroupRank, b.directoryGroup);
  if (directoryDiff !== 0) return directoryDiff;

  const languageDiff = getSearchResultLanguageRank(a) - getSearchResultLanguageRank(b);
  if (languageDiff !== 0) return languageDiff;

  const nameA = String(a.fileName || a.path || "");
  const nameB = String(b.fileName || b.path || "");
  const nameDiff = nameA.localeCompare(nameB, "ja", { numeric: true, sensitivity: "variant" });
  if (nameDiff !== 0) return nameDiff;

  return String(a.path || "").localeCompare(String(b.path || ""), "ja", { numeric: true, sensitivity: "variant" });
}

function buildSearchResultSortRecord(row, index, priorityMaps) {
  const normalized = normalizeSearchRow(row, index);
  const languageRank = getSearchResultLanguageRank(normalized);
  return {
    row: normalized,
    index,
    groupRank: getPriorityRank(priorityMaps.groupRank, normalized.group),
    directoryGroupRank: getPriorityRank(priorityMaps.directoryGroupRank, normalized.directoryGroup),
    languageRank,
    fileNameKey: String(normalized.fileName || normalized.path || ""),
    pathKey: String(normalized.path || "")
  };
}

function compareSearchResultSortRecords(a, b) {
  // fix91: Servletが判定した「検索キーワード == ファイル名」の完全一致を最優先で維持する。
  const exactDiff = Number(Boolean(b.row && b.row.exactFileNameMatch)) - Number(Boolean(a.row && a.row.exactFileNameMatch));
  if (exactDiff !== 0) return exactDiff;

  const groupDiff = a.groupRank - b.groupRank;
  if (groupDiff !== 0) return groupDiff;

  const directoryDiff = a.directoryGroupRank - b.directoryGroupRank;
  if (directoryDiff !== 0) return directoryDiff;

  const languageDiff = a.languageRank - b.languageRank;
  if (languageDiff !== 0) return languageDiff;

  const nameDiff = a.fileNameKey.localeCompare(b.fileNameKey, "ja", { numeric: true, sensitivity: "variant" });
  if (nameDiff !== 0) return nameDiff;

  const pathDiff = a.pathKey.localeCompare(b.pathKey, "ja", { numeric: true, sensitivity: "variant" });
  return pathDiff !== 0 ? pathDiff : a.index - b.index;
}

function sortSearchResultsForDisplay(rows) {
  const priorityMaps = buildSearchResultPriorityMapsFromHistory();
  return (Array.isArray(rows) ? rows : [])
    .map((row, index) => buildSearchResultSortRecord(row, index, priorityMaps))
    .sort(compareSearchResultSortRecords)
    .map((item, index) => Object.assign({}, item.row, { no: String(index + 1) }));
}


function normalizeCloneDisplayValue(value, params) {
  const raw = value == null ? "" : String(value).trim();
  if (raw === "YES" || raw === "表示" || raw === "表示する") return "表示";
  if (raw === "NO" || raw === "非表示" || raw === "表示しない") return "非表示";

  // 旧WARで日本語定数が文字化けしていても、送信したclone条件から正しく表示する。
  return params && params.clone === "YES" ? "表示" : "非表示";
}

function setText(id, value) {
  const element = $(id);
  if (element) element.textContent = value == null ? "" : String(value);
}

function setSummaryFromParams(params, startedAt, endedAt, hitCount) {
  setText("summaryCount", hitCount == null ? "-" : hitCount);
  setText("summaryKeyword", params ? params.rawKeyword : "");
  setText("summaryProject", params ? (params.projectText || params.project) : "");
  setText("summaryDirectoryGroup", params ? (params.directoryGroupText || params.directoryGroup || "ALL") : "ALL");
  setText("summaryLanguage", params ? (params.languageText || params.language) : "");
  setText("summaryStart", startedAt ? formatDateTime(startedAt) : "-");
  setText("summaryEnd", endedAt ? formatDateTime(endedAt) : "-");
  setText("summaryClone", params && params.clone === "YES" ? "表示" : "非表示");
}

function setSummaryFromServer(summary, params, startedAt, endedAt, fallbackCount) {
  const source = summary || {};
  const hasDirectoryFilter = params && normalizeDirectoryGroupFilterValue(params.directoryGroup) !== "ALL";
  setText("summaryCount", hasDirectoryFilter ? fallbackCount : (source.hitCount || source.count || fallbackCount || 0));
  setText("summaryKeyword", source.keyword || (params ? params.rawKeyword : ""));
  setText("summaryProject", source.project || (params ? (params.projectText || params.project) : ""));
  setText("summaryDirectoryGroup", params ? (params.directoryGroupText || params.directoryGroup || "ALL") : "ALL");
  setText("summaryLanguage", source.language || (params ? (params.languageText || params.language) : ""));
  setText("summaryStart", formatSummaryDateTimeValue(source.startTime, startedAt));
  setText("summaryEnd", formatSummaryDateTimeValue(source.endTime, endedAt));
  setText("summaryClone", normalizeCloneDisplayValue(source.clone, params));
}

function buildInitialResultPlaceholderRows(count = INITIAL_RESULT_PLACEHOLDER_COUNT) {
  return Array.from({ length: count }, (_, index) => ({
    no: String(index + 1),
    fileName: HISTORY_PLACEHOLDER_VALUE,
    group: HISTORY_PLACEHOLDER_VALUE,
    directoryGroup: HISTORY_PLACEHOLDER_VALUE,
    path: HISTORY_PLACEHOLDER_VALUE,
    placeholder: true
  }));
}

function renderInitialResultPlaceholders() {
  renderSearchInitialEmptyState();
}

function renderSearchInitialEmptyState() {
  const body = $("resultBody");
  if (!body) return;
  const card = document.querySelector("#searchView .resultCard");
  if (card) {
    card.classList.add("isInitialEmptyResultCard");
    card.classList.remove("hasSearchResultRows");
  }
  body.innerHTML = `
    <tr class="resultEmptyStateRow">
      <td colspan="5">
        <div class="resultEmptyStateMessage">検索結果がここに表示されます</div>
      </td>
    </tr>
  `;
}

function resetInitialSearchSummary() {
  setText("summaryCount", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryKeyword", "");
  setText("summaryProject", "ALL");
  setText("summaryDirectoryGroup", "ALL");
  setText("summaryLanguage", "ALL");
  setText("summaryStart", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryEnd", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryClone", "非表示");
}

function getSearchRowFromElement(rowElement, fallbackIndex = 0) {
  const index = Number(rowElement && rowElement.dataset ? rowElement.dataset.index : fallbackIndex);
  if (Number.isFinite(index) && currentRenderedSearchRows[index]) return currentRenderedSearchRows[index];
  return normalizeSearchRow({
    no: rowElement && rowElement.dataset ? rowElement.dataset.no || String(fallbackIndex + 1) : String(fallbackIndex + 1),
    fileName: rowElement && rowElement.dataset ? rowElement.dataset.fileName || "" : "",
    project: rowElement && rowElement.dataset ? rowElement.dataset.project || "" : "",
    group: rowElement && rowElement.dataset ? rowElement.dataset.group || "" : "",
    directoryGroup: rowElement && rowElement.dataset ? rowElement.dataset.directoryGroup || "" : "",
    path: rowElement && rowElement.dataset ? rowElement.dataset.path || "" : "",
    href: rowElement && rowElement.dataset ? rowElement.dataset.href || "" : "",
    sourceUrl: rowElement && rowElement.dataset ? rowElement.dataset.sourceUrl || "" : "",
    preview: rowElement ? rowElement.getAttribute("aria-label") || (rowElement.dataset ? rowElement.dataset.path || "" : "") : "",
    language: rowElement && rowElement.dataset ? rowElement.dataset.language || "" : ""
  }, fallbackIndex);
}

function bindResultRowEvents(body, normalizedRows = []) {
  if (!body) return;
  currentRenderedSearchRows = Array.isArray(normalizedRows) ? normalizedRows : [];
  if (body.__krugleResultRowDelegatedClickBound === true) return;
  body.__krugleResultRowDelegatedClickBound = true;
  body.addEventListener("click", event => {
    const rowElement = event.target && event.target.closest ? event.target.closest("tr[data-index]") : null;
    if (!rowElement || !body.contains(rowElement)) return;
    const index = Number(rowElement.dataset.index);
    const row = getSearchRowFromElement(rowElement, Number.isFinite(index) ? index : 0);
    if (row && !row.placeholder) openCode(row.path, { row });
  });
}

function setResultCardState(rowCount) {
  const card = document.querySelector("#searchView .resultCard");
  if (card) {
    card.classList.remove("isInitialEmptyResultCard");
    card.classList.toggle("hasSearchResultRows", Number(rowCount || 0) > 0);
  }
}

function buildSearchResultRowHtml(row, index) {
  return `
    <tr class="${row.placeholder ? "isPlaceholderResultRow" : ""}"
        data-index="${index}"
        data-no="${escapeHtml(row.no || String(index + 1))}"
        data-file-name="${escapeHtml(row.fileName || "")}"
        data-project="${escapeHtml(row.project || "")}"
        data-group="${escapeHtml(row.group || "")}"
        data-directory-group="${escapeHtml(row.directoryGroup || "")}"
        data-path="${escapeHtml(row.path || "")}"
        data-language="${escapeHtml(row.language || "")}"
        aria-label="${escapeHtml(row.placeholder ? "" : (row.preview || row.path))}">
      <td>${escapeHtml(row.no || String(index + 1))}</td>
      <td>${escapeHtml(row.fileName || row.path)}</td>
      <td>${escapeHtml(row.group || row.project)}</td>
      <td>${escapeHtml(row.directoryGroup || "")}</td>
      <td>${escapeHtml(row.path || "")}</td>
    </tr>
  `;
}

function buildSearchResultRowsHtml(rows, startIndex = 0, endIndex = rows.length) {
  const parts = [];
  const safeEnd = Math.min(endIndex, rows.length);
  for (let index = startIndex; index < safeEnd; index++) {
    parts.push(buildSearchResultRowHtml(rows[index], index));
  }
  return parts.join("");
}

function scheduleSearchRowsAppend(body, rows, startIndex, renderId) {
  const schedule = typeof window.requestIdleCallback === "function"
    ? callback => window.requestIdleCallback(callback, { timeout: 120 })
    : callback => window.requestAnimationFrame(callback);

  const appendChunk = () => {
    if (renderId !== searchRenderSequence) return;
    if (!body || !body.isConnected) return;
    const endIndex = Math.min(startIndex + SEARCH_RENDER_CHUNK_ROWS, rows.length);
    body.insertAdjacentHTML("beforeend", buildSearchResultRowsHtml(rows, startIndex, endIndex));
    if (endIndex < rows.length) {
      scheduleSearchRowsAppend(body, rows, endIndex, renderId);
    }
  };

  schedule(appendChunk);
}

function renderSearchHtml(resultHtml, rows = []) {
  const body = $("resultBody");
  if (!body) return;

  const normalizedRows = Array.isArray(rows) ? rows.map(normalizeSearchRow) : [];
  setResultCardState(normalizedRows.length);
  searchRenderSequence += 1;
  currentRenderedSearchRows = normalizedRows;
  body.innerHTML = resultHtml || `
    <tr class="resultNoDataRow">
      <td colspan="5">検索結果がありません</td>
    </tr>
  `;
  bindResultRowEvents(body, normalizedRows);
}

function renderSearchRows(rows, options = {}) {
  const body = $("resultBody");
  if (!body) return { rowCount: 0, initialRows: 0, chunked: false };

  const isPlaceholderMode = options && options.placeholder === true;
  const alreadyNormalized = options && options.normalized === true;
  const normalizedRows = Array.isArray(rows)
    ? (isPlaceholderMode || alreadyNormalized ? rows : rows.map(normalizeSearchRow))
    : [];
  const rowCount = normalizedRows.length;
  const renderId = ++searchRenderSequence;
  currentRenderedSearchRows = normalizedRows;
  setResultCardState(rowCount);
  bindResultRowEvents(body, normalizedRows);

  if (!rowCount) {
    body.innerHTML = `
      <tr class="resultNoDataRow">
        <td colspan="5">検索結果がありません</td>
      </tr>
    `;
    return { rowCount: 0, initialRows: 0, chunked: false };
  }

  const initialRows = rowCount > SEARCH_RENDER_INITIAL_ROWS ? SEARCH_RENDER_INITIAL_ROWS : rowCount;
  body.innerHTML = buildSearchResultRowsHtml(normalizedRows, 0, initialRows);

  if (initialRows < rowCount) {
    scheduleSearchRowsAppend(body, normalizedRows, initialRows, renderId);
  }

  return { rowCount, initialRows, chunked: initialRows < rowCount };
}



// 2026-08-07 修正19:
// 検索結果タブのCopyでは、summaryGrid（ヒット数/検索条件の2行）を出力しない。
// 画面の検索結果テーブルと同じ5列だけをTSV化する。
const SEARCH_RESULT_EXPORT_HEADERS = Object.freeze(["No", "ファイル名", "移行グループ", "ディレクトリグループ", "パス"]);

function getSearchResultExportRows() {
  const sourceRows = Array.isArray(lastSearchResults) && lastSearchResults.length
    ? lastSearchResults
    : Array.from(document.querySelectorAll("#resultBody tr[data-index]"))
        .map((rowElement, index) => normalizeSearchRow({
          no: rowElement.dataset.no || String(index + 1),
          fileName: rowElement.dataset.fileName || "",
          project: rowElement.dataset.project || "",
          group: rowElement.dataset.group || "",
          directoryGroup: rowElement.dataset.directoryGroup || "",
          path: rowElement.dataset.path || "",
          language: rowElement.dataset.language || ""
        }, index));

  return sourceRows
    .map((row, index) => normalizeSearchRow(row, index))
    .filter(row => row && !row.placeholder && !isPlaceholderHistoryValue(row.path || row.fileName || ""));
}

function buildSearchResultExportValues(row, index) {
  const normalized = normalizeSearchRow(row, index);
  return [
    normalized.no || String(index + 1),
    normalized.fileName || normalized.path || "",
    normalized.group || normalized.project || "",
    normalized.directoryGroup || "",
    normalized.path || ""
  ];
}

function buildSearchResultCopyText(rows) {
  const body = (Array.isArray(rows) ? rows : []).map((row, index) =>
    buildSearchResultExportValues(row, index).join("\t")
  );
  return [SEARCH_RESULT_EXPORT_HEADERS.join("\t")].concat(body).join("\n");
}


// 2026-08-07 修正20:
// ホームタブのCopy/Downloadでは、DOMのinnerTextをそのまま使わない。
// historySearchText内のspanが改行としてコピーされる環境があるため、
// 表示元データからTSVを組み立て、セル内CR/LF/TABを除去して1行1履歴に固定する。
const HOME_FILE_HISTORY_EXPORT_HEADERS = Object.freeze(["No", "過去の閲覧履歴 ／ ファイル名", "移行グループ", "ディレクトリグループ"]);
const HOME_SEARCH_HISTORY_EXPORT_HEADERS = Object.freeze(["No", "過去の閲覧履歴 ／ 検索キーワード", "対象プロジェクト", "言語"]);

function normalizeExportCell(value) {
  const text = String(value ?? "")
    .replace(/[\r\n]+/g, " ")
    .replace(/\t+/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim();
  return text || HISTORY_PLACEHOLDER_VALUE;
}

function buildTsvLine(values) {
  return (Array.isArray(values) ? values : [])
    .map(normalizeExportCell)
    .join("\t");
}

function getHomeFileHistoryExportRows() {
  return getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT);
}

function getHomeSearchHistoryExportRows() {
  let words = USE_SAMPLE_DATA ? sampleSearchWords : readArray(SEARCH_HISTORY_STORAGE_KEY, []);
  if (!USE_SAMPLE_DATA) {
    words = seedHistoryStorage(SEARCH_HISTORY_STORAGE_KEY, words, sampleSearchWords, INITIAL_HISTORY_SAMPLE_COUNT);
  }
  return getDisplayHistoryRows(words, INITIAL_HISTORY_SAMPLE_COUNT);
}

function buildHomeFileHistoryExportValues(value, index) {
  const parts = formatHistoryFileParts(value);
  return [String(index + 1), parts[0], parts[1], parts[2]];
}

function buildHomeSearchHistoryExportValues(value, index) {
  if (isPlaceholderHistoryValue(value)) {
    return [String(index + 1), HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE];
  }
  const parsed = parseSearchHistoryValue(value);
  return [
    String(index + 1),
    parsed.keyword || HISTORY_PLACEHOLDER_VALUE,
    parsed.group || HISTORY_PLACEHOLDER_VALUE,
    parsed.language || HISTORY_PLACEHOLDER_VALUE
  ];
}

function buildHomeHistoryExportText() {
  const fileLines = [buildTsvLine(HOME_FILE_HISTORY_EXPORT_HEADERS)].concat(
    getHomeFileHistoryExportRows().map((value, index) => buildTsvLine(buildHomeFileHistoryExportValues(value, index)))
  );
  const searchLines = [buildTsvLine(HOME_SEARCH_HISTORY_EXPORT_HEADERS)].concat(
    getHomeSearchHistoryExportRows().map((value, index) => buildTsvLine(buildHomeSearchHistoryExportValues(value, index)))
  );
  return fileLines.concat([""], searchLines).join("\n");
}


// 2026-08-07 fix28:
// highlight.js は .properties / .env / .lst などの社内テキストで言語判定がぶれると、
// Cupertino の白背景が当たらず黒背景のまま見える場合がある。
// これらはユーザー要望どおり .sh 相当、つまり highlight.js の bash として表示する。
const SHELL_LIKE_TEXT_EXTENSIONS = new Set([
  "properties", "property", "props", "prop",
  "env", "lst", "list", "txt",
  "conf", "cfg", "cnf", "ini",
  "profile"
]);

function cleanPathForLanguage(path) {
  return String(path || "")
    .split(/[?#]/)[0]
    .replace(/\\/g, "/")
    .toLowerCase();
}

function getPathExtensionForLanguage(path) {
  const value = cleanPathForLanguage(path);
  const fileName = value.substring(value.lastIndexOf("/") + 1);
  const dotIndex = fileName.lastIndexOf(".");
  if (dotIndex < 0) return "";
  return fileName.substring(dotIndex + 1);
}

function isShellLikeTextPath(path) {
  const value = cleanPathForLanguage(path);
  const fileName = value.substring(value.lastIndexOf("/") + 1);
  const extension = getPathExtensionForLanguage(value);
  return SHELL_LIKE_TEXT_EXTENSIONS.has(extension) || fileName === ".env" || fileName.startsWith(".env.");
}

// 2026-08-13 fix69:
// JSP/HTML系ソースは、ソース本文そのものに <html> / <script> / <li> などを含む。
// highlight.js やKrugle HTML wrapper抽出の誤判定でDOMとして解釈されないよう、
// 該当拡張子は安全なプレーンテキスト描画へ寄せる。
const RAW_MARKUP_SOURCE_EXTENSIONS = new Set([
  "jsp", "jspx", "html", "htm", "xhtml", "tag", "tagx",
  // 2026-08-13 fix71: HTML以外でも、pre/codeへ流し込むとDOM解釈リスクがある
  // XML/SVG系マークアップはhighlight.jsに渡さず、必ずtextContentのプレーン表示に寄せる。
  "xml", "xsd", "xsl", "xslt", "svg"
]);

function isRawMarkupSourcePath(path) {
  return RAW_MARKUP_SOURCE_EXTENSIONS.has(getPathExtensionForLanguage(path));
}

function containsExecutableMarkupRiskForPreCode(sourceText) {
  const source = String(sourceText || "");
  if (!source) return false;

  // 2026-08-13 fix71:
  // codeBlock へは必ず textContent で入れているが、highlight.jsや後続加工へ渡す前に、
  // HTML/JSP以外のソース内に含まれる実行系マークアップも安全側で検知する。
  // 例: JavaScript/SQL/XML/Java文字列内の <script> / onerror= / javascript: / SVG など。
  return /<\s*\/?\s*(?:script|iframe|object|embed|svg|math|link|meta|style|img|body|html|head|form|input|button|textarea|select|option)\b/i.test(source)
    || /\son[a-z][a-z0-9_-]*\s*=/i.test(source)
    || /(?:href|src|xlink:href|formaction|action)\s*=\s*["']?\s*javascript\s*:/i.test(source)
    || /<%[@!=]?|<jsp:/i.test(source);
}

function isSafeMarkupHighlightSource(displayLanguage, path) {
  const language = normalizeHighlightLanguage(displayLanguage || "");
  if (isRawMarkupSourcePath(path)) return true;
  return language === "jsp" || language === "html" || language === "xhtml" || language === "xml" || language === "svg";
}

function shouldRenderSourceAsSafePlainText(displayLanguage, path, sourceText) {
  // fix89: JSP/HTML/XMLなど、ファイル種別が明確なマークアップは別の安全ハイライト経路で処理する。
  // 不明な言語の本文に実行系マークアップが混ざった場合だけ、従来どおりプレーン表示へ退避する。
  if (isSafeMarkupHighlightSource(displayLanguage, path)) return false;

  const source = String(sourceText || "");
  if (containsExecutableMarkupRiskForPreCode(source)) return true;

  // パス/言語が不明なままJSP/HTMLらしい本文だけ来た場合は安全側でプレーン描画する。
  return /^\s*(?:<%@|<jsp:|<!DOCTYPE\s+html\b|<html\b)/i.test(source);
}

function renderSourceAsSafePlainText(codeBlock, sourceText) {
  if (!codeBlock) return;
  codeBlock.removeAttribute("data-safe-markup-highlight");
  codeBlock.className = "language-plaintext hljs codeBlockPlainSource";
  codeBlock.setAttribute("data-safe-plain-source", "true");
  codeBlock.textContent = sourceText || "";
  enforceSafeCodeBlockDom(codeBlock);
}

function enforceSafeCodeBlockDom(codeBlock) {
  if (!codeBlock || typeof codeBlock.querySelectorAll !== "function") return;

  // codeBlock配下は、highlight.jsのspanと自前ハイライトbutton以外を許可しない。
  // 万一、外部ライブラリや後続加工が予期しないタグ/属性を生成しても、文字列へ戻す。
  const allowedTags = new Set(["SPAN", "BUTTON"]);
  Array.from(codeBlock.querySelectorAll("*")).forEach(element => {
    if (!allowedTags.has(element.tagName)) {
      element.replaceWith(document.createTextNode(element.textContent || ""));
    }
  });

  Array.from(codeBlock.querySelectorAll("*")).forEach(element => {
    Array.from(element.attributes || []).forEach(attribute => {
      const name = String(attribute.name || "").toLowerCase();
      if (name.startsWith("on") || /^(href|src|srcdoc|xlink:href|formaction|action)$/i.test(name)) {
        element.removeAttribute(attribute.name);
        return;
      }
      if (name === "style" && !(element.classList && element.classList.contains("codeKeywordLink"))) {
        element.removeAttribute(attribute.name);
      }
    });
  });
}


function inferLanguageFromPath(path, fallback = "plaintext") {
  const value = cleanPathForLanguage(path);
  if (value.endsWith(".java")) return "java";
  if (value.endsWith(".sql")) return "sql";
  if (value.endsWith(".xml")) return "xml";
  if (value.endsWith(".jsp")) return "xml";
  if (value.endsWith(".html") || value.endsWith(".htm")) return "xml";
  if (value.endsWith(".js")) return "javascript";
  if (value.endsWith(".css")) return "css";
  if (value.endsWith(".sh") || value.endsWith(".csh") || value.endsWith(".ksh") || value.endsWith(".bash")) return "bash";
  if (isShellLikeTextPath(value)) return "bash";
  return fallback;
}

function resolveHighlightDisplayLanguage(language, path) {
  if (isShellLikeTextPath(path)) return "bash";

  let value = normalizeHighlightLanguage(language || inferLanguageFromPath(path, "plaintext"));
  if (!value) value = inferLanguageFromPath(path, "plaintext");
  if (value === "shell") value = "bash";

  // highlight.js に未登録の拡張子を渡すと、hljs クラスが付かず黒背景のまま残ることがある。
  // 未登録言語は bash、bash もなければ plaintext に落とす。
  if (window.hljs && typeof window.hljs.getLanguage === "function" && !window.hljs.getLanguage(value)) {
    return window.hljs.getLanguage("bash") ? "bash" : "plaintext";
  }
  return value || "plaintext";
}

const GROUP_SELECT_SECTIONS = [
  {
    key: "NIKKO",
    label: "NIKKO",
    match: value => /^(newnikko|nikko|nk)/i.test(value)
  },
  {
    key: "BPS",
    label: "BPS",
    match: value => /^(bpnet|bps)/i.test(value)
  },
  {
    key: "SY",
    label: "→ SYはじまり",
    match: value => /^sy/i.test(value)
  },
  {
    key: "RPS",
    label: "RPS",
    match: value => /^rps/i.test(value)
  },
  {
    key: "OTHER",
    label: "その他",
    match: () => true
  }
];

function normalizeGroupProjectOption(project) {
  const source = project || {};
  const value = typeof project === "string" ? project : (source.value || source.text || "");
  const text = typeof project === "string" ? project : (source.text || source.value || "");
  const normalized = {
    value: String(value == null ? "" : value).trim(),
    text: String(text == null ? "" : text).trim(),
    selected: Boolean(source && source.selected)
  };
  if (!normalized.value && !normalized.text) return null;
  if (!normalized.text) normalized.text = normalized.value;
  if (!normalized.value) normalized.value = normalized.text;
  return normalized;
}

function isAllProjectOption(option) {
  const value = String(option && option.value || "").trim().toLowerCase();
  const text = String(option && option.text || "").trim().toLowerCase();
  return value === "all" || text === "all" || text === "すべて";
}

function groupProjectClassifierValue(option) {
  return `${option.value || ""} ${option.text || ""}`.replace(/\s+/g, "").trim();
}

function groupProjectDisplayText(option) {
  const rawText = String((option && (option.text || option.value)) || "").trim();
  if (!rawText) return "";

  // Select の value は API から来た値をそのまま保持する。
  // 画面に出す文字だけ、NIKKO. / BPS. / RPS. / SY. などのカテゴリ接頭詞を外す。
  const stripped = rawText.replace(/^(?:NewNikko|NIKKO|BPS|RPS|SY)[._-](?=.)/i, "");
  return stripped || rawText;
}

function findGroupProjectSection(option) {
  const value = groupProjectClassifierValue(option);
  return GROUP_SELECT_SECTIONS.find(section => section.match(value)) || GROUP_SELECT_SECTIONS[GROUP_SELECT_SECTIONS.length - 1];
}

const RECENT_GROUP_SELECT_SECTION_LABEL = "最近閲覧した移行グループ";

function normalizeGroupSelectCompareValue(value) {
  return String(value == null ? "" : value).trim().toLowerCase();
}

function getHistoryMigrationGroupPriority() {
  const result = [];
  const seen = new Set();
  const values = readFileHistoryValues();

  values.forEach(value => {
    const entry = splitHistoryStorageValue(value);
    const rawPath = String(entry.path || "").trim().replace(/\\/g, "/");
    if (!rawPath || isPlaceholderHistoryValue(rawPath)) return;

    const firstSegment = rawPath.replace(/^\/+/, "").split("/")[0] || "";
    const project = normalizeProjectValue(
      entry.project || (isKnownMigrationGroupSegment(firstSegment) ? firstSegment : "")
    );
    const group = normalizeMigrationGroupName(
      entry.group || extractMigrationGroupFromPath(rawPath) || project
    );

    const exactProjectKey = normalizeGroupSelectCompareValue(project);
    const groupKey = normalizeGroupSelectCompareValue(group);
    const uniqueKey = exactProjectKey || groupKey;
    if (!uniqueKey || seen.has(uniqueKey)) return;

    seen.add(uniqueKey);
    result.push({ exactProjectKey, groupKey });
  });

  return result;
}

function getGroupSelectOptionMatchScore(option, historyItem) {
  if (!option || !historyItem) return 0;

  const valueKey = normalizeGroupSelectCompareValue(option.value);
  const projectKey = normalizeGroupSelectCompareValue(normalizeProjectValue(option.value));
  if (historyItem.exactProjectKey &&
      (valueKey === historyItem.exactProjectKey || projectKey === historyItem.exactProjectKey)) {
    return 2;
  }

  if (!historyItem.groupKey) return 0;
  const candidateGroupKeys = [
    normalizeMigrationGroupName(option.value),
    normalizeMigrationGroupName(option.text),
    groupProjectDisplayText(option)
  ].map(normalizeGroupSelectCompareValue).filter(Boolean);

  return candidateGroupKeys.includes(historyItem.groupKey) ? 1 : 0;
}

function isRecentGroupSelectCopiedOption(option) {
  if (!option || !option.parentElement) return false;
  const parent = option.parentElement;
  if (String(parent.tagName || "").toUpperCase() !== "OPTGROUP") return false;
  const label = String(parent.label || parent.getAttribute("label") || "").trim();
  return label === RECENT_GROUP_SELECT_SECTION_LABEL;
}

function collectGroupSelectOptions(select, options = {}) {
  const records = [];
  const seen = new Set();
  const skipRecentCopiedOptions = options.skipRecentCopiedOptions !== false;

  Array.from(select && select.options ? select.options : []).forEach(option => {
    if (!option || option.disabled || isAllProjectOption(option)) return;
    // 上段へコピーした「最近閲覧した移行グループ」は、履歴用の別枠として扱う。
    // 元の optgroup 側の候補順まで履歴順に引きずられないよう、
    // original 一覧を組み直す材料からは除外する。
    if (skipRecentCopiedOptions && isRecentGroupSelectCopiedOption(option)) return;
    const key = normalizeGroupSelectCompareValue(option.value || option.textContent);
    if (!key || seen.has(key)) return;
    seen.add(key);
    records.push({
      value: option.value,
      text: String(option.textContent || option.value || "").trim(),
      className: option.className || "",
      title: option.title || ""
    });
  });

  return records;
}

function appendGroupSelectOption(parent, record) {
  const option = document.createElement("option");
  option.value = record.value;
  option.textContent = record.text;
  if (record.className) option.className = record.className;
  if (record.title) option.title = record.title;
  parent.appendChild(option);
}

function prioritizeGroupSelectOptionsByHistory() {
  const select = $("groupSelect");
  if (!select) return;

  const selectedValue = select.value || "ALL";
  const records = collectGroupSelectOptions(select);
  if (!records.length) return;

  // 最近閲覧した移行グループは上段へ「移動」せず、上段へコピーする。
  // 同じ履歴が複数回あっても、上段のコピーは1件だけにする。
  const copiedIndexes = new Set();
  const recentRecords = [];
  getHistoryMigrationGroupPriority().forEach(historyItem => {
    let matchedIndex = -1;
    let matchedScore = 0;

    records.forEach((record, index) => {
      if (copiedIndexes.has(index)) return;
      const score = getGroupSelectOptionMatchScore(record, historyItem);
      if (score > matchedScore) {
        matchedIndex = index;
        matchedScore = score;
      }
    });

    if (matchedIndex >= 0) {
      copiedIndexes.add(matchedIndex);
      recentRecords.push(records[matchedIndex]);
    }
  });

  // 元の分類欄には全候補を残す。上段へコピーした候補も除外しない。
  const originalBuckets = GROUP_SELECT_SECTIONS.reduce((acc, section) => {
    acc[section.key] = [];
    return acc;
  }, {});

  records.forEach(record => {
    const section = findGroupProjectSection(record);
    originalBuckets[section.key].push(record);
  });

  const fragment = document.createDocumentFragment();
  const allOption = document.createElement("option");
  allOption.value = "ALL";
  allOption.className = "groupSelectAll";
  allOption.textContent = "すべて";
  fragment.appendChild(allOption);

  if (recentRecords.length) {
    const recentGroup = document.createElement("optgroup");
    recentGroup.label = RECENT_GROUP_SELECT_SECTION_LABEL;
    recentRecords.forEach(record => appendGroupSelectOption(recentGroup, record));
    fragment.appendChild(recentGroup);
  }

  GROUP_SELECT_SECTIONS.forEach(section => {
    const items = originalBuckets[section.key] || [];
    if (!items.length) return;
    const group = document.createElement("optgroup");
    group.label = section.label;
    items.forEach(record => appendGroupSelectOption(group, record));
    fragment.appendChild(group);
  });

  select.innerHTML = "";
  select.appendChild(fragment);
  setGroupSelectValue(select, selectedValue);
  refreshGroupCombo({ resetFilter: true });
}

function buildGroupedProjectOptionsHtml(projects) {
  const normalized = (Array.isArray(projects) ? projects : [])
    .map(normalizeGroupProjectOption)
    .filter(Boolean);

  const seen = new Set(["all"]);
  const buckets = GROUP_SELECT_SECTIONS.reduce((acc, section) => {
    acc[section.key] = [];
    return acc;
  }, {});

  normalized.forEach(option => {
    if (isAllProjectOption(option)) return;
    const seenKey = String(option.value || option.text || "").trim().toLowerCase();
    if (!seenKey || seen.has(seenKey)) return;
    seen.add(seenKey);
    const section = findGroupProjectSection(option);
    buckets[section.key].push(option);
  });

  const html = [`<option value="ALL" class="groupSelectAll">すべて</option>`];
  GROUP_SELECT_SECTIONS.forEach(section => {
    const items = buckets[section.key] || [];
    if (!items.length) return;
    html.push(`<optgroup label="${escapeHtml(section.label)}">`);
    items.forEach(item => {
      const displayText = groupProjectDisplayText(item);
      const selected = item.selected ? " selected" : "";
      html.push(`<option value="${escapeHtml(item.value)}"${selected}>${escapeHtml(displayText)}</option>`);
    });
    html.push(`</optgroup>`);
  });
  return html.join("");
}

function setGroupSelectValue(select, currentValue) {
  if (!select) return;
  const target = currentValue || "ALL";
  const hasTarget = Array.from(select.options).some(option => !option.disabled && option.value === target);
  select.value = hasTarget ? target : "ALL";
}


function groupComboOptionMatches(option, query) {
  if (!query) return true;
  const text = String(option && option.textContent || "").toLowerCase();
  const value = String(option && option.value || "").toLowerCase();
  return text.includes(query) || value.includes(query);
}

function getGroupComboElements() {
  return {
    select: $("groupSelect"),
    combo: $("groupCombo"),
    button: $("groupComboButton"),
    search: $("groupComboSearch"),
    list: $("groupComboList")
  };
}

function ensureGroupComboDom() {
  const select = $("groupSelect");
  if (!select) return null;

  const field = select.closest ? select.closest(".field") : null;
  if (field) field.classList.add("fieldGroup");

  let combo = $("groupCombo");
  if (!combo) {
    combo = document.createElement("div");
    combo.id = "groupCombo";
    combo.className = "groupCombo";
    combo.innerHTML = `
      <div id="groupComboButton" class="groupComboButton" role="combobox" aria-haspopup="listbox" aria-expanded="false" aria-controls="groupComboMenu">
        <input id="groupComboSearch" class="groupComboSearch" type="text" autocomplete="off" spellcheck="false" aria-label="移行グループ検索" value="すべて">
        <span class="groupComboArrow" aria-hidden="true"></span>
      </div>
      <div id="groupComboMenu" class="groupComboMenu" role="listbox" aria-label="移行グループ選択">
        <div id="groupComboList" class="groupComboList"></div>
      </div>
    `;
    select.insertAdjacentElement("afterend", combo);
  }

  select.classList.add("nativeGroupSelect");
  if (field) field.classList.add("isComboReady");

  const elements = getGroupComboElements();
  if (!combo.dataset.bound) {
    combo.dataset.bound = "1";
    combo.dataset.searching = "0";

    const openFromDisplay = () => {
      openGroupCombo();
    };

    elements.button.addEventListener("click", event => {
      event.preventDefault();
      openFromDisplay();
    });

    elements.search.addEventListener("focus", () => {
      openFromDisplay();
      // 現在選択中の表示文字は初期表示として残す。
      // そのまま入力すると置き換えられるように全選択する。
      setTimeout(() => elements.search.select(), 0);
    });

    elements.search.addEventListener("input", () => {
      combo.dataset.searching = "1";
      openGroupCombo({ skipSelect: true });
      refreshGroupCombo({ keepOpen: true });
    });

    elements.search.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        event.preventDefault();
        closeGroupCombo();
        elements.search.focus({ preventScroll: true });
        return;
      }
      if (event.key === "Enter") {
        const firstItem = elements.list.querySelector(".groupComboItem");
        if (firstItem) {
          event.preventDefault();
          selectGroupComboValue(firstItem.dataset.value);
        }
        return;
      }
      if (event.key === "ArrowDown") {
        const firstItem = elements.list.querySelector(".groupComboItem");
        if (firstItem) {
          event.preventDefault();
          firstItem.focus({ preventScroll: true });
        }
      }
    });

    elements.list.addEventListener("click", event => {
      const item = event.target.closest ? event.target.closest(".groupComboItem") : null;
      if (!item) return;
      event.preventDefault();
      selectGroupComboValue(item.dataset.value);
    });

    elements.list.addEventListener("keydown", event => {
      const current = event.target.closest ? event.target.closest(".groupComboItem") : null;
      if (!current) return;
      const items = Array.from(elements.list.querySelectorAll(".groupComboItem"));
      const index = items.indexOf(current);
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectGroupComboValue(current.dataset.value);
        return;
      }
      if (event.key === "Escape") {
        event.preventDefault();
        closeGroupCombo();
        elements.search.focus({ preventScroll: true });
        return;
      }
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        const nextIndex = event.key === "ArrowDown" ? Math.min(items.length - 1, index + 1) : Math.max(0, index - 1);
        if (items[nextIndex]) items[nextIndex].focus({ preventScroll: true });
      }
    });

    elements.list.addEventListener("wheel", event => {
      // ドロップダウン内では、ページ側ではなくリスト側を優先して縦スクロールさせる。
      const list = elements.list;
      const maxScrollTop = list.scrollHeight - list.clientHeight;
      const goingUp = event.deltaY < 0;
      const goingDown = event.deltaY > 0;
      const canScrollUp = list.scrollTop > 0;
      const canScrollDown = list.scrollTop < maxScrollTop - 1;
      if ((goingUp && canScrollUp) || (goingDown && canScrollDown)) {
        event.stopPropagation();
      }
    }, { passive: true });

    document.addEventListener("click", event => {
      if (!combo.contains(event.target)) closeGroupCombo();
    });
  }

  refreshGroupCombo({ resetFilter: true, keepOpen: combo.classList.contains("isOpen") });
  return elements;
}

function openGroupCombo(options = {}) {
  const elements = getGroupComboElements();
  if (!elements.combo || !elements.button || !elements.search) return;
  elements.combo.classList.add("isOpen");
  elements.button.setAttribute("aria-expanded", "true");
  refreshGroupCombo({ keepOpen: true });
  if (!options.skipSelect) {
    setTimeout(() => {
      elements.search.focus({ preventScroll: true });
      if (elements.combo.dataset.searching !== "1") elements.search.select();
    }, 0);
  }
}

function closeGroupCombo() {
  const elements = getGroupComboElements();
  if (!elements.combo || !elements.button || !elements.search) return;
  elements.combo.classList.remove("isOpen");
  elements.button.setAttribute("aria-expanded", "false");
  elements.combo.dataset.searching = "0";
  elements.search.value = getSelectedGroupComboLabel(elements.select);
}

function selectGroupComboValue(value) {
  const elements = getGroupComboElements();
  if (!elements.select) return;
  const target = String(value || "ALL");
  const option = Array.from(elements.select.options).find(item => !item.disabled && item.value === target);
  elements.select.value = option ? option.value : "ALL";
  elements.select.dispatchEvent(new Event("change", { bubbles: true }));
  if (elements.combo) elements.combo.dataset.searching = "0";
  if (elements.search) elements.search.value = getSelectedGroupComboLabel(elements.select);
  refreshGroupCombo({ resetFilter: true });
  closeGroupCombo();
  if (elements.search) elements.search.focus({ preventScroll: true });
}

function getSelectedGroupComboLabel(select) {
  if (!select) return "すべて";
  const selected = select.options[select.selectedIndex];
  if (!selected || selected.disabled) return "すべて";
  return String(selected.textContent || selected.value || "すべて").trim() || "すべて";
}

function appendGroupComboItem(fragment, option, className = "") {
  const item = document.createElement("button");
  item.type = "button";
  item.className = `groupComboItem ${className}`.trim();
  item.setAttribute("role", "option");
  item.dataset.value = option.value || "ALL";
  item.textContent = String(option.textContent || option.value || "").trim();
  item.title = option.value || item.textContent;
  item.tabIndex = -1;
  fragment.appendChild(item);
  return item;
}

function refreshGroupCombo(options = {}) {
  const elements = getGroupComboElements();
  const { select, combo, search, list } = elements;
  if (!select || !combo || !search || !list) return;

  if (options.resetFilter) {
    combo.dataset.searching = "0";
    search.value = getSelectedGroupComboLabel(select);
  }

  const query = combo.dataset.searching === "1" ? String(search.value || "").trim().toLowerCase() : "";

  const fragment = document.createDocumentFragment();
  const allOptions = [];
  const sections = [];
  let currentSection = null;

  Array.from(select.options).forEach(option => {
    if (option.disabled && option.classList.contains("groupSelectHeader")) {
      currentSection = { label: String(option.textContent || "").trim(), items: [] };
      sections.push(currentSection);
      return;
    }

    if (option.value === "ALL" || option.classList.contains("groupSelectAll")) {
      allOptions.push(option);
      return;
    }

    if (!currentSection) {
      currentSection = { label: "その他", items: [] };
      sections.push(currentSection);
    }
    currentSection.items.push(option);
  });

  allOptions.forEach(option => {
    if (!query || groupComboOptionMatches(option, query)) {
      const item = appendGroupComboItem(fragment, option, "groupComboAll");
      item.setAttribute("aria-selected", select.value === option.value ? "true" : "false");
      item.classList.toggle("isSelected", select.value === option.value);
    }
  });

  let visibleDataCount = 0;
  sections.forEach(section => {
    const matchedItems = section.items.filter(option => groupComboOptionMatches(option, query));
    if (!matchedItems.length) return;

    const header = document.createElement("div");
    header.className = "groupComboHeader";
    header.textContent = section.label;
    fragment.appendChild(header);

    matchedItems.forEach(option => {
      const item = appendGroupComboItem(fragment, option, "groupComboData");
      const selected = select.value === option.value;
      item.setAttribute("aria-selected", selected ? "true" : "false");
      item.classList.toggle("isSelected", selected);
      visibleDataCount += 1;
    });
  });

  if (!fragment.childNodes.length || (query && visibleDataCount === 0 && !allOptions.some(option => groupComboOptionMatches(option, query)))) {
    const empty = document.createElement("div");
    empty.className = "groupComboEmpty";
    empty.textContent = "該当なし";
    fragment.appendChild(empty);
  }

  const previousScrollTop = list.scrollTop;
  list.innerHTML = "";
  list.appendChild(fragment);
  if (options.keepOpen) list.scrollTop = Math.min(previousScrollTop, Math.max(0, list.scrollHeight - list.clientHeight));
}

async function loadInitialData() {
  if (USE_SAMPLE_DATA) {
    prioritizeGroupSelectOptionsByHistory();
    return;
  }

  try {
    const resolved = await resolveApiBaseOnce();
    let data = resolved.initData;
    if (!data) {
      try {
        data = await fetchJsonAtBase(resolved.base, "/init", {}, {
          method: "GET",
          timeoutMs: API_ACCESS_TIMEOUT_MS
        });
        validateInitResponse(data, resolved.base);
      } catch (e) {
        clearApiBaseSelection();
        const retried = await resolveApiBaseOnce({ forceCheck: true });
        data = retried.initData;
      }
    }

    const projects = Array.isArray(data && data.projects) ? data.projects : [];
    const select = $("groupSelect");
    if (!select) return;
    if (!projects.length) {
      prioritizeGroupSelectOptionsByHistory();
      return;
    }

    const current = select.value || "ALL";
    select.innerHTML = buildGroupedProjectOptionsHtml(projects);
    setGroupSelectValue(select, current);
    prioritizeGroupSelectOptionsByHistory();
  } catch (e) {
    // HTMLに埋め込んだ初期選択肢を残し、画面全体は利用可能な状態にする。
    console.warn("/init 接続失敗。HTML初期値を使用します。", e);
    prioritizeGroupSelectOptionsByHistory();
    showCopyFeedback("Servlet未接続（初期値で表示）");
  }
}

function readArray(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) && value.length > 0 ? value : fallback;
  } catch (e) {
    return fallback;
  }
}

function saveArray(key, value) {
  localStorage.setItem(key, JSON.stringify(value.slice(0, key === FILE_HISTORY_STORAGE_KEY ? 300 : 100))); }

function isAutoFilledRecentTab(item) {
  return Boolean(item && (item.autoFilled === true || item.__autoFilled === true));
}

function createAutoFilledRecentTab(path, openedAt) {
  return {
    path: getHistoryEntryPath(path || currentCodePath || sampleFiles[0]),
    openedAt: toSafeDate(openedAt).toISOString(),
    autoFilled: true
  };
}

function ensureMinimumRecentTabs(tabs) {
  const base = (Array.isArray(tabs) ? tabs : [])
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (base.length === 0) {
    base.push(createAutoFilledRecentTab(currentCodePath || sampleFiles[0], new Date()));
  }

  // 実履歴が35件未満の場合は、画面右端にある最後の時刻から1分ずつ戻して35件まで補完する。
  // 補完行は localStorage へ保存しない。実際に閲覧された履歴と混ざらないよう autoFilled を付ける。
  let cursor = toSafeDate(base[base.length - 1].openedAt);
  const fillerPath = base[base.length - 1].path || currentCodePath || sampleFiles[0];
  while (base.length < RECENT_TAB_MIN_COUNT) {
    cursor = new Date(cursor.getTime() - 60 * 1000);
    base.push(createAutoFilledRecentTab(fillerPath, cursor));
  }

  return base.slice(0, RECENT_TAB_STORE_LIMIT);
}

function readRecentTabs() {
  // ①ホーム履歴、②上段ファイル名タブ、③ソース右側履歴は同じ元データから作る。
  // ファイル名タブは fileStorage に入っているファイル履歴分をそのまま使う。
  // ただし件数が多すぎる場合は、並び順上位100件までに制限する。
  const historyValues = readFileHistoryValues();
  const tabs = normalizeFileHistoryValues(historyValues)
    .map((value, index) => buildRecentTabFromHistoryValue(value, new Date(Date.now() - index * 60 * 1000)))
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  return tabs.map((item, index) => normalizeRecentTab(item, index));
}

function saveRecentTabs(value) {
  // 互換用。時間タブ専用のlocalStorageは使わず、krugle.history.filesを正とする。
}

function recentTabKey(item) {
  if (!item) return "";
  return `${item.openedAt || ""}::${item.path || ""}`;
}

function createRecentTabInstanceId(item, index) {
  const safeIndex = Math.max(0, Number.isFinite(Number(index)) ? Number(index) : 0);
  const path = String(item && item.path || "");
  const openedAt = String(item && item.openedAt || "");
  // PathやopenedAtが同じでも、ヘッダー上の表示位置が違えば別タブとして扱う。
  return `recent-instance:${safeIndex}:${openedAt}:${path}`;
}

function findRecentTabInstanceIndex(tabs, tabId) {
  const id = String(tabId || "");
  if (!id) return -1;
  return (Array.isArray(tabs) ? tabs : []).findIndex((item, index) => createRecentTabInstanceId(item, index) === id);
}

function findRecentTabInstanceIdForItem(targetItem) {
  const target = normalizeRecentTab(targetItem, 0);
  if (!target || !target.path || !target.openedAt) return "";

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  const targetKey = recentTabKey(target);
  let index = tabs.findIndex(item => recentTabKey(item) === targetKey);
  if (index < 0) index = tabs.findIndex(item => item.path === target.path);
  return index >= 0 ? createRecentTabInstanceId(tabs[index], index) : "";
}

function setActiveRecentTabId(tabId) {
  activeRecentTabKey = String(tabId || "");
  if (activeRecentTabKey) volatileVisitedRecentTabIds.add(activeRecentTabKey);
}

function readVisitedRecentTabIdSet() {
  return new Set(volatileVisitedRecentTabIds);
}

function updateRecentTabVisitedStyles() {
  const visitedIds = readVisitedRecentTabIdSet();
  document.querySelectorAll(".tabTime[data-tab-id]").forEach(button => {
    const visited = visitedIds.has(button.dataset.tabId || "");
    button.classList.toggle("isVisited", visited);
    if (visited) {
      button.setAttribute("data-visited", "true");
    } else {
      button.removeAttribute("data-visited");
    }
  });
}

function ensureActiveRecentVisible(tabs) {
  if (!Array.isArray(tabs) || !tabs.length) {
    recentWindowStart = 0;
    return;
  }

  const activeIndex = findRecentTabInstanceIndex(tabs, activeRecentTabKey);
  if (activeIndex < 0) {
    recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
    return;
  }

  if (activeIndex < recentWindowStart) {
    recentWindowStart = activeIndex;
  } else if (activeIndex >= recentWindowStart + RECENT_TAB_VISIBLE_LIMIT) {
    recentWindowStart = activeIndex - RECENT_TAB_VISIBLE_LIMIT + 1;
  }

  recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
}

function addRecentTab(path, meta = {}) {
  const fullPath = getHistoryEntryPath(path);
  if (!fullPath) return null;

  // localStorageへ保存される日時と、画面・SessionStorageで使う一意IDの日時を完全に一致させる。
  // 以前はDateのミリ秒付きIDと、保存後の秒単位IDがずれていたため、同じタブを特定できなかった。
  const openedAt = new Date();
  const storageValue = createHistoryStorageValue(fullPath, openedAt, meta);
  const canonicalOpenedAt = getHistoryEntryOpenedAt(storageValue, openedAt);
  const item = { path: fullPath, openedAt: canonicalOpenedAt };

  addHistory(FILE_HISTORY_STORAGE_KEY, storageValue, []);
  setActiveRecentTabId(createRecentTabInstanceId(item, 0));
  recentWindowStart = 0;
  renderRecentTabs();
  return item;
}

function toSafeDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? new Date() : date;
}

function normalizeRecentTab(item, index) {
  const fallback = sampleRecentTabs[index % sampleRecentTabs.length] || sampleRecentTabs[0];
  const path = getHistoryEntryPath(item && item.path ? item.path : (fallback ? fallback.path : sampleFiles[0]));
  const openedAtValue = item && item.openedAt ? item.openedAt : (fallback ? fallback.openedAt : new Date().toISOString());
  const openedAt = toSafeDate(openedAtValue).toISOString();
  return { path, openedAt, autoFilled: isAutoFilledRecentTab(item) };
}

function formatTabDate(isoText) {
  const date = toSafeDate(isoText);
  const week = ["日", "月", "火", "水", "木", "金", "土"][date.getDay()];
  const pad = value => String(value).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())}(${week})`;
}

// ヘッダー履歴タブには時刻ではなくファイル名を表示する。
// Unicode文字も1文字として数え、先頭12文字を超える場合だけ末尾に「…」を付ける。
function getRecentTabFileName(path) {
  const cleanPath = String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/")
    .replace(/\/+$/, "");
  const fileName = cleanPath.substring(cleanPath.lastIndexOf("/") + 1);
  return fileName || cleanPath || "-";
}


// 2026-08-14 fix86:
// ソースコードタブ上のファイル名バッジは廃止し、画面下中央のfixed表示へ統合する。
// ソース表示ではbasename、テーブル情報表示ではテーブル名を表示する。
function updateCodeContextFixedLabel(path = currentCodePath) {
  const sourceTab = $("codeSourceModeTab");
  if (sourceTab) {
    sourceTab.removeAttribute("data-badge");
    sourceTab.removeAttribute("data-file-name-badge");
    sourceTab.removeAttribute("title");
    sourceTab.removeAttribute("aria-label");
  }

  const label = $("codeContextFixedLabel");
  if (!label) return "";

  let visibleName = "";
  if (currentView === "code" && isTableInfoPanel(activeCodePanel)) {
    const state = getActiveTableInfoState();
    const selected = state && state.selected ? state.selected : {};
    visibleName = String((selected && selected.name) || (state && state.tableName) || "").trim();
  } else if (currentView === "code" && activeCodePanel === "source") {
    const fileName = getRecentTabFileName(path);
    visibleName = fileName && fileName !== "-" ? fileName : "";
  }

  label.textContent = visibleName;
  label.hidden = !visibleName;
  label.classList.toggle("isVisible", Boolean(visibleName));
  return visibleName;
}

function formatRecentTabFileName(path, maxLength = 12) {
  const fileName = getRecentTabFileName(path);
  const characters = Array.from(fileName);
  return characters.length > maxLength
    ? `${characters.slice(0, maxLength).join("")}…`
    : fileName;
}


// 2026-08-03 サイト修正1: ヘッダー数字タブhover時の黒帯表示文言を整形する。
// 表示形式: ファイル名 = xxx.java ｜ nkCCIS ｜ kyak.online.jar ｜ .java
function getRawDirectoryGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "-";

  if (isKnownMigrationGroupSegment(parts[0])) {
    return parts[1] || "-";
  }

  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return parts[1] || parts[0] || "-";
  }

  return parts[0] || "-";
}

function getFileExtensionLabel(path) {
  const fileName = getRecentTabFileName(path);
  const match = String(fileName || "").match(/\.([^./\\]+)$/);
  return match ? match[1] : "-";
}

function buildFullWidthHoverBandText(items) {
  return (Array.isArray(items) ? items : [])
    .map(item => {
      const label = String(item && item.label || "").trim();
      const value = String(item && item.value || "-").trim() || "-";
      return label ? `${label}　＝　${value}` : value;
    })
    .filter(Boolean)
    .join("　｜　");
}

function formatRecentTabFullPathBandText(path) {
  const fileName = getRecentTabFileName(path) || "-";
  const group = extractMigrationGroupFromPath(path) || "-";
  const directoryGroup = getRawDirectoryGroupFromPath(path) || "-";
  const extension = getFileExtensionLabel(path);
  return buildFullWidthHoverBandText([
    { label: "ファイル名", value: fileName },
    { value: group },
    { value: directoryGroup },
    { value: extension }
  ]);
}

function formatRecentTabItemBandText(item) {
  const source = item && typeof item === "object" ? item : {};
  const path = String(source.path || "").trim();
  const fileName = String(source.fileName || getRecentTabFileName(path) || "-").trim() || "-";
  const group = normalizeMigrationGroupName(
    source.group || source.migrationGroup || extractMigrationGroupFromPath(path) || "-"
  ) || "-";
  const directoryGroup = cleanDirectoryGroupName(
    source.directoryGroup || source.dirGroup || getRawDirectoryGroupFromPath(path) || "-"
  ) || "-";
  const language = String(
    source.language || inferLanguageFromPath(path, "") || getFileExtensionLabel(path) || "-"
  ).replace(/^\./, "").trim() || "-";

  return buildFullWidthHoverBandText([
    { label: "ファイル名", value: fileName },
    { label: "移行グループ", value: group },
    { label: "ディレクトリグループ", value: directoryGroup },
    { label: "言語", value: language }
  ]);
}

function ensureRecentTabFullPathViewportBand() {
  let band = $("recentTabFullPathViewportBand");
  if (!band && document.body) {
    band = document.createElement("div");
    band.id = "recentTabFullPathViewportBand";
    band.className = "recentTabFullPathViewportBand";
    band.setAttribute("aria-hidden", "true");
    document.body.appendChild(band);
  }
  return band;
}

// 2026-08-04 サイト修正1: 全幅グレー帯の表示文字をspan単位に分割して配置する。
// 「ファイル名 = ... ｜ nkCCIS ｜ kyak.online.jar ｜ java」の各項目を別spanにする。
function splitFullWidthBandTextItems(text) {
  const value = String(text || "").trim();
  if (!value) return [];
  return value
    .split(/[　\s]*[｜|][　\s]*/)
    .map(part => part.trim())
    .filter(Boolean);
}

function renderFullWidthBandContent(band, text) {
  if (!band) return false;
  const items = splitFullWidthBandTextItems(text);
  band.textContent = "";
  if (!items.length) return false;

  const inner = document.createElement("span");
  inner.className = "recentTabFullPathBandInner";
  items.forEach((item, index) => {
    const part = document.createElement("span");
    part.className = "recentTabFullPathBandPart";
    part.textContent = item;
    inner.appendChild(part);

    if (index < items.length - 1) {
      const separator = document.createElement("span");
      separator.className = "recentTabFullPathBandSeparator";
      separator.setAttribute("aria-hidden", "true");
      separator.textContent = "｜";
      inner.appendChild(separator);
    }
  });
  band.appendChild(inner);
  return true;
}

// 2026-08-03 サイト修正7: テーブル行hoverでも、ヘッダー数字タブと同じ全幅グレー帯を表示する。
// hover中にENTERを押した場合は、その行クリックと同じ処理を実行する。
let activeFullWidthHoverBandAction = null;

// 2026-08-04 サイト修正3: hover帯からENTER/クリックで遷移した直後に、
// 遷移先で偶然カーソル下にある別要素のhover帯が即時表示されることを抑止する。
let fullWidthHoverBandSuppressUntil = 0;

function isFullWidthHoverBandSuppressed() {
  return Date.now() < fullWidthHoverBandSuppressUntil;
}

function suppressFullWidthHoverBandTemporarily(durationMs = 1200) {
  fullWidthHoverBandSuppressUntil = Date.now() + Math.max(0, Number(durationMs) || 0);
  hideRecentTabFullPathViewportBand();
}

function clearFullWidthHoverBandSuppression() {
  fullWidthHoverBandSuppressUntil = 0;
}

function showRecentTabFullPathViewportBand(text, action) {
  // 2026-08-04 サイト修正2: ヘッダー数字タブhover中もENTERで対象ソースを開けるようにする。
  if (isFullWidthHoverBandSuppressed()) {
    hideRecentTabFullPathViewportBand();
    return;
  }
  activeFullWidthHoverBandAction = null;
  const band = ensureRecentTabFullPathViewportBand();
  if (!band) return;
  const hasContent = renderFullWidthBandContent(band, text);
  band.classList.toggle("isVisible", hasContent);
  document.body.classList.toggle("isRecentTabFullPathBandVisible", hasContent);
  activeFullWidthHoverBandAction = typeof action === "function" && hasContent ? action : null;
}

function hideRecentTabFullPathViewportBand() {
  activeFullWidthHoverBandAction = null;
  const band = $("recentTabFullPathViewportBand");
  if (band) {
    band.classList.remove("isVisible");
  }
  if (document.body) {
    document.body.classList.remove("isRecentTabFullPathBandVisible");
  }
}

function showInteractiveFullWidthHoverBand(text, action) {
  if (isFullWidthHoverBandSuppressed()) {
    hideRecentTabFullPathViewportBand();
    return;
  }
  const band = ensureRecentTabFullPathViewportBand();
  if (!band) return;
  const hasContent = renderFullWidthBandContent(band, text);
  band.classList.toggle("isVisible", hasContent);
  if (document.body) {
    document.body.classList.toggle("isRecentTabFullPathBandVisible", hasContent);
  }
  activeFullWidthHoverBandAction = typeof action === "function" && hasContent ? action : null;
}

function hideInteractiveFullWidthHoverBand(action) {
  if (action && activeFullWidthHoverBandAction && activeFullWidthHoverBandAction !== action) return;
  activeFullWidthHoverBandAction = null;
  const band = $("recentTabFullPathViewportBand");
  if (band) band.classList.remove("isVisible");
  if (document.body) document.body.classList.remove("isRecentTabFullPathBandVisible");
}

function isKeyboardTypingTarget(target) {
  const tagName = target && target.tagName ? target.tagName.toLowerCase() : "";
  if (["input", "select", "textarea"].includes(tagName)) return true;
  return Boolean(target && target.isContentEditable);
}

function isTabPreviewControllerElement(target) {
  const element = target && target.nodeType === 1 ? target : null;
  if (!element || typeof element.closest !== "function") return false;
  return Boolean(element.closest(".codeSideNavBtn, .recentNavArrow"));
}

function isRenderedRecentTabButtonElement(target) {
  const element = target && target.nodeType === 1 ? target : null;
  if (!element || typeof element.closest !== "function") return false;
  return Boolean(element.closest(".tabTime[data-tab-id], .tabTime[data-path]"));
}

function activateFullWidthHoverBandActionByEnter(event) {
  if (!activeFullWidthHoverBandAction || !event || event.key !== "Enter") return false;
  if (isKeyboardTypingTarget(event.target)) return false;
  // 2026-08-12 fix60:
  // マウスカーソルが右/左タブ移動ボタン、またはヘッダー左右矢印上にある状態のEnterは、
  // 現在focusが数字タブに残っていても、hover帯の確定(openCode)ではなく
  // 各ボタンの「次/前の数字タブをhoverしたように見せる」プレビュー処理へ必ず渡す。
  if (activeCodeSideNavigationHoverOffset || activeRecentNavArrowHoverOffset) return false;
  // 右/左タブ移動ボタンやヘッダー左右矢印自身でEnterした場合は、
  // 既存のhover帯確定アクションを実行せず、各ボタンのkeydown処理で
  // 対象数字タブの疑似hoverプレビュー表示だけを行わせる。
  if (isTabPreviewControllerElement(event.target)) return false;
  const action = activeFullWidthHoverBandAction;
  event.preventDefault();
  event.stopPropagation();
  clearRecentTabKeyboardPreviewStyles();
  suppressFullWidthHoverBandTemporarily();
  action();
  return true;
}

function createHistorySearchBandText(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim())
    .filter(Boolean);
  const keyword = parts[0] || "-";
  const group = parts[1] || "-";
  const language = parts[2] || "-";
  return buildFullWidthHoverBandText([
    { label: "検索キーワード", value: keyword },
    { value: group },
    { value: language }
  ]);
}

function createSearchResultBandText(row) {
  const source = row || {};
  const path = source.path || source.fullPath || source.filePath || "";
  const fileName = source.fileName || getRecentTabFileName(path) || source.path || "-";
  const group = normalizeMigrationGroupName(source.group || source.project || extractMigrationGroupFromPath(path) || "-") || "-";
  const directoryGroup = source.directoryGroup || getRawDirectoryGroupFromPath(path) || "-";
  const language = String(source.language || getFileExtensionLabel(path) || "-").replace(/^\./, "") || "-";
  return buildFullWidthHoverBandText([
    { label: "ファイル名", value: fileName },
    { value: group },
    { value: directoryGroup },
    { value: language }
  ]);
}

function bindFullWidthHoverBandToRow(rowElement, text, action) {
  if (!rowElement || !text || typeof action !== "function") return;
  if (rowElement.classList.contains("isPlaceholderHistoryRow") || rowElement.classList.contains("isPlaceholderResultRow")) return;
  if (rowElement.classList.contains("resultEmptyStateRow") || rowElement.classList.contains("resultNoDataRow")) return;

  rowElement.tabIndex = 0;
  rowElement.dataset.hoverBandText = text;
  // 2026-08-04 サイト修正5: 行hover時にブラウザ標準の黒いtitleツールチップを出さない。
  // Full幅のグレー帯は独自UIで表示するため、ネイティブtitleはaria-labelへ退避する。
  const nativeTitle = rowElement.getAttribute("title");
  if (nativeTitle) {
    if (!rowElement.getAttribute("aria-label")) rowElement.setAttribute("aria-label", nativeTitle);
    rowElement.removeAttribute("title");
  }

  const show = () => showInteractiveFullWidthHoverBand(text, action);
  const hide = () => hideInteractiveFullWidthHoverBand(action);

  rowElement.addEventListener("mouseenter", show);
  rowElement.addEventListener("mouseleave", hide);
  rowElement.addEventListener("focusin", show);
  rowElement.addEventListener("focusout", hide);
  rowElement.addEventListener("click", hide);
}

// ヘッダーのファイル履歴タブは、ファイル名そのものではなく日付単位の番号で表示する。
// 同一日付内では古い順に1から採番し、999を超えた場合は1へ戻す。
function getRecentTabNumberLabelForIndex(index) {
  const safeIndex = Math.max(0, Number(index) || 0);
  const number = (safeIndex % 999) + 1;
  return String(number);
}

function createRecentTabNumberLabelMap(tabs) {
  const result = new Map();
  const groupedByDate = new Map();

  (Array.isArray(tabs) ? tabs : []).forEach((item, index) => {
    if (!item || !item.openedAt) return;
    const key = dateKey(item.openedAt);
    if (!groupedByDate.has(key)) groupedByDate.set(key, []);
    groupedByDate.get(key).push({ item, index });
  });

  groupedByDate.forEach(entries => {
    const count = entries.length;
    entries.forEach((entry, index) => {
      // tabsは新しい順。日付内の一番古いタブを1にするため、表示側は降順番号にする。
      result.set(createRecentTabInstanceId(entry.item, entry.index), getRecentTabNumberLabelForIndex(count - 1 - index));
    });
  });

  return result;
}


function dateKey(isoText) {
  const date = toSafeDate(isoText);
  const pad = value => String(value).padStart(2, "0");
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}`;
}

function shiftRecentWindow(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!tabs.length) return;

  const maxStart = Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT);
  recentWindowStart = Math.max(0, Math.min(maxStart, recentWindowStart + offset));
  manualRecentWindowShift = true;
  renderRecentTabs();
}

function renderRecentTabs() {
  const area = $("recentTabArea");
  if (!area) return;

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!activeRecentTabKey && currentView === "code" && currentCodePath && tabs.length) {
    const fallbackActiveIndex = tabs.findIndex(item => item.path === currentCodePath);
    if (fallbackActiveIndex >= 0) {
      setActiveRecentTabId(createRecentTabInstanceId(tabs[fallbackActiveIndex], fallbackActiveIndex));
    }
  }

  if (manualRecentWindowShift) {
    recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
    manualRecentWindowShift = false;
  } else {
    ensureActiveRecentVisible(tabs);
  }

  area.classList.toggle("hasMoreLeft", recentWindowStart > 0);
  area.classList.toggle("hasMoreRight", recentWindowStart + RECENT_TAB_VISIBLE_LIMIT < tabs.length);

  const visibleTabs = tabs.slice(recentWindowStart, recentWindowStart + RECENT_TAB_VISIBLE_LIMIT);
  const recentTabNumberLabelMap = createRecentTabNumberLabelMap(tabs);
  const visitedRecentTabIds = readVisitedRecentTabIdSet();
  const groups = [];
  visibleTabs.forEach(item => {
    const key = dateKey(item.openedAt);
    const last = groups[groups.length - 1];
    if (!last || last.key !== key) {
      groups.push({ key, label: formatTabDate(item.openedAt), count: 1 });
    } else {
      last.count += 1;
    }
  });

  area.innerHTML = `
    <button class="recentNavArrow recentNavArrowLeft" type="button" aria-label="左のタブへ移動" title="左のタブへ移動">
      <svg class="recentNavIconSvg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M14.2 4.8L8.3 12l5.9 7.2" />
      </svg>
    </button>
    <div class="recentDateRow">
      ${groups.map((group, index) => {
        const prevGroup = groups[index - 1];
        const afterNarrowDateGroup = !!prevGroup && prevGroup.count <= 2;
        const className = afterNarrowDateGroup ? "recentDateGroup isAfterNarrowDateGroup" : "recentDateGroup";
        const shiftPx = 0;
        const extraWidthPx = group.count <= 2 && index < groups.length - 1 ? (group.count === 1 ? 70 : 44) : 0;
        return `
        <div class="${className}" style="--tab-count:${group.count}; --date-shift-x:${shiftPx}px; --date-extra-width:${extraWidthPx}px">
          ${escapeHtml(group.label)}
        </div>
      `;
      }).join("")}
    </div>
    <div class="recentTimeRow">
      ${visibleTabs.map((item, index) => {
        const absoluteIndex = recentWindowStart + index;
        const tabId = createRecentTabInstanceId(item, absoluteIndex);
        const isVisited = visitedRecentTabIds.has(tabId);
        const fullFileName = getRecentTabFileName(item.path);
        const numberLabel = recentTabNumberLabelMap.get(tabId) || getRecentTabNumberLabelForIndex(index);
        const fullPathBandText = formatRecentTabItemBandText(item);
        return `
          <button class="tabTime${isVisited ? " isVisited" : ""}${tabId === activeRecentTabKey ? " isActive" : ""}" type="button"
                  data-tab-id="${escapeHtml(tabId)}"
                  data-path="${escapeHtml(item.path)}"
                  data-opened-at="${escapeHtml(item.openedAt)}"
                  data-recent-index="${absoluteIndex}"
                  data-full-file-name="${escapeHtml(fullFileName)}"
                  data-hover-band-text="${escapeHtml(fullPathBandText)}"
                  data-number-label="${escapeHtml(numberLabel)}"
                  aria-label="${escapeHtml(`ファイル ${fullFileName}、タブ番号 ${numberLabel}`)}"
                  title="${escapeHtml(fullFileName)}">
            <span class="recentTabLabel">${escapeHtml(numberLabel)}</span>
            <span class="recentTabTooltip" role="tooltip" aria-hidden="true">${escapeHtml(fullFileName)}</span>
            <span class="recentTabFullPathBand" role="tooltip" aria-hidden="true">${escapeHtml(fullPathBandText)}</span>
          </button>
        `;
      }).join("")}
    </div>
    <button class="recentNavArrow recentNavArrowRight" type="button" aria-label="右のタブへ移動" title="右のタブへ移動">
      <svg class="recentNavIconSvg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M9.8 4.8L15.7 12l-5.9 7.2" />
      </svg>
    </button>
  `;

  area.querySelectorAll(".tabTime").forEach(button => {
    const openRecentTabSourceFromHeader = () => {
      const index = Number(button.dataset.recentIndex);
      const item = tabs[index];
      if (item) openCode(item.path, { addRecent: false, recentItem: item, recentTabId: button.dataset.tabId || "" });
    };
    const showHeaderHoverBand = () => {
      showRecentTabFullPathViewportBand(
        button.dataset.hoverBandText || button.dataset.path || "",
        openRecentTabSourceFromHeader
      );
    };

    button.addEventListener("mouseenter", showHeaderHoverBand);
    button.addEventListener("mouseleave", hideRecentTabFullPathViewportBand);
    button.addEventListener("focus", showHeaderHoverBand);
    button.addEventListener("blur", hideRecentTabFullPathViewportBand);
    button.addEventListener("click", () => {
      clearRecentTabKeyboardPreviewStyles();
      suppressFullWidthHoverBandTemporarily();
      openRecentTabSourceFromHeader();
    });
  });

  const recentPrevButton = area.querySelector(".recentNavArrowLeft");
  const recentNextButton = area.querySelector(".recentNavArrowRight");
  bindRecentNavArrowPreviewButton(recentPrevButton, -1);
  bindRecentNavArrowPreviewButton(recentNextButton, 1);

  updateRecentTabVisitedStyles();
}

function openRelativeRecentTab(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!tabs.length) return;

  let index = findRecentTabInstanceIndex(tabs, activeRecentTabKey);
  if (index < 0) index = tabs.findIndex(item => item.path === currentCodePath);
  if (index < 0) index = 0;

  const nextIndex = (index + offset + tabs.length) % tabs.length;
  const next = tabs[nextIndex];
  if (next && next.path) {
    openCode(next.path, {
      addRecent: false,
      recentItem: next,
      recentTabId: createRecentTabInstanceId(next, nextIndex)
    });
  }
}

function getHeaderKeyboardNavigationRecentTabs() {
  return readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);
}

function getHeaderKeyboardNavigationItems() {
  const items = [
    { type: "view", viewName: "home" },
    { type: "view", viewName: "search" }
  ];

  getHeaderKeyboardNavigationRecentTabs().forEach((item, index) => {
    items.push({
      type: "recent",
      recentItem: item,
      recentIndex: index,
      recentTabId: createRecentTabInstanceId(item, index)
    });
  });

  return items;
}

function getCurrentHeaderKeyboardNavigationIndex(items) {
  if (!Array.isArray(items) || !items.length) return 0;
  if (currentView === "search") return Math.min(1, items.length - 1);
  if (currentView !== "code") return 0;

  const activeIndex = items.findIndex(item =>
    item &&
    item.type === "recent" &&
    item.recentTabId === activeRecentTabKey
  );
  if (activeIndex >= 0) return activeIndex;

  const pathIndex = items.findIndex(item =>
    item &&
    item.type === "recent" &&
    item.recentItem &&
    item.recentItem.path === currentCodePath
  );
  return pathIndex >= 0 ? pathIndex : Math.min(2, items.length - 1);
}

function activateHeaderKeyboardNavigationItem(item) {
  if (!item) return;

  if (item.type === "view") {
    showView(item.viewName);
    return;
  }

  if (item.type === "recent" && item.recentItem && item.recentItem.path) {
    openCode(item.recentItem.path, {
      addRecent: false,
      recentItem: item.recentItem,
      recentTabId: item.recentTabId || createRecentTabInstanceId(item.recentItem, item.recentIndex)
    });
  }
}

function moveMainTabByKeyboard(offset) {
  // 右/左タブ移動ボタンは従来どおり、ヘッダー全体のタブ順で即時移動する。
  // Home → Search → Source Tab 1 → Source Tab 2 → ... → Last → Home の循環。
  // 逆方向は Home ← Search ← Source Tab 1 ← ... ← Last の循環にする。
  const items = getHeaderKeyboardNavigationItems();
  if (!items.length) return;

  const currentIndex = getCurrentHeaderKeyboardNavigationIndex(items);
  const nextIndex = (currentIndex + offset + items.length) % items.length;
  activateHeaderKeyboardNavigationItem(items[nextIndex]);
}

function clearRecentTabKeyboardPreviewStyles() {
  activeRecentTabPreviewTabId = "";
  document.querySelectorAll(".tabTime.isKeyboardPreview").forEach(button => {
    button.classList.remove("isKeyboardPreview");
    button.removeAttribute("aria-selected");
  });
  clearRecentNavArrowPreviewStyles();
  clearCodeSideNavigationPreviewStyles();
}

function getFocusedRecentTabIndex(tabs) {
  const active = document.activeElement;
  if (!active || !active.classList || !active.classList.contains("tabTime")) return -1;
  const index = Number(active.dataset.recentIndex);
  return Number.isFinite(index) && index >= 0 && index < tabs.length ? index : -1;
}

function getCurrentRecentTabKeyboardPreviewIndex(tabs) {
  const focusedIndex = getFocusedRecentTabIndex(tabs);
  if (focusedIndex >= 0) return focusedIndex;

  // 2026-08-14 fix93:
  // recentNavArrowRight / recentNavArrowLeft を連続クリックすると、クリック直前に矢印ボタンへ
  // focusが移るため数字タブのfocusoutでグレー帯が一瞬非表示になる。
  // 旧処理は「帯が表示中」の場合だけ preview ID を採用していたため、連続クリック時に
  // 毎回現在開いているタブを基点に戻ることがあった。
  // 帯の表示状態とは独立して直前のカーソル位置（preview ID）を基点にし、
  // Rightなら1つ右、Leftなら1つ左へ確実に進める。
  const previewIndex = findRecentTabInstanceIndex(tabs, activeRecentTabPreviewTabId);
  if (previewIndex >= 0) return previewIndex;

  let index = findRecentTabInstanceIndex(tabs, activeRecentTabKey);
  if (index < 0) index = tabs.findIndex(item => item && item.path === currentCodePath);
  return index;
}

function findRenderedRecentTabButtonByTabId(tabId) {
  const area = $("recentTabArea");
  if (!area) return null;
  const buttons = Array.from(area.querySelectorAll(".tabTime"));
  return buttons.find(button => button.dataset.tabId === tabId) || null;
}

function ensureRecentTabIndexRendered(index, tabs) {
  if (index < 0 || !Array.isArray(tabs) || index >= tabs.length) return;

  const maxStart = Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT);
  let nextStart = recentWindowStart;
  if (index < nextStart) {
    nextStart = index;
  } else if (index >= nextStart + RECENT_TAB_VISIBLE_LIMIT) {
    nextStart = index - RECENT_TAB_VISIBLE_LIMIT + 1;
  }

  nextStart = Math.max(0, Math.min(maxStart, nextStart));
  if (nextStart !== recentWindowStart) {
    recentWindowStart = nextStart;
    manualRecentWindowShift = true;
    renderRecentTabs();
  }
}

function buildRecentTabKeyboardPreviewAction(item, recentTabId) {
  return () => {
    if (!item || !item.path) return;
    openCode(item.path, {
      addRecent: false,
      recentItem: item,
      recentTabId
    });
  };
}

function previewRecentTabByKeyboard(offset, options = {}) {
  // 2026-08-05 サイト修正4:
  // ArrowLeft / ArrowRight はソースコード数字タブを即時オープンせず、
  // 数字タブhoverと同じ全幅グレー帯を表示する。Enterでクリック相当のopenCodeを実行する。
  const tabs = getHeaderKeyboardNavigationRecentTabs();
  if (!tabs.length) return false;

  const direction = offset >= 0 ? 1 : -1;
  const currentIndex = getCurrentRecentTabKeyboardPreviewIndex(tabs);
  const baseIndex = currentIndex >= 0 ? currentIndex : (direction > 0 ? -1 : 0);
  const nextIndex = (baseIndex + direction + tabs.length) % tabs.length;
  const item = tabs[nextIndex];
  if (!item || !item.path) return false;

  const recentTabId = createRecentTabInstanceId(item, nextIndex);
  ensureRecentTabIndexRendered(nextIndex, tabs);

  let button = findRenderedRecentTabButtonByTabId(recentTabId);
  if (!button) {
    renderRecentTabs();
    button = findRenderedRecentTabButtonByTabId(recentTabId);
  }
  if (!button) return false;

  clearFullWidthHoverBandSuppression();
  clearRecentTabKeyboardPreviewStyles();
  activeRecentTabPreviewTabId = recentTabId;
  button.classList.add("isKeyboardPreview");
  button.setAttribute("aria-selected", "true");
  if (options.focusTab !== false && typeof button.focus === "function") {
    try {
      button.focus({ preventScroll: true });
    } catch (e) {
      button.focus();
    }
  }

  showRecentTabFullPathViewportBand(
    formatRecentTabItemBandText(item),
    buildRecentTabKeyboardPreviewAction(item, recentTabId)
  );
  return true;
}


function handleRecentTabArrowKeyNavigation(offset, event) {
  // 2026-08-12 fix65:
  // ArrowLeft / ArrowRight のdocument keydownは、この1本へ集約する。
  if (isKeyboardTypingTarget(event && event.target)) return false;
  const ok = previewRecentTabByKeyboard(offset);
  if (!ok) return false;
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  return true;
}

function clearRecentNavArrowPreviewStyles() {
  document.querySelectorAll(".recentNavArrow.isRecentNavArrowPreview").forEach(button => {
    button.classList.remove("isRecentNavArrowPreview");
    button.removeAttribute("aria-current");
  });
}

function activateRecentNavArrowButton(offset, event) {
  // 2026-08-14 fix78:
  // recentNavArrowRight / recentNavArrowLeft の click / Enter は、人工的な KeyboardEvent を作らず、
  // 実際の ArrowRight / ArrowLeft keydown と同じ共通ハンドラへ直接流す。
  // 共通ハンドラ内で previewRecentTabByKeyboard() が実行され、
  // 数字タブhoverと同じ全幅グレー帯を表示し、対象数字タブへfocusを移す。
  // その後の Enter は既存 activateFullWidthHoverBandActionByEnter() が openCode() を実行する。
  return handleRecentTabArrowKeyNavigation(offset, event);
}

function bindRecentNavArrowPreviewButton(button, offset) {
  if (!button) return;

  const runPreview = event => {
    activateRecentNavArrowButton(offset, event);
  };

  button.addEventListener("click", runPreview);
  button.addEventListener("keydown", event => {
    if (event.key !== "Enter") return;
    // preventDefault は handleRecentTabArrowKeyNavigation() 側で行うため、
    // Enterによるbutton標準clickが後から二重発火することも防止できる。
    runPreview(event);
  });
}

function clearCodeSideNavigationPreviewStyles() {
  activeCodeSideNavigationPreviewOffset = 0;
  document.querySelectorAll(".codeSideNavBtn.isSideNavigationPreview").forEach(button => {
    button.classList.remove("isSideNavigationPreview");
    button.removeAttribute("aria-current");
  });
}

function previewRecentTabBySideNavigationButton(offset, sourceButton, options = {}) {
  const reuseVisiblePreview = options.reuseVisiblePreview === true;
  const focusTab = options.focusTab === true;
  const hasVisiblePreview = Boolean(
    document.body &&
    document.body.classList.contains("isRecentTabFullPathBandVisible") &&
    activeFullWidthHoverBandAction
  );

  // hover → focus → click の順で同じボタンイベントが連続しても、候補タブを二重に進めない。
  // ただしclick/Enterでは対象タブへfocusを移す必要があるため、focusTab=trueの場合は再プレビューする。
  if (!focusTab && reuseVisiblePreview && hasVisiblePreview && activeCodeSideNavigationPreviewOffset === offset) {
    if (sourceButton) {
      sourceButton.classList.add("isSideNavigationPreview");
      sourceButton.setAttribute("aria-current", "true");
    }
    return true;
  }

  const ok = previewRecentTabByKeyboard(offset, { focusTab });
  if (!ok) return false;

  activeCodeSideNavigationPreviewOffset = offset;
  if (sourceButton) {
    sourceButton.classList.add("isSideNavigationPreview");
    sourceButton.setAttribute("aria-current", "true");
  }
  return true;
}

function hideCodeSideNavigationPreview(button, offset) {
  if (button && document.activeElement === button) return;
  if (activeCodeSideNavigationPreviewOffset !== offset) return;
  hideRecentTabFullPathViewportBand();
  clearRecentTabKeyboardPreviewStyles();
}

function activateCodeSideNavigationButton(offset, event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  // 2026-08-12 fix60:
  // 右/左タブ移動ボタンのClick/Enterは、実DOMのhoverイベントや数字タブへのfocus移動に頼らず、
  // ヘッダー数字タブへhoverしたときと同じ見た目・全幅グレー帯をJS状態で再現する。
  // focusを数字タブへ移さないことで、ボタン上でEnterを連打しても1つずつプレビューが進む。
  const sourceButton = event && event.currentTarget && event.currentTarget.classList
    ? event.currentTarget
    : document.querySelector(offset < 0 ? "#codePrevBtn" : "#codeNextBtn");
  clearFullWidthHoverBandSuppression();
  previewRecentTabBySideNavigationButton(offset, sourceButton, { reuseVisiblePreview: false, focusTab: false });
}

function bindCodeSideNavigationPreviewButton(id, offset) {
  const button = $(id);
  if (!button) return;

  const preview = (event, reuseVisiblePreview = true, focusTab = false) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    clearFullWidthHoverBandSuppression();
    return previewRecentTabBySideNavigationButton(offset, button, { reuseVisiblePreview, focusTab });
  };

  const rememberHoverOffset = () => {
    activeCodeSideNavigationHoverOffset = offset;
  };

  const clearHoverOffset = () => {
    if (activeCodeSideNavigationHoverOffset === offset) {
      activeCodeSideNavigationHoverOffset = 0;
    }
  };

  const showHoverPreview = () => {
    rememberHoverOffset();
    preview(null, true, false);
  };

  // 2026-08-12 fix46:
  // mouseenterだけに依存せず、pointer/focusでも右/左タブ移動ボタン上の状態を保持する。
  // これにより「カーソルがボタン上にある状態でEnter」をdocument keydown側で確実に検出する。
  button.addEventListener("pointerenter", showHoverPreview);
  button.addEventListener("pointerleave", clearHoverOffset);
  button.addEventListener("mouseenter", showHoverPreview);
  button.addEventListener("mouseleave", clearHoverOffset);
  button.addEventListener("focus", showHoverPreview);
  button.addEventListener("blur", clearHoverOffset);

  button.addEventListener("click", event => {
    // clickは対象数字タブのhover相当プレビューだけにする。実focusはボタン側に残す。
    activateCodeSideNavigationButton(offset, event);
  });

  button.addEventListener("keydown", event => {
    if (event.key !== "Enter" && event.key !== " ") return;
    // ボタン自身のEnter/Spaceも、対象数字タブのhover相当プレビューだけにする。
    activateCodeSideNavigationButton(offset, event);
  });
}

function bindCodeSideNavigationPreviewButtons() {
  bindCodeSideNavigationPreviewButton("codePrevBtn", -1);
  bindCodeSideNavigationPreviewButton("codeNextBtn", 1);
}

function addHistory(key, value, fallback) {
  if (!value) return;
  if (key === FILE_HISTORY_STORAGE_KEY) {
    const current = readArray(key, fallback || []);
    const next = normalizeFileHistoryValues([value].concat(current));
    saveArray(key, next);
    prioritizeGroupSelectOptionsByHistory();
    return;
  }
  const next = readArray(key, fallback).filter(item => item !== value);
  next.unshift(value);
  saveArray(key, next);
}

function buildPlaceholderHistory(count = INITIAL_HISTORY_SAMPLE_COUNT) {
  return Array.from({ length: count }, () => HISTORY_PLACEHOLDER_VALUE);
}

function isPlaceholderHistoryValue(value) {
  return String(value || "").trim() === HISTORY_PLACEHOLDER_VALUE;
}

function isValidFileHistoryPath(path) {
  const text = String(path || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) return false;

  // 過去版で localStorage に入った「ファイル名だけ」「列分割後の断片」などのゴミを除外する。
  // ファイル履歴は、NIKKO.nkCCIS/kyak.online.jar/... のようなフルパスだけを正とする。
  if (text.indexOf("/") < 0) return false;
  if (/^(undefined|null|nan)$/i.test(text)) return false;
  return true;
}

function cleanDirectoryGroupName(value) {
  const text = String(value || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) return text;

  // 2列目のパス要素が kyak.online.jar / xxx.war / xxx.zip の場合は、
  // DIRGROUP としては拡張子を落として kyak.online の形で表示する。
  return text.replace(/\.(jar|war|ear|zip)$/i, "");
}


function normalizeProjectValue(value) {
  const text = String(value || "").trim().replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
  if (!text || /^(ALL|すべて)$/i.test(text)) return "";
  return text;
}

function resolveProjectFromGroup(group) {
  const normalizedGroup = normalizeMigrationGroupName(group);
  if (!normalizedGroup) return "";

  const select = $("groupSelect");
  if (!select || !select.options) return "";

  const matches = Array.from(select.options)
    .map(option => normalizeProjectValue(option.value))
    .filter(value => value && normalizeMigrationGroupName(value).toLowerCase() === normalizedGroup.toLowerCase());
  return matches.length === 1 ? matches[0] : "";
}

function buildCompleteKruglePath(path, project, group) {
  let rawPath = String(path || "").trim().replace(/\\/g, "/");
  rawPath = rawPath.replace(/^\/+/, "").replace(/\/{2,}/g, "/");
  if (!rawPath || isPlaceholderHistoryValue(rawPath)) return rawPath;

  const normalizedProject = normalizeProjectValue(project) || resolveProjectFromGroup(group);
  const firstSegment = rawPath.split("/")[0] || "";

  // すでに NIKKO.nkCCIS/... のような完全パスなら、そのまま保持する。
  if (isKnownMigrationGroupSegment(firstSegment)) return rawPath;
  if (!normalizedProject) return rawPath;
  if (rawPath === normalizedProject || rawPath.startsWith(`${normalizedProject}/`)) return rawPath;
  return `${normalizedProject}/${rawPath}`;
}

function getPathPartsForGroup(path) {
  return String(path || "")
    .split("/")
    .map(part => part.trim())
    .filter(Boolean);
}

function isKnownMigrationGroupSegment(value) {
  return /^(NIKKO|BPS|RPS)\./i.test(String(value || "").trim());
}

function isLikelyDirectoryOnlyPath(parts) {
  if (!Array.isArray(parts) || parts.length < 2) return false;
  return /^(lib|java|src|source|sql|xml|jsp|sh|config|conf|classes)$/i.test(parts[1]);
}

function extractProjectFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";
  if (isKnownMigrationGroupSegment(parts[0])) return parts[0];
  const group = extractMigrationGroupFromPath(path);
  return resolveProjectFromGroup(group) || group || "";
}

function extractMigrationGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";

  // NIKKO.nkCCIS/... / BPS.xxx/... / RPS.xxx/... は1階層目が移行グループ。
  if (isKnownMigrationGroupSegment(parts[0])) {
    return normalizeMigrationGroupName(parts[0]);
  }

  // SMBC/smbc_dbac/... のように1階層目が移行グループ、2階層目がディレクトリグループの形式。
  // kayk.online/lib/... のように2階層目が lib の場合は、1階層目をディレクトリグループとして扱う。
  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return normalizeMigrationGroupName(parts[0]);
  }

  return "";
}

function extractDirectoryGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";

  if (isKnownMigrationGroupSegment(parts[0])) {
    return cleanDirectoryGroupName(parts[1] || "");
  }

  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return cleanDirectoryGroupName(parts[1] || parts[0]);
  }

  return cleanDirectoryGroupName(parts[0]);
}

function stringifyHistoryValueForCompare(value) {
  const entry = splitHistoryStorageValue(value);
  return [
    getHistoryEntryPath(value) || "",
    entry.openedAtRaw || "",
    entry.fileName || "",
    entry.project || "",
    entry.group || "",
    entry.directoryGroup || ""
  ].join("");
}

function normalizeHistoryValues(values) {
  const result = [];
  const used = new Set();
  (Array.isArray(values) ? values : []).forEach(value => {
    const text = String(value || "").trim();
    const path = getHistoryEntryPath(value);
    if (!text || !path || isPlaceholderHistoryValue(path) || used.has(path)) return;
    used.add(path);
    result.push(text);
  });
  return result;
}

function compareFileHistoryItems(a, b) {
  const timeDiff = toSafeDate(b.openedAt).getTime() - toSafeDate(a.openedAt).getTime();
  if (timeDiff !== 0) return timeDiff;
  return String(a.path || "").localeCompare(String(b.path || ""));
}

function normalizeFileHistoryValues(values) {
  const map = new Map();
  (Array.isArray(values) ? values : []).forEach((value, index) => {
    const entry = splitHistoryStorageValue(value);
    const path = buildCompleteKruglePath(entry.path, entry.project, entry.group);
    if (!isValidFileHistoryPath(path)) return;

    const openedAt = parseHistoryOpenedAt(entry.openedAtRaw, new Date(Date.now() - index * 60 * 1000));
    const normalizedValue = createHistoryStorageValue(path, openedAt, {
      fileName: entry.fileName,
      project: entry.project,
      group: entry.group,
      directoryGroup: entry.directoryGroup,
      initialSeed: entry.initialSeed,
      seedMarker: entry.seedMarker
    });
    const existing = map.get(path);
    if (!existing || toSafeDate(openedAt).getTime() > toSafeDate(existing.openedAt).getTime()) {
      map.set(path, { path, openedAt, value: normalizedValue });
    }
  });

  return Array.from(map.values())
    .sort(compareFileHistoryItems)
    .map(item => item.value);
}

function seedFileHistoryStorage(key, values, sampleValues) {
  let result = normalizeFileHistoryValues(values);
  if (!result.length) {
    result = normalizeFileHistoryValues(sampleValues);
  }

  const raw = Array.isArray(values) ? values.map(stringifyHistoryValueForCompare).filter(Boolean) : [];
  const normalized = result.map(stringifyHistoryValueForCompare).filter(Boolean);
  if (!USE_SAMPLE_DATA && normalized.join("") !== raw.join("")) {
    saveArray(key, result);
  }
  return result;
}

function getDisplayFileHistoryRows(values, count = FILE_HISTORY_HOME_DISPLAY_LIMIT) {
  return normalizeFileHistoryValues(values).slice(0, count);
}

function addSearchResultsToFileHistory(rows, openedAt = new Date()) {
  if (USE_SAMPLE_DATA) return;
  const additions = (Array.isArray(rows) ? rows : [])
    .map((row, index) => normalizeSearchRow(row, index))
    .filter(row => row && !row.placeholder && isValidFileHistoryPath(row.path))
    .map(row => createHistoryStorageValue(row.path, openedAt, {
      fileName: row.fileName,
      project: row.project,
      group: row.group,
      directoryGroup: row.directoryGroup
    }));
  if (!additions.length) return;

  const current = readArray(FILE_HISTORY_STORAGE_KEY, []);
  saveArray(FILE_HISTORY_STORAGE_KEY, normalizeFileHistoryValues(additions.concat(current)));
  prioritizeGroupSelectOptionsByHistory();
  sessionRecentTabs = null;
  renderRecentTabs();
}

function seedHistoryStorage(key, values, sampleValues, count = INITIAL_HISTORY_SAMPLE_COUNT) {
  const original = normalizeHistoryValues(values);
  const result = original.slice();
  const used = new Set(result);

  (Array.isArray(sampleValues) ? sampleValues : []).forEach(value => {
    if (result.length >= count) return;
    const text = String(value || "").trim();
    if (!text || isPlaceholderHistoryValue(text) || used.has(text)) return;
    used.add(text);
    result.push(text);
  });

  // 初回表示や履歴20件未満の環境では、サンプルを含めて20件までlocalStorageへ保存する。
  // 後で固定サンプル値に差し替えるだけで、全ユーザーの初回起動時に20件入った状態を再現できる。
  // 過去版で入った「-」補完も、保存し直すことで履歴データから除去する。
  const rawLength = Array.isArray(values) ? values.length : 0;
  const hasStorageDifference = rawLength !== original.length || result.join("") !== original.join("");
  if (!USE_SAMPLE_DATA && hasStorageDifference) {
    saveArray(key, result);
  }
  return result;
}

function getDisplayHistoryRows(values, count = INITIAL_HISTORY_SAMPLE_COUNT) {
  return normalizeHistoryValues(values).slice(0, count);
}

function normalizeMigrationGroupName(value) {
  const text = String(value || "").trim();
  if (!text) return "";

  // 2026-08-14 fix77:
  // ドットは移行グループ名そのものに含まれる場合がある。
  // 例: NIKKO.nikkoEZ.java17 -> nikkoEZ.java17
  //      nikkoEZ.java17       -> nikkoEZ.java17
  //      ROKINREN.bpsrk       -> ROKINREN.bpsrk
  // そのため「最初/最後のドット以降だけを残す」汎用処理は禁止する。
  // NIKKO / BPS / RPS / NewNikko は分類用接頭辞としてのみ除去する。
  const withoutKnownPrefix = text.replace(/^(NIKKO|BPS|RPS|NewNikko)\./i, "");
  if (withoutKnownPrefix !== text) return withoutKnownPrefix;

  // 既存データ互換:
  // SMBC.SMBC / fast2024.fast2024 / nikkoEZ.nikkoEZ のように
  // 前後が同一名称の重複表現だけは1つへ畳む。
  const duplicateMatch = text.match(/^([^.]+)\.([^.]+)$/);
  if (duplicateMatch && duplicateMatch[1].toLowerCase() === duplicateMatch[2].toLowerCase()) {
    return duplicateMatch[2];
  }

  // nikkoEZ.java17 / nikkoEZ.container / ROKINREN.bpsrk 等は
  // ドットを含めた全体が1つの移行グループ名なので保持する。
  return text;
}

function formatHistoryFileParts(value) {
  const entry = splitHistoryStorageValue(value);
  const path = getHistoryEntryPath(value) || entry.path;
  if (!isValidFileHistoryPath(path)) {
    return [HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE];
  }

  const pathParts = getPathPartsForGroup(path);
  const fileName = String(entry.fileName || pathParts[pathParts.length - 1] || path).trim();

  // 保存済みメタデータが空、旧形式、または「-」でも、完全パス／projectから必ず補完する。
  // 例: NIKKO.nkCCIS/kyak.online.jar/... -> nkCCIS / kyak.online
  const storedGroup = normalizeMigrationGroupName(entry.group);
  const pathGroup = normalizeMigrationGroupName(extractMigrationGroupFromPath(path));
  const projectGroup = normalizeMigrationGroupName(entry.project);
  const group = [pathGroup, projectGroup, storedGroup]
    .find(part => part && !isPlaceholderHistoryValue(part)) || HISTORY_PLACEHOLDER_VALUE;

  const storedDirectoryGroup = cleanDirectoryGroupName(entry.directoryGroup);
  const pathDirectoryGroup = cleanDirectoryGroupName(extractDirectoryGroupFromPath(path));
  const directoryGroup = [storedDirectoryGroup, pathDirectoryGroup]
    .find(part => part && !isPlaceholderHistoryValue(part)) || HISTORY_PLACEHOLDER_VALUE;

  return [fileName || HISTORY_PLACEHOLDER_VALUE, group, directoryGroup];
}

function formatHistoryFileHtml(value) {
  const parts = formatHistoryFileParts(value);
  const names = ["name", "group", "area"];
  return parts.map((part, index) =>
    `<span class="historyToken historyToken-${names[index] || index}">${escapeHtml(part)}</span>`
  ).join("");
}

function formatHistoryFileCellsHtml(value, cellClassPrefix = "historyFile") {
  const parts = formatHistoryFileParts(value);
  const classes = ["Name", "Group", "Dir"];
  return parts.map((part, index) =>
    `<td class="${cellClassPrefix}${classes[index]}">${escapeHtml(part)}</td>`
  ).join("");
}


function renderGlobalHistoryMini(displayFiles) {
  const body = $("globalHistoryMiniBody");
  if (!body) return;

  // ソースコード画面右側もホーム左側と同じ表示配列・同じセル生成処理をそのまま使用する。
  // 件数、並び順、ファイル名、移行グループ、ディレクトリグループを別仕様にしない。
  const source = Array.isArray(displayFiles) ? displayFiles : [];

  body.innerHTML = source.map((value, index) => {
    const path = getHistoryEntryPath(value);
    const isPlaceholder = !isValidFileHistoryPath(path);
    return `
      <tr class="globalHistoryMiniRow${isPlaceholder ? " isPlaceholderHistoryRow" : ""}" data-path="${isPlaceholder ? "" : escapeHtml(path)}" aria-label="${escapeHtml(path)}">
        <td>${index + 1}</td>
        ${formatHistoryFileCellsHtml(value, "historyFile")}
      </tr>
    `;
  }).join("");

  body.querySelectorAll("tr").forEach(row => {
    const activate = () => {
      if (!row.dataset.path) return;
      openCode(row.dataset.path);
    };
    row.addEventListener("click", activate);
    if (row.dataset.path) {
      bindFullWidthHoverBandToRow(row, formatRecentTabFullPathBandText(row.dataset.path), activate);
    }
  });
}

function formatHistorySearchHtml(value) {
  if (isPlaceholderHistoryValue(value)) {
    return [HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE]
      .map((part, index) =>
        `<span class="historySearchToken historySearchToken-${index}">${escapeHtml(part)}</span>`
      )
      .join("");
  }

  return String(value || "")
    .split("|")
    .map(part => part.trim())
    .filter(Boolean)
    .map((part, index) =>
      `<span class="historySearchToken historySearchToken-${index}">${escapeHtml(part)}</span>`
    )
    .join("");
}

// 2026-07-29 再開修正3: AJAX検索ではブラウザ標準の入力履歴に残らないため、
// Krugle+ の検索履歴を datalist へ反映し、検索キーワード入力欄で候補表示できるようにする。
function parseSearchHistoryValue(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim());

  return {
    keyword: parts[0] || "",
    group: parts[1] || "ALL",
    language: parts[2] || "ALL"
  };
}

function getKeywordHistorySuggestions(values, limit = 100) {
  const result = [];
  const used = new Set();

  (Array.isArray(values) ? values : []).forEach(value => {
    const keyword = parseSearchHistoryValue(value).keyword;
    if (!keyword || isPlaceholderHistoryValue(keyword)) return;

    const key = keyword.toLowerCase();
    if (used.has(key)) return;

    used.add(key);
    result.push(keyword);
  });

  return result.slice(0, limit);
}

function renderKeywordHistoryDatalist(values) {
  const list = $("keywordHistoryList");
  if (!list) return;

  let sourceValues = Array.isArray(values)
    ? values
    : (USE_SAMPLE_DATA ? sampleSearchWords : readArray(SEARCH_HISTORY_STORAGE_KEY, []));

  if (!USE_SAMPLE_DATA && !Array.isArray(values)) {
    sourceValues = seedHistoryStorage(SEARCH_HISTORY_STORAGE_KEY, sourceValues, sampleSearchWords, INITIAL_HISTORY_SAMPLE_COUNT);
  }

  const suggestions = getKeywordHistorySuggestions(sourceValues);
  list.innerHTML = suggestions
    .map(keyword => `<option value="${escapeHtml(keyword)}"></option>`)
    .join("");
}

function setSelectValueByTextOrValue(selectElement, value, fallback = "ALL") {
  if (!selectElement) return;
  const target = String(value || fallback).trim();
  const normalizedTarget = target.toLowerCase();
  const option = Array.from(selectElement.options).find(item => {
    const optionValue = String(item.value || "").trim().toLowerCase();
    const optionText = String(item.textContent || "").trim().toLowerCase();
    return optionValue === normalizedTarget || optionText === normalizedTarget;
  });
  selectElement.value = option ? option.value : fallback;
}

function fillSearchFormFromHistory(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim());

  const keyword = parts[0] || "";
  const group = parts[1] || "ALL";
  const language = parts[2] || "ALL";

  const keywordInput = $("keywordInput");
  if (keywordInput) keywordInput.value = keyword;

  setSelectValueByTextOrValue($("groupSelect"), group, "ALL");
  refreshGroupCombo({ resetFilter: true });
  setSelectValueByTextOrValue($("languageSelect"), language, "ALL");
}

function openSearchFromHistory(value) {
  fillSearchFormFromHistory(value);
  showView("search");
  runSearch(true, "normal");
}

function resetStoredHistories() {
  // 履歴以外のlocalStorage設定やSessionStorageは残し、対象の2履歴だけを初期化する。
  localStorage.removeItem(FILE_HISTORY_STORAGE_KEY);
  localStorage.removeItem(SEARCH_HISTORY_STORAGE_KEY);
  localStorage.removeItem(FILE_HISTORY_INITIALIZED_VERSION_KEY);

  const initialFiles = createInitialFileHistorySeedValues().slice(0, INITIAL_HISTORY_SAMPLE_COUNT);
  const initialWords = normalizeHistoryValues(sampleSearchWords).slice(0, INITIAL_HISTORY_SAMPLE_COUNT);

  saveArray(FILE_HISTORY_STORAGE_KEY, initialFiles);
  saveArray(SEARCH_HISTORY_STORAGE_KEY, initialWords);
  localStorage.setItem(FILE_HISTORY_INITIALIZED_VERSION_KEY, FILE_HISTORY_INITIAL_VERSION);
  prioritizeGroupSelectOptionsByHistory();

  // 時刻タブも初期化後のファイル履歴から再構築する。
  sessionRecentTabs = null;
  recentWindowStart = 0;
  activeRecentTabKey = "";
  volatileVisitedRecentTabIds.clear();
  renderRecentTabs();
  renderHistory();
  showCopyFeedback("履歴を30件の初期データに戻しました");
}

function renderHistory() {
  let files = readFileHistoryValues();
  let words = USE_SAMPLE_DATA ? sampleSearchWords : readArray(SEARCH_HISTORY_STORAGE_KEY, []);

  if (!USE_SAMPLE_DATA) {
    words = seedHistoryStorage(SEARCH_HISTORY_STORAGE_KEY, words, sampleSearchWords, INITIAL_HISTORY_SAMPLE_COUNT);
  }

  const displayFiles = getDisplayFileHistoryRows(files, FILE_HISTORY_HOME_DISPLAY_LIMIT);
  const displayWords = getDisplayHistoryRows(words, INITIAL_HISTORY_SAMPLE_COUNT);

  renderKeywordHistoryDatalist(words);
  renderGlobalHistoryMini(displayFiles);

  $("historyFileBody").innerHTML = displayFiles.map((value, index) => {
    const path = getHistoryEntryPath(value);
    const isPlaceholder = !isValidFileHistoryPath(path);
    return `
      <tr class="${isPlaceholder ? "isPlaceholderHistoryRow" : ""}" data-path="${isPlaceholder ? "" : escapeHtml(path)}" aria-label="${escapeHtml(path)}">
        <td>${index + 1}</td>
        ${formatHistoryFileCellsHtml(value, "historyFile")}
      </tr>
    `;
  }).join("");

  $("historySearchBody").innerHTML = displayWords.map((value, index) => {
    const isPlaceholder = isPlaceholderHistoryValue(value);
    return `
      <tr class="${isPlaceholder ? "isPlaceholderHistoryRow" : ""}" data-keyword="${isPlaceholder ? "" : escapeHtml(value)}" aria-label="${escapeHtml(value)}">
        <td>${index + 1}</td>
        <td class="historySearchText">${formatHistorySearchHtml(value)}</td>
      </tr>
    `;
  }).join("");

  document.querySelectorAll("#historyFileBody tr").forEach(row => {
    const activate = () => {
      if (!row.dataset.path) return;
      openCode(row.dataset.path);
    };
    row.addEventListener("click", activate);
    if (row.dataset.path) {
      bindFullWidthHoverBandToRow(row, formatRecentTabFullPathBandText(row.dataset.path), activate);
    }
  });
  document.querySelectorAll("#historySearchBody tr").forEach(row => {
    const activate = () => {
      if (!row.dataset.keyword) return;
      openSearchFromHistory(row.dataset.keyword);
    };
    row.addEventListener("click", activate);
    if (row.dataset.keyword) {
      bindFullWidthHoverBandToRow(row, createHistorySearchBandText(row.dataset.keyword), activate);
    }
  });
}

function setActiveTab(viewName) {
  document.querySelectorAll(".tabBtn").forEach(button => button.classList.remove("isActive"));
  if (viewName !== "code") {
    document.querySelectorAll(".tabTime").forEach(button => button.classList.remove("isActive"));
  }
  const target = document.querySelector(`.tabBtn[data-view="${viewName}"]:not(.tabFile)`);
  if (target) target.classList.add("isActive"); }


function getWindowScrollTopForCodeSearchPanel() {
  const doc = document.documentElement;
  const body = document.body;
  return Math.max(
    0,
    Number(window.pageYOffset || 0),
    Number(doc && doc.scrollTop || 0),
    Number(body && body.scrollTop || 0)
  );
}

let codeSearchPanelScrollAnimationFrame = 0;

function isCodeSearchPanelScrollAutoHideTarget() {
  const codeView = $("codeView");
  return Boolean(document.body && document.body.classList.contains("isCodeScreen") && codeView && codeView.classList.contains("isVisible"));
}

function updateCodeSearchPanelScrollState() {
  if (!document.body) return;
  if (!isCodeSearchPanelScrollAutoHideTarget()) {
    document.body.classList.remove("isCodeSearchPanelScrolled");
    return;
  }

  const shouldHide = getWindowScrollTopForCodeSearchPanel() > 12;
  document.body.classList.toggle("isCodeSearchPanelScrolled", shouldHide);
}

function requestCodeSearchPanelScrollStateUpdate() {
  if (codeSearchPanelScrollAnimationFrame) return;
  codeSearchPanelScrollAnimationFrame = window.requestAnimationFrame
    ? window.requestAnimationFrame(() => {
        codeSearchPanelScrollAnimationFrame = 0;
        updateCodeSearchPanelScrollState();
      })
    : window.setTimeout(() => {
        codeSearchPanelScrollAnimationFrame = 0;
        updateCodeSearchPanelScrollState();
      }, 16);
}

function showView(viewName, options = {}) {
  if ((viewName === "home" || viewName === "search") && options.recordNavigation !== false) {
    recordTabNavigation(createViewTabNavigationEntry(viewName));
  }

  // コード取得中にホーム・検索結果へ戻った場合、遅れて返った/source結果で状態を上書きさせない。
  if (viewName !== "code") sourceOpenRequestSequence += 1;

  currentView = viewName;
  document.body.classList.toggle("isCodeScreen", viewName === "code");
  document.querySelectorAll(".viewBlock").forEach(view => view.classList.remove("isVisible"));
  const targetView = $(`${viewName}View`);
  if (targetView) targetView.classList.add("isVisible");
  setActiveTab(viewName);
  if (viewName === "home") renderHistory();
  if (viewName === "code") renderCode();
  requestCodeSearchPanelScrollStateUpdate();
}

function getDirectoryGroup(path) {
  return extractDirectoryGroupFromPath(path);
}

function nowForSearchPerformance() {
  return (window.performance && typeof window.performance.now === "function") ? window.performance.now() : Date.now();
}

function roundSearchPerformanceMs(value) {
  return Math.round(Number(value || 0) * 10) / 10;
}

function logSearchPerformance(metrics) {
  if (!window.console || typeof window.console.info !== "function") return;
  console.info("Krugle+ search performance", metrics);
}

async function runSearch(saveHistory = true, mode = "normal", options = {}) {
  const startedAt = new Date();
  const params = options && options.paramsOverride
    ? Object.assign({}, options.paramsOverride)
    : buildSearchParams(mode);

  // 2026-08-12 fix47: ユーザー操作の検索でキーワードが空/記号だけの場合は、
  // 画面表示を変えず、履歴追加もServlet呼び出しも行わない。
  if (saveHistory && !hasExecutableSearchKeyword(params.rawKeyword)) return false;

  lastSearchMode = mode;
  lastSearchParams = params;

  if (saveHistory) {
    addHistory(SEARCH_HISTORY_STORAGE_KEY, `${params.rawKeyword} | ${params.projectText || params.project} | ${params.languageText || params.language}`, []);
    renderKeywordHistoryDatalist();
  }

  setSummaryFromParams(params, startedAt, null, "検索中");
  // 2026-08-12 fix63: 前回検索の分割描画が残っていても、次検索の「検索中」表示へ追記させない。
  searchRenderSequence += 1;
  currentRenderedSearchRows = [];
  const body = $("resultBody");
  if (body) body.innerHTML = `<tr><td colspan="5">検索中...</td></tr>`;

  if (USE_SAMPLE_DATA) {
    const endedAt = new Date(startedAt.getTime() + 1000);
    const sortedSampleRows = sortSearchResultsForDisplay(sampleResults);
    lastSearchResults = filterSearchResultsByDirectoryGroup(sortedSampleRows, params.directoryGroup);
    setSummaryFromParams(params, startedAt, endedAt, lastSearchResults.length);
    // 2026-08-04 サイト修正2: 検索実行だけでは、検索結果を閲覧履歴・ヘッダー数字タブへ登録しない。
    // 実際に検索結果行をクリック、またはEnterで開いたときだけ openCode() 経由で登録する。
    const sampleRenderStart = nowForSearchPerformance();
    const sampleRenderInfo = renderSearchRows(lastSearchResults, { normalized: true });
    logSearchPerformance({
      backend: "sample",
      rows: lastSearchResults.length,
      renderInitialMs: roundSearchPerformanceMs(nowForSearchPerformance() - sampleRenderStart),
      initialRows: sampleRenderInfo.initialRows,
      chunked: sampleRenderInfo.chunked
    });
    return;
  }

  try {
    // 2026-08-05 修正10:
    // ブラウザ -> Servlet は従来どおり /search POST。
    // Servlet 側で Krugle の get_csv.cgi を正規CSVとして取得・洗浄してJSON化する。
    // source_disp は get_csv.cgi の検索CSV取得では不要なため渡さない。
    const fetchStart = nowForSearchPerformance();
    const data = await fetchJson("/search", {
      path_output_format: "PATH",
      keyword: params.keyword,
      project: params.project,
      language: params.languageForApi,
      findin: params.findin,
      clone: params.clone
    }, { method: "POST" });
    const fetchEnd = nowForSearchPerformance();
    const endedAt = new Date();
    const serverRows = Array.isArray(data.rows) ? data.rows : data.results;
    const sortStart = nowForSearchPerformance();
    const sortedServerRows = sortSearchResultsForDisplay(serverRows);
    lastSearchResults = filterSearchResultsByDirectoryGroup(sortedServerRows, params.directoryGroup);
    const sortEnd = nowForSearchPerformance();
    setSummaryFromServer(data.summary, params, startedAt, endedAt, lastSearchResults.length);
    // 2026-08-04 サイト修正2: 検索実行だけでは、検索結果を閲覧履歴・ヘッダー数字タブへ登録しない。
    // 実際に検索結果行をクリック、またはEnterで開いたときだけ openCode() 経由で登録する。
    // 2026-08-03 サイト修正4: 検索結果はクライアント側で優先順に並び替えるため、
    // サーバー生成HTMLではなく、並び替え後の行データから再描画する。
    // 2026-08-12 fix63: 検索結果100件超は初期100行だけ先に描画し、残りは分割追加する。
    const renderStart = nowForSearchPerformance();
    const renderInfo = renderSearchRows(lastSearchResults, { normalized: true });
    const renderEnd = nowForSearchPerformance();
    logSearchPerformance({
      backend: data.backend || "krugle",
      rows: lastSearchResults.length,
      fetchMs: roundSearchPerformanceMs(fetchEnd - fetchStart),
      sortMs: roundSearchPerformanceMs(sortEnd - sortStart),
      renderInitialMs: roundSearchPerformanceMs(renderEnd - renderStart),
      initialRows: renderInfo.initialRows,
      chunked: renderInfo.chunked,
      server: data.performance || null
    });
  } catch (e) {
    console.error(e);
    lastSearchResults = [];
      setSummaryFromParams(params, startedAt, new Date(), 0);
    if (body) body.innerHTML = `<tr><td colspan="5">/search 接続失敗：${escapeHtml(e.message)}</td></tr>`;
    showCopyFeedback("/search 接続失敗");
  }
}

function applyInitialSearchCondition() {
  const keywordInput = $("keywordInput");
  const groupSelect = $("groupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  if (keywordInput) keywordInput.value = INITIAL_SEARCH_CONDITION.keyword;
  setSelectValueByTextOrValue(groupSelect, INITIAL_SEARCH_CONDITION.project, "ALL");
  setSelectValueByTextOrValue(languageSelect, INITIAL_SEARCH_CONDITION.language, "ALL");

  // 添付画面と同じく「Clone 非表示」は未チェック。APIには clone=YES を渡す。
  if (cloneCheck) cloneCheck.checked = false;

  // カスタム移行グループ表示が存在する場合も、選択文字を同期する。
  refreshGroupCombo({ resetFilter: true });
}

async function loadInitialSearchResult() {
  // 初回表示のMock/初期検索は、検索条件入力欄へ値を入れない。
  // 表示結果だけ KYF1940 / NIKKO.nkCCIS / Java 条件で取得する。
  clearInitialSearchForm();
  await runSearch(false, INITIAL_SEARCH_CONDITION.mode, {
    paramsOverride: buildSearchParamsFromCondition(INITIAL_SEARCH_CONDITION, INITIAL_SEARCH_CONDITION.mode),
    // 初期表示用の52件を、閲覧履歴・ヘッダー履歴へ自動登録しない。
    addResultsToFileHistory: false
  });
  clearInitialSearchForm();
}

async function openCode(path, options = {}) {
  const requestId = ++sourceOpenRequestSequence;
  currentCodePath = getHistoryEntryPath(path || currentCodePath);
  updateCodeContextFixedLabel(currentCodePath);
  const requestedPath = currentCodePath;
  currentCodeMeta = options.row ? Object.assign({}, options.row) : { path: currentCodePath };
  currentCodeMeta.path = currentCodePath;
  currentSourceText = "読み込み中...";
  currentSourceLanguage = inferLanguageFromPath(currentCodePath, currentCodeMeta.language || "java");
  activeCodePanel = "source";
  resetTableInfoState();

  let openedRecentItem = null;
  if (options.addRecent === false && options.recentItem) {
    openedRecentItem = normalizeRecentTab(options.recentItem, 0);
    setActiveRecentTabId(options.recentTabId || findRecentTabInstanceIdForItem(openedRecentItem));
    renderRecentTabs();
  } else {
    openedRecentItem = addRecentTab(currentCodePath, currentCodeMeta || {});
  }

  if (openedRecentItem && options.recordNavigation !== false) {
    recordTabNavigation(createRecentTabNavigationEntry(openedRecentItem, currentCodeMeta || {}));
  }

  // 開いた直後の最新履歴を、ホーム左側と同じ件数・並び・列データで右側にも反映する。
  renderGlobalHistoryMini(
    getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT)
  );

  showView("code", { recordNavigation: false });
  setCurrentTableNames([]);
  renderCode(currentSourceText, currentSourceLanguage);

  if (USE_SAMPLE_DATA) {
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    setCurrentTableNames(["MST_CUSTOMER", "KYF1940", "RPS_TABLE_LIST"]);
    currentSourceText = sampleCode;
    mergeCurrentTableNames(extractJavaTableNamesFromSource(currentSourceText));
    renderCode(currentSourceText, currentSourceLanguage);
    return;
  }

  const sourceParams = {
    path: currentCodeMeta.path || currentCodePath,
    fullPath: currentCodeMeta.path || currentCodePath,
    filePath: currentCodeMeta.path || currentCodePath,
    project: currentCodeMeta.project || "",
    href: currentCodeMeta.href || "",
    sourceUrl: currentCodeMeta.sourceUrl || "",
    language: currentSourceLanguage,
    source_disp: "YES"
  };

  // 2026-08-03 サイト修正9:
  // Javaクラス名ハイライトから開く場合は、フロントでは全パスを推測しきらず、
  // クラス名 + 遷移元情報をServletへ渡し、AI_FILE1のFULLPATH/FILEPATH解決をServlet側へ任せる。
  const sourceEndpoint = currentCodeMeta.javaClassName ? "/source-by-class" : "/source";
  if (currentCodeMeta.javaClassName) {
    sourceParams.className = currentCodeMeta.javaClassName;
    sourceParams.javaClassName = currentCodeMeta.javaClassName;
    // 2026-08-14 fix80: importに完全修飾クラス名が存在する場合は、単純クラス名と両方をServletへ渡す。
    // AI_FILE1で同名クラスが複数ヒットしても、Servlet側でpackage完全一致候補を最優先できるようにする。
    sourceParams.qualifiedClassName = currentCodeMeta.javaQualifiedClassName || currentCodeMeta.qualifiedClassName || "";
    sourceParams.javaQualifiedClassName = sourceParams.qualifiedClassName;
    sourceParams.importQualifiedClassName = sourceParams.qualifiedClassName;
    sourceParams.originPath = currentCodeMeta.originPath || currentCodeMeta.originFullPath || "";
    sourceParams.originFullPath = currentCodeMeta.originFullPath || currentCodeMeta.originPath || "";
    sourceParams.originProject = currentCodeMeta.originProject || "";
    sourceParams.originGroup = currentCodeMeta.originGroup || "";
    sourceParams.originDirectoryGroup = currentCodeMeta.originDirectoryGroup || "";
    sourceParams.originPackage = currentCodeMeta.originPackage || "";
  }
  // 2026-08-05 修正11: Krugle source_disp.cgi の実URLはServlet側で ? 以降を %2F 付きに正規エンコードする。
  const directUrl = `${apiPath(sourceEndpoint)}?${buildQueryString(sourceParams)}`;

  try {
    // sourceはGETで呼ぶ。ソース表示は /init 疎通確認を待たず、保存済み接続先または第1Servletへ直接取りに行く。
    const cacheKey = buildSourceResponseCacheKey(sourceEndpoint, sourceParams);
    const cachedData = readSourceResponseCache(cacheKey);
    const data = cachedData || await fetchSourceJsonFast(sourceEndpoint, sourceParams);
    if (!cachedData) writeSourceResponseCache(cacheKey, data);
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    if (data.resolvedPath || data.fullPath || data.path) {
      const resolvedPath = data.resolvedPath || data.fullPath || data.path;
      currentCodePath = getHistoryEntryPath(resolvedPath);
      updateCodeContextFixedLabel(currentCodePath);
      currentCodeMeta.path = currentCodePath;
      currentCodeMeta.fullPath = currentCodePath;
      currentCodeMeta.fileName = getRecentTabFileName(currentCodePath);
      currentCodeMeta.project = data.project || extractProjectFromPath(currentCodePath) || currentCodeMeta.project || "";
      currentCodeMeta.group = data.group || extractMigrationGroupFromPath(currentCodePath) || currentCodeMeta.group || "";
      currentCodeMeta.directoryGroup = data.directoryGroup || getRawDirectoryGroupFromPath(currentCodePath) || currentCodeMeta.directoryGroup || "";
    }
    currentSourceText = stripKrugleMockSourceBanner(data.source || data.text || "");
    currentSourceLanguage = data.language || currentSourceLanguage;

    // 2026-08-07 修正22:
    // /source ServletがRPS_TABLE_LIST照合済みの tableHighlightTargets を同梱するため、
    // 最初の renderCode() からテーブルハイライトを反映する。
    // 追加の /table-highlight-targets は、旧WAR応答・source-by-class・辞書更新時の保険として後続確認だけ行う。
    const initialTableTargets = getLegacyServerTableHighlightTargets(data);
    setCurrentTableNames(initialTableTargets);
    if (data.tableListError) {
      console.warn("table list load failed:", data.tableListError);
    }
    renderCode(currentSourceText, currentSourceLanguage);
    loadSourceTableHighlightTargetsInBackground(requestId, currentCodePath, currentSourceText, data, sourceEndpoint, initialTableTargets);
  } catch (e) {
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    console.error(e);
    currentSourceText = `/source 接続失敗

${e.message}

直接確認URL:
${directUrl}

確認ポイント:
1. krugleapi.war がCORS対応版か
2. /krugleapi/source が404にならないか
3. Chrome DevToolsのNetworkでAccess-Control-Allow-Originが返っているか`;
    renderCode(currentSourceText, "plaintext");
    showCopyFeedback("/source 接続失敗");
  }
}

function stripKrugleMockSourceBanner(sourceText) {
  const source = normalizeKrugleSourceText(String(sourceText || "").replace(/^\uFEFF/, ""));

  // 旧WARが付加していたMock説明コメントは、表示・Copy・Downloadの対象から除外する。
  return source
    .replace(/^[ \t]*\/\*[ \t]*Krugle Mock: embedded template=[\s\S]*?\*\/[ \t]*(?:\r?\n)?/, "")
    .replace(/^--[ \t]*Krugle Mock: embedded template=.*(?:\r?\n)?/, "")
    .replace(/^--[ \t]*Krugle Mock SQL[ \t]*(?:\r?\n)?/, "");
}

// 2026-08-05 修正8:
// Krugle source_disp.cgi が HTML(<pre><ol><li>...</li></ol></pre>)や制御文字を返す場合があるため、
// Java側Filterに加えてクライアント側でも保険としてプレーンソースへ整形する。
function normalizeKrugleSourceText(sourceText) {
  let source = String(sourceText || "")
    .replace(/^\uFEFF/, "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "");

  const htmlExtracted = extractKrugleHtmlListSource(source);
  if (htmlExtracted) {
    source = htmlExtracted;
  } else {
    source = removeAppendedKrugleHtmlDocument(source);
    source = decodeHtmlEntities(source);
  }

  return normalizeSourceLineBreaks(source);
}

function isKrugleSourceHtmlListDocument(sourceText) {
  const source = String(sourceText || "");
  if (!/<li\b/i.test(source) || !/<\/li>/i.test(source)) return false;
  if (!/<pre\b[^>]*>\s*<ol\b[^>]*>/i.test(source) || !/<\/ol>\s*<\/pre>/i.test(source)) return false;

  // 元Krugleのsource_disp.cgiは、タイトル/パス表示 + hr + pre/ol/li という骨格を持つ。
  if (/<p\b[^>]*>\s*<strong\b/i.test(source) && /<hr\b/i.test(source)) return true;

  // 骨格が一部欠けた応答でも、liの中身がHTMLエスケープされたソース行ならKrugle wrapperとして扱う。
  // 逆に、JSP/HTMLソース本文そのものに <html>/<li> が含まれるだけの場合は、ここで除外する。
  const bodies = [];
  source.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi, (_, body) => {
    if (bodies.length < 12) bodies.push(String(body || ""));
    return "";
  });
  if (!bodies.length) return false;

  const encodedLineCount = bodies.filter(body => /&(?:lt|gt|quot|apos|amp|#\d+|#x[0-9a-f]+);/i.test(body)).length;
  return encodedLineCount >= Math.min(2, bodies.length);
}

function extractKrugleHtmlListSource(sourceText) {
  const source = String(sourceText || "");
  if (!isKrugleSourceHtmlListDocument(source)) return "";

  const lines = [];
  source.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi, (_, body) => {
    const line = decodeHtmlEntities(stripHtmlTags(String(body || "")))
      .replace(/[\r\n]+/g, "")
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
      .replace(/[ \t\f]+$/g, "");
    lines.push(line);
    return "";
  });

  return lines.length ? lines.join("\n") : "";
}

function removeAppendedKrugleHtmlDocument(sourceText) {
  const source = String(sourceText || "");
  const htmlIndex = source.search(/<html\b/i);
  if (htmlIndex < 0) return source;

  const before = source.substring(0, htmlIndex);
  if (!before.trim()) return source;

  // 2026-08-13 fix74:
  // JSP/HTMLソース本文は「JSPディレクティブ/DOCTYPE の後に <HTML> が続く」形が普通にある。
  // 旧処理は、その <HTML> を「Krugleが後ろに付けた余分なHTML文書」と誤認し、
  // <%@ page ... %> と <!DOCTYPE ...> の2行だけを残して以降を削っていた。
  // 先頭側がマークアップソースらしい場合は絶対に切り捨てない。
  if (looksLikeMarkupSourcePrefix(before)) return source;

  const appended = source.substring(htmlIndex);
  // 余分なKrugle HTMLフッター/ラッパーらしい骨格がある場合だけ、保険として切り離す。
  // 単にコード中に <html> という文字列が現れた程度では削らない。
  if (looksLikeAppendedKrugleHtmlDocument(appended)) {
    return before;
  }
  return source;
}

function looksLikeMarkupSourcePrefix(text) {
  const value = String(text || "").trim().toLowerCase();
  if (!value) return false;
  return value.indexOf("<%@") >= 0
    || value.indexOf("<%--") >= 0
    || value.indexOf("<jsp:") >= 0
    || value.indexOf("<!doctype") >= 0
    || value.indexOf("<?xml") >= 0
    || value.indexOf("<!--") >= 0;
}

function looksLikeAppendedKrugleHtmlDocument(text) {
  const value = String(text || "").toLowerCase();
  if (value.indexOf("<html") < 0 || value.indexOf("</html>") < 0) return false;
  return value.indexOf("source_disp.cgi") >= 0
    || value.indexOf("krugle") >= 0
    || /<p\b[^>]*>\s*<strong\b/i.test(text)
    || /<pre\b[^>]*>\s*<ol\b[^>]*>/i.test(text);
}

function stripHtmlTags(value) {
  return String(value || "")
    .replace(/<br\s*\/?\s*>/gi, "\n")
    .replace(/<\/(p|div|li)\s*>/gi, "\n")
    .replace(/<[^>]+>/g, "");
}

function decodeHtmlEntities(value) {
  const text = String(value || "")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&");

  return text.replace(/&#(x[0-9a-f]+|\d+);/gi, (_, code) => {
    const radix = /^x/i.test(code) ? 16 : 10;
    const normalizedCode = /^x/i.test(code) ? code.substring(1) : code;
    const value = parseInt(normalizedCode, radix);
    return Number.isFinite(value) ? String.fromCharCode(value) : _;
  });
}

function normalizeSourceLineBreaks(sourceText) {
  const lines = String(sourceText || "")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .split("\n")
    .map(line => line.replace(/[ \t\f]+$/g, ""));

  let start = 0;
  let end = lines.length - 1;
  while (start <= end && lines[start].trim().length === 0) start += 1;
  while (end >= start && lines[end].trim().length === 0) end -= 1;
  if (start > end) return "";

  const removeOneBlankFromEachGap = isLikelyParserInsertedBlankLines(lines, start, end);
  const normalized = [];
  let pendingBlanks = 0;
  let wroteNonBlank = false;

  for (let i = start; i <= end; i += 1) {
    const line = lines[i];
    if (line.trim().length === 0) {
      pendingBlanks += 1;
      continue;
    }

    if (wroteNonBlank && pendingBlanks > 0) {
      const keep = removeOneBlankFromEachGap ? Math.max(0, pendingBlanks - 1) : Math.min(pendingBlanks, 1);
      for (let k = 0; k < keep; k += 1) normalized.push("");
    }
    normalized.push(line);
    wroteNonBlank = true;
    pendingBlanks = 0;
  }

  return normalized.join("\n");
}

function isLikelyParserInsertedBlankLines(lines, start = 0, end = lines.length - 1) {
  let nonBlank = 0;
  let gapCount = 0;
  let positiveGaps = 0;
  let oneBlankGaps = 0;
  let blankLines = 0;
  let pendingBlanks = -1;
  let currentOneBlankStreak = 0;
  let maxOneBlankStreak = 0;

  for (let i = start; i <= end; i += 1) {
    const blank = String(lines[i] || "").trim().length === 0;
    if (blank) {
      blankLines += 1;
      if (pendingBlanks >= 0) pendingBlanks += 1;
      continue;
    }

    nonBlank += 1;
    if (pendingBlanks >= 0) {
      gapCount += 1;
      if (pendingBlanks > 0) {
        positiveGaps += 1;
        if (pendingBlanks === 1) {
          oneBlankGaps += 1;
          currentOneBlankStreak += 1;
          maxOneBlankStreak = Math.max(maxOneBlankStreak, currentOneBlankStreak);
        } else {
          currentOneBlankStreak = 0;
        }
      } else {
        currentOneBlankStreak = 0;
      }
    }
    pendingBlanks = 0;
  }

  if (nonBlank < 12 || gapCount < 10 || blankLines < 8) return false;
  if (maxOneBlankStreak >= 8 && oneBlankGaps >= 8) return true;
  return positiveGaps * 100 >= gapCount * 35 && oneBlankGaps * 100 >= positiveGaps * 65;
}

function renderCode(sourceText = currentSourceText, language = currentSourceLanguage) {
  const codeView = $("codeView");
  const codeBlock = $("codeBlock");
  const tableInfoPanel = $("tableInfoPanel");
  const codeBodyFrame = codeView ? codeView.querySelector(".codeBodyFrame") : null;
  const tableMode = isTableInfoPanel(activeCodePanel);
  if (tableMode) {
    activeTableInfoTabId = getTableInfoTabIdFromPanel(activeCodePanel) || activeTableInfoTabId;
    tableInfoState = getActiveTableInfoState();
  }

  const tableDetailMode = tableMode && tableInfoState && tableInfoState.status === "detail";
  if (codeView) {
    codeView.classList.toggle("isTableInfoMode", tableMode);
    codeView.classList.toggle("isTableInfoDetailMode", tableDetailMode);
  }
  if (tableInfoPanel) tableInfoPanel.hidden = !tableMode;
  if (codeBodyFrame) codeBodyFrame.hidden = tableMode;

  document.querySelectorAll(".codeModeTab").forEach(button => {
    button.classList.toggle("isActive", button.dataset.codePanel === activeCodePanel);
  });

  // fix82: openCode以外の再描画経路でも、ソースタブのファイル名バッジを現在パスへ同期する。
  updateCodeContextFixedLabel(currentCodePath);

  if (tableMode) {
    const titleElement = $("codeTitle");
    if (titleElement) {
      // 2026-08-12 fix48: テーブル詳細表示時も、codeTitleにテーブル名/DBTYPE/スキーマ/Versionを表示する。
      titleElement.textContent = getTableInfoTitle();
    }
    renderTableInfoPanel();
    renderRecentTabs();
    return;
  }

  const source = stripKrugleMockSourceBanner(sourceText || (USE_SAMPLE_DATA ? sampleCode : ""));
  let displayText = source;
  let displayLanguage = language || inferLanguageFromPath(currentCodePath, "java");

  if (activeCodePanel === "ai") {
    displayText = sampleAiCode;
    displayLanguage = "java";
  } else if (activeCodePanel === "summary") {
    displayText = sampleSummaryText;
    displayLanguage = "plaintext";
  }

  if (codeView) codeView.classList.remove("isTableInfoDetailMode");
  $("codeTitle").textContent = currentCodePath || "";

  displayLanguage = resolveHighlightDisplayLanguage(displayLanguage, currentCodePath);

  codeBlock.removeAttribute("data-highlighted");
  delete codeBlock.dataset.highlighted;

  const safeMarkupHighlight = activeCodePanel === "source"
    && isSafeMarkupHighlightSource(displayLanguage, currentCodePath);
  const safePlainSource = activeCodePanel === "source"
    && shouldRenderSourceAsSafePlainText(displayLanguage, currentCodePath, displayText);

  if (safePlainSource) {
    renderSourceAsSafePlainText(codeBlock, displayText || "");
  } else {
    codeBlock.removeAttribute("data-safe-plain-source");
    if (safeMarkupHighlight) {
      // fix89: JSP/HTML/XMLはソース文字列をinnerHTMLへ直接入れない。
      // textContentでDOMへ投入してからhighlight.js(xml)に処理させることで、<script>やJSP式を実行させない。
      displayLanguage = "xml";
      codeBlock.className = "language-xml safeMarkupHighlightedSource";
      codeBlock.setAttribute("data-safe-markup-highlight", "true");
    } else {
      codeBlock.removeAttribute("data-safe-markup-highlight");
      codeBlock.className = `language-${displayLanguage}`;
    }
    codeBlock.textContent = displayText || "";
  }
  setCodeFontSize(codeFontSize);

  if (!safePlainSource && window.hljs) {
    try {
      window.hljs.highlightElement(codeBlock);
      // highlight.jsが生成したDOMを後段で必ず検査し、SPAN以外の実行可能要素/属性を残さない。
      enforceSafeCodeBlockDom(codeBlock);
    } catch (error) {
      console.warn("highlight.js failed. fallback:", displayLanguage, error);
      codeBlock.removeAttribute("data-highlighted");
      delete codeBlock.dataset.highlighted;
      codeBlock.textContent = displayText || "";
      if (safeMarkupHighlight) {
        // マークアップソースをbashへ誤判定させず、安全なプレーン表示へ戻す。
        codeBlock.removeAttribute("data-safe-markup-highlight");
        renderSourceAsSafePlainText(codeBlock, displayText || "");
      } else {
        displayLanguage = "bash";
        codeBlock.className = "language-bash";
        try {
          window.hljs.highlightElement(codeBlock);
          enforceSafeCodeBlockDom(codeBlock);
        } catch (fallbackError) {
          console.warn("highlight.js bash fallback failed:", fallbackError);
          codeBlock.className = "language-plaintext hljs";
          codeBlock.textContent = displayText || "";
        }
      }
    }
  }

  if (!safePlainSource) enforceSafeCodeBlockDom(codeBlock);

  if (activeCodePanel === "source" && !safePlainSource && !safeMarkupHighlight) {
    enhanceSourceHighlights(codeBlock, {
      language: displayLanguage,
      path: currentCodePath
    });
    enforceSafeCodeBlockDom(codeBlock);
  }

  renderRecentTabs();
}

function updateHighlightToggleButton() {
  const button = $("highlightToggleBtn");
  if (!button) return;

  const enabled = codeHighlightBackgroundEnabled === true;
  const nextState = enabled ? "OFF" : "ON";

  button.classList.toggle("isOn", enabled);
  button.classList.toggle("isOff", !enabled);
  button.setAttribute("aria-pressed", enabled ? "true" : "false");
  button.setAttribute(
    "aria-label",
    `ハイライト表示は現在${enabled ? "ON" : "OFF"}です。クリックすると${nextState}になります。`
  );
  button.title = `ハイライト表示: ${enabled ? "ON" : "OFF"}（背景色のみ切替）`;

  const label = document.createElement("span");
  label.className = "highlightToggleLabel";
  label.textContent = "ハイライト表示";

  const off = document.createElement("span");
  off.className = "highlightToggleChoice highlightToggleChoiceOff" + (!enabled ? " isActive" : "");
  off.textContent = "OFF";
  off.setAttribute("aria-hidden", "true");

  const on = document.createElement("span");
  on.className = "highlightToggleChoice highlightToggleChoiceOn" + (enabled ? " isActive" : "");
  on.textContent = "ON";
  on.setAttribute("aria-hidden", "true");

  button.replaceChildren(label, off, on);
}

function setCodeHighlightBackgroundEnabled(enabled) {
  codeHighlightBackgroundEnabled = enabled === true;

  const codeView = $("codeView");
  if (codeView) {
    codeView.classList.toggle("isHighlightBackgroundOn", codeHighlightBackgroundEnabled);
    codeView.classList.toggle("isHighlightBackgroundOff", !codeHighlightBackgroundEnabled);
  }

  updateHighlightToggleButton();
}

function toggleCodeHighlightBackground() {
  setCodeHighlightBackgroundEnabled(!codeHighlightBackgroundEnabled);
}

function normalizeTableNames(tableNames) {
  const out = [];
  const seen = new Set();
  (Array.isArray(tableNames) ? tableNames : []).forEach(value => {
    const name = String(value == null ? "" : value).trim();
    // 2026-07-31 修正2: テーブル名は大文字小文字を区別する。
    // KYF0010 と Kyf0010 は別物として扱い、登録時も大文字化しない。
    if (!name || seen.has(name)) return;
    seen.add(name);
    out.push(name);
  });
  return out;
}

function setCurrentTableNames(tableNames) {
  currentTableNames = normalizeTableNames(tableNames);
  currentTableNameSet = new Set(currentTableNames);
}

function mergeCurrentTableNames(tableNames) {
  if (!Array.isArray(tableNames) || tableNames.length === 0) return;
  setCurrentTableNames((currentTableNames || []).concat(tableNames));
}

function getLegacyServerTableHighlightTargets(data) {
  if (!data || typeof data !== "object") return [];
  return normalizeTableNames(data.tableHighlightTargets || data.tableNames || []);
}

function buildTableHighlightCandidateTokens(sourceText, legacyTargets = []) {
  const tokens = [];
  const seen = new Set();
  const add = value => {
    const token = String(value == null ? "" : value).trim();
    if (!/^[A-Z][A-Z0-9_$#]{2,}$/.test(token)) return;
    if (seen.has(token)) return;
    seen.add(token);
    tokens.push(token);
  };

  (Array.isArray(legacyTargets) ? legacyTargets : []).forEach(add);

  const source = String(sourceText || "");
  const pattern = /(^|[^A-Za-z0-9_$#])([A-Z][A-Z0-9_$#]{2,})(?=$|[^A-Za-z0-9_$#])/g;
  let match;
  while ((match = pattern.exec(source)) !== null) {
    add(match[2]);
    if (tokens.length >= 5000) break;
  }
  return tokens;
}

async function loadSourceTableHighlightTargets(sourceText, sourceResponseData = {}, options = {}) {
  const legacyTargets = getLegacyServerTableHighlightTargets(sourceResponseData);
  const candidates = buildTableHighlightCandidateTokens(sourceText, legacyTargets);
  if (candidates.length === 0) return [];

  try {
    const params = {
      mode: "highlightTargets",
      candidates: candidates.join("\n")
    };
    const source = String(sourceText || "");
    if (source.length > 0 && source.length <= 200000) {
      params.source = source;
    }

    const data = await fetchJson(TABLE_HIGHLIGHT_ENDPOINT, params, {
      method: "POST",
      timeoutMs: API_ACCESS_TIMEOUT_MS,
      transport: "fetch"
    });

    if (data && data.ok === true) {
      return normalizeTableNames(data.tableHighlightTargets || data.tableNames || []);
    }
    console.warn("table highlight target validation failed:", data && data.error ? data.error : data);
  } catch (e) {
    console.warn("table highlight target validation failed:", e);
  }

  // 旧 /source は既にRPS_TABLE_LIST照合済みのため、検証APIが失敗した場合だけ互換フォールバックする。
  // /source-by-class は旧Servletが大文字語を広く返すため、失敗時は誤ハイライト防止を優先して空にする。
  return options.allowLegacyFallback === true ? legacyTargets : [];
}

function areSameTableTargets(left, right) {
  const a = normalizeTableNames(left);
  const b = normalizeTableNames(right);
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i += 1) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

function loadSourceTableHighlightTargetsInBackground(requestId, requestedPath, sourceText, sourceResponseData, sourceEndpoint, initialTargets) {
  window.setTimeout(async () => {
    const tableTargets = await loadSourceTableHighlightTargets(sourceText, sourceResponseData, {
      allowLegacyFallback: sourceEndpoint !== "/source-by-class"
    });
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    if (activeCodePanel !== "source") return;
    if (areSameTableTargets(initialTargets, tableTargets)) return;
    setCurrentTableNames(tableTargets);
    renderCode(currentSourceText, currentSourceLanguage);
  }, 0);
}

function isJavaSourceForTableHighlight(language, path) {
  const normalized = normalizeHighlightLanguage(language);
  return normalized === "java" || /\.java(?:$|[?#])/i.test(String(path || ""));
}

function extractJavaTableNamesFromSource(sourceText) {
  const source = String(sourceText || "");
  const out = [];
  const seen = new Set();
  const pattern = /\b([A-Z][A-Za-z0-9_$]*?)Table(?:Accessor|Record(?:Value|PKey)?|Record|Data)?\b/g;
  let match;

  while ((match = pattern.exec(source)) !== null) {
    const rawName = String(match[1] || "").replace(/[$_#]+$/g, "");
    if (!rawName || !/[0-9]/.test(rawName)) continue;

    const normalized = rawName.toUpperCase();
    if (normalized.length < 4 || seen.has(normalized)) continue;
    seen.add(normalized);
    out.push(normalized);
  }

  return out;
}

function normalizeHighlightLanguage(language) {
  const rawValue = String(language || "")
    .toLowerCase()
    .trim()
    .replace(/^language-/, "");
  if (!rawValue) return "plaintext";

  const aliasMap = {
    "shell": "bash",
    "shell script": "bash",
    "c++": "cpp",
    "c#": "csharp",
    "html": "xml",
    "xhtml": "xml"
  };
  const value = aliasMap[rawValue] || rawValue;

  // classNameへ入る言語名を安全なトークンに制限する。
  // 不正文字を含む値は、highlight.jsへ渡さずplaintextへ落とす。
  if (!/^[a-z0-9][a-z0-9_+.#-]*$/.test(value)) return "plaintext";

  if (value === "java") return "java";
  if (value === "sql") return "sql";
  return value;
}

function enhanceSourceHighlights(codeBlock, options = {}) {
  if (!codeBlock || !codeBlock.textContent) return;

  const language = normalizeHighlightLanguage(options.language || inferLanguageFromPath(options.path || currentCodePath, "plaintext"));
  const path = String(options.path || currentCodePath || "");
  const isJava = language === "java" || /\.java(?:$|[?#])/i.test(path);
  const javaSourceClassName = isJava ? getJavaSourceClassName(path) : "";
  const tableSet = currentTableNameSet || new Set();
  // 2026-07-31 修正2: KYF0010Accessor のような識別子内部のテーブル名はハイライトしない。
  // テーブル名は、前後が半角スペースの完全一致だけを対象にする。
  const javaEmbeddedTableNames = [];
  const fullText = codeBlock.textContent || "";

  // フレームワーク側（package に appfw を含む .java）は、テーブル名・Javaクラス名ともに自前ハイライトしない。
  const javaCommentRanges = isJava ? findJavaCommentRanges(fullText) : [];
  const javaLiteralRanges = isJava ? findJavaLiteralRanges(fullText) : [];
  const javaImportExclusions = isJava ? buildJavaImportHighlightExclusions(fullText) : new Set();
  const javaPublicClassLineRanges = isJava ? findJavaPublicClassLineRanges(fullText) : [];
  const javaExtendsClauseRanges = isJava
    ? findJavaExtendsClauseRanges(fullText, javaCommentRanges, javaLiteralRanges)
    : [];

  const textNodes = collectHighlightTargetTextNodes(codeBlock, isJava);
  textNodes.forEach(item => replaceTextNodeWithCodeHighlights(item, {
    isJava,
    tableSet,
    fullText,
    javaCommentRanges,
    javaLiteralRanges,
    javaImportExclusions,
    javaPublicClassLineRanges,
    javaExtendsClauseRanges,
    javaSourceClassName,
    javaEmbeddedTableNames
  }));
}

function collectHighlightTargetTextNodes(root, isJava) {
  const result = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let offset = 0;

  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue || "";
    const start = offset;
    offset += text.length;

    if (!text || !CODE_IDENTIFIER_PATTERN.test(text)) {
      CODE_IDENTIFIER_PATTERN.lastIndex = 0;
      continue;
    }
    CODE_IDENTIFIER_PATTERN.lastIndex = 0;

    const parent = node.parentElement;
    if (!parent) continue;
    if (parent.closest && parent.closest(".codeKeywordLink")) continue;

    // .java でもテーブル名はコメント・文字列・Accessor名の中に出るため、
    // ここではコメントを除外しない。Javaクラス名側の除外は classifyCodeKeyword で行う。

    result.push({ node, text, start });
  }
  return result;
}

function replaceTextNodeWithCodeHighlights(item, context) {
  const node = item.node;
  const text = item.text;
  const start = item.start;
  const fragment = document.createDocumentFragment();
  let lastIndex = 0;
  CODE_IDENTIFIER_PATTERN.lastIndex = 0;
  let match;

  while ((match = CODE_IDENTIFIER_PATTERN.exec(text)) !== null) {
    const keyword = match[0];
    const index = match.index;
    const globalIndex = start + index;
    const embeddedTable = findJavaEmbeddedTableNameMatch(keyword, globalIndex, context);
    const highlight = embeddedTable ? null : classifyCodeKeyword(keyword, globalIndex, context);

    if (index > lastIndex) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex, index)));
    }

    if (embeddedTable) {
      if (embeddedTable.start > 0) {
        fragment.appendChild(document.createTextNode(keyword.slice(0, embeddedTable.start)));
      }

      const tableText = keyword.slice(embeddedTable.start, embeddedTable.end);
      fragment.appendChild(createCodeKeywordLink(tableText, {
        type: "table",
        className: "codeTableKeyword",
        title: embeddedTable.tableName + " テーブル名"
      }, embeddedTable.tableName));

      if (embeddedTable.end < keyword.length) {
        fragment.appendChild(document.createTextNode(keyword.slice(embeddedTable.end)));
      }
    } else if (highlight) {
      fragment.appendChild(createCodeKeywordLink(keyword, highlight, keyword));
    } else {
      fragment.appendChild(document.createTextNode(keyword));
    }

    lastIndex = index + keyword.length;
  }

  if (lastIndex < text.length) {
    fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
  }

  if (node.parentNode) node.parentNode.replaceChild(fragment, node);
}

function createCodeKeywordLink(keyword, highlight, datasetKeyword) {
  const link = document.createElement("button");
  link.type = "button";
  link.className = "codeKeywordLink " + highlight.className;
  link.dataset.keyword = datasetKeyword || keyword;
  link.dataset.keywordType = highlight.type;
  link.style.setProperty("--keyword-hit-width", "calc(" + keyword.length + "ch + 1.7em)");
  link.textContent = keyword;
  link.title = highlight.title;
  return link;
}

function buildJavaEmbeddedTableNameCandidates(tableNames) {
  return normalizeTableNames(tableNames)
    .filter(name => /^[A-Z0-9_#$]+$/i.test(name) && /[0-9_]/.test(name) && name.length >= 4)
    .sort((a, b) => b.length - a.length);
}

function findJavaEmbeddedTableNameMatch(keyword, globalIndex, context) {
  // 2026-07-31 修正2:
  // テーブル名は大文字小文字を区別し、かつ前後が半角スペースの完全一致のみハイライトする。
  // そのため KYF0010Accessor / Kyf0010TableAccessor のような識別子内部の部分一致は対象外。
  return null;
}

function isTableKeywordHighlightTarget(keyword, globalIndex, context) {
  const tableSet = context && context.tableSet;
  if (!keyword || !tableSet || !tableSet.has(keyword)) return false;

  const source = String(context && context.fullText || "");
  const start = Number(globalIndex) || 0;
  const end = start + String(keyword).length;
  const before = start > 0 ? source.charAt(start - 1) : "";
  const after = end < source.length ? source.charAt(end) : "";

  // 2026-08-03 サイト修正5:
  // テーブル名の大文字小文字は区別したまま、判定時だけ前後の区切り記号を半角スペース扱いにする。
  // 例: ="KYF0010" / {KYF0010} / (KYF0010) / タブや全角スペース前後は対象。
  // 例: KYF0010Accessor / KYF0010_TABLE のように英数字・_・$・# と連続するものは対象外。
  return isTableHighlightSeparator(before) && isTableHighlightSeparator(after);
}

function isTableHighlightSeparator(value) {
  if (value == null || value === "") return true;
  const ch = String(value).charAt(0);
  if (/\s/.test(ch) || ch === "　") return true;

  // テーブル名・Java/SQL識別子の一部として扱う文字は、半角スペースへ置換しない。
  // それ以外の半角記号・全角記号は、ハイライト判定上は半角スペース扱いにする。
  return !/[A-Za-z0-9_$#]/.test(ch);
}

function classifyCodeKeyword(keyword, globalIndex, context) {
  const isJava = context.isJava;
  const tableSet = context.tableSet;
  const fullText = context.fullText;
  const javaCommentRanges = context.javaCommentRanges || [];
  const javaLiteralRanges = context.javaLiteralRanges || [];
  const javaImportExclusions = context.javaImportExclusions || new Set();
  const javaPublicClassLineRanges = context.javaPublicClassLineRanges || [];
  const javaExtendsClauseRanges = context.javaExtendsClauseRanges || [];
  const javaSourceClassName = String(context.javaSourceClassName || "");

  // 2026-08-03 サイト修正5:
  // テーブル名は .java / .sql などファイル種別にかかわらず、以下の同一ルールでハイライトする。
  // - 大文字小文字を区別する
  // - 前後のタブ・全角スペース・記号を半角スペース扱いにした上で、独立したテーブル名だけ対象にする
  if (isTableKeywordHighlightTarget(keyword, globalIndex, context)) {
    return {
      type: "table",
      className: "codeTableKeyword",
      title: keyword + " テーブル名"
    };
  }

  // 表示中の .java ファイル自身のクラス名は、自前ハイライトの対象外にする。
  // 例: KakzJohoSyutkQueryAccessor.java -> KakzJohoSyutkQueryAccessor は強調しない。
  if (isJava && javaSourceClassName && keyword === javaSourceClassName) {
    return null;
  }

  if (isJava && (
    isJavaPackageOrImportLineAt(fullText, globalIndex) ||
    isIndexInRanges(globalIndex, javaCommentRanges) ||
    isIndexInRanges(globalIndex, javaLiteralRanges) ||
    isIndexInRanges(globalIndex, javaPublicClassLineRanges) ||
    isIndexInRanges(globalIndex, javaExtendsClauseRanges)
  )) {
    return null;
  }

  // java.sql/java.util などの標準パッケージ、com.cm.com.、appfw 由来のクラスはハイライトしない。
  if (isJava && (
    javaImportExclusions.has(keyword) ||
    isJavaOrFrameworkQualifiedIdentifierAt(fullText, globalIndex)
  )) {
    return null;
  }

  if (isJava && isJavaClassNameCandidate(keyword)) {
    return {
      type: "java-class",
      className: "codeJavaClassKeyword",
      title: keyword + " Javaクラス名"
    };
  }

  return null;
}

function getJavaSourceClassName(path) {
  const cleanPath = String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/");
  const fileName = cleanPath.substring(cleanPath.lastIndexOf("/") + 1);
  return /\.java$/i.test(fileName) ? fileName.slice(0, -5) : "";
}


// 2026-08-03 サイト修正8:
// Javaクラス名ハイライトをクリックした場合、現在表示中ソースのimport/packageと
// 現在のKrugleフルパスから、Servlet /source に渡せるフルパスへ解決する。
function escapeRegExp(text) {
  return String(text || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function getCleanSourcePath(path) {
  return String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/")
    .replace(/\/+/g, "/");
}

function getDirectoryPath(path) {
  const cleanPath = getCleanSourcePath(path).replace(/\/+$/, "");
  const slash = cleanPath.lastIndexOf("/");
  return slash >= 0 ? cleanPath.substring(0, slash) : "";
}

function getJavaPackageRootPrefixFromPath(path) {
  const directory = getDirectoryPath(path);
  const lower = directory.toLowerCase();
  const roots = ["/jp/", "/com/", "/org/", "/net/"];
  let best = -1;

  roots.forEach(root => {
    const index = lower.lastIndexOf(root);
    if (index > best) best = index;
  });

  if (best >= 0) return directory.substring(0, best + 1);
  if (/^(?:jp|com|org|net)\//i.test(directory)) return "";
  return directory ? directory + "/" : "";
}

function getCurrentJavaPackageName() {
  const match = String(currentSourceText || "").match(/^\s*package\s+([A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)*)\s*;/m);
  return match ? match[1] : "";
}

function findImportedJavaClassQualifiedName(className) {
  const name = String(className || "").trim();
  if (!name) return "";

  const pattern = new RegExp(
    "^\\s*import\\s+(?:static\\s+)?([A-Za-z_$][A-Za-z0-9_$]*(?:\\.[A-Za-z_$][A-Za-z0-9_$]*)*\\." +
      escapeRegExp(name) +
      ")\\s*;",
    "m"
  );
  const match = String(currentSourceText || "").match(pattern);
  return match ? match[1] : "";
}

function qualifiedJavaNameToFullPath(qualifiedName) {
  const qName = String(qualifiedName || "").trim();
  if (!qName) return "";
  const root = getJavaPackageRootPrefixFromPath(currentCodePath);
  return root + qName.replace(/\./g, "/") + ".java";
}

function buildSiblingJavaClassFullPath(className) {
  const directory = getDirectoryPath(currentCodePath);
  return (directory ? directory + "/" : "") + String(className || "").trim() + ".java";
}

function resolveJavaClassKeywordFullPath(className) {
  const name = String(className || "").trim();
  if (!name) return "";

  const imported = findImportedJavaClassQualifiedName(name);
  if (imported) return qualifiedJavaNameToFullPath(imported);

  const packageName = getCurrentJavaPackageName();
  if (packageName) return qualifiedJavaNameToFullPath(packageName + "." + name);

  return buildSiblingJavaClassFullPath(name);
}

function openJavaClassKeywordSource(className) {
  const name = String(className || "").trim();
  if (!name) return;

  // 2026-08-14 fix80:
  // Javaクラス名をクリックした時、表示中ソースのimportに完全修飾名があれば単純名と両方をServletへ渡す。
  // 例: import jp.co.xxx.Kyc0250TableAccessor; を検出した場合
  //   className=Kyc0250TableAccessor
  //   qualifiedClassName=jp.co.xxx.Kyc0250TableAccessor
  // とし、AI_FILE1同名候補のpackage判定をServlet側へ一元化する。
  const importedQualifiedName = findImportedJavaClassQualifiedName(name);
  const fallbackPath = buildSiblingJavaClassFullPath(name);
  const originPath = currentCodePath;
  openCode(fallbackPath, {
    row: {
      fileName: name + ".java",
      path: fallbackPath,
      fullPath: fallbackPath,
      project: extractProjectFromPath(originPath) || "",
      group: extractMigrationGroupFromPath(originPath) || "",
      directoryGroup: getRawDirectoryGroupFromPath(originPath) || "",
      language: "java",
      javaClassName: name,
      javaQualifiedClassName: importedQualifiedName,
      qualifiedClassName: importedQualifiedName,
      originPath,
      originFullPath: originPath,
      originProject: extractProjectFromPath(originPath) || "",
      originGroup: extractMigrationGroupFromPath(originPath) || "",
      originDirectoryGroup: getRawDirectoryGroupFromPath(originPath) || "",
      originPackage: getCurrentJavaPackageName()
    }
  });
}

function isJavaPackageOrImportLineAt(fullText, index) {
  const source = String(fullText || "");
  const lineStart = source.lastIndexOf("\n", Math.max(0, index - 1)) + 1;
  let lineEnd = source.indexOf("\n", index);
  if (lineEnd < 0) lineEnd = source.length;
  const line = source.slice(lineStart, lineEnd);
  return /^\s*(?:package|import\s+(?:static\s+)?)\b/.test(line);
}


function isAppfwJavaSource(sourceText, path) {
  const source = String(sourceText || "");
  const packageMatch = source.match(/^\s*package\s+([^;]+);/m);
  const packageName = packageMatch ? packageMatch[1].trim() : "";
  const pathText = String(path || "");

  return /(^|\.)appfw(\.|$)/i.test(packageName) ||
    /(?:^|[\\/._-])appfw(?:[\\/._-]|$)/i.test(pathText) ||
    /\.appfw\./i.test(pathText);
}

function buildJavaImportHighlightExclusions(sourceText) {
  const excludes = new Set();
  const source = String(sourceText || "");
  const importPattern = /^\s*import\s+(?:static\s+)?([^;]+);/gm;
  let match;

  while ((match = importPattern.exec(source)) !== null) {
    const importPath = String(match[1] || "").trim();
    if (!importPath || !isIgnoredJavaImportPackage(importPath)) continue;

    if (isComTaskWildcardImport(importPath)) {
      excludes.add("Task");
      excludes.add("TaskResult");
    }

    const className = extractImportedClassName(importPath);
    if (className) excludes.add(className);
  }

  return excludes;
}

function isComTaskImportPackage(importPath) {
  const value = String(importPath || "").trim().toLowerCase();
  return value.startsWith("com.task.") || value.includes(".com.task.");
}

function isComTaskWildcardImport(importPath) {
  const value = String(importPath || "").trim().toLowerCase();
  return value.endsWith(".*") && (value === "com.task.*" || value.endsWith(".com.task.*"));
}

function isIgnoredJavaImportPackage(importPath) {
  const value = String(importPath || "").trim().toLowerCase();
  return value.startsWith("java.") ||
    value.startsWith("javax.") ||
    value.startsWith("jdk.") ||
    value.startsWith("sun.") ||
    value.startsWith("com.sun.") ||
    value.startsWith("org.w3c.") ||
    value.startsWith("org.xml.sax.") ||
    value.includes("com.cm.com.") ||
    isComTaskImportPackage(value) ||
    /(^|\.)[^.]*fw[^.]*(\.|$)/i.test(value);
}

function extractImportedClassName(importPath) {
  const cleaned = String(importPath || "").trim();
  if (!cleaned || cleaned.endsWith(".*")) return "";

  const parts = cleaned.split(".").filter(Boolean);
  for (let i = parts.length - 1; i >= 0; i--) {
    if (/^[A-Z_$]/.test(parts[i])) return parts[i];
  }
  return "";
}

function isJavaOrFrameworkQualifiedIdentifierAt(sourceText, index) {
  const source = String(sourceText || "");
  const prefix = source.slice(Math.max(0, index - 220), index);
  const qualifiedPrefixMatch = prefix.match(/(?:[$A-Za-z_][_$A-Za-z0-9]*\.)+$/);
  if (!qualifiedPrefixMatch) return false;

  const qualifiedPrefix = qualifiedPrefixMatch[0].toLowerCase();
  return qualifiedPrefix.startsWith("java.") ||
    qualifiedPrefix.startsWith("javax.") ||
    qualifiedPrefix.startsWith("jdk.") ||
    qualifiedPrefix.startsWith("sun.") ||
    qualifiedPrefix.startsWith("com.sun.") ||
    qualifiedPrefix.startsWith("org.w3c.") ||
    qualifiedPrefix.startsWith("org.xml.sax.") ||
    qualifiedPrefix.includes("com.cm.com.") ||
    qualifiedPrefix.startsWith("com.task.") ||
    qualifiedPrefix.includes(".com.task.") ||
    /(^|\.)[^.]*fw[^.]*\./i.test(qualifiedPrefix);
}

function findJavaPublicClassLineRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  let lineStart = 0;

  while (lineStart <= source.length) {
    let lineEnd = source.indexOf("\n", lineStart);
    if (lineEnd < 0) lineEnd = source.length;

    const line = source.slice(lineStart, lineEnd);
    const classKeywordIndex = line.search(/\bclass\b/);
    if (classKeywordIndex >= 0) {
      const beforeClass = line.slice(0, classKeywordIndex);
      const modifierOnlyPrefix = /^\s*(?:@[A-Za-z0-9_.$]+(?:\([^)]*\))?\s*)*(?:(?:public|protected|private|abstract|final|static|strictfp|sealed|non-sealed)\s+)*$/;

      if (/\bpublic\b/.test(beforeClass) && modifierOnlyPrefix.test(beforeClass)) {
        ranges.push({ start: lineStart, end: lineEnd });
      }
    }

    if (lineEnd >= source.length) break;
    lineStart = lineEnd + 1;
  }

  return ranges;
}

function findJavaExtendsClauseRanges(sourceText, commentRanges = [], literalRanges = []) {
  const source = String(sourceText || "");
  if (!source) return [];

  // コメント・文字列内の class / extends を宣言として誤認しないよう、文字数を変えずに空白化する。
  const masked = source.split("");
  const ignoredRanges = (commentRanges || []).concat(literalRanges || [])
    .slice()
    .sort((a, b) => a.start - b.start);

  ignoredRanges.forEach(range => {
    const start = Math.max(0, Number(range.start) || 0);
    const end = Math.min(masked.length, Number(range.end) || 0);
    for (let i = start; i < end; i++) {
      if (masked[i] !== "\n" && masked[i] !== "\r") masked[i] = " ";
    }
  });

  const maskedSource = masked.join("");
  const ranges = [];
  const classPattern = /\bclass\s+[A-Za-z_$][_$A-Za-z0-9]*/g;
  let match;

  while ((match = classPattern.exec(maskedSource)) !== null) {
    const declarationBodyStart = match.index + match[0].length;
    let declarationEnd = maskedSource.length;

    for (let i = declarationBodyStart; i < maskedSource.length; i++) {
      const ch = maskedSource.charAt(i);
      if (ch === "{" || ch === ";") {
        declarationEnd = i;
        break;
      }
    }

    const declarationTail = maskedSource.slice(declarationBodyStart, declarationEnd);
    const extendsMatch = /\bextends\b/.exec(declarationTail);
    if (!extendsMatch) {
      classPattern.lastIndex = Math.max(classPattern.lastIndex, declarationEnd + 1);
      continue;
    }

    const extendsStart = declarationBodyStart + extendsMatch.index + extendsMatch[0].length;
    const afterExtends = maskedSource.slice(extendsStart, declarationEnd);
    const clauseEndMatch = /\b(?:implements|permits)\b/.exec(afterExtends);
    const extendsEnd = clauseEndMatch
      ? extendsStart + clauseEndMatch.index
      : declarationEnd;

    if (extendsEnd > extendsStart) {
      ranges.push({ start: extendsStart, end: extendsEnd });
    }

    classPattern.lastIndex = Math.max(classPattern.lastIndex, declarationEnd + 1);
  }

  return ranges;
}

function findJavaLiteralRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  let i = 0;

  while (i < source.length) {
    const ch = source.charAt(i);
    const next = source.charAt(i + 1);

    // コメント内の引用符を文字列開始と誤認しないよう、コメントは読み飛ばす。
    if (ch === "/" && next === "/") {
      const lineEnd = source.indexOf("\n", i + 2);
      i = lineEnd < 0 ? source.length : lineEnd + 1;
      continue;
    }
    if (ch === "/" && next === "*") {
      const commentEnd = source.indexOf("*/", i + 2);
      i = commentEnd < 0 ? source.length : commentEnd + 2;
      continue;
    }

    if (ch !== "\"" && ch !== "'") {
      i++;
      continue;
    }

    const quote = ch;
    const start = i;
    let escaped = false;
    i++;

    while (i < source.length) {
      const current = source.charAt(i);
      if (escaped) {
        escaped = false;
      } else if (current === "\\") {
        escaped = true;
      } else if (current === quote) {
        i++;
        break;
      }
      i++;
    }

    ranges.push({ start, end: i });
  }

  return ranges;
}

function findJavaCommentRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  let quote = "";
  let escaped = false;

  for (let i = 0; i < source.length; i++) {
    const ch = source.charAt(i);
    const next = source.charAt(i + 1);

    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === quote) {
        quote = "";
      }
      continue;
    }

    if (ch === "\"" || ch === "'") {
      quote = ch;
      continue;
    }

    if (ch === "/" && next === "/") {
      const start = i;
      let end = source.indexOf("\n", i + 2);
      if (end < 0) end = source.length;
      ranges.push({ start, end });
      i = end;
      continue;
    }

    if (ch === "/" && next === "*") {
      const start = i;
      let end = source.indexOf("*/", i + 2);
      end = end < 0 ? source.length : end + 2;
      ranges.push({ start, end });
      i = end - 1;
    }
  }
  return ranges;
}

function isIndexInRanges(index, ranges) {
  for (let i = 0; i < ranges.length; i++) {
    if (index >= ranges[i].start && index < ranges[i].end) return true;
    if (index < ranges[i].start) return false;
  }
  return false;
}

function isJavaClassNameCandidate(keyword) {
  if (!keyword) return false;
  if (JAVA_STANDARD_CLASS_EXCLUDES.has(keyword)) return false;
  if (JAVA_RESERVED_WORD_EXCLUDES.has(keyword)) return false;
  if (!/^[A-Z][A-Za-z0-9_$]*$/.test(keyword)) return false;
  if (/Exception/i.test(keyword)) return false;

  // IAppContext のような I 始まりのインターフェース名は除外する。
  if (/^I[A-Za-z0-9_$]*$/.test(keyword)) return false;

  // Command / Task / Context のように大文字が先頭1文字だけの単語型クラス名は除外する。
  const upperCaseCount = (keyword.match(/[A-Z]/g) || []).length;
  if (upperCaseCount <= 1) return false;

  // SELECT_FOR_UPDATE や DB_UPDJI1 などの定数・カラム名は、クラス名としては除外する。
  if (/^[A-Z0-9_$]+$/.test(keyword)) return false;

  return true;
}

const CODE_IDENTIFIER_PATTERN = /[$#A-Za-z_][_$#A-Za-z0-9]*/g;


function getTableInfoTabTemplate() {
  return document.querySelector(".codeTableInfoTab:not(.codeTableInfoDynamicTab)");
}

function getTableInfoTabContainer() {
  const template = getTableInfoTabTemplate();
  return template ? template.parentElement : document.querySelector(".codeModeTabs");
}

function getTableInfoPanelId(tabId) {
  return tabId ? `table:${tabId}` : "table";
}

function isTableInfoPanel(panelId) {
  const value = String(panelId || "");
  return value === "table" || value.indexOf("table:") === 0;
}

function getTableInfoTabIdFromPanel(panelId) {
  const value = String(panelId || "");
  if (value.indexOf("table:") === 0) return value.slice(6);
  return activeTableInfoTabId || "";
}

function createDefaultTableInfoState(values = {}) {
  return Object.assign({
    id: "",
    status: "idle",
    tableName: "",
    candidates: [],
    selected: null,
    tableMeta: null,
    columns: [],
    unique: false,
    error: "",
    requestKey: 0
  }, values || {});
}

function createTableInfoTabId(tableName) {
  tableInfoTabSequence += 1;
  const safeName = String(tableName || "table").replace(/[^A-Za-z0-9_]+/g, "_").replace(/^_+|_+$/g, "") || "table";
  return `${safeName}_${tableInfoTabSequence}`;
}

function getTableInfoStateById(tabId) {
  const id = String(tabId || "");
  return tableInfoStates.find(state => state && state.id === id) || null;
}

function getActiveTableInfoState() {
  return getTableInfoStateById(activeTableInfoTabId) || tableInfoStates[0] || tableInfoState || createDefaultTableInfoState();
}

const TABLE_INFO_TAB_LABEL_MAX_CHARS = 12;

function shortenTableInfoTabLabel(label) {
  const text = String(label || "").trim();
  if (!text) return "テーブル選択";
  const chars = Array.from(text);
  return chars.length > TABLE_INFO_TAB_LABEL_MAX_CHARS
    ? `${chars.slice(0, TABLE_INFO_TAB_LABEL_MAX_CHARS).join("")}...`
    : text;
}

function getTableInfoTabFullLabel(state) {
  const current = state || {};
  if (current.status === "candidates") return "テーブル選択";
  const selected = current.selected || {};
  const detailName = current.status === "detail" && selected.name ? String(selected.name).trim() : "";
  return detailName || String(current.tableName || "テーブル選択").trim() || "テーブル選択";
}

function getTableInfoTabLabel(state) {
  return shortenTableInfoTabLabel(getTableInfoTabFullLabel(state));
}

function upsertTableInfoState(nextState) {
  const state = createDefaultTableInfoState(nextState || {});
  if (!state.id) state.id = createTableInfoTabId(state.tableName);
  const index = tableInfoStates.findIndex(item => item && item.id === state.id);
  if (index >= 0) {
    tableInfoStates[index] = state;
  } else {
    tableInfoStates.push(state);
  }
  if (!activeTableInfoTabId) activeTableInfoTabId = state.id;
  tableInfoState = getActiveTableInfoState();
  return state;
}

function updateTableInfoTabsFromState() {
  const container = getTableInfoTabContainer();
  const template = getTableInfoTabTemplate();
  if (!container) return;

  if (template) {
    template.hidden = true;
    template.setAttribute("aria-hidden", "true");
  }

  container.querySelectorAll(".codeTableInfoDynamicTab").forEach(tab => tab.remove());

  tableInfoStates.forEach(state => {
    const button = document.createElement("button");
    button.className = "codeModeTab codeTableInfoTab codeTableInfoDynamicTab";
    button.type = "button";
    button.dataset.codePanel = getTableInfoPanelId(state.id);
    button.dataset.tableInfoTabId = state.id;
    const fullLabel = getTableInfoTabFullLabel(state);
    const shortLabel = getTableInfoTabLabel(state);
    button.textContent = shortLabel;
    button.title = fullLabel;
    button.dataset.fullLabel = fullLabel;
    button.setAttribute("aria-hidden", "false");
    button.setAttribute("aria-label", `${fullLabel} のテーブル選択`);
    button.classList.toggle("isActive", activeCodePanel === button.dataset.codePanel);
    container.appendChild(button);
  });
}

function getTableInfoTab() {
  if (activeTableInfoTabId) {
    return document.querySelector(`.codeTableInfoDynamicTab[data-table-info-tab-id="${cssEscapeValue(activeTableInfoTabId)}"]`);
  }
  return getTableInfoTabTemplate();
}

function setTableInfoTabVisible(visible, label) {
  if (!visible) {
    tableInfoStates = [];
    activeTableInfoTabId = "";
    if (isTableInfoPanel(activeCodePanel)) activeCodePanel = "source";
  } else if (label && activeTableInfoTabId) {
    const state = getTableInfoStateById(activeTableInfoTabId);
    if (state && !state.tableName) state.tableName = String(label || "");
  }
  updateTableInfoTabsFromState();
}

function updateTableInfoTabFromState() {
  updateTableInfoTabsFromState();
}

function resetTableInfoState() {
  tableInfoRequestSequence++;
  tableInfoStates = [];
  activeTableInfoTabId = "";
  tableInfoState = createDefaultTableInfoState();
  setTableInfoTabVisible(false, "テーブル選択");
  renderTableInfoPanel();
}

function normalizeTableCandidate(value) {
  const source = value && typeof value === "object" ? value : {};
  return {
    id: source.id == null ? "" : String(source.id).trim(),
    name: String(source.name || source.tableName || "").trim(),
    name2: String(source.name2 || source.displayName || source.logicalName || "").trim(),
    dbtype: String(source.dbtype || source.dbType || "").trim(),
    schema: String(source.schema || "").trim(),
    version: String(source.version || source.ver || "").trim(),
    displayName: String(source.displayName || source.name2 || source.logicalName || "").trim()
  };
}

function getTableCandidateDbtypePriority(dbtype) {
  const value = String(dbtype || "").trim().toUpperCase();
  if (value === "KYKDB") return 0;
  if (value === "EZDB") return 1;
  return 2;
}

function getTableCandidateSchemaPriority(candidate) {
  const dbtype = String(candidate && candidate.dbtype || "").trim().toUpperCase();
  const schema = String(candidate && candidate.schema || "").trim().toUpperCase();
  if (dbtype === "KYKDB" && schema === "KYKOWNER") return 0;
  if (dbtype === "EZDB" && schema === "EZOWNER") return 0;
  return 1;
}

function compareTextAscending(a, b) {
  return String(a || "").localeCompare(String(b || ""), "ja", {
    numeric: true,
    sensitivity: "base"
  });
}

function compareTableCandidatesForDisplay(a, b) {
  const dbPriorityDiff = getTableCandidateDbtypePriority(a && a.dbtype) - getTableCandidateDbtypePriority(b && b.dbtype);
  if (dbPriorityDiff !== 0) return dbPriorityDiff;

  const aDbtype = String(a && a.dbtype || "").trim();
  const bDbtype = String(b && b.dbtype || "").trim();
  const dbtypeDiff = compareTextAscending(aDbtype, bDbtype);
  if (dbtypeDiff !== 0) return dbtypeDiff;

  const schemaPriorityDiff = getTableCandidateSchemaPriority(a) - getTableCandidateSchemaPriority(b);
  if (schemaPriorityDiff !== 0) return schemaPriorityDiff;

  return compareTextAscending(a && a.schema, b && b.schema)
    || compareTextAscending(a && a.version, b && b.version)
    || compareTextAscending(a && a.name, b && b.name)
    || compareTextAscending(a && a.name2, b && b.name2)
    || compareTextAscending(a && a.id, b && b.id);
}

function sortTableCandidatesForDisplay(candidates) {
  return (Array.isArray(candidates) ? candidates : [])
    .slice()
    .sort(compareTableCandidatesForDisplay);
}

function normalizeTableMeta(value, fallbackCandidate) {
  const source = value && typeof value === "object" ? value : {};
  const candidate = normalizeTableCandidate(fallbackCandidate || source);
  return {
    id: source.id == null ? candidate.id : String(source.id).trim(),
    name: String(source.name || source.tableName || candidate.name || "").trim(),
    name2: String(source.name2 || source.displayName || source.logicalName || candidate.name2 || "").trim(),
    dbtype: String(source.dbtype || source.dbType || candidate.dbtype || "").trim(),
    schema: String(source.schema || candidate.schema || "").trim(),
    dbAlias: String(source.dbAlias || source.dbName || source.dbIdentifier || source.dbtype || candidate.dbtype || "").trim(),
    version: String(source.version || source.ver || candidate.version || "").trim(),
    displayName: String(source.displayName || source.name2 || source.logicalName || candidate.displayName || candidate.name2 || "").trim()
  };
}

function buildTableDisplayName(tableName, logicalName) {
  const name = String(tableName || "").trim();
  const displayName = String(logicalName || "").trim();
  if (!name) return displayName || "テーブル情報";
  if (!displayName || displayName === name || displayName === "テーブル定義情報") return name;
  return `${name}（${displayName}）`;
}

function buildTableInfoTitleText(tableName, logicalName, version, dbtype, schema) {
  const safeDbtype = String(dbtype || "-").trim() || "-";
  const safeSchema = String(schema || "-").trim() || "-";
  const safeVersion = String(version || "-").trim() || "-";
  // 2026-08-12 fix48: テーブル詳細タイトルの表示順・表記を指定フォーマットに合わせる。
  return `${buildTableDisplayName(tableName, logicalName)}　　　DBTYPE　：　${safeDbtype}　　　スキーマ　：　${safeSchema}　　　Version　：　${safeVersion}`;
}

function getTableInfoTitle() {
  const state = getActiveTableInfoState();
  const selected = state.selected || {};
  const meta = state.tableMeta || {};
  if (state.status === "detail" && state.unique === true) {
    const tableName = meta.name || selected.name || state.tableName || "";
    const displayName = meta.displayName || meta.name2 || selected.displayName || selected.name2 || "";
    const version = meta.version || selected.version || "-";
    const dbtype = meta.dbtype || selected.dbtype || "-";
    const schema = meta.schema || selected.schema || "-";
    return buildTableInfoTitleText(tableName, displayName, version, dbtype, schema);
  }
  return getTableInfoTabLabel(state);
}

function setTableInfoState(nextState, tabId = activeTableInfoTabId, renderAfterUpdate = true) {
  const id = String(tabId || activeTableInfoTabId || (nextState && nextState.id) || createTableInfoTabId(nextState && nextState.tableName));
  const current = getTableInfoStateById(id) || createDefaultTableInfoState({ id });
  const merged = createDefaultTableInfoState(Object.assign({}, current, nextState || {}, { id }));
  upsertTableInfoState(merged);
  if (activeTableInfoTabId === id) tableInfoState = merged;
  updateTableInfoTabFromState();
  if (renderAfterUpdate && isTableInfoPanel(activeCodePanel) && getTableInfoTabIdFromPanel(activeCodePanel) === id) renderCode();
  return merged;
}

function tableApiError(data, fallback) {
  if (data && data.ok === false) return new Error(String(data.error || fallback || "テーブル情報を取得できませんでした。"));
  return null;
}

function applyTableInfoResponse(data, fallbackName, fallbackCandidates, tabId = activeTableInfoTabId) {
  const mode = String(data && data.mode || "").trim();
  const candidates = sortTableCandidatesForDisplay((Array.isArray(data && data.candidates) ? data.candidates : (fallbackCandidates || []))
    .map(normalizeTableCandidate)
    .filter(item => item.name));

  if (mode === "detail" || data && data.unique === true && data.table) {
    const selected = normalizeTableCandidate(data.table || {});
    const tableMeta = normalizeTableMeta(data.table || {}, selected);
    setTableInfoState({
      status: "detail",
      tableName: selected.name || fallbackName,
      candidates,
      selected,
      tableMeta,
      columns: Array.isArray(data.columns) ? data.columns : [],
      unique: true,
      error: ""
    }, tabId);
    return;
  }

  if (mode === "candidates" || candidates.length > 1) {
    setTableInfoState({
      status: "candidates",
      tableName: String(data && data.tableName || fallbackName || "").trim(),
      candidates,
      selected: null,
      tableMeta: null,
      columns: [],
      unique: false,
      error: ""
    }, tabId);
    return;
  }

  setTableInfoState({
    status: "empty",
    tableName: String(data && data.tableName || fallbackName || "").trim(),
    candidates,
    selected: null,
    tableMeta: null,
    columns: [],
    unique: false,
    error: ""
  }, tabId);
}

async function openTableInformation(tableName) {
  const name = String(tableName || "").trim();
  if (!name) return;

  const tabId = createTableInfoTabId(name);
  const requestKey = ++tableInfoRequestSequence;
  activeTableInfoTabId = tabId;
  activeCodePanel = getTableInfoPanelId(tabId);
  setTableInfoState({
    id: tabId,
    status: "loadingCandidates",
    tableName: name,
    candidates: [],
    selected: null,
    tableMeta: null,
    columns: [],
    unique: false,
    error: "",
    requestKey
  }, tabId, false);
  updateTableInfoTabsFromState();
  renderCode();

  try {
    const data = await fetchJson(TABLE_INFO_ENDPOINT, { tableName: name }, {
      method: "GET",
      timeoutMs: API_ACCESS_TIMEOUT_MS
    });
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    const apiError = tableApiError(data, `${name} のテーブル情報をDBから取得できませんでした。`);
    if (apiError) throw apiError;
    applyTableInfoResponse(data, name, [], tabId);
  } catch (error) {
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    setTableInfoState({
      status: "error",
      tableName: name,
      candidates: [],
      selected: null,
      tableMeta: null,
      columns: [],
      unique: false,
      error: String(error && error.message ? error.message : error),
      requestKey
    }, tabId);
  }
}

async function loadTableInformationDetail(candidateValue) {
  const candidate = normalizeTableCandidate(candidateValue);
  if (!candidate.name) return;

  const tabId = activeTableInfoTabId;
  const currentState = getTableInfoStateById(tabId) || getActiveTableInfoState();
  const currentCandidates = Array.isArray(currentState.candidates) ? currentState.candidates.slice() : [];
  const requestKey = ++tableInfoRequestSequence;
  activeCodePanel = getTableInfoPanelId(tabId);
  setTableInfoState({
    status: "loadingDetail",
    tableName: candidate.name,
    candidates: currentCandidates,
    selected: candidate,
    tableMeta: null,
    columns: [],
    unique: false,
    error: "",
    requestKey
  }, tabId, false);
  updateTableInfoTabsFromState();
  renderCode();

  try {
    const data = await fetchJson(TABLE_INFO_ENDPOINT, {
      tableListId: candidate.id,
      tableName: candidate.name,
      dbtype: candidate.dbtype,
      schema: candidate.schema,
      version: candidate.version
    }, {
      method: "GET",
      timeoutMs: API_ACCESS_TIMEOUT_MS
    });
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    const apiError = tableApiError(data, `${candidate.name} のテーブル定義をDBから取得できませんでした。`);
    if (apiError) throw apiError;
    applyTableInfoResponse(data, candidate.name, currentCandidates, tabId);
  } catch (error) {
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    setTableInfoState({
      status: "error",
      tableName: candidate.name,
      candidates: currentCandidates,
      selected: candidate,
      tableMeta: null,
      columns: [],
      unique: false,
      error: String(error && error.message ? error.message : error),
      requestKey
    }, tabId);
  }
}

function tableCell(value) {
  return escapeHtml(value == null ? "" : String(value));
}

function renderTableInfoPanel() {
  const panel = $("tableInfoPanel");
  const status = $("tableInfoStatus");
  const title = $("codeTitle");
  const content = $("tableInfoContent");
  if (!panel || !content) return;

  const setTableInfoStatusText = (text, options = {}) => {
    const value = String(text || "");
    if (status) {
      status.textContent = value;
      return;
    }
    if (title && options.useTitle !== false) {
      title.textContent = value;
    }
  };

  const state = getActiveTableInfoState();
  tableInfoState = state;
  updateCodeContextFixedLabel(currentCodePath);
  content.innerHTML = "";

  if (state.status === "loadingCandidates") {
    setTableInfoStatusText(`${state.tableName} のテーブル情報をDBから取得しています…`);
    return;
  }
  if (state.status === "loadingDetail") {
    const selected = state.selected || {};
    setTableInfoStatusText(`${selected.name || state.tableName} の項目定義をDBから取得しています…`);
    return;
  }
  if (state.status === "empty") {
    setTableInfoStatusText(`${state.tableName} に一致するRPS_TABLE_LIST.NAMEがありません。`);
    return;
  }
  if (state.status === "error") {
    setTableInfoStatusText("テーブル情報の取得に失敗しました。");
    content.innerHTML = `<div class="tableInfoError">${escapeHtml(state.error || "不明なエラー")}</div>`;
    return;
  }
  if (state.status === "candidates") {
    setTableInfoStatusText(`${state.tableName} は候補データが複数件あります。以下のDBTYPEおよびスキーマから、1行を選択してください。`);
    content.innerHTML = `
      <div class="tableInfoTableWrap tableCandidateTableWrap">
        <table class="tableInfoTable tableCandidateTable">
          <thead><tr><th>NO</th><th>DBTYPE</th><th>スキーマ</th><th>バージョン</th><th>テーブル名</th><th>日本語</th><th class="tableCandidateActionHeader">選択</th></tr></thead>
          <tbody>${state.candidates.map((item, index) => `
            <tr class="tableCandidateRow" data-table-candidate-index="${index}" tabindex="0" role="button" aria-label="${tableCell(item.name)} ${tableCell(item.dbtype)} ${tableCell(item.schema)} ${tableCell(item.version)} を選択">
              <td>${index + 1}</td>
              <td>${tableCell(item.dbtype)}</td>
              <td>${tableCell(item.schema)}</td>
              <td>${tableCell(item.version)}</td>
              <td>${tableCell(item.name)}</td>
              <td>${tableCell(item.name2 || item.displayName)}</td>
              <td class="tableCandidateActionCell"><button class="tableCandidateSelectBtn" type="button" aria-label="${tableCell(item.name)} ${tableCell(item.dbtype)} ${tableCell(item.schema)} ${tableCell(item.version)} を選択">選択</button></td>
            </tr>`).join("")}</tbody>
        </table>
      </div>`;
    return;
  }
  if (state.status === "detail") {
    const selected = state.selected || {};
    const meta = state.tableMeta || {};
    const rows = Array.isArray(state.columns) ? state.columns : [];
    const tableName = meta.name || selected.name || state.tableName || "-";
    const dbtype = meta.dbtype || selected.dbtype || "-";
    const schema = meta.schema || selected.schema || "-";
    const version = meta.version || selected.version || "-";
    const displayName = meta.displayName || meta.name2 || selected.displayName || selected.name2 || "";
    content.innerHTML = `
      <div class="tableInfoTableWrap tableDefinitionTableWrap">
        <table class="tableInfoTable tableDefinitionTable">
          <thead>
            <tr>
              <th>No.</th><th>項目名</th><th>キー</th><th>Par</th><th>データ型</th><th>データ長</th>
              <th>NULL制約</th><th>日本語名称</th><th>項目説明</th><th>外部参照</th>
              <th>省略時値</th><th>CHECK制約</th>
            </tr>
          </thead>
          <tbody>${rows.map(row => `
            <tr>
              <td>${tableCell(row.no)}</td>
              <td>${tableCell(row.name)}</td>
              <td>${tableCell(row.pkkey)}</td>
              <td>${tableCell(row.part)}</td>
              <td>${tableCell(row.kata)}</td>
              <td>${tableCell(row.columnSize)}</td>
              <td>${tableCell(row.nullConst)}</td>
              <td>${tableCell(row.name2)}</td>
              <td>${tableCell(row.description)}</td>
              <td>${tableCell(row.reference)}</td>
              <td>${tableCell(row.defaultValue)}</td>
              <td>${tableCell(row.checkConst)}</td>
            </tr>`).join("") || `<tr><td colspan="12">RPS_TABLE_DATAに項目がありません。</td></tr>`}</tbody>
        </table>
      </div>`;
    return;
  }

  setTableInfoStatusText("ソースコード内で下線表示されたテーブル名をクリックしてください。");
}

function selectTableCandidateFromElement(element) {
  const index = Number(element && element.dataset ? element.dataset.tableCandidateIndex : -1);
  const state = getActiveTableInfoState();
  const candidate = Array.isArray(state.candidates) ? state.candidates[index] : null;
  if (candidate) loadTableInformationDetail(candidate);
}

function handleTableCandidateKeydown(event) {
  const row = event && event.target && event.target.closest ? event.target.closest("[data-table-candidate-index]") : null;
  if (!row) return;
  if (event.key !== "Enter" && event.key !== " ") return;
  event.preventDefault();
  selectTableCandidateFromElement(row);
}

document.addEventListener("keydown", handleTableCandidateKeydown, true);

const JAVA_RESERVED_WORD_EXCLUDES = new Set([
  "Abstract", "Assert", "Boolean", "Break", "Byte", "Case", "Catch", "Char", "Class", "Const",
  "Continue", "Default", "Do", "Double", "Else", "Enum", "Extends", "Final", "Finally", "Float",
  "For", "Goto", "If", "Implements", "Import", "Instanceof", "Int", "Interface", "Long", "Native",
  "New", "Package", "Private", "Protected", "Public", "Return", "Short", "Static", "Strictfp", "Super",
  "Switch", "Synchronized", "This", "Throw", "Throws", "Transient", "Try", "Void", "Volatile", "While"
]);

const JAVA_STANDARD_CLASS_EXCLUDES = new Set([
  "Appendable", "AutoCloseable", "Boolean", "Byte", "Character", "CharSequence", "Class", "ClassLoader",
  "Cloneable", "Comparable", "Compiler", "Double", "Enum", "Exception", "Float", "Integer", "Iterable",
  "Long", "Math", "Number", "Object", "Package", "Process", "ProcessBuilder", "Readable", "Runtime",
  "RuntimeException", "SecurityManager", "Short", "StackTraceElement", "StrictMath", "String", "StringBuffer",
  "StringBuilder", "System", "Thread", "ThreadGroup", "ThreadLocal", "Throwable", "Void",
  "BigDecimal", "BigInteger", "Date", "Calendar", "GregorianCalendar", "Locale", "TimeZone", "Optional",
  "List", "ArrayList", "LinkedList", "Map", "HashMap", "LinkedHashMap", "TreeMap", "Set", "HashSet",
  "LinkedHashSet", "TreeSet", "Collection", "Collections", "Arrays", "Iterator", "Enumeration", "Objects",
  "Comparator", "Queue", "Deque", "ArrayDeque", "Properties", "Random", "UUID", "Timer", "TimerTask",
  "File", "InputStream", "OutputStream", "Reader", "Writer", "BufferedReader", "BufferedWriter",
  "InputStreamReader", "OutputStreamWriter", "IOException", "FileInputStream", "FileOutputStream", "PrintWriter",
  "PrintStream", "Serializable", "Externalizable",
  "Charset", "StandardCharsets", "ByteBuffer", "Path", "Paths", "Files", "URL", "URI", "URLConnection",
  "HttpURLConnection", "URLEncoder", "URLDecoder",
  "Connection", "DriverManager", "PreparedStatement", "CallableStatement", "Statement", "ResultSet", "SQLException",
  "SQLWarning", "Savepoint", "DatabaseMetaData", "ResultSetMetaData", "ParameterMetaData", "Types",
  "Timestamp", "Time", "Blob", "Clob", "NClob", "SQLXML", "Array", "Ref", "RowId", "Struct"
]);

document.addEventListener("click", event => {
  const candidateRow = event.target.closest ? event.target.closest("[data-table-candidate-index]") : null;
  if (candidateRow) {
    event.preventDefault();
    selectTableCandidateFromElement(candidateRow);
    return;
  }

  const keywordButton = event.target.closest ? event.target.closest(".codeKeywordLink") : null;
  if (!keywordButton) return;

  const keyword = keywordButton.dataset.keyword || keywordButton.textContent || "";
  if (!keyword) return;

  if (keywordButton.dataset.keywordType === "table") {
    event.preventDefault();
    openTableInformation(keyword);
    return;
  }

  if (keywordButton.dataset.keywordType === "java-class") {
    event.preventDefault();
    openJavaClassKeywordSource(keyword);
    return;
  }
});

document.addEventListener("keydown", event => {
  if (event.key !== "Enter" && event.key !== " ") return;
  const candidateRow = event.target.closest ? event.target.closest("[data-table-candidate-index]") : null;
  if (!candidateRow) return;
  event.preventDefault();
  selectTableCandidateFromElement(candidateRow);
});


function setCodeFontSize(nextSize) {
  const next = Number(nextSize);
  codeFontSize = Math.min(CODE_FONT_MAX, Math.max(CODE_FONT_MIN, Number.isFinite(next) ? next : 12));

  const codeView = $("codeView");
  if (codeView) {
    codeView.style.setProperty("--code-font-size", `${codeFontSize}px`);
  }

  const codeBlock = $("codeBlock");
  if (codeBlock) {
    codeBlock.style.setProperty("font-size", `${codeFontSize}px`, "important");
  }
}

function getActionFeedbackTextTarget(button) {
  if (!button) return null;
  return button.querySelector(".sideActionText") || button;
}

function getActionFeedbackButtons(action) {
  const ids = action === "download"
    ? ["downloadBtn"]
    : ["copyBtn"];
  return ids.map(id => $(id)).filter(Boolean);
}

function getActionFeedbackSourceButton(source) {
  if (!source) return null;
  const target = source.currentTarget || source.target || source;
  return target && target.closest ? target.closest("button") : target;
}

function isActionFeedbackSource(source, action) {
  const button = getActionFeedbackSourceButton(source);
  if (!button) return false;
  const validIds = action === "download"
    ? ["downloadBtn"]
    : ["copyBtn"];
  return validIds.includes(button.id);
}

function showSynchronizedActionButtonFeedback(action, feedbackText, fallbackText, stateClass) {
  const buttons = getActionFeedbackButtons(action);
  if (!buttons.length) return;

  if (!showSynchronizedActionButtonFeedback.buttonTimers) {
    showSynchronizedActionButtonFeedback.buttonTimers = new WeakMap();
  }

  buttons.forEach(button => {
    const textTarget = getActionFeedbackTextTarget(button);
    if (!textTarget) return;

    const originalKey = action === "download" ? "originalDownloadText" : "originalCopyText";
    const originalText = button.dataset[originalKey] || textTarget.textContent || fallbackText;
    button.dataset[originalKey] = originalText;
    textTarget.textContent = feedbackText;
    button.classList.add(stateClass);

    window.clearTimeout(showSynchronizedActionButtonFeedback.buttonTimers.get(button));
    showSynchronizedActionButtonFeedback.buttonTimers.set(button, window.setTimeout(() => {
      textTarget.textContent = button.dataset[originalKey] || fallbackText;
      button.classList.remove(stateClass);
    }, 1400));
  });
}

function showToastFeedback(message = "コピーしました") {
  let toast = $("copyToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "copyToast";
    toast.className = "copyToast";
    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.classList.add("isVisible");
  window.clearTimeout(showToastFeedback.timer);
  showToastFeedback.timer = window.setTimeout(() => {
    toast.classList.remove("isVisible");
  }, 1400);
}

function showCopyFeedback(message = "コピーしました", source) {
  showToastFeedback(message);
  if (message === "コピーしました" && isActionFeedbackSource(source, "copy")) {
    showSynchronizedActionButtonFeedback("copy", "コピー済", "Copy", "isCopied");
  }
}

function showDownloadFeedback(message = "ダウンロードしました", source) {
  showToastFeedback(message);
  if (isActionFeedbackSource(source, "download")) {
    showSynchronizedActionButtonFeedback("download", "ダウンロード済", "Download", "isDownloaded");
  }
}

function fallbackCopyText(text) {
  const area = document.createElement("textarea");
  area.value = text;
  area.setAttribute("readonly", "readonly");
  area.style.position = "fixed";
  area.style.left = "-9999px";
  area.style.top = "0";
  document.body.appendChild(area);
  area.focus();
  area.select();

  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch (e) {
    ok = false;
  }

  document.body.removeChild(area);
  return ok;
}


function getSafeDownloadFileName(pathOrName, fallbackName = "krugle.txt") {
  const fallback = String(fallbackName || "krugle.txt").trim() || "krugle.txt";
  const raw = String(pathOrName || "").trim();
  const lastSegment = raw
    .replace(/\\/g, "/")
    .split("/")
    .filter(Boolean)
    .pop() || fallback;
  const withoutQuery = lastSegment.split(/[?#]/)[0] || fallback;
  let decoded = withoutQuery;
  try {
    decoded = decodeURIComponent(withoutQuery);
  } catch (e) {
    decoded = withoutQuery;
  }
  const safe = String(decoded || fallback)
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_")
    .replace(/\s+/g, " ")
    .replace(/[. ]+$/g, "")
    .trim();
  return safe || fallback;
}

// 2026-08-12 fix50:
// DownloadはServlet /downloadへ投げず、現在画面の文字列をブラウザ側で保存する。
// 対応ブラウザでは File System Access API(showSaveFilePicker) で保存先を選択し、
// 非対応・HTTP制約・キャンセル以外の失敗時は従来の a[download] へフォールバックする。
function getDownloadFileExtension(filename) {
  const match = String(filename || "").match(/(\.[A-Za-z0-9_+-]+)$/);
  return match ? match[1].toLowerCase() : ".txt";
}

function getDownloadMimeType(filename, fallbackMimeType = "text/plain;charset=utf-8") {
  const ext = getDownloadFileExtension(filename);
  switch (ext) {
    case ".tsv": return "text/tab-separated-values;charset=utf-8";
    case ".csv": return "text/csv;charset=utf-8";
    case ".html": return "text/html;charset=utf-8";
    case ".js": return "text/javascript;charset=utf-8";
    case ".css": return "text/css;charset=utf-8";
    case ".json": return "application/json;charset=utf-8";
    case ".xml": return "application/xml;charset=utf-8";
    case ".java": return "text/x-java-source;charset=utf-8";
    case ".sql": return "application/sql;charset=utf-8";
    case ".sh":
    case ".bash": return "text/x-shellscript;charset=utf-8";
    default: return fallbackMimeType;
  }
}

function getFileSystemAccessMimeType(mimeType) {
  return String(mimeType || "text/plain").split(";")[0] || "text/plain";
}

function buildTextDownloadBlob(text, mimeType, includeBom = true) {
  const body = String(text ?? "");
  const parts = includeBom ? [new Uint8Array([0xef, 0xbb, 0xbf]), body] : [body];
  return new Blob(parts, { type: mimeType || "text/plain;charset=utf-8" });
}

async function saveBlobWithBrowserFileApi(blob, filename, mimeType) {
  const safeName = getSafeDownloadFileName(filename, "krugle.txt");
  const ext = getDownloadFileExtension(safeName);
  const fsMimeType = getFileSystemAccessMimeType(mimeType);

  if (typeof window.showSaveFilePicker === "function") {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: safeName,
        types: [{
          description: "Text file",
          accept: { [fsMimeType]: [ext] }
        }]
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return { ok: true, method: "file-system-access" };
    } catch (e) {
      if (e && e.name === "AbortError") return { ok: false, aborted: true };
      console.warn("showSaveFilePicker failed; fallback to anchor download", e);
    }
  }

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.download = safeName;
  link.href = url;
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  window.setTimeout(() => {
    URL.revokeObjectURL(url);
    link.remove();
  }, 1000);
  return { ok: true, method: "anchor-download" };
}

function normalizeTableInfoExportCell(value) {
  return String(value == null ? "" : value)
    .replace(/\r\n?/g, "\n")
    .replace(/\n+/g, " ")
    .replace(/\t+/g, " ")
    .trim();
}

function getTableInfoExportMatrix() {
  const table = document.querySelector("#tableInfoPanel .tableInfoTable");
  if (!table) return [];

  const title = $("codeTitle");
  const titleText = normalizeTableInfoExportCell(title ? title.textContent : getTableInfoTitle());
  const tableRows = Array.from(table.querySelectorAll("tr")).map(row =>
    Array.from(row.children).map(cell => normalizeTableInfoExportCell(cell.innerText || cell.textContent || ""))
  );

  return titleText ? [[titleText], []].concat(tableRows) : tableRows;
}

function buildTableInfoCopyText() {
  return getTableInfoExportMatrix()
    .map(row => row.join("\t"))
    .join("\n");
}

function buildCsvExportLine(values) {
  return (Array.isArray(values) ? values : [])
    .map(value => `"${String(value == null ? "" : value).replace(/"/g, '""')}"`)
    .join(",");
}

function buildTableInfoDownloadText() {
  return getTableInfoExportMatrix()
    .map(buildCsvExportLine)
    .join("\r\n");
}

function getTableInfoDownloadFileName() {
  const state = getActiveTableInfoState();
  const selected = state.selected || {};
  const meta = state.tableMeta || {};
  const tableName = meta.name || selected.name || state.tableName || "table_info";
  return `${getSafeDownloadFileName(tableName, "table_info")}.csv`;
}

function buildSearchDownloadFileName(params) {
  const keyword = getSafeDownloadFileName((params && (params.rawKeyword || params.keyword)) || "search", "search");
  return `${keyword}_search_results.tsv`;
}

function getCurrentDownloadPayload() {
  if (currentView === "search") {
    const params = lastSearchParams || buildSearchParams(lastSearchMode || "normal");
    return {
      filename: buildSearchDownloadFileName(params),
      text: buildSearchResultCopyText(getSearchResultExportRows()),
      mimeType: "text/tab-separated-values;charset=utf-8",
      includeBom: true
    };
  }

  if (currentView === "code") {
    const codeView = $("codeView");
    if (codeView && codeView.classList.contains("isTableInfoMode")) {
      return {
        filename: getTableInfoDownloadFileName(),
        text: buildTableInfoDownloadText(),
        mimeType: "text/csv;charset=utf-8",
        includeBom: true
      };
    }

    const codeBlock = $("codeBlock");
    const filename = getSafeDownloadFileName(
      currentCodeMeta && (currentCodeMeta.fileName || currentCodeMeta.name) || currentCodePath,
      "code.txt"
    );
    return {
      filename,
      text: codeBlock ? codeBlock.textContent : currentSourceText || "",
      mimeType: getDownloadMimeType(filename, "text/plain;charset=utf-8"),
      includeBom: false
    };
  }

  return {
    filename: "history.tsv",
    text: buildHomeHistoryExportText(),
    mimeType: "text/tab-separated-values;charset=utf-8",
    includeBom: true
  };
}

async function downloadCurrent(event) {
  if (event && typeof event.preventDefault === "function") event.preventDefault();
  if (event && typeof event.stopPropagation === "function") event.stopPropagation();

  try {
    const payload = getCurrentDownloadPayload();
    const text = String(payload && payload.text != null ? payload.text : "");
    if (!text) {
      showDownloadFeedback("ダウンロード対象がありません", event);
      return;
    }

    const filename = getSafeDownloadFileName(payload.filename, "krugle.txt");
    const mimeType = payload.mimeType || getDownloadMimeType(filename, "text/plain;charset=utf-8");
    const blob = buildTextDownloadBlob(text, mimeType, payload.includeBom !== false);
    const result = await saveBlobWithBrowserFileApi(blob, filename, mimeType);
    if (result && result.aborted) return;
    showDownloadFeedback("ダウンロードしました", event);
  } catch (e) {
    console.error(e);
    showDownloadFeedback("ダウンロードできませんでした", event);
  }
}

async function copyCurrent(event) {
  const visibleView = document.querySelector(".viewBlock.isVisible");
  const text = currentView === "code"
    ? (isTableInfoPanel(activeCodePanel)
      ? buildTableInfoCopyText()
      : ($("codeBlock") ? $("codeBlock").textContent : currentSourceText || ""))
    : (currentView === "search"
      ? buildSearchResultCopyText(getSearchResultExportRows())
      : (currentView === "home"
        ? buildHomeHistoryExportText()
        : (visibleView ? visibleView.innerText : "")));

  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
    } else if (!fallbackCopyText(text)) {
      throw new Error("fallback copy failed");
    }
    showCopyFeedback("コピーしました", event);
  } catch (e) {
    if (fallbackCopyText(text)) {
      showCopyFeedback("コピーしました", event);
    } else {
      showCopyFeedback("コピーできませんでした", event);
    }
  }
}

function csv(value) {
  return `"${String(value).replaceAll('"', '""')}"`; }

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}



const QUICK_LINK_CSV_PATH = "images/links.csv";
const QUICK_LINK_ICON_PATH = "images/quick-link.svg";
const QUICK_LINK_FALLBACK_ROWS = [
  { label: "CRUD", url: "http://10.202.6.34/BatchSupportSiteManager/crud/crudInit" },
  { label: "HULFT", url: "http://10.202.6.36/cgi-bin/si/index.cgi?controller=HulftList" },
  { label: "RPS", url: "http://10.202.168.238:19001/" },
  { label: "本番RPS", url: "http://10.202.168.238:13010/" },
  { label: "jpmon", url: "http://jpmon.dc/app_index.html" },
  { label: "Desknets", url: "http://d9grphonv01.nss.nksol.co.jp/scripts/dneo/dneo.exe" }
];

function splitQuickLinkCsvLine(line) {
  const cells = [];
  let value = "";
  let inQuote = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line.charAt(i);
    const next = line.charAt(i + 1);
    if (ch === '"' && inQuote && next === '"') {
      value += '"';
      i += 1;
    } else if (ch === '"') {
      inQuote = !inQuote;
    } else if (ch === "," && !inQuote) {
      cells.push(value.trim());
      value = "";
    } else {
      value += ch;
    }
  }
  cells.push(value.trim());
  return cells;
}

function normalizeQuickLinkUrl(url) {
  const value = String(url || "").trim();
  if (!value) return "#";
  if (/^(https?:|mailto:|file:|\/|#)/i.test(value)) return value;
  return `http://${value}`;
}

function parseQuickLinkCsv(text) {
  const rows = [];
  String(text || "")
    .replace(/^\uFEFF/, "")
    .split(/\r?\n/)
    .forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) return;
      const cells = splitQuickLinkCsvLine(line);
      const label = (cells.shift() || "").trim();
      const url = cells.join(",").trim();
      if (!label || !url) return;
      rows.push({ label, url: normalizeQuickLinkUrl(url) });
    });
  return rows;
}

function decodeQuickLinkCsvBuffer(buffer) {
  let text = new TextDecoder("utf-8").decode(buffer);
  if (text.includes("・・")) {
    try {
      const sjisText = new TextDecoder("shift_jis").decode(buffer);
      if (!sjisText.includes("・・")) text = sjisText;
    } catch (ignore) {
      // Edge/Chrome では shift_jis を利用できる。失敗した場合は UTF-8 の結果を使う。
    }
  }
  return text;
}

function orderQuickLinkRows(rows, listElement) {
  const map = new Map();
  rows.forEach(row => {
    if (row && row.label) map.set(row.label, row);
  });

  const currentOrder = Array.from(listElement.querySelectorAll(".quickLinkItem"))
    .map(item => item.dataset.linkName || item.textContent.trim())
    .filter(Boolean);

  const ordered = [];
  currentOrder.forEach(label => {
    if (map.has(label)) {
      ordered.push(map.get(label));
      map.delete(label);
    }
  });

  rows.forEach(row => {
    if (map.has(row.label)) {
      ordered.push(row);
      map.delete(row.label);
    }
  });

  return ordered;
}

function createQuickLinkItem(row) {
  const link = document.createElement("a");
  link.className = "quickLinkItem";
  link.href = normalizeQuickLinkUrl(row.url);
  link.dataset.linkName = row.label;
  if (link.href && link.getAttribute("href") !== "#") {
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  }

  const icon = document.createElement("img");
  icon.className = "quickLinkIconImg";
  icon.src = QUICK_LINK_ICON_PATH;
  icon.alt = "";
  icon.setAttribute("aria-hidden", "true");
  icon.addEventListener("error", () => {
    icon.style.display = "none";
  }, { once: true });

  const text = document.createElement("span");
  text.textContent = row.label;

  link.appendChild(icon);
  link.appendChild(text);
  return link;
}

function renderQuickLinks(rows) {
  const list = $("quickLinkList");
  if (!list) return;

  const orderedRows = orderQuickLinkRows(rows, list);
  list.innerHTML = "";

  if (!orderedRows.length) {
    const empty = document.createElement("div");
    empty.className = "quickLinkItem quickLinkItemEmpty";
    empty.textContent = "links.csv にリンクがありません";
    list.appendChild(empty);
    return;
  }

  orderedRows.forEach(row => {
    list.appendChild(createQuickLinkItem(row));
  });
}

async function loadQuickLinksFromCsv() {
  const list = $("quickLinkList");
  if (!list) return;

  // file://ではローカルCSVへのfetch自体がブラウザ仕様でCORSエラーになる。
  // そのため通信を発生させず、同内容の埋め込み初期値を使用する。
  if (window.location.protocol === "file:") {
    renderQuickLinks(QUICK_LINK_FALLBACK_ROWS);
    return;
  }

  const csvPath = list.dataset.linksCsv || QUICK_LINK_CSV_PATH;
  try {
    const response = await fetch(csvPath, { cache: "no-store", credentials: "same-origin" });
    if (!response.ok) throw new Error(`links.csv load failed: ${response.status}`);
    const buffer = await response.arrayBuffer();
    const rows = parseQuickLinkCsv(decodeQuickLinkCsvBuffer(buffer));
    renderQuickLinks(rows.length ? rows : QUICK_LINK_FALLBACK_ROWS);
  } catch (error) {
    console.warn("links.csvを読み込めないため、埋め込み初期値を使用します。", error);
    renderQuickLinks(QUICK_LINK_FALLBACK_ROWS);
  }
}

function openIndexPageAsInitialStartup() {
  // Krugle+アイコン押下時は、SPA内のホーム切替ではなく index.html を開き直す。
  // これにより、サイトを初期起動した時と同じ初期表示に戻す。
  try {
    removeSessionStorage(TAB_NAVIGATION_STORAGE_KEY);
    removeSessionStorage(TAB_NAVIGATION_CURRENT_ID_KEY);
  } catch (e) {
    // 画面遷移を優先する。
  }

  const fallback = "index.html";
  try {
    const url = new URL(window.location.href);
    const path = url.pathname || "/";
    const basePath = path.endsWith("/")
      ? path
      : /\/[^/]+\.[^/]*$/.test(path)
        ? path.replace(/\/[^/]*$/, "/")
        : `${path}/`;
    url.pathname = `${basePath}index.html`.replace(/\/+/g, "/");
    url.search = "";
    url.hash = "";
    window.location.assign(url.toString());
  } catch (e) {
    window.location.assign(fallback);
  }
}

function bindEvents() {
  const on = (id, eventName, handler) => {
    const element = $(id);
    if (element) element.addEventListener(eventName, handler);
  };

  document.querySelectorAll(".tabBtn").forEach(button => {
    button.addEventListener("click", () => {
      if (button.classList.contains("tabFile")) {
        const index = Number(button.dataset.code || 0);
        openCode(sampleFiles[index] || sampleFiles[0]);
        document.querySelectorAll(".tabBtn").forEach(item => item.classList.remove("isActive"));
        button.classList.add("isActive");
      } else {
        showView(button.dataset.view);
      }
    });
  });
  on("searchBtn", "click", () => {
    runSearchFromCurrentInput("normal");
  });
  on("sampleBtn", "click", () => {
    runSearchFromCurrentInput("fuzzy");
  });
  on("groupSelect", "change", () => {
    loadDirectoryGroupsForSelectedMigrationGroup({ preserveValue: false });
  });
  on("downloadBtn", "click", downloadCurrent);
  on("copyBtn", "click", copyCurrent);
  on("krugleBadge", "click", () => {
    openIndexPageAsInitialStartup();
  });
  on("historyClearBtn", "click", resetStoredHistories);

  // 通常のネイティブ select に戻す。カスタム検索コンボは初期化しない。

  const quickLinkDock = $("quickLinkDock");
  const quickLinkTrigger = $("quickLinkTrigger");
  const quickLinkOverlay = $("quickLinkOverlay");
  const quickLinkPanel = $("quickLinkPanel");
  const quickLinkClose = $("quickLinkClose");

  // 白いリンクパネルに一度でもマウスが入ったかを保持する。
  // パネルに入る前（Linksからパネルへ移動中など）は閉じず、
  // 一度入った後にパネル外へ出た時だけ閉じる。
  let quickLinkPanelHoverActivated = false;

  const setQuickLinkExpanded = expanded => {
    const wasExpanded = Boolean(quickLinkOverlay && quickLinkOverlay.classList.contains("isOpen"));
    if (expanded && !wasExpanded) quickLinkPanelHoverActivated = false;
    if (!expanded) quickLinkPanelHoverActivated = false;

    if (quickLinkTrigger) quickLinkTrigger.setAttribute("aria-expanded", expanded ? "true" : "false");
    if (quickLinkOverlay) {
      quickLinkOverlay.classList.toggle("isOpen", expanded);
      quickLinkOverlay.setAttribute("aria-hidden", expanded ? "false" : "true");

      // 閉じた後の透明な前面要素が、背面の履歴テーブル hover を邪魔しないようにする。
      if (expanded) {
        quickLinkOverlay.removeAttribute("hidden");
        quickLinkOverlay.style.display = "flex";
        quickLinkOverlay.style.pointerEvents = "auto";
        quickLinkOverlay.style.visibility = "visible";
        quickLinkOverlay.style.zIndex = "900";
      } else {
        quickLinkOverlay.setAttribute("hidden", "hidden");
        quickLinkOverlay.style.display = "none";
        quickLinkOverlay.style.pointerEvents = "none";
        quickLinkOverlay.style.visibility = "hidden";
        quickLinkOverlay.style.zIndex = "-1";
      }
    }
    document.body.classList.toggle("quickLinksOpen", expanded);
  };
  const openQuickLinks = () => setQuickLinkExpanded(true);
  const closeQuickLinks = () => {
    setQuickLinkExpanded(false);
  };
  if (quickLinkOverlay) setQuickLinkExpanded(false);

  if (quickLinkDock && quickLinkTrigger && quickLinkOverlay) {
    quickLinkDock.addEventListener("mouseenter", openQuickLinks);
    quickLinkTrigger.addEventListener("focus", openQuickLinks);
    quickLinkTrigger.addEventListener("click", event => {
      event.preventDefault();
      openQuickLinks();
      if (quickLinkPanel) quickLinkPanel.focus({ preventScroll: true });
    });
    if (quickLinkClose) {
      quickLinkClose.addEventListener("click", event => {
        event.preventDefault();
        closeQuickLinks();
      });
    }
    quickLinkOverlay.addEventListener("click", event => {
      if (event.target === quickLinkOverlay) closeQuickLinks();
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape" && quickLinkOverlay.classList.contains("isOpen")) {
        event.preventDefault();
        closeQuickLinks();
      }
    });
  }


  if (quickLinkPanel) {
    quickLinkPanel.addEventListener("mouseenter", () => {
      if (quickLinkOverlay && quickLinkOverlay.classList.contains("isOpen")) {
        quickLinkPanelHoverActivated = true;
      }
    });

    quickLinkPanel.addEventListener("mouseleave", () => {
      if (!quickLinkPanelHoverActivated) return;
      quickLinkPanelHoverActivated = false;
      closeQuickLinks();
    });

    quickLinkPanel.addEventListener("click", event => {
      const link = event.target.closest ? event.target.closest(".quickLinkItem") : null;
      if (!link || link.tagName.toLowerCase() !== "a") return;
      if (!link.getAttribute("href") || link.getAttribute("href") === "#") {
        event.preventDefault();
        const label = link.textContent.trim() || "リンク";
        showCopyFeedback(`${label} のURLは未設定です`);
      }
    });
  }
  // 2026-08-07 fix29:
  // 右/左タブ移動ボタンは通常ボタンと同じくclick/Enter/Spaceで即時移動する。
  bindCodeSideNavigationPreviewButtons();
  const codeModeTabs = document.querySelector(".codeModeTabs");
  if (codeModeTabs) {
    codeModeTabs.addEventListener("click", event => {
      const button = event.target.closest ? event.target.closest(".codeModeTab") : null;
      if (!button || !codeModeTabs.contains(button)) return;
      if (button.disabled || button.getAttribute("aria-disabled") === "true") return;
      activeCodePanel = button.dataset.codePanel || "source";
      if (isTableInfoPanel(activeCodePanel)) {
        activeTableInfoTabId = getTableInfoTabIdFromPanel(activeCodePanel);
        tableInfoState = getActiveTableInfoState();
      }
      renderCode();
    });
  }
  on("smallBtn", "click", () => setCodeFontSize(codeFontSize - CODE_FONT_STEP));
  on("largeBtn", "click", () => setCodeFontSize(codeFontSize + CODE_FONT_STEP));
  on("highlightToggleBtn", "click", toggleCodeHighlightBackground);
  bindCodeBackTabButton();

  window.addEventListener("scroll", requestCodeSearchPanelScrollStateUpdate, { passive: true });
  window.addEventListener("resize", requestCodeSearchPanelScrollStateUpdate);

  // ページを開いた直後は必ずOFF。下線はCSSで常時表示し、背景色だけを無効にする。
  setCodeHighlightBackgroundEnabled(false);

  on("keywordInput", "focus", () => renderKeywordHistoryDatalist());
  on("keywordInput", "input", () => renderKeywordHistoryDatalist());

  on("keywordInput", "keydown", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      runSearchFromCurrentInput("normal");
    }
  });

  // captureフェーズで受け取り、ブラウザ標準の履歴戻りより先にサイト内タブ履歴へ割り当てる。
  document.addEventListener("keydown", handleBackspaceTabNavigation, true);

  // 2026-08-12 fix59: マウスカーソルが右側縦ボタン「前のタブへ戻る」上にある場合のEnterもBackSpaceと同じ処理にする。
  document.addEventListener("keydown", event => {
    if (event.key !== "Enter") return;
    if (!activeCodeBackTabButtonHover) return;
    if (isKeyboardTypingTarget(event.target)) return;
    activatePreviousOpenedTabButton(event);
  }, true);

  document.addEventListener("keydown", event => {
    activateFullWidthHoverBandActionByEnter(event);
  }, true);

  // 2026-08-12 fix46: マウスカーソルが右/左タブ移動ボタン上にある場合も、
  // EnterはArrowRight/ArrowLeftキーと同じく対象数字タブへfocus移動 + 全幅グレー帯表示だけにする。
  document.addEventListener("keydown", event => {
    if (event.key !== "Enter") return;
    if (!activeCodeSideNavigationHoverOffset) return;
    if (isKeyboardTypingTarget(event.target)) return;
    // 2026-08-12 fix60:
    // 数字タブにfocusが残っていても、マウスが右/左タブ移動ボタン上なら
    // Enterはタブを開かず、ボタンの疑似hoverプレビューを1つ進める。
    activateCodeSideNavigationButton(activeCodeSideNavigationHoverOffset, event);
  }, true);


  // 2026-08-04 サイト修正3: 全幅グレー帯が出ている状態でクリック遷移する場合も、
  // 遷移直後の別hover帯の即時再表示を防ぐ。
  document.addEventListener("click", () => {
    if (document.body && document.body.classList.contains("isRecentTabFullPathBandVisible")) {
      suppressFullWidthHoverBandTemporarily();
    }
  }, true);

  document.addEventListener("keydown", event => {
    if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
    handleRecentTabArrowKeyNavigation(event.key === "ArrowRight" ? 1 : -1, event);
  });

  const stalker = $("mouseStalker");
  const hoverTargetSelector = [
    "button",
    "#historyFileBody tr",
    "#historySearchBody tr",
    ".tabTime",
    ".recentNavArrow",
    ".krugleBadge",
    ".quickLinkDock",
    ".quickLinkTrigger",
    ".quickLinkOverlay",
    ".quickLinkClose",
    ".quickLinkItem",
    ".searchPanel input",
    ".searchPanel select",
    ".groupCombo",
    ".groupComboItem",
    ".groupComboSearch",
    ".searchPanel .cloneField",
    ".globalHistoryMini tr"
  ].join(",");

  document.addEventListener("mousemove", event => {
    stalker.style.transform = `translate(${event.clientX}px, ${event.clientY}px)`;
    if (event.target.closest && event.target.closest(hoverTargetSelector)) {
      stalker.classList.add("isActive");
    } else {
      stalker.classList.remove("isActive");
    }
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  initializeTabNavigationHistory();
  bindEvents();
  await loadQuickLinksFromCsv();
  resetInitialSearchSummary();
  renderInitialResultPlaceholders();
  renderRecentTabs();
  await loadInitialData();
  await loadInitialSearchResult();
  renderHistory();
  requestCodeSearchPanelScrollStateUpdate();
});


