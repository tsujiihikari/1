package jp.dbplus;

import java.io.*;
import java.util.*;

/** DBSchema.csv（引用符付きCSV）と、従来のタブ区切りpropertiesを同じ列名で読む。 */
final class Catalog {
    static final class Entry {
        String key,type,dbtype,schema,host,port,service,sid,user,password;
        String url(){
            return service.isEmpty()?"jdbc:oracle:thin:@"+host+":"+port+":"+sid
                :"jdbc:oracle:thin:@//"+host+":"+port+"/"+service;
        }
        Map<String,Object> publicInfo(){
            // DBユーザー・パスワードを画面へ送らない。重複接続先はラベルで識別する。
            return Json.obj("connectionId",key,"type",type,"dbtype",dbtype,"schema",schema,
                "label",type+" / "+dbtype+" / "+schema+" / "+(service.isEmpty()?sid:service)+" ("+host+")");
        }
    }
    final List<Entry> entries=new ArrayList<>();
    Catalog(String text) throws IOException {
        text=text.replaceFirst("^\\uFEFF","").replaceFirst("^(?:[ \\t]*\\r?\\n)+","");
        String first=text.split("\\r?\\n",2)[0];
        List<List<String>> rows=records(text,first.contains("\t")?'\t':',');
        if(rows.size()<2)throw new IOException("DBSchemaの接続定義が空です。");
        Map<String,Integer> headers=new HashMap<>();List<String> h=rows.get(0);
        for(int i=0;i<h.size();i++)headers.put(h.get(i).trim(),i);
        for(String n:Arrays.asList("type","db_type","sid","host","port","service_name","user_name","password","rps_schema_name"))
            if(!headers.containsKey(n))throw new IOException("DBSchemaの必須ヘッダーがありません: "+n);
        for(int line=1;line<rows.size();line++){
            List<String> a=rows.get(line);
            if(a.size()==1&&a.get(0).trim().isEmpty())continue;
            if(a.size()!=h.size())throw new IOException("DBSchemaの列数が不正です。レコード: "+(line+1));
            Entry e=new Entry();e.key="connection-"+(line+1);e.type=val(a,headers,"type");
            e.dbtype=val(a,headers,"db_type");e.schema=val(a,headers,"rps_schema_name");
            e.host=val(a,headers,"host");e.port=val(a,headers,"port");e.service=val(a,headers,"service_name");
            e.sid=val(a,headers,"sid");e.user=val(a,headers,"user_name");
            e.password=a.get(headers.get("password")); // パスワードの前後空白を変更しない。
            if(!e.host.matches("[A-Za-z0-9.-]+")||!e.port.matches("[0-9]{1,5}")
                ||Integer.parseInt(e.port)<1||Integer.parseInt(e.port)>65535
                ||(e.service.isEmpty()&&e.sid.isEmpty())||e.schema.isEmpty()||e.user.isEmpty()||e.dbtype.isEmpty())
                throw new IOException("DBSchemaの接続定義が不正です。レコード: "+(line+1));
            entries.add(e);
        }
        if(entries.isEmpty())throw new IOException("DBSchemaの接続先がありません。");
    }
    /** CSVの二重引用符、引用符内のカンマ・改行、CRLF、末尾空列を処理する。 */
    static List<List<String>> records(String text,char separator) throws IOException {
        List<List<String>> out=new ArrayList<>();List<String> row=new ArrayList<>();
        StringBuilder field=new StringBuilder();boolean quoted=false,closed=false;
        for(int i=0;i<text.length();i++){
            char ch=text.charAt(i);
            if(quoted){
                if(ch=='"'){
                    if(i+1<text.length()&&text.charAt(i+1)=='"'){field.append('"');i++;}
                    else{quoted=false;closed=true;}
                }else field.append(ch);
            }else if(ch==separator||ch=='\n'||ch=='\r'){
                row.add(field.toString());field.setLength(0);closed=false;
                if(ch!=separator){out.add(row);row=new ArrayList<>();if(ch=='\r'&&i+1<text.length()&&text.charAt(i+1)=='\n')i++;}
            }else if(closed)throw new IOException("DBSchemaの引用符の後に不正な文字があります。");
            else if(ch=='"'){
                if(field.length()!=0)throw new IOException("DBSchemaの引用符の位置が不正です。");
                quoted=true;
            }else field.append(ch);
        }
        if(quoted)throw new IOException("DBSchemaの引用符が閉じていません。");
        if(field.length()!=0||!row.isEmpty()||closed){row.add(field.toString());out.add(row);}
        return out;
    }
    static String val(List<String> a,Map<String,Integer> h,String n){return a.get(h.get(n)).trim();}
    Entry resolve(String key,String dbtype,String schema){
        List<Entry> matches=new ArrayList<>();
        for(Entry e:entries)if((key.isEmpty()||key.equals(e.key))&&e.dbtype.equals(dbtype)&&e.schema.equals(schema))matches.add(e);
        if(matches.size()!=1)throw new IllegalArgumentException(matches.isEmpty()?"接続先・DBTYPE・スキーマの組合せが登録されていません。":"同じDBTYPE・スキーマに複数の接続先があります。connectionIdを指定してください。");
        return matches.get(0);
    }
    List<Object> publicEntries(){List<Object> a=new ArrayList<>();for(Entry e:entries)a.add(e.publicInfo());return a;}
}
