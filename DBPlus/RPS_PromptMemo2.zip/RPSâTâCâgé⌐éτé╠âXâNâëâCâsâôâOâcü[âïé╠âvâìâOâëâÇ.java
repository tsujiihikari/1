import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

    // =========================================================
    // RPS�ڑ���
    // =========================================================
    static String BASE = "http://10.202.168.238:13010";
    static String LOGIN_URL = BASE + "/login/login?domain=nss.nksol.co.jp&shain_cd=8045984&pass=066HikariNaho";
    static String SCHEMA = "KYKOWNER";

    static long SLEEP_MS = 100;

    // �v���L�V�s�v�Ȃ� false
    static boolean USE_PROXY = true;
    static String PROXY_HOST = "10.202.5.30";
    static int PROXY_PORT = 8080;

    // =========================================================
    // Oracle �ڑ��ݒ�
    // =========================================================
    static String JDBC_URL = "jdbc:oracle:thin:@//10.206.12.112:1621/dlmkt1.world";
    static String JDBC_USER = "OBJECT_KYKELT";
    static String JDBC_PASS = "OBJECT_USER_KYKELT";

    // �o�b�`�T�C�Y
    static final int BATCH_SIZE = 500;

    // �ڍ׎擾���������i0�ȉ��Ȃ�S���j
    static int MAX_DETAIL_FETCH = 0;

    static CookieManager cookieManager = new CookieManager(null, CookiePolicy.ACCEPT_ALL);

    public static void main(String[] args) throws Exception {

        CookieHandler.setDefault(cookieManager);

        File resultDir = new File("./result");
        if (!resultDir.exists()) resultDir.mkdirs();

        Class.forName("oracle.jdbc.OracleDriver");

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS)) {
            conn.setAutoCommit(false);

            // 1. ���O�C��
            String loginHtml = get(LOGIN_URL);
            writeText(new File(resultDir, "_debug_login.html"), loginHtml);

            String token = extractFirst(loginHtml, "name=\"authenticity_token\"\\s+value=\"([^\"]+)\"");
            System.out.println("token=" + token);

            if (isBlank(token)) {
                throw new RuntimeException("authenticity_token ���擾�ł��܂���ł����B���O�C��HTML���m�F���Ă��������B");
            }

            sleep();

            // 2. schema�ݒ�
            String schemaBody =
                    "schema=" + urlEnc(SCHEMA)
                    + "&utf8=" + urlEnc("?")
                    + "&authenticity_token=" + urlEnc(token);

            String schemaResp = post(BASE + "/schema/set_schema", schemaBody);
            writeText(new File(resultDir, "_debug_set_schema.html"), schemaResp);

            sleep();

            // schema�ݒ��HTML���� token ����蒼��
            String token2 = extractFirst(schemaResp, "name=\"authenticity_token\"\\s+value=\"([^\"]+)\"");
            if (!isBlank(token2)) {
                token = token2;
            }

            // 3. �e�[�u���ꗗ�擾�i�y�[�W���O�j
            List<TableListInfo> tables = fetchAllTableList(resultDir);
            System.out.println("tables=" + tables.size());

            // 4. �ꗗInsert -> �ڍ�Insert
            insertAll(conn, tables, resultDir);

            conn.commit();
            System.out.println("==== END ====");
        }
    }

    // =========================================================
    // �ꗗ�y�[�W���O�擾
    // =========================================================
    static List<TableListInfo> fetchAllTableList(File resultDir) throws Exception {
        List<TableListInfo> all = new ArrayList<>();
        int page = 1;

        while (true) {
            sleep();

            String listUrl =
                    BASE + "/table/list"
                    + "?utf8=%E2%9C%93"
                    + "&pm=ent"
                    + "&keyword_db="
                    + "&keyword_object_name="
                    + "&keyword_description="
                    + "&keyword_group_name="
                    + "&search_condition%5Btype%5D=REFLECT"
                    + "&submit=%E5%85%A8%E4%BB%B6%E8%A1%A8%E7%A4%BA"
                    + "&page=" + page;

            String listHtml = get(listUrl);

            if (page == 1) {
                writeText(new File(resultDir, "_debug_table_list_page1.html"), listHtml);
            }

            List<TableListInfo> pageList = parseTableList(listHtml);
            System.out.println("page=" + page + " tables=" + pageList.size());

            if (pageList.isEmpty()) {
                break;
            }

            all.addAll(pageList);

            if (!hasNextPage(listHtml, page)) {
                break;
            }

            page++;
            if (page > 9999) {
                throw new RuntimeException("�y�[�W�����ُ�ł��Bpage=" + page);
            }
        }

        return uniqueTables(all);
    }

    static boolean hasNextPage(String html, int currentPage) {
        if (html == null) return false;
        String next1 = "page=" + (currentPage + 1);
        String next2 = ">" + (currentPage + 1) + "<";
        return html.contains(next1) || html.contains(next2);
    }

    // =========================================================
    // �ꗗHTML���
    // =========================================================
    static List<TableListInfo> parseTableList(String html) throws Exception {
        List<TableListInfo> list = new ArrayList<>();

        String tableHtml = extractFirst(html, "(<table class=\"std_hover\">.*?</table>)");
        if (isBlank(tableHtml)) {
            return list;
        }

        List<String> trList = extractAll(tableHtml, "<tr[^>]*>(.*?)</tr>");
        if (trList.isEmpty()) return list;

        // �擪�̓w�b�_�s
        for (int i = 1; i < trList.size(); i++) {
            String tr = trList.get(i);

            List<String> tdList = extractAll(tr, "<td[^>]*>(.*?)</td>");
            if (tdList.size() < 5) {
                continue;
            }

            String anchorHref = extractFirst(tr, "<a\\s+href=\"([^\"]*/column/show_table\\?[^\"]+)\"[^>]*>");
            if (isBlank(anchorHref)) {
                continue;
            }

            String full = anchorHref.startsWith("http") ? anchorHref : BASE + anchorHref;
            Map<String, String> qp = parseQuery(full);

            String tableName = qp.getOrDefault("table_name", "");
            if (isBlank(tableName)) {
                continue;
            }

            TableListInfo o = new TableListInfo();
            o.dbType = qp.getOrDefault("instance", cleanText(getByIndex(tdList, 0)));
            o.version = qp.getOrDefault("version", cleanText(getByIndex(tdList, 1)));
            o.name = tableName;
            o.partition = tdList.size() > 3 ? cleanText(tdList.get(3)) : "";
            o.name2 = qp.getOrDefault("description", cleanText(getByIndex(tdList, 4)));
            o.maxCount = tdList.size() > 5 ? cleanText(tdList.get(5)) : "";
            o.updateDay = tdList.size() > 6 ? cleanText(tdList.get(6)) : "";
            o.tantosha = tdList.size() > 7 ? cleanText(tdList.get(7)) : "";
            o.personalData = tdList.size() > 8 ? cleanText(tdList.get(8)) : "";
            o.statistics = tdList.size() > 9 ? cleanText(tdList.get(9)) : "";

            o.schema = qp.getOrDefault("schema", SCHEMA);
            o.detailUrl = full;

            list.add(o);
        }

        return list;
    }

    static List<TableListInfo> uniqueTables(List<TableListInfo> src) {
        Map<String, TableListInfo> map = new LinkedHashMap<>();
        for (TableListInfo t : src) {
            String key = nvl(t.dbType) + "|" + nvl(t.version) + "|" + nvl(t.name);
            map.put(key, t);
        }
        return new ArrayList<>(map.values());
    }

    // =========================================================
    // �ꗗ -> �ڍ� �̏��ňꊇInsert
    // =========================================================
    static void insertAll(Connection conn, List<TableListInfo> tables, File resultDir) throws Exception {

        String seqSql = "SELECT RPS_TABLE_LIST_SEQ.NEXTVAL FROM DUAL";

        // PARTITION �͗\������̂��߃_�u���N�H�[�g
String insertListSql =
        "INSERT INTO RPS_TABLE_LIST ("
        + " ID, DBTYPE, VERSION, NAME, PART, NAME2, MAX_COUNT, UPDATE_DAY, TANTOSHA, PERSONAL_DATA, STATISTICS"
        + ") VALUES ("
        + " ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?"
        + ")";

        String insertDataSql =
                "INSERT INTO RPS_TABLE_DATA ("
                + " ID, NO, NAME, PKKEY, PART, KATA, COLUMN_SIZE, NULL_CONST, NAME2, DESCRIPTION, REFERENCE, DEFAULT_VALUE, CHECK_CONST"
                + ") VALUES ("
                + " ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?"
                + ")";

        int listCount = 0;
        int dataCount = 0;

        try (
                PreparedStatement seqPs = conn.prepareStatement(seqSql);
                PreparedStatement psList = conn.prepareStatement(insertListSql);
                PreparedStatement psData = conn.prepareStatement(insertDataSql)
        ) {
            // -------------------------------------------------
            // 1. �V�[�P���X��S������Ɋm��
            // -------------------------------------------------
            Map<String, Long> idMap = new LinkedHashMap<>();
            int reserveTargetCount = 0;

            for (int i = 0; i < tables.size(); i++) {
                if (MAX_DETAIL_FETCH > 0 && reserveTargetCount >= MAX_DETAIL_FETCH) {
                    break;
                }

                TableListInfo t = tables.get(i);
                long id = nextSeq(seqPs);
                idMap.put(buildTableKey(t), id);
                reserveTargetCount++;
            }

            System.out.println("reserved seq count=" + idMap.size());

            // -------------------------------------------------
            // 2. �ꗗ���ɑS�� INSERT
            //    _debug_table_list_page1.html ���擾����parse�����ꗗ�f�[�^�������Ŕ��f
            // -------------------------------------------------
            int listTargetCount = 0;

            for (int i = 0; i < tables.size(); i++) {
                if (MAX_DETAIL_FETCH > 0 && listTargetCount >= MAX_DETAIL_FETCH) {
                    break;
                }

                TableListInfo t = tables.get(i);
                Long id = idMap.get(buildTableKey(t));
                if (id == null) {
                    throw new RuntimeException("ID���m��: " + t.name);
                }

                psList.setLong(1, id);
                setStringLimit(psList, 2, t.dbType, 20, "RPS_TABLE_LIST.DBTYPE", t.name);
                setStringLimit(psList, 3, t.version, 20, "RPS_TABLE_LIST.VERSION", t.name);
                setStringLimit(psList, 4, t.name, 60, "RPS_TABLE_LIST.NAME", t.name);
                setStringLimit(psList, 5, t.partition, 30, "RPS_TABLE_LIST.PART", t.name);
                setStringLimit(psList, 6, t.name2, 300, "RPS_TABLE_LIST.NAME2", t.name);
                setStringLimit(psList, 7, t.maxCount, 30, "RPS_TABLE_LIST.MAX_COUNT", t.name);
                setStringLimit(psList, 8, t.updateDay, 30, "RPS_TABLE_LIST.UPDATE_DAY", t.name);
                setStringLimit(psList, 9, t.tantosha, 30, "RPS_TABLE_LIST.TANTOSHA", t.name);
                setStringLimit(psList, 10, t.personalData, 30, "RPS_TABLE_LIST.PERSONAL_DATA", t.name);
                setStringLimit(psList, 11, t.statistics, 30, "RPS_TABLE_LIST.STATISTICS", t.name);
                psList.addBatch();

                listCount++;
                listTargetCount++;

                if (listCount % BATCH_SIZE == 0) {
                    psList.executeBatch();
                    conn.commit();
                    System.out.println("list batch committed. count=" + listCount);
                }
            }

            if (listCount % BATCH_SIZE != 0) {
                psList.executeBatch();
            }
            conn.commit();
            System.out.println("LIST insert done. total=" + listCount);

            // -------------------------------------------------
            // 3. �ꗗINSERT������ɏڍׂ��擾���� DATA INSERT
            // -------------------------------------------------
            int fetched = 0;

            for (int i = 0; i < tables.size(); i++) {
                if (MAX_DETAIL_FETCH > 0 && fetched >= MAX_DETAIL_FETCH) {
                    break;
                }

                TableListInfo t = tables.get(i);
                Long id = idMap.get(buildTableKey(t));
                if (id == null) {
                    throw new RuntimeException("DETAIL����ID���m��: " + t.name);
                }

                try {
                    sleep();

                    String html = get(t.detailUrl);
                    if (i < 3) {
                        writeText(new File(resultDir, "_debug_detail_" + safeFileName(t.name) + ".html"), html);
                    }

                    DetailTable detail = parseDetailTable(html);

                    int fallbackRowNo = 0;
                    for (ColumnInfo c : detail.columns) {
                        fallbackRowNo++;

                        int no = c.no > 0 ? c.no : fallbackRowNo;

                        psData.setLong(1, id);
                        psData.setInt(2, no);
                        setStringLimit(psData, 3, c.name, 30, "RPS_TABLE_DATA.NAME", t.name + ":" + no);
                        setStringLimit(psData, 4, c.pkKey, 20, "RPS_TABLE_DATA.PKKEY", t.name + ":" + no);
                        setStringLimit(psData, 5, c.part, 30, "RPS_TABLE_DATA.PART", t.name + ":" + no);
                        setStringLimit(psData, 6, c.kata, 20, "RPS_TABLE_DATA.KATA", t.name + ":" + no);
                        setStringLimit(psData, 7, c.columnSize, 20, "RPS_TABLE_DATA.COLUMN_SIZE", t.name + ":" + no);
                        setStringLimit(psData, 8, c.nullConst, 20, "RPS_TABLE_DATA.NULL_CONST", t.name + ":" + no);
                        setStringLimit(psData, 9, c.name2, 300, "RPS_TABLE_DATA.NAME2", t.name + ":" + no);
                        setStringLimit(psData, 10, c.description, 600, "RPS_TABLE_DATA.DESCRIPTION", t.name + ":" + no);
                        setStringLimit(psData, 11, c.reference, 600, "RPS_TABLE_DATA.REFERENCE", t.name + ":" + no);
                        setStringLimit(psData, 12, c.defaultValue, 100, "RPS_TABLE_DATA.DEFAULT_VALUE", t.name + ":" + no);
                        setStringLimit(psData, 13, c.checkConst, 100, "RPS_TABLE_DATA.CHECK_CONST", t.name + ":" + no);
                        psData.addBatch();
                        dataCount++;

                        if (dataCount % BATCH_SIZE == 0) {
                            psData.executeBatch();
                            conn.commit();
                            System.out.println("data batch committed. count=" + dataCount);
                        }
                    }

                    fetched++;
                    System.out.println("saved=" + t.name + " (" + (i + 1) + "/" + tables.size() + ") detailRows=" + detail.columns.size());

                } catch (Exception e) {
                    System.out.println("ERR detail table=" + t.name + " msg=" + e.getMessage());
                    e.printStackTrace(System.out);
                }
            }

            if (dataCount % BATCH_SIZE != 0) {
                psData.executeBatch();
            }

            conn.commit();
            System.out.println("DATA insert done. total=" + dataCount);
        }
    }

    static long nextSeq(PreparedStatement seqPs) throws SQLException {
        try (ResultSet rs = seqPs.executeQuery()) {
            if (rs.next()) {
                return rs.getLong(1);
            }
        }
        throw new SQLException("RPS_TABLE_LIST_SEQ.NEXTVAL ���擾�ł��܂���ł���");
    }

    static String buildTableKey(TableListInfo t) {
        return nvl(t.dbType) + "|" + nvl(t.version) + "|" + nvl(t.name);
    }

    // =========================================================
    // �ڍ�HTML���
    // =========================================================
    static DetailTable parseDetailTable(String html) {
        DetailTable dt = new DetailTable();

        String tableHtml = extractFirst(html, "(<table class=\"std_hover\">.*?</table>)");
        if (isBlank(tableHtml)) {
            return dt;
        }

        List<String> trList = extractAll(tableHtml, "<tr[^>]*>(.*?)</tr>");
        if (trList.isEmpty()) {
            return dt;
        }

        List<String> headers = new ArrayList<>();
        boolean headerDone = false;

        for (String tr : trList) {

            List<String> ths = extractAll(tr, "<th[^>]*>(.*?)</th>");
            List<String> headerTds = extractAll(tr, "<td[^>]*>(.*?)</td>");

            if (!headerDone) {
                if (!ths.isEmpty()) {
                    for (String th : ths) {
                        headers.add(normalizeHeader(cleanText(th)));
                    }
                    headerDone = true;
                    continue;
                } else if (looksLikeHeaderRow(headerTds)) {
                    for (String td : headerTds) {
                        headers.add(normalizeHeader(cleanText(td)));
                    }
                    headerDone = true;
                    continue;
                }
            }

            List<String> tds = extractAll(tr, "<td[^>]*>(.*?)</td>");
            if (tds.isEmpty()) {
                continue;
            }

            List<String> vals = new ArrayList<>();
            for (String td : tds) {
                vals.add(cleanText(td));
            }

            ColumnInfo c = toColumnInfo(headers, vals);
            if (!isBlank(c.name) || !isBlank(c.name2) || !isBlank(c.description) || c.no > 0) {
                dt.columns.add(c);
            }
        }

        return dt;
    }

    static boolean looksLikeHeaderRow(List<String> tds) {
        if (tds == null || tds.isEmpty()) return false;

        String joined = "";
        for (String td : tds) {
            joined += " " + normalizeHeader(cleanText(td));
        }

        return containsAny(joined, "No.", "���ږ�", "�L�[", "Par", "�f�[�^�^", "�f�[�^��", "NULL����", "���{�ꖼ��", "���ڐ���", "�O���Q��", "�ȗ����l", "CHECK����");
    }

    static ColumnInfo toColumnInfo(List<String> headers, List<String> vals) {
        ColumnInfo c = new ColumnInfo();

        // header�������ꍇ�͗񏇂ōŒ���l�߂�
        if (headers == null || headers.isEmpty()) {
            c.no = parseIntSafe(getByIndex(vals, 0), 0);
            c.name = getByIndex(vals, 1);
            c.pkKey = getByIndex(vals, 2);
            c.part = getByIndex(vals, 3);
            c.kata = getByIndex(vals, 4);
            c.columnSize = getByIndex(vals, 5);
            c.nullConst = getByIndex(vals, 6);
            c.name2 = getByIndex(vals, 7);
            c.description = getByIndex(vals, 8);
            c.reference = getByIndex(vals, 9);
            c.defaultValue = getByIndex(vals, 10);
            c.checkConst = getByIndex(vals, 11);
            return c;
        }

        for (int i = 0; i < headers.size() && i < vals.size(); i++) {
            String h = headers.get(i);
            String v = vals.get(i);

            if (containsAny(h, "No.", "No", "�ԍ�")) {
                c.no = parseIntSafe(v, c.no);
            } else if (containsAny(h, "���ږ�", "�J������", "��", "name")) {
                c.name = v;
            } else if (containsAny(h, "�L�[", "pk", "��L�[")) {
                c.pkKey = v;
            } else if (containsAny(h, "par", "partition", "�p�[�e�B�V����")) {
                c.part = v;
            } else if (containsAny(h, "�^", "�f�[�^�^", "�^��")) {
                c.kata = v;
            } else if (containsAny(h, "�T�C�Y", "����", "length", "�f�[�^��")) {
                c.columnSize = v;
            } else if (containsAny(h, "null", "nullable", "notnull", "NULL����")) {
                c.nullConst = v;
            } else if (containsAny(h, "���{�ꖼ��", "����", "name2")) {
                c.name2 = v;
            } else if (containsAny(h, "���ڐ���", "����", "description")) {
                c.description = v;
            } else if (containsAny(h, "�O���Q��", "�Q��", "reference")) {
                c.reference = v;
            } else if (containsAny(h, "�ȗ����l", "�f�t�H���g", "default")) {
                c.defaultValue = v;
            } else if (containsAny(h, "check", "CHECK����", "�`�F�b�N")) {
                c.checkConst = v;
            }
        }

        return c;
    }

    static boolean containsAny(String src, String... keys) {
        if (src == null) return false;
        String s = src.toLowerCase(Locale.ROOT);
        for (String k : keys) {
            if (s.contains(k.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    static String normalizeHeader(String s) {
        if (s == null) return "";
        String x = s;
        x = x.replace("�@", " ");
        x = x.replaceAll("\\s+", "");
        return x;
    }

    static String getByIndex(List<String> vals, int idx) {
        return idx < vals.size() ? vals.get(idx) : "";
    }

    static int parseIntSafe(String s, int defaultValue) {
        if (s == null) return defaultValue;
        String x = s.replaceAll("[^0-9-]", "");
        if (x.isEmpty()) return defaultValue;
        try {
            return Integer.parseInt(x);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    // =========================================================
    // HTTP GET / POST
    // =========================================================
    static String get(String urlStr) throws Exception {
        HttpURLConnection con = openConnection(urlStr);
        con.setRequestMethod("GET");
        con.setInstanceFollowRedirects(true);
        con.setConnectTimeout(15000);
        con.setReadTimeout(15000);
        con.setRequestProperty("User-Agent", "Mozilla/5.0");

        int code = con.getResponseCode();
        InputStream is = (code >= 400) ? con.getErrorStream() : con.getInputStream();

        if (is == null) return "";

        return readAll(is);
    }

    static String post(String urlStr, String body) throws Exception {
        HttpURLConnection con = openConnection(urlStr);
        con.setRequestMethod("POST");
        con.setInstanceFollowRedirects(true);
        con.setDoOutput(true);
        con.setConnectTimeout(15000);
        con.setReadTimeout(15000);
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        con.setRequestProperty("User-Agent", "Mozilla/5.0");

        try (OutputStream os = con.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }

        int code = con.getResponseCode();
        InputStream is = (code >= 400) ? con.getErrorStream() : con.getInputStream();

        if (is == null) return "";

        return readAll(is);
    }

    static HttpURLConnection openConnection(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        if (USE_PROXY) {
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_HOST, PROXY_PORT));
            return (HttpURLConnection) url.openConnection(proxy);
        } else {
            return (HttpURLConnection) url.openConnection();
        }
    }

    static String readAll(InputStream is) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line).append('\n');
        }
        return sb.toString();
    }

    // =========================================================
    // Query parse / util
    // =========================================================
    static Map<String, String> parseQuery(String url) throws Exception {
        Map<String, String> map = new LinkedHashMap<>();

        url = url.replace("&amp;", "&");

        int idx = url.indexOf('?');
        if (idx < 0) return map;

        String query = url.substring(idx + 1);
        String[] parts = query.split("&");

        for (String s : parts) {
            String[] kv = s.split("=", 2);
            if (kv.length == 2) {
                map.put(URLDecoder.decode(kv[0], "UTF-8"), URLDecoder.decode(kv[1], "UTF-8"));
            }
        }

        return map;
    }

    static String extractFirst(String src, String regex) {
        if (src == null) return "";
        Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(src);
        return m.find() ? m.group(1) : "";
    }

    static List<String> extractAll(String src, String regex) {
        List<String> list = new ArrayList<>();
        if (src == null) return list;

        Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(src);
        while (m.find()) {
            list.add(m.group(1));
        }
        return list;
    }

    static String cleanText(String s) {
        if (s == null) return "";
        String x = s;

        x = x.replace("&nbsp;", " ");
        x = x.replace("&amp;", "&");
        x = x.replace("&lt;", "<");
        x = x.replace("&gt;", ">");
        x = x.replace("&quot;", "\"");
        x = x.replace("&#39;", "'");

        x = x.replaceAll("(?is)<script.*?</script>", " ");
        x = x.replaceAll("(?is)<style.*?</style>", " ");
        x = x.replaceAll("(?is)<br\\s*/?>", "\n");
        x = x.replaceAll("(?is)<[^>]+>", " ");
        x = x.replaceAll("[\\t\\x0B\\f\\r ]+", " ");
        x = x.replaceAll("\\n+", "\n");
        x = x.trim();

        return x;
    }

    static void writeText(File f, String s) throws Exception {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8)) {
            w.write(s == null ? "" : s);
        }
    }

    static String urlEnc(String s) throws Exception {
        return URLEncoder.encode(s, "UTF-8");
    }

    static void sleep() {
        try {
            Thread.sleep(SLEEP_MS);
        } catch (Exception ignored) {
        }
    }

    static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    static String nvl(String s) {
        return s == null ? "" : s;
    }

    static String safeFileName(String s) {
        if (s == null || s.isEmpty()) return "noname";
        return s.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    static String limit(String value, int max) {
        if (value == null) return null;
        if (max <= 0) return value;
        if (value.length() <= max) return value;
        return value.substring(0, max);
    }

    static void setStringLimit(PreparedStatement ps, int idx, String value, int max, String colName, String keyInfo) throws SQLException {
        if (value == null) {
            ps.setNull(idx, Types.VARCHAR);
            return;
        }

        String trimmed = limit(value, max);
        if (!value.equals(trimmed)) {
            System.out.println("[WARN] truncate " + colName + " max=" + max + " key=" + keyInfo + " len=" + value.length());
        }
        ps.setString(idx, trimmed);
    }

    // =========================================================
    // Data class
    // =========================================================
    static class TableListInfo {
        String dbType;
        String version;
        String name;
        String partition;
        String name2;
        String maxCount;
        String updateDay;
        String tantosha;
        String personalData;
        String statistics;

        String schema;
        String detailUrl;
    }

    static class DetailTable {
        List<ColumnInfo> columns = new ArrayList<>();
    }

    static class ColumnInfo {
        int no = 0;
        String name = "";
        String pkKey = "";
        String part = "";
        String kata = "";
        String columnSize = "";
        String nullConst = "";
        String name2 = "";
        String description = "";
        String reference = "";
        String defaultValue = "";
        String checkConst = "";
    }
}