/* jsdomによるDOM・通信競合テスト。実ブラウザの描画品質・速度測定ではない。 */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {execFileSync} = require('node:child_process');
const {JSDOM} = require('jsdom');
const root=path.resolve(__dirname,'..');
const script=`import sys,json\nsys.path.insert(0,${JSON.stringify(path.join(root,'scripts'))})\nimport demo_server as d\nnames=['KYF1940','KYF1941','EMPTY_TABLE','LONG_TEXT','PARTIAL_ERROR']\nprint(json.dumps({n:d.detail({'connectionId':'demo','schemaName':'SCHEMA_A','tableName':n}) for n in names},ensure_ascii=False))`;
const fixtures=JSON.parse(execFileSync('python3',['-c',script],{maxBuffer:16*1024*1024}));
const html=fs.readFileSync(path.join(root,'index.html'),'utf8').replace(/<script[^>]*><\/script>/g,'');
const dom=new JSDOM(html,{url:'http://test.local/dbplus/index.html',runScripts:'outside-only',pretendToBeVisual:true});
const w=dom.window,doc=w.document;
const errors=[];w.addEventListener('error',e=>errors.push(e.message));
w.ResizeObserver=class {observe(){} disconnect(){}};
Object.defineProperty(w.HTMLElement.prototype,'clientHeight',{get(){return this.classList.contains('dbp-viewport')&&!this.closest('[hidden]')?400:0;}});
Object.defineProperty(w.HTMLElement.prototype,'scrollHeight',{get(){const table=this.querySelector('table');return table?40+(Number(table.getAttribute('aria-rowcount')||1)-1)*32:400;}});
Object.defineProperty(w.HTMLElement.prototype,'clientWidth',{get(){return 1000;}});
Object.defineProperty(w.HTMLElement.prototype,'scrollWidth',{get(){return 1100;}});
w.HTMLTableSectionElement.prototype.getBoundingClientRect=function(){return {height:40};};
w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;};
const calls=[];let slowResolve;let slowNext=false;
const env=(body)=>({protocolVersion:1,requestId:'test-'+calls.length,...body});
const respond=(body)=>Promise.resolve(new Response(JSON.stringify(body),{headers:{'Content-Type':'application/json'}}));
w.fetch=(input)=>{
 const url=new URL(input,'http://test.local/dbplus/index.html');calls.push(url.pathname+url.search);
 if(url.pathname.endsWith('/config/ui.json'))return respond({apiBase:'api/',deploymentId:'test',links:[]});
 if(url.pathname.endsWith('/connections'))return respond(env({items:[{connectionId:'demo',label:'DEMO',dbProduct:'DEMO'}]}));
 if(url.pathname.endsWith('/schemas'))return respond(env({connectionId:'demo',items:[{schemaName:'SCHEMA_A',label:'SCHEMA_A'},{schemaName:'SCHEMA_B',label:'SCHEMA_B'}]}));
 if(url.pathname.endsWith('/tables')){
  const schema=url.searchParams.get('schemaName');const names=[...Object.keys(fixtures),...Array.from({length:3995},(_,i)=>'TABLE_'+String(i).padStart(4,'0'))].sort();
  return respond(env({connectionId:'demo',schemaName:schema,fetchedAt:new Date().toISOString(),maxTables:4000,returnedTables:4000,hasMore:true,items:names.map(tableName=>({tableName,schemaName:schema,logicalName:'デモ',objectType:'TABLE'}))}));
 }
 if(url.pathname.endsWith('/table-detail')){
  const name=url.searchParams.get('tableName');const data=structuredClone(fixtures[name]);data.ref.schemaName=url.searchParams.get('schemaName');
  if(slowNext){slowNext=false;return new Promise(resolve=>{slowResolve=()=>resolve(new Response(JSON.stringify(data),{headers:{'Content-Type':'application/json'}}));});}
  return respond(data);
 }
 return Promise.reject(new Error('Unknown request '+url));
};
const wait=async()=>{for(let i=0;i<5;i++)await new Promise(r=>setTimeout(r,15));};
const click=id=>doc.getElementById(id).click();
async function filterOpen(name){const input=doc.getElementById('tableFilterInput');input.value=name;input.dispatchEvent(new w.Event('input'));await wait();doc.querySelector('#tableListBody button').click();await wait();}
async function run(){
 w.localStorage.setItem('dbplus.history.tables.v1:test:/dbplus/','{broken');
 w.eval(fs.readFileSync(path.join(root,'js/main.js'),'utf8').replace(/export\s*\{\s*\}\s*;/g,''));await wait();
 assert.equal(doc.getElementById('schemaSelect').value,'SCHEMA_A');assert.equal(doc.querySelectorAll('#tableTabList button').length,0);
 doc.getElementById('tableSearchForm').dispatchEvent(new w.Event('submit',{cancelable:true}));await wait();
 assert(Number(doc.getElementById('tableListTable').dataset.renderedRows)<40);assert(doc.getElementById('tableListStatus').textContent.includes('上限'));
 await filterOpen('KYF1940');assert.equal(doc.getElementById('tableWorkspaceName').textContent,'KYF1940');
 assert(Number(doc.getElementById('dataGridTable').dataset.renderedRows)<40);assert.equal(doc.querySelectorAll('#dataGridBody img').length,0);
 assert(doc.querySelector('#dataGridBody .dbp-cell').textContent==='1');
 const viewport=doc.getElementById('dataGridViewport');viewport.scrollTop=95640;viewport.dispatchEvent(new w.Event('scroll'));await wait();
 assert(doc.querySelector('#dataGridBody tr[data-row-index="2999"]'));assert(Number(doc.getElementById('dataGridTable').dataset.renderedRows)<40);
 const before=calls.filter(x=>x.includes('/table-detail')).length;click('definitionTabBtn');await wait();
 assert.equal(doc.querySelectorAll('#definitionContent th').length,12);click('indexesTabBtn');await wait();assert.equal(doc.querySelectorAll('#indexesContent th').length,10);click('synonymsTabBtn');await wait();assert.equal(doc.querySelectorAll('#synonymsContent th').length,8);
 assert.equal(calls.filter(x=>x.includes('/table-detail')).length,before);
 click('dataTabBtn');await wait();assert.equal(viewport.scrollTop,95640);
 click('homeTabBtn');await wait();await filterOpen('EMPTY_TABLE');assert(doc.getElementById('dataStatus').textContent.includes('データがありません'));assert.equal(doc.querySelectorAll('#dataGridHead th').length,5);
 click('homeTabBtn');await wait();await filterOpen('PARTIAL_ERROR');click('definitionTabBtn');await wait();assert(doc.getElementById('definitionStatus').classList.contains('is-error'));click('dataTabBtn');await wait();assert(doc.querySelector('#dataGridBody tr[data-row-index="0"]'));
 click('homeTabBtn');await wait();await filterOpen('LONG_TEXT');doc.querySelector('#dataGridBody [data-truncated="true"]').click();assert(doc.getElementById('cellDetailDialog').open);assert(doc.getElementById('cellDetailNote').textContent.includes('2048'));click('cellDetailCloseBtn');
 click('linksTriggerBtn');assert(!doc.getElementById('linksPanel').hidden);doc.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape'}));assert(doc.getElementById('linksPanel').hidden);
 // 遅いAを選択し直後にBへ。fetchがabortを無視してもAの応答を描画しない。
 click('homeTabBtn');await wait();slowNext=true;await filterOpen('KYF1940');click('homeTabBtn');await wait();await filterOpen('KYF1941');slowResolve();await wait();assert.equal(doc.getElementById('tableWorkspaceName').textContent,'KYF1941');assert.equal(doc.getElementById('tableWorkspaceView').getAttribute('aria-busy'),'false');
 const stored=JSON.parse(w.localStorage.getItem('dbplus.history.tables.v1:test:/dbplus/'));assert(stored.items.every(i=>Object.keys(i).sort().join(',')==='connectionId,lastViewedAt,schemaName,tableName'));assert(stored.items.every(i=>!i.rowsHtml));
 // 同名でも別スキーマは独立タブ。
 click('homeTabBtn');await wait();doc.getElementById('schemaSelect').value='SCHEMA_B';doc.getElementById('schemaSelect').dispatchEvent(new w.Event('change'));doc.getElementById('tableSearchForm').dispatchEvent(new w.Event('submit',{cancelable:true}));await wait();await filterOpen('KYF1941');
 assert.equal([...doc.querySelectorAll('#tableTabList .dbp-tab-name')].filter(x=>x.textContent==='KYF1941').length,2);
 const countBeforeCache=calls.filter(x=>x.includes('/table-detail')).length;
 doc.querySelector('#tableTabList button[aria-selected="true"]').click();await wait();assert.equal(calls.filter(x=>x.includes('/table-detail')).length,countBeforeCache);
 const realNow=w.Date.now;w.Date.now=()=>realNow()+60001;doc.querySelector('#tableTabList button[aria-selected="true"]').click();await wait();assert.equal(calls.filter(x=>x.includes('/table-detail')).length,countBeforeCache+1);w.Date.now=realNow;
 const restoredData=w.localStorage.getItem('dbplus.history.tables.v1:test:/dbplus/');const beforeRestore=calls.filter(x=>x.includes('/table-detail')).length;
 const second=new JSDOM(html,{url:'http://test.local/dbplus/index.html',runScripts:'outside-only',pretendToBeVisual:true});second.window.ResizeObserver=w.ResizeObserver;second.window.fetch=w.fetch;second.window.localStorage.setItem('dbplus.history.tables.v1:test:/dbplus/',restoredData);
 second.window.eval(fs.readFileSync(path.join(root,'js/main.js'),'utf8').replace(/export\s*\{\s*\}\s*;/g,''));await wait();assert.equal(second.window.document.querySelectorAll('#tableTabList button').length,JSON.parse(restoredData).items.length);assert.equal(calls.filter(x=>x.includes('/table-detail')).length,beforeRestore);assert(!second.window.document.getElementById('homeView').hidden);second.window.close();
 assert.equal(errors.length,0);console.log('DOM contract checks passed: virtualization, last row, 4 panels, no duplicate requests, scroll restore, empty, partial error, preview, links, history, response race, schema identity, cache TTL, lazy history restore.');
 dom.window.close();
}
run().catch(e=>{console.error(e);dom.window.close();process.exitCode=1;});
