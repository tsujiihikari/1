package jp.dbplus;

import java.io.*;
import java.sql.*;
import java.util.*;

/** 参照専用。SQLの値はbind、識別子はALL_OBJECTSで存在確認してから二重引用符で囲む。 */
final class OracleReader {
    static final int LIMIT=5000;
    static Connection connect(Catalog.Entry e,Config c) throws Exception {
        Class.forName("oracle.jdbc.OracleDriver");
        Properties p=new Properties();p.setProperty("user",e.user);p.setProperty("password",e.password);
        p.setProperty("oracle.net.CONNECT_TIMEOUT",""+Math.min(c.number("http.connect.timeout.ms",15000),c.remainingMillis()));
        p.setProperty("oracle.jdbc.ReadTimeout",""+Math.min(c.number("jdbc.read.timeout.ms",30000),c.remainingMillis()));
        return DriverManager.getConnection(e.url(),p);
    }
    static PreparedStatement prepare(Connection conn,String sql,Config c) throws Exception {
        PreparedStatement st=conn.prepareStatement(sql);
        try{st.setFetchSize(100);st.setQueryTimeout(Math.min(c.number("jdbc.query.timeout.seconds",60),Math.max(1,c.remainingMillis()/1000)));return st;}
        catch(Exception e){st.close();throw e;}
    }
    static String placeholders(int n){return String.join(",",Collections.nCopies(n,"?"));}
    /** 一覧ページ内の最大50オブジェクトだけを辞書照合し、Oracle全件一覧は取得しない。 */
    static void enrich(Connection conn,Rps.Kind kind,List<Rps.Row> rows,Config c) throws Exception {
        Map<String,List<Rps.Row>> owners=new LinkedHashMap<>();
        for(Rps.Row r:rows)owners.computeIfAbsent(r.owner,x->new ArrayList<>()).add(r);
        for(Map.Entry<String,List<Rps.Row>> group:owners.entrySet()){
            LinkedHashSet<String> names=new LinkedHashSet<>();for(Rps.Row r:group.getValue())names.add(r.name);
            String suffix=" IN ("+placeholders(names.size())+")";String sql;
            if(kind==Rps.Kind.TABLE)sql="SELECT t.OWNER,t.TABLE_NAME NAME,tc.COMMENTS,t.TABLESPACE_NAME,t.NUM_ROWS,t.PARTITIONED,t.TEMPORARY,TO_CHAR(t.LAST_ANALYZED,'YYYY-MM-DD HH24:MI:SS') LAST_ANALYZED FROM ALL_TABLES t LEFT JOIN ALL_TAB_COMMENTS tc ON tc.OWNER=t.OWNER AND tc.TABLE_NAME=t.TABLE_NAME AND tc.TABLE_TYPE='TABLE' WHERE t.OWNER=? AND t.TABLE_NAME"+suffix;
            else if(kind==Rps.Kind.INDEX)sql="SELECT OWNER,INDEX_NAME NAME,TABLE_OWNER,TABLE_NAME,INDEX_TYPE,UNIQUENESS,PARTITIONED,STATUS,TABLESPACE_NAME FROM ALL_INDEXES WHERE OWNER=? AND INDEX_NAME"+suffix;
            else if(kind==Rps.Kind.VIEW)sql="SELECT v.OWNER,v.VIEW_NAME NAME,tc.COMMENTS,v.TEXT_LENGTH FROM ALL_VIEWS v LEFT JOIN ALL_TAB_COMMENTS tc ON tc.OWNER=v.OWNER AND tc.TABLE_NAME=v.VIEW_NAME AND tc.TABLE_TYPE='VIEW' WHERE v.OWNER=? AND v.VIEW_NAME"+suffix;
            else sql="SELECT s.OWNER,s.SYNONYM_NAME NAME,s.TABLE_OWNER,s.TABLE_NAME,s.DB_LINK,tc.COMMENTS FROM ALL_SYNONYMS s LEFT JOIN ALL_TAB_COMMENTS tc ON tc.OWNER=s.TABLE_OWNER AND tc.TABLE_NAME=s.TABLE_NAME AND s.DB_LINK IS NULL WHERE s.OWNER=? AND s.SYNONYM_NAME"+suffix;
            try(PreparedStatement st=prepare(conn,sql,c)){
                bindNames(st,group.getKey(),names);
                try(ResultSet rs=st.executeQuery()){
                    ResultSetMetaData md=rs.getMetaData();while(rs.next()){
                        c.remainingMillis();String name=rs.getString("NAME");
                        for(Rps.Row r:group.getValue())if(r.name.equals(name)){
                            r.oracle=true;for(int i=1;i<=md.getColumnCount();i++)r.db.put(md.getColumnLabel(i),Rps.nvl(rs.getString(i)));
                        }
                    }
                }
            }
            if(kind==Rps.Kind.INDEX){
                String cols="SELECT INDEX_NAME,COLUMN_NAME,COLUMN_POSITION,DESCEND FROM ALL_IND_COLUMNS WHERE INDEX_OWNER=? AND INDEX_NAME"+suffix+" ORDER BY INDEX_NAME,COLUMN_POSITION";
                try(PreparedStatement st=prepare(conn,cols,c)){
                    bindNames(st,group.getKey(),names);try(ResultSet rs=st.executeQuery()){
                        while(rs.next()){
                            c.remainingMillis();for(Rps.Row r:group.getValue())if(r.name.equals(rs.getString(1))){
                                String old=Rps.nvl(r.db.get("COLUMNS"));r.db.put("COLUMNS",old+(old.isEmpty()?"":", ")+rs.getString(2)+" "+rs.getString(4));
                            }
                        }
                    }
                }
            }
        }
    }
    static void bindNames(PreparedStatement st,String owner,Set<String> names) throws SQLException {
        int i=1;st.setString(i++,owner);for(String n:names)st.setString(i++,n);
    }
    static String quote(String identifier){
        if(identifier==null||identifier.isEmpty()||identifier.length()>128||identifier.indexOf('\u0000')>=0)throw new IllegalArgumentException("識別子が不正です。");
        return "\""+identifier.replace("\"","\"\"")+"\"";
    }
    static String dataSql(String owner,String table){return "SELECT * FROM "+quote(owner)+"."+quote(table)+" WHERE ROWNUM <= ?";}
    static Map<String,Object> data(Connection conn,Config c,String table,Map<String,String> names) throws Exception {
        try(PreparedStatement check=prepare(conn,"SELECT OBJECT_TYPE FROM ALL_OBJECTS WHERE OWNER=? AND OBJECT_NAME=? AND OBJECT_TYPE='TABLE' AND SUBOBJECT_NAME IS NULL",c)){
            check.setString(1,c.schema);check.setString(2,table);
            try(ResultSet rs=check.executeQuery()){if(!rs.next())throw new IllegalArgumentException("指定テーブルがOracleにないか参照権限がありません。");}
        }
        List<Object> columns=new ArrayList<>();List<Object> rows=new ArrayList<>();
        long bytes=0;int truncated=0;boolean responseLimited=false;
        // メモリを保護し、LOBや極端に幅の広い結果も上限を明示して返す。
        try(PreparedStatement st=prepare(conn,dataSql(c.schema,table),c)){
            st.setInt(1,LIMIT);st.setMaxRows(LIMIT);
            try(ResultSet rs=st.executeQuery()){
                ResultSetMetaData md=rs.getMetaData();int count=md.getColumnCount();
                for(int i=1;i<=count;i++)columns.add(Json.obj("name",md.getColumnLabel(i),"japaneseName",Rps.nvl(names.get(md.getColumnLabel(i))),"type",md.getColumnTypeName(i)));
                while(rows.size()<LIMIT&&rs.next()){
                    c.remainingMillis();
                    List<Object> values=new ArrayList<>();
                    for(int i=1;i<=count;i++){
                        Cell cell=cell(rs,i,md.getColumnType(i));if(cell.truncated)truncated++;
                        values.add(cell.value);if(cell.value!=null)bytes+=cell.value.length()*2L;
                    }
                    if(bytes>32L*1024*1024){responseLimited=true;break;}
                    rows.add(values);
                }
            }
        }
        return Json.obj("columns",columns,"rows",rows,"rowCount",rows.size(),"limit",LIMIT,"limitReached",rows.size()==LIMIT,"truncatedCells",truncated,"responseLimited",responseLimited);
    }
    static final class Cell {String value;boolean truncated;Cell(String s,boolean t){value=s;truncated=t;}}
    static Cell cell(ResultSet rs,int i,int type) throws Exception {
        if(type==Types.BLOB||type==Types.BINARY||type==Types.VARBINARY||type==Types.LONGVARBINARY){
            InputStream in=rs.getBinaryStream(i);if(in==null)return new Cell(null,false);
            try(InputStream close=in){byte[] b=new byte[4097];int n=0,r;while(n<b.length&&(r=in.read(b,n,b.length-n))!=-1)n+=r;
                StringBuilder s=new StringBuilder();for(int z=0;z<Math.min(n,4096);z++)s.append(String.format("%02X",b[z]&255));return new Cell(s.toString(),n>4096);}
        }
        if(type==Types.CLOB||type==Types.NCLOB||type==Types.LONGVARCHAR||type==Types.LONGNVARCHAR){
            Reader reader=rs.getCharacterStream(i);if(reader==null)return new Cell(null,false);
            try(Reader close=reader){char[] b=new char[4097];int n=0,r;while(n<b.length&&(r=reader.read(b,n,b.length-n))!=-1)n+=r;return new Cell(new String(b,0,Math.min(n,4096)),n>4096);}
        }
        String s=rs.getString(i);return new Cell(s==null?null:s.length()>4096?s.substring(0,4096):s,s!=null&&s.length()>4096);
    }
}
