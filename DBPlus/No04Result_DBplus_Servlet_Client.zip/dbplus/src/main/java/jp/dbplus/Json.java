package jp.dbplus;

import java.util.*;

/** 外部JSONライブラリを増やさず、文字列・Map・ListのみをJSONへ書き出す。 */
final class Json {
    static Map<String,Object> obj(Object... a){
        Map<String,Object> m=new LinkedHashMap<>();for(int i=0;i<a.length;i+=2)m.put((String)a[i],a[i+1]);return m;
    }
    static String write(Object value){StringBuilder b=new StringBuilder();append(b,value);return b.toString();}
    static void append(StringBuilder b,Object v){
        if(v==null){b.append("null");return;}
        if(v instanceof Number||v instanceof Boolean){b.append(v);return;}
        if(v instanceof Map){b.append('{');boolean first=true;for(Object o:((Map<?,?>)v).entrySet()){
            Map.Entry<?,?> e=(Map.Entry<?,?>)o;if(!first)b.append(',');first=false;quote(b,String.valueOf(e.getKey()));b.append(':');append(b,e.getValue());}b.append('}');return;}
        if(v instanceof Iterable){b.append('[');boolean first=true;for(Object o:(Iterable<?>)v){if(!first)b.append(',');first=false;append(b,o);}b.append(']');return;}
        if(v instanceof Object[]){append(b,Arrays.asList((Object[])v));return;}
        quote(b,String.valueOf(v));
    }
    static void quote(StringBuilder b,String s){
        b.append('"');for(int i=0;i<s.length();i++){char c=s.charAt(i);switch(c){
            case '"':b.append("\\\"");break;case '\\':b.append("\\\\");break;
            case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;
            default:if(c<32||c=='\u2028'||c=='\u2029')b.append(String.format("\\u%04x",(int)c));else b.append(c);
        }}b.append('"');
    }
}
