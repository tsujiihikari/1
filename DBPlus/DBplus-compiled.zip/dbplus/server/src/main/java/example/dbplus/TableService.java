package example.dbplus;

import java.sql.*;
import java.util.*;

/** 有効な対象を確認後、各タブを独立取得。定義の失敗でデータ表示を失わせない。 */
final class TableService {
    private final JdbcRepository jdbc=new JdbcRepository();
    Map<String,Object> tables(Profiles.Profile p,String schema,Deadline d) throws Exception {
        try(Connection c=p.source().getConnection()){d.check();jdbc.verifyProduct(c,p);return jdbc.tables(c,p,schema,d);}
    }
    Map<String,Object> detail(Profiles.Profile p,String schema,String table,Deadline d,String requestId) throws Exception {
        Map<String,Object> result=Api.map("ref",Api.map("connectionId",p.id,"schemaName",schema,"tableName",table),"connectionLabel",p.label,"logicalName","");
        try(Connection c=p.source().getConnection()){
            d.check();jdbc.verifyProduct(c,p);jdbc.validateTable(c,p,schema,table,d);
            // 各Repositoryは接続を保持し続けず、ResultSet/Statementを取得単位で閉じる。
            result.put("data",safe(()->jdbc.data(c,p,schema,table,d)));
            result.put("definition",safe(()->{
                if("none".equals(p.definitionSource))return Api.failure("unavailable","DEFINITION_UNCONFIGURED","テーブル定義の取得元が未設定です。");
                if("catalog".equals(p.definitionSource))return jdbc.definition(c,schema,table,d);
                try(Connection rps=p.rpsSource().getConnection()){d.check();return new RpsDefinitionRepository().fetch(rps,p,schema,table,d);}
            }));
            result.put("indexes",safe(()->jdbc.indexes(c,schema,table,d)));
            result.put("synonyms",safe(()->jdbc.synonyms(c,p,schema,table,d)));
        }
        @SuppressWarnings("unchecked") Map<String,Object> definition=(Map<String,Object>)result.get("definition");
        if(definition.get("logicalName")!=null)result.put("logicalName",definition.get("logicalName"));
        boolean partial=false;for(String name:Arrays.asList("data","definition","indexes","synonyms")){@SuppressWarnings("unchecked") Map<String,Object> part=(Map<String,Object>)result.get(name);if(Arrays.asList("error","forbidden","unavailable").contains(part.get("status")))partial=true;}
        result.put("partial",partial);result.put("fetchedAt",Api.now());return result;
    }
    private interface Fetch {Map<String,Object> run() throws Exception;}
    private Map<String,Object> safe(Fetch fetch) {
        try{return fetch.run();}
        catch(SQLTimeoutException e){return Api.failure("error","QUERY_TIMEOUT","取得処理が期限を超えました。再取得してください。");}
        catch(SQLException e){String state=e.getSQLState();if((state!=null&&(state.startsWith("28")||"42501".equals(state)))||e.getErrorCode()==1031)return Api.failure("forbidden","ACCESS_DENIED","この情報を参照する権限がありません。");return Api.failure("error","DB_QUERY_FAILED","DB情報を取得できません。管理者へ確認してください。");}
        catch(Exception e){return Api.failure("error","SOURCE_UNAVAILABLE","取得元を利用できません。設定・接続状態を確認してください。");}
    }
}
