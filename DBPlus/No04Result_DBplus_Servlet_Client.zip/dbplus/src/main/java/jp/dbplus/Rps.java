package jp.dbplus;
import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.text.html.parser.ParserDelegator;


final class Rps {
    enum Kind {
        TABLE("table", "テーブル", "テーブル名", new String[]{"DB識別名", "テーブル名", "Ver", "Par", "日本語名称", "最大想定件数", "最終更新日", "担当者", "個人情報", "DDL", "統計情報", "情報", "状況"}),
        INDEX("index", "インデックス", "インデックス名", new String[]{"DB識別名", "インデックス名", "Ver", "テーブル名", "Type", "Par", "日本語名称", "最終更新日", "担当者", "DDL", "情報"}),
        VIEW("view", "ビュー", "ビュー名", new String[]{"DB識別名", "ビュー名", "Ver", "エイリアス", "With Option", "日本語名称", "最終更新日", "担当者", "DDL"}),
        SYNONYM("synonym", "シノニム", "シノニム名", new String[]{"DB識別名", "シノニム名", "Ver", "設定元スキーマ", "設定元オブジェクト", "タイプ", "設定元状況", "DBリンク", "パブリック区分", "権限設定先", "S", "U", "I", "D", "A", "E", "最終更新日", "担当者", "日本語名称", "DDL"});
        final String path, title, nameLabel; final String[] headers;
        Kind(String p, String t, String n, String[] h) { path=p; title=t; nameLabel=n; headers=h; }
        int name2Index() { return this==TABLE?4:this==INDEX?6:this==VIEW?5:18; }
        int dataColumns() { return this==TABLE?9:this==INDEX?9:this==VIEW?8:19; }
    }
    static class Row {
        final List<String> cells=new ArrayList<>(); final Map<String,String> db=new LinkedHashMap<>();
        String name="",owner="",dbtype=""; boolean rps, oracle;
    }
    static class RpsException extends IOException { RpsException(String message){super(message);} }
    static class AuthException extends RpsException { AuthException(String message){super(message);} }
    static class Http {
        final Config c; final URI base; final CookieManager cookies;
        Http(Config c,CookieManager cookies) throws Exception {this.c=c;this.cookies=cookies;base=new URI(c.get("rps.base.url","http://10.202.168.238:19001"));if(base.getHost()==null || base.getUserInfo()!=null || base.getQuery()!=null)throw new IOException("RPS URL不正");}
        boolean same(URI u){return Objects.equals(base.getScheme(),u.getScheme())&&Objects.equals(base.getHost(),u.getHost())&&base.getPort()==u.getPort();}
        URI resolve(String u) throws Exception {URI v=base.resolve(u);if(!same(v))throw new IOException("異なる接続先への遷移はできません。");return v;}
        String request(String target,String body) throws Exception {
            URI u=resolve(target);String method=body==null?"GET":"POST";
            for(int hop=0;hop<10;hop++) {
                c.remainingMillis();
                Proxy proxy=Proxy.NO_PROXY;
                HttpURLConnection con=(HttpURLConnection)u.toURL().openConnection(proxy);
                try {
                    con.setConnectTimeout(Math.min(c.number("http.connect.timeout.ms",15000),c.remainingMillis()));
                    con.setReadTimeout(Math.min(c.number("http.read.timeout.ms",30000),c.remainingMillis()));
                    con.setInstanceFollowRedirects(false);con.setRequestMethod(method);
                    con.setRequestProperty("User-Agent","Mozilla/5.0");con.setRequestProperty("Accept","text/html");
                    for(Map.Entry<String,List<String>> e:cookies.get(u,Collections.<String,List<String>>emptyMap()).entrySet())con.setRequestProperty(e.getKey(),String.join("; ",e.getValue()));
                    if("POST".equals(method)) {con.setDoOutput(true);con.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");byte[] b=body.getBytes(StandardCharsets.UTF_8);con.setFixedLengthStreamingMode(b.length);try(OutputStream o=con.getOutputStream()){o.write(b);}}
                    int status=con.getResponseCode();cookies.put(u,con.getHeaderFields());
                    if(status==301||status==302||status==303||status==307||status==308) {
                        String loc=con.getHeaderField("Location");if(loc==null)throw new IOException("Locationなし");
                        URI next=u.resolve(loc);if(!same(next))throw new IOException("接続先の異なるリダイレクト");
                        u=next;if(status==303||((status==301||status==302)&&"POST".equals(method))){method="GET";body=null;}continue;
                    }
                    if(status==401||status==403)throw new AuthException("RPSの認証または参照権限を確認してください。");
                    if(status!=200)throw new RpsException("HTTP "+status+"（"+u.getPath()+"）");
                    byte[] b;try(InputStream in=con.getInputStream()){b=readBytes(in,c);}
                    String override=c.get("rps.charset","auto");
                    if(!"auto".equalsIgnoreCase(override))return new String(b,Charset.forName(override));
                    Matcher m=Pattern.compile("(?i)charset\\s*=\\s*['\"]?([a-zA-Z0-9_-]+)").matcher(nvl(con.getContentType()));
                    if(m.find())try {
                        return Charset.forName(m.group(1)).newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                            .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString();
                    } catch(IllegalArgumentException | CharacterCodingException ignored) { /* 宣言と実バイトが異なる場合は再判別 */ }
                    return decode(b,"auto");
                } finally {con.disconnect();}
            }
            throw new IOException("リダイレクト上限");
        }
        void login() throws Exception {
            String html=request(c.get("rps.login.path","/login/login")+"?domain="+enc(c.domain)+"&shain_cd="+enc(c.user)+"&pass="+enc(c.password),null);
            if(token(html).isEmpty() || !hasSchemaField(html) || loginForm(html))
                throw new AuthException("RPSの認証に失敗しました。認証情報を更新してください。");
        }
        void setSchema() throws Exception {
            String html=request("/table/list?pm=ent",null);
            if(loginForm(html)||!hasSchemaField(html))throw new AuthException("RPSの認証期限が切れました。");
            String csrf=token(html);
            if(csrf.isEmpty())throw new RpsException("スキーマ設定用のCSRFトークンがありません。");
            String result=request("/schema/set_schema","schema="+enc(c.schema)+"&utf8="+enc("\u2713")+"&authenticity_token="+enc(csrf));
            if(!schemaValue(result).equals(c.schema))result=request("/table/list?pm=ent",null);
            validateListSchema(result,c);
        }
    }
    static void validateListSchema(String html,Config c) throws IOException {
        if(loginForm(html)||schemaValue(html).isEmpty())throw new AuthException("RPSの認証期限が切れました。");
        if(!schemaValue(html).equals(c.schema))throw new RpsException("RPSのスキーマが要求と一致しません。");
    }
    static boolean loginForm(String html) {
        return Pattern.compile("(?is)<input\\b[^>]*type\\s*=\\s*['\"]?password").matcher(html).find();
    }
    static boolean hasSchemaField(String html) {
        Matcher m=Pattern.compile("(?is)<input\\b([^>]*)>").matcher(html);
        while(m.find())if("schema".equals(attr(m.group(1),"name")))return true;
        return false;
    }
    static String token(String html){String value=input(html,"authenticity_token");if(!value.isEmpty())return value;Matcher m=Pattern.compile("(?is)<meta\\b([^>]*)>").matcher(html);while(m.find())if("csrf-token".equals(attr(m.group(1),"name")))return attr(m.group(1),"content");return "";}
    static String schemaValue(String html){return input(html,"schema");}
    static String input(String html,String name){Matcher m=Pattern.compile("(?is)<input\\b([^>]*)>").matcher(html);while(m.find())if(name.equals(attr(m.group(1),"name")))return attr(m.group(1),"value");return "";}
    static String attr(String attrs,String name) {
        Matcher m=Pattern.compile("(?is)(?:^|\\s)"+Pattern.quote(name)+"\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))").matcher(attrs);
        return m.find()?entities(m.group(1)!=null?m.group(1):m.group(2)!=null?m.group(2):m.group(3)):"";
    }
    // 保存HTMLにも実サイトにも同じパーサーを利用。ソース中のスクリプト等は出力しない。
    static List<Row> parse(String html,Kind k,Config c) throws Exception {
        return parse(html,k,c,true);
    }
    static List<Row> parse(String html,Kind k,Config c,boolean filterDbtype) throws Exception {
        // 外側のレイアウト表に依存せずstd_hover開始タグを直接探す。
        Matcher start=Pattern.compile("(?is)<table\\b[^>]*\\bclass\\s*=\\s*(?:\"[^\"]*\\bstd_hover\\b[^\"]*\"|'[^']*\\bstd_hover\\b[^']*'|std_hover)[^>]*>").matcher(html);
        if(!start.find())throw new RpsException(k.title+"の一覧表std_hoverが見つかりません。検索条件または認証を確認してください");
        int end=html.toLowerCase(Locale.ROOT).indexOf("</table",start.end());if(end<0)throw new RpsException("一覧表の終端がありません");
        String table=html.substring(start.end(),end);
        List<Row> out=new ArrayList<>();Matcher tr=Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr\\s*>").matcher(table);
        boolean header=false; int[] columnMap=null;
        while(tr.find()) {
            List<String> cells=new ArrayList<>();Matcher td=Pattern.compile("(?is)<t[dh]\\b[^>]*>(.*?)</t[dh]\\s*>").matcher(tr.group(1));
            while(td.find())cells.add(clean(td.group(1)));
            if(cells.contains(k.nameLabel)&&cells.contains("DB識別名")){
                header=true;
                if(k!=Kind.SYNONYM) {
                    columnMap=new int[k.headers.length];Arrays.fill(columnMap,-1);
                    for(int j=0;j<k.headers.length;j++)for(int z=0;z<cells.size();z++)
                        if(normalizeHeader(k.headers[j]).equals(normalizeHeader(cells.get(z)))){columnMap[j]=z;break;}
                    if(columnMap[0]<0||columnMap[1]<0||columnMap[2]<0||columnMap[k.name2Index()]<0)
                        throw new RpsException(k.title+"の必須列が見つかりません");
                }
                continue;
            }
            if(cells.size()<k.dataColumns())continue;
            if(columnMap!=null) {
                List<String> normalized=new ArrayList<>();
                for(int z:columnMap)normalized.add(z>=0&&z<cells.size()?cells.get(z):"");
                cells=normalized;
            }
            if(filterDbtype&&!cells.get(0).equals(c.dbtype))continue;
            Row r=new Row();r.cells.addAll(cells);r.dbtype=cells.get(0);r.name=cells.get(1);r.owner=k==Kind.SYNONYM&&"Y".equals(cell(r,8))?"PUBLIC":c.schema;r.rps=true;
            // 正常版と同じく、テーブル/索引の識別情報は詳細リンクのクエリを優先する。
            // 統計や参照先へのリンクには別スキーマがあり得るため、対象の詳細リンクだけを見る。
            Matcher a=Pattern.compile("(?is)<a\\b([^>]*)>").matcher(tr.group(1));
            while(a.find()) {
                String href=attr(a.group(1),"href");String detailPath=href.split("\\?",2)[0];
                if(!detailPath.endsWith("/column/show_"+k.path))continue;
                Map<String,String> q=query(href);
                if(q.containsKey("instance")&&!r.dbtype.equals(q.get("instance")))throw new RpsException("一覧のDB識別名と詳細リンクが一致しません");
                if(q.containsKey("schema")&&!c.schema.equals(q.get("schema")))throw new RpsException("一覧の詳細リンクが指定スキーマと一致しません");
                String key=k==Kind.TABLE?"table_name":k==Kind.INDEX?"index_name":"";
                if(!key.isEmpty()&&q.containsKey(key)) {r.name=q.get(key);r.cells.set(1,r.name);}
                if(q.containsKey("version"))r.cells.set(2,q.get("version"));
                if(q.containsKey("description"))r.cells.set(k.name2Index(),q.get("description"));
                break;
            }
            if(r.name.isEmpty())throw new RpsException("オブジェクト名が空です");out.add(r);
        }
        if(!header)throw new RpsException(k.title+"の一覧ヘッダーが想定と異なります");
        return out;
    }
    static String normalizeHeader(String h) {
        return h.replaceAll("\\s+", "").replace("テーブル名称","日本語名称")
            .replace("Partition","Par");
    }
    static Map<String,String> query(String url) throws Exception {
        Map<String,String> q=new HashMap<>();int i=url.indexOf('?');if(i<0)return q;
        for(String kv:url.substring(i+1).split("&")){String[] a=kv.split("=",2);q.put(URLDecoder.decode(a[0],"UTF-8"),a.length==2?URLDecoder.decode(a[1],"UTF-8"):"");}return q;
    }
    static String clean(String s){return entities(s.replaceAll("(?is)<script\\b.*?</script>","").replaceAll("(?is)<style\\b.*?</style>","").replaceAll("(?is)<[^>]*>"," ")).replace('\u00a0',' ').replaceAll("\\s+"," ").trim();}
    static String entities(String s) {
        // Swingの標準HTMLエンティティ辞書を初期化。追加JARは不要。
        Matcher m=Pattern.compile("&(#x[0-9a-fA-F]+|#\\d+|[a-zA-Z][a-zA-Z0-9]+);").matcher(s);StringBuffer b=new StringBuffer();
        while(m.find()){String n=m.group(1),v=m.group();try{if(n.startsWith("#")){int cp=Integer.parseInt(n.substring(n.startsWith("#x")?2:1),n.startsWith("#x")?16:10);v=new String(Character.toChars(cp));}else{javax.swing.text.html.parser.Entity e=javax.swing.text.html.parser.DTD.getDTD("html32").getEntity(n);if(e!=null)v=new String(e.getData());}}catch(Exception ignored){}m.appendReplacement(b,Matcher.quoteReplacement(v));}m.appendTail(b);return b.toString();
    }
    static {try{new ParserDelegator().parse(new StringReader(""),new HTMLEditorKit.ParserCallback(){},true);}catch(IOException e){throw new ExceptionInInitializerError(e);}}

    static byte[] readBytes(InputStream in,Config c) throws Exception {ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[16384];int n;while((n=in.read(buf))!=-1){c.remainingMillis();if(b.size()+n>64*1024*1024)throw new IOException("HTMLが64MiBを超えました。");b.write(buf,0,n);}return b.toByteArray();}
    static String readLocal(Path p,String charset) throws Exception {return decode(Files.readAllBytes(p),charset);}
    static String decode(byte[] bytes,String charset) throws Exception {
        if(!"auto".equalsIgnoreCase(charset))return new String(bytes,Charset.forName(charset));
        try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString().replaceFirst("^\\uFEFF","");}
        catch(CharacterCodingException e){return new String(bytes,Charset.forName("Windows-31J"));}
    }
    static String cell(Row r,int i){return i<r.cells.size()?r.cells.get(i):"";}
    static String nvl(String s){return s==null?"":s;}
    static String enc(String s) throws Exception{return URLEncoder.encode(s,"UTF-8");}
    static String esc(String s){return nvl(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
    static String[] dbKeys(Kind k) {return k==Kind.TABLE?new String[]{"COMMENTS","TABLESPACE_NAME","NUM_ROWS","PARTITIONED","TEMPORARY","LAST_ANALYZED"}:k==Kind.INDEX?new String[]{"TABLE_OWNER","TABLE_NAME","INDEX_TYPE","UNIQUENESS","COLUMNS","PARTITIONED","STATUS","TABLESPACE_NAME"}:k==Kind.VIEW?new String[]{"COMMENTS","TEXT_LENGTH"}:new String[]{"TABLE_OWNER","TABLE_NAME","DB_LINK","COMMENTS"};}
    static String[] dbHeaders(Kind k){return k==Kind.TABLE?new String[]{"COMMENTS","表領域","統計上の件数","パーティション","一時表","最終統計取得日時"}:k==Kind.INDEX?new String[]{"テーブル所有者","テーブル名","索引種別","一意性","構成列（順序）","パーティション","状態","表領域"}:k==Kind.VIEW?new String[]{"COMMENTS","定義文字数"}:new String[]{"参照先所有者","参照先名","DBリンク","参照先COMMENTS"};}
}
