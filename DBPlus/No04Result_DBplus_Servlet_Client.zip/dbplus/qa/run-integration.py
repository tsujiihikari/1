#!/usr/bin/env python3
"""外部接続なしの結合検証。製品Servlet＋模擬RPS＋JDBC。任意で実ブラウザー確認。"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookiejar import CookieJar
from urllib.parse import parse_qs, urlencode, urlparse
from urllib.request import build_opener, HTTPCookieProcessor, Request
from urllib.error import HTTPError
from pathlib import Path
from html import escape
import json, os, shutil, subprocess, sys, threading, time, uuid
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
HEADERS = {
    'table': ['DB識別名','テーブル名','Ver','Par','日本語名称','最大想定件数','最終更新日','担当者','個人情報','DDL','統計情報','情報','状況'],
    'index': ['DB識別名','インデックス名','Ver','テーブル名','Type','Par','日本語名称','最終更新日','担当者','DDL','情報'],
    'view': ['DB識別名','ビュー名','Ver','エイリアス','With Option','日本語名称','最終更新日','担当者','DDL'],
    'synonym': ['DB識別名','シノニム名','Ver','設定元スキーマ','設定元オブジェクト','タイプ','設定元状況','DBリンク','パブリック区分','権限設定先','S','U','I','D','A','E','最終更新日','担当者','日本語名称','DDL']
}
TRACE, SESSIONS = [], {}
FORCE_EXPIRE = False
CHECKS = 0

class RpsMock(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_POST(self): self.handle_request()
    def do_GET(self): self.handle_request()
    def handle_request(self):
        url = urlparse(self.path)
        q = {k: v[-1] for k, v in parse_qs(url.query, keep_blank_values=True).items()}
        if self.command == 'POST':
            q.update({k:v[-1] for k,v in parse_qs(self.rfile.read(int(self.headers.get('Content-Length','0'))).decode(), keep_blank_values=True).items()})
        # 認証情報はログへ保持しない。
        TRACE.append((url.path,{k:v for k,v in q.items() if k not in ('pass','shain_cd','domain')}))
        sid = next((x.strip()[4:] for x in self.headers.get('Cookie','').split(';') if x.strip().startswith('RPS=')), '')
        session = SESSIONS.get(sid)
        cookie = None
        if url.path == '/login/login':
            if q.get('domain')=='example.local' and q.get('shain_cd') in ('demo','other') and q.get('pass')=='demo-pass':
                sid=uuid.uuid4().hex;session={'schema':''};SESSIONS[sid]=session
                cookie='RPS='+sid+'; Path=/';body=self.fields('')
            else: body="<input type='password' name='pass'>"
        elif not session or FORCE_EXPIRE: body="<input type='password' name='pass'>"
        elif url.path == '/schema/set_schema':
            if q.get('authenticity_token') != 'qa-token': return self.respond(403,'token error')
            session['schema']=q['schema'];body=self.fields(session['schema'])
        elif url.path == '/column/show_table':
            if q.get('table_name') == 'KYF0004': return self.respond(500,'simulated definition failure')
            body=self.fields(session['schema'])+"<input name='table_name' value='"+escape(q['table_name'],quote=True)+"'><table class='std_hover'><tr><th>項目名</th><th>日本語名称</th><th>型</th></tr>"
            for name, jp in [('DB_UPDJI1','更新日'),('CUSTOMER_ID','顧客番号'),('CUSTOMER_NAME','顧客名'),('BALANCE','残高'),('NOTES','備考')]:
                body+='<tr><td>'+name+'</td><td>'+jp+'</td><td>VARCHAR2</td></tr>'
            body+='</table>'
        elif url.path.endswith('/show_ddl'):
            if q.get('object_name')=='KYF0005': return self.respond(500,'simulated DDL failure')
            ddl='CREATE TABLE "'+q['schema']+'"."'+q['object_name']+'" (\n  CUSTOMER_ID VARCHAR2(20),\n  CUSTOMER_NAME VARCHAR2(80)\n);\n-- Ver '+q['version']
            body='<pre>'+escape(ddl)+'</pre>'
        elif url.path.endswith('/list'):
            kind=url.path.split('/')[1]
            if kind not in HEADERS: return self.respond(404,'unknown')
            if not q.get('keyword_db'): body=self.fields(session['schema'])
            else: body=self.list_page(kind,q,session['schema'])
        else: return self.respond(404,'unknown')
        self.respond(200,body,cookie)
    @staticmethod
    def fields(schema):
        return "<input name='schema' value='"+escape(schema,quote=True)+"'><input name='authenticity_token' value='qa-token'>"
    def list_page(self,kind,q,schema):
        page=int(q.get('page','1'));name=q.get('keyword_object_name',q.get('keyword_name',''))
        total=0 if name.startswith('ZZZ') else 75 if name else 123
        jp_index={'table':4,'index':6,'view':5,'synonym':18}[kind]
        headers=HEADERS[kind]
        body=self.fields(schema)+'<p>全 '+str(total)+' 件</p><span class="current">'+str(page)+'</span><table class="std_hover"><tr>'
        body+=''.join('<th>'+x+'</th>' for x in headers)+'</tr>'
        for i in range((page-1)*50+1,min(page*50,total)+1):
            row=['']*len(headers);row[0]=q['keyword_db'];row[1]=('KYF' if kind=='table' else {'index':'IX_','view':'VW_','synonym':'S_'}[kind])+f'{i:04}'
            row[2]='2.4';row[jp_index]='顧客管理 '+f'{i:03}'
            row[{'table':6,'index':7,'view':6,'synonym':16}[kind]]='2026/10/21'
            if kind=='synonym': row[3]=schema;row[4]='KYF0001'
            body+='<tr>'+''.join('<td>'+escape(x)+'</td>' for x in row)+'</tr>'
        body+='</table>'
        for p in range(1,max(1,(total+49)//50)+1): body+='<a href="/'+kind+'/list?page='+str(p)+'">'+str(p)+'</a>'
        return body
    def respond(self,status,body,cookie=None):
        data=body.encode()
        self.send_response(status);self.send_header('Content-Type','text/html; charset=UTF-8');self.send_header('Content-Length',str(len(data)))
        if cookie:self.send_header('Set-Cookie',cookie)
        self.end_headers();self.wfile.write(data)

def check(ok,label):
    global CHECKS
    if not ok: raise AssertionError(label)
    CHECKS+=1

def client():
    return build_opener(HTTPCookieProcessor(CookieJar()))

def api(opener,base,endpoint,fields=None,header=True,method='POST'):
    data=None if method=='GET' else urlencode(fields or {}).encode()
    req=Request(base+'api/'+endpoint,data=data,method=method)
    if header:req.add_header('X-DBPlus-Request','1')
    try:
        with opener.open(req,timeout=20) as res:return res.status,json.load(res)
    except HTTPError as e:return e.code,json.load(e)

def run_api(base):
    global FORCE_EXPIRE
    creds={'domain':'example.local','loginID':'demo','loginPass':'demo-pass'}
    c=client()
    status,r=api(c,base,'login',creds,header=False);check(status==403,'画面用ヘッダー必須')
    status,r=api(c,base,'login',creds,method='GET');check(status==405,'GET禁止')
    status,r=api(c,base,'login',{**creds,'loginPass':'wrong'});check(status==401 and r['status']=='失敗','ログイン失敗')
    status,r=api(c,base,'login',creds);check(status==200 and r['status']=='接続OK','ログイン接続OK')
    check(len(r['connections'])==77,'77接続を返す')
    check('password' not in json.dumps(r) and 'user_name' not in json.dumps(r),'DB認証情報を返さない')
    con=next(e for e in r['connections'] if e['dbtype']=='KYKDB' and e['schema']=='KYKOWNER')
    ctx={k:con[k] for k in ('connectionId','schema','dbtype')}
    status,initial=api(c,base,'initial',{**creds,**ctx})
    check(status==200 and set(initial['lists'])==set(HEADERS),'4種類の初回一覧')
    for k,listing in initial['lists'].items():
        check(listing['ok'] and listing['page']==1 and len(listing['rows'])==50,k+' page1/50件')
    row=initial['lists']['table']['rows'][0]
    identity={k:row[k] for k in ('recordId','connectionId','schema','dbtype','kind','version')};identity['object_name']=row['name']
    search={**creds,**ctx,'kind':'table','page':'2','TYPE':'prefix','object_name':'KYF','description':'顧客'}
    status,r=api(c,base,'search',search)
    check(status==200 and r['page']==2 and len(r['rows'])==25,'検索と2ページ目')
    sent=[q for p,q in TRACE if p=='/table/list' and q.get('keyword_object_name')=='KYF%'][-1]
    check(sent['keyword_description']=='顧客%' and sent['page']=='2','RPSへ前方一致と日本語名とページを送る')
    status,r=api(c,base,'search',{**search,'page':'1','TYPE':'contains'})
    check(status==200,'曖昧検索')
    check(any(q.get('keyword_object_name')=='%KYF%' and q.get('keyword_description')=='%顧客%' for p,q in TRACE),'RPSへ曖昧条件')
    status,r=api(c,base,'search',{**search,'object_name':'ZZZ','page':'1'});check(status==200 and r['rows']==[],'検索0件')
    for bad in ({'TYPE':'invalid'},{'page':'0'},{'page':'bad'},{'connectionId':'fake'}):
        status,r=api(c,base,'search',{**search,**bad});check(status==400,'不正条件 '+str(bad))
    status,r=api(c,base,'detail',{**creds,**identity})
    check(status==200 and not r['partial'] and r['definition']['ok'] and r['ddl']['ok'] and r['data']['ok'],'詳細を一括取得')
    check(r['data']['rowCount']==5000 and r['data']['limitReached'],'DBデータ5000件')
    check(r['data']['columns'][0]['japaneseName']=='更新日','日本語カラム名')
    check(r['data']['rows'][0][3]=='9007199254740993','大きな数値を文字列で維持')
    check('\n' in r['ddl']['text'] and row['name'] in r['ddl']['text'],'DDL本文と改行を保持')
    for key,value in [('version','9.9'),('object_name','FAKE'),('recordId','fake')]:
        status,r=api(c,base,'detail',{**creds,**identity,key:value});check(status==400,'詳細識別情報照合 '+key)
    for idx,failed in [(1,'data'),(3,'definition'),(4,'ddl')]:
        row2=initial['lists']['table']['rows'][idx]
        ident={k:row2[k] for k in ('recordId','connectionId','schema','dbtype','kind','version')};ident['object_name']=row2['name']
        status,r=api(c,base,'detail',{**creds,**ident});check(status==200 and r['partial'] and not r[failed]['ok'],'部分失敗を区別 '+failed)
        check(any(r[x]['ok'] for x in ('definition','data','ddl')),'成功した詳細を維持 '+failed)
    for kind in ('index','synonym','view'):
        row2=initial['lists'][kind]['rows'][0]
        ident={k:row2[k] for k in ('recordId','connectionId','schema','dbtype','kind','version')};ident['object_name']=row2['name']
        status,r=api(c,base,'detail',{**creds,**ident})
        check(status==200 and r['ddl']['ok'] and r['data'] is None,kind+' DDLのみ')
    c2=client();status,r=api(c2,base,'login',{**creds,'loginID':'other'});check(status==200,'別利用者ログイン')
    status,r=api(c2,base,'detail',{**creds,'loginID':'other',**identity});check(status==400,'別利用者のrecordId拒否')
    FORCE_EXPIRE=True
    status,r=api(c,base,'search',search);check(status==401 and r['code']=='AUTH_REQUIRED','RPS認証期限切れ')
    FORCE_EXPIRE=False
    status,r=api(c,base,'search',search);check(status==401,'認証失効後は再ログイン必須')
    status,r=api(c,base,'login',creds);check(status==200,'再ログイン')
    status,r=api(c,base,'login',{'operation':'logout'});check(status==200,'ログアウト')
    status,r=api(c,base,'initial',{**creds,**ctx});check(status==401,'ログアウト後のアクセス拒否')
    ns={'j':'http://java.sun.com/xml/ns/javaee'}
    xml=ET.parse(ROOT/'src/main/webapp/WEB-INF/web.xml')
    check({e.text for e in xml.findall('.//j:url-pattern',ns)}=={'/api/'+x for x in ('login','initial','search','detail')},'web.xmlのURLは4つ')
    return {'checks':CHECKS,'result':'passed','rps_calls':len(TRACE)}

def main():
    if '--no-build' not in sys.argv: subprocess.run([sys.executable,str(ROOT/'build.py'),'--test'],check=True)
    mock=ThreadingHTTPServer(('127.0.0.1',0),RpsMock)
    threading.Thread(target=mock.serve_forever,daemon=True).start()
    cp=os.pathsep.join(str(ROOT/p) for p in ('build/classes','build/test-classes','build-tools/servlet-api.jar','src/main/webapp/WEB-INF/lib/ojdbc6.jar'))
    java=subprocess.Popen([shutil.which('java'),'--add-modules','jdk.httpserver','-cp',cp,'jp.dbplus.MockContainer',str(ROOT),'http://127.0.0.1:'+str(mock.server_port)],stdout=subprocess.PIPE,stderr=None,text=True)
    try:
        line=java.stdout.readline().strip()
        if not line.startswith('READY '): raise RuntimeError('模擬コンテナが起動しませんでした。')
        base='http://127.0.0.1:'+line.split()[1]+'/dbplus/'
        if '--serve' in sys.argv:
            print('TEST_URL='+base,flush=True)
            while java.poll() is None: time.sleep(1)
            return
        report=run_api(base)
        (ROOT/'docs/api-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
        print('API integration:',report,flush=True)
        if '--client' in sys.argv: subprocess.run([shutil.which('node'),str(ROOT/'qa/client-test.cjs'),base],check=True)
    finally:
        java.terminate()
        try:java.wait(timeout=10)
        except subprocess.TimeoutExpired:java.kill()
        mock.shutdown()
if __name__=='__main__': main()
