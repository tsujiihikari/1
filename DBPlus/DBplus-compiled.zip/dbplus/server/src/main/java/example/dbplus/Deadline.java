package example.dbplus;

import java.sql.*;

/** 論理期限。ドライバのsocket timeout／プール借用期限はコンテナで別途設定する。 */
final class Deadline {
    private final long end=System.nanoTime()+30_000_000_000L;
    void check() throws SQLTimeoutException {if(System.nanoTime()>=end)throw new SQLTimeoutException("要求期限超過");}
    void apply(Statement s) throws SQLException {check();long remain=Math.max(1,(end-System.nanoTime()+999_999_999L)/1_000_000_000L);s.setQueryTimeout((int)Math.min(10,remain));}
}
