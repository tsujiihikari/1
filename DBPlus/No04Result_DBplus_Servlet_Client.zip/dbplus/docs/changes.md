# 元ソースからの変更点

| 項目 | 元ソース | 今回 |
| --- | --- | --- |
| Servletの入口 | /api + action | /api/login, /api/initial, /api/search, /api/detail の4つ |
| クライアント認証名 | domain / shain_cd / pass | domain / loginID / loginPass |
| 初回取得 | 選択種別だけ | 4種類を各page=1、最大50件 |
| 一覧のOracle接続 | ページごとに辞書照合 | 一覧はRPSのみ、Oracle接続はテーブル詳細時 |
| 詳細取得 | definition / ddl / data を別々に要求 | 1回のdetailで定義・DDL・データを取得 |
| 詳細の識別情報 | 画面から名前とバージョンを指定 | サーバー発行recordIdと接続先・名前・バージョンを照合 |
| DB取得件数 | 5,001件目の存在確認 | SQL・JDBCとも最大5,000件、続きは未確認と明示 |
| 接続定義 | 拡張子propertiesのTSVのみ | CSV優先、既存TSVも読み込み可能 |
| 画面 | DB＋のオレンジ系UI | Krugle＋を参考にしたグレー・白・緑のUI |
| 待機表示 | 主に文字メッセージ | スピナー付きモーダル＋「しばらくお待ちください」 |
| データ表示 | 個別データダイアログ | 定義・DDL・データを同じ詳細内のタブに統合 |
| コピー・保存 | 画面との接続が限定的 | 一覧と詳細に接続。CSV / SQL保存 |
| エラー | 全体または個別要求のエラー | 詳細の3取得を個別に判定し、取得済み内容も表示 |
| 検証 | 実HTMLの単体検証 | 実HTML＋実Servlet HTTP結合＋実app.js結合 |

Rps.java のログイン、set_schema、文字コード判定、Cookie処理、一覧解析は変更していません。
RpsService.java の検索URL・一覧/定義解析も維持し、DDL本文の取得メソッドを追加しました。
OracleReader.java は5,000件の上限判定を変更し、接続・識別子の引用・型処理を再利用しています。
