@echo off
setlocal
cd /d "%~dp0"
if not exist classes mkdir classes
javac -encoding UTF-8 -source 8 -target 8 -d classes Main.java
if errorlevel 1 exit /b 1
java -cp "classes;ojdbc6.jar" Main %*
exit /b %errorlevel%
