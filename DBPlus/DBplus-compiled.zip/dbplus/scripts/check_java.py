#!/usr/bin/env python3
"""WARの実装クラスを使ってJava契約テストを実行。JDK 8以上が必要。"""
import argparse
from pathlib import Path
import subprocess
import tempfile
import zipfile
import os
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--war',default=str(root/'server/dbplus.war'))
args=parser.parse_args()
with tempfile.TemporaryDirectory() as temp:
    out=Path(temp)
    with zipfile.ZipFile(args.war) as z:
        for item in z.infolist():
            if item.filename.startswith('WEB-INF/classes/') or item.filename.startswith('WEB-INF/lib/'):
                z.extract(item,out)
    classes=out/'WEB-INF/classes'
    cp=os.pathsep.join([str(classes)]+[str(p) for p in (out/'WEB-INF/lib').glob('*.jar')])
    subprocess.run(['javac','-source','1.8','-target','1.8','-encoding','UTF-8','-cp',cp,'-d',str(classes),str(root/'tests/JavaContracts.java')],check=True)
    subprocess.run(['java','-cp',cp,'example.dbplus.JavaContracts'],check=True)
