package jp.dbplus;

import java.io.*;
import java.util.*;

/** 不変の共通設定から、リクエスト単位の認証・スキーマ・期限を作る。 */
final class Config {
    final Properties p = new Properties();
    String schema="", dbtype="", domain="", user="", password="";
    final long deadline;
    Config(Properties common) {
        p.putAll(common);
        deadline=System.nanoTime()+number("total.timeout.seconds",540)*1000000000L;
    }
    String get(String k,String d){return p.getProperty(k,d).trim();}
    int number(String k,int d){int n=Integer.parseInt(get(k,""+d));if(n<=0)throw new IllegalArgumentException("設定値が不正です: "+k);return n;}
    boolean yes(String k){return Boolean.parseBoolean(get(k,"false"));}
    String required(String k) throws IOException {String v=get(k,"");if(v.isEmpty())throw new IOException("必須設定がありません: "+k);return v;}
    int remainingMillis() throws IOException {
        long n=(deadline-System.nanoTime())/1000000L;
        if(n<=0)throw new IOException("処理時間の上限に達しました。");
        return (int)Math.min(n,Integer.MAX_VALUE);
    }
}
