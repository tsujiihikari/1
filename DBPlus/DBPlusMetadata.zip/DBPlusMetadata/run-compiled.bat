@echo off
setlocal
cd /d "%~dp0"
java -cp "classes;ojdbc6.jar" Main %*
exit /b %errorlevel%
