'use strict';
// 同一WAR内の4つのURLだけを使う。画面条件と、実際に取得済みの検索条件を分けて管理する。
(() => {
  const $ = id => document.getElementById(id);
  const KEY = 'dbplus.rps.credentials.v1', PREF = 'dbplus.connection.v1';
  const kinds = {
    table: { title: 'テーブル', name: 'テーブル名', jp: 4, updated: 6 },
    index: { title: 'インデックス', name: 'インデックス名', jp: 6, updated: 7 },
    synonym: { title: 'シノニム', name: 'シノニム名', jp: 18, updated: 16 },
    view: { title: 'ビュー', name: 'ビュー名', jp: 5, updated: 6 }
  };
  const endpoints = { login: 'api/login', initial: 'api/initial', search: 'api/search', detail: 'api/detail' };
  const blankQuery = () => ({ object_name: '', description: '', target_object_name: '', TYPE: 'prefix' });
  const state = {
    credentials: null, ready: false, busy: false, connections: [], kind: 'table',
    lists: {}, detail: null, detailTab: 'data', selectedId: '', storageWarning: '', window: ''
  };
  let toastTimer = 0, scrollFrame = 0;

  function readStored(key) {
    try { return JSON.parse(localStorage.getItem(key)); } catch (_) { return null; }
  }
  function saveStored(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (_) { return false; }
  }
  function removeStored(key) { try { localStorage.removeItem(key); } catch (_) { /* 保存無効の端末でも画面は利用できる */ } }
  function credentialsFrom(value) {
    return value ? { domain: value.domain || '', loginID: value.loginID || value.shain_cd || '', loginPass: value.loginPass ?? value.pass ?? '' } : null;
  }
  function currentResult() { return state.lists[state.kind]; }
  function selected() { return state.connections.find(e => e.connectionId === $('connection').value); }
  function context() {
    const c = selected();
    if (!c) throw new Error('スキーマ / 接続先を選択してください。');
    return { connectionId: c.connectionId, schema: c.schema, dbtype: c.dbtype };
  }
  function message(text, type = '') { $('message').textContent = text; $('message').className = type; }
  function toast(text) {
    clearTimeout(toastTimer); $('toast').textContent = text; $('toast').hidden = false;
    toastTimer = setTimeout(() => { $('toast').hidden = true; }, 3500);
  }
  function syncControls() {
    document.querySelectorAll('[data-work]').forEach(el => { el.disabled = state.busy || !state.ready; });
    document.querySelectorAll('[data-auth]').forEach(el => { el.disabled = state.busy; });
    $('credentials').disabled = state.busy;
    $('detail-close').disabled = state.busy;
    document.querySelectorAll('[data-detail]').forEach(el => { el.disabled = state.busy; });
    const result = currentResult(), usable = state.ready && !state.busy && result?.ok;
    for (const id of ['first', 'previous', 'side-previous']) $(id).disabled = !usable || result.page <= 1;
    for (const id of ['next', 'last', 'side-next']) $(id).disabled = !usable || result.page >= result.totalPages;
    $('page').disabled = $('go').disabled = !usable;
    const part = state.detail?.[state.detailTab];
    const canExport = state.ready && !state.busy && ($('detail-dialog').open ? part?.ok : result?.ok && result.rows.length > 0);
    document.querySelectorAll('[data-export]').forEach(el => { el.disabled = !canExport; });
  }
  // dialogを最上面に置き、二重クリックや検索中の条件変更を止める。finallyで必ず閉じる。
  function busy(value, text = '') {
    state.busy = value;
    $('results').setAttribute('aria-busy', String(value));
    if (value) {
      $('wait-description').textContent = text || 'RPSから情報を取得しています。';
      if (!$('wait-dialog').open) $('wait-dialog').showModal();
    } else if ($('wait-dialog').open) $('wait-dialog').close();
    syncControls();
  }
  async function post(endpoint, fields = {}, credentials = state.credentials) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 550000);
    try {
      const response = await fetch(endpoints[endpoint], {
        method: 'POST', credentials: 'same-origin', cache: 'no-store', signal: controller.signal,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-DBPlus-Request': '1' },
        body: new URLSearchParams({ ...credentials, ...fields })
      });
      let result;
      try { result = await response.json(); } catch (_) { throw new Error('Servletの応答を読めませんでした。WARの配置先とサーバーの状態を確認してください。'); }
      if (!response.ok || result.ok === false) {
        const e = new Error(result.error || '情報を取得できませんでした。'); e.status = response.status; throw e;
      }
      return result;
    } catch (e) {
      if (e.name === 'AbortError') throw new Error('処理の待機時間を超えました。接続先の状態を確認して、もう一度実行してください。');
      if (e instanceof TypeError) throw new Error('Servletに接続できませんでした。サーバーの起動と接続状態を確認してください。');
      throw e;
    } finally { clearTimeout(timeout); }
  }
  function clearResults() {
    state.lists = {}; state.detail = null; state.selectedId = '';
    if ($('detail-dialog').open) $('detail-dialog').close();
    renderList();
  }
  function handleError(e, inDetail = false) {
    if (inDetail) { $('detail-status').textContent = e.message; $('detail-status').className = 'detail-status error'; }
    else message(e.message, 'error');
    if (e.status === 401) {
      state.ready = false; clearResults(); setIdentity(); openAuth(e.message);
    }
  }
  function setIdentity() {
    $('identity').classList.toggle('connected', state.ready);
    $('identity').replaceChildren();
    $('identity').append(document.createElement('i'), document.createTextNode(state.ready ? '接続OK · ' + state.credentials.loginID : '未接続'));
  }
  function openAuth(text = '') {
    const c = state.credentials || credentialsFrom(readStored(KEY));
    if (!$('auth-dialog').open && c) {
      $('domain').value = c.domain; $('employee').value = c.loginID; $('password').value = c.loginPass;
    }
    $('auth-message').textContent = text; $('auth-message').className = 'form-message' + (text ? ' error' : '');
    $('auth-cancel').hidden = !state.ready;
    if (!$('auth-dialog').open) $('auth-dialog').showModal();
  }
  function options(select, values, chosen) {
    select.replaceChildren();
    values.forEach(v => select.add(new Option(v.label || v.value, v.value)));
    if (values.some(v => v.value === chosen)) select.value = chosen;
  }
  function fillConnections(entries) {
    if (!entries.length) throw new Error('DBSchema.csvに接続先がありません。');
    state.connections = entries;
    const stored = readStored(PREF);
    const preferred = entries.find(e => e.connectionId === stored?.connectionId && e.label === stored.label)
      || entries.find(e => e.dbtype === 'KYKDB' && e.schema === 'KYKOWNER' && e.type === 'JH') || entries[0];
    options($('dbtype'), [...new Set(entries.map(e => e.dbtype))].map(value => ({ value })), preferred.dbtype);
    fillEnvironment(preferred.type, preferred.connectionId);
  }
  function fillEnvironment(type, key) {
    const entries = state.connections.filter(e => e.dbtype === $('dbtype').value);
    options($('environment'), [...new Set(entries.map(e => e.type))].map(value => ({ value })), type);
    fillSchemas(key);
  }
  function fillSchemas(key) {
    const entries = state.connections.filter(e => e.dbtype === $('dbtype').value && e.type === $('environment').value);
    options($('connection'), entries.map(e => ({ value: e.connectionId, label: e.label })), key);
  }
  async function authenticate(credentials) {
    if (state.busy) return;
    busy(true, 'RPSのログイン情報を確認しています。');
    let success = false;
    try {
      const result = await post('login', {}, credentials);
      state.credentials = credentials; state.ready = true; clearResults(); fillConnections(result.connections);
      state.storageWarning = '';
      if ($('remember').checked) {
        if (!saveStored(KEY, credentials)) state.storageWarning = 'この端末ではログイン情報を保存できません。今回の接続は利用できます。';
      } else removeStored(KEY);
      setIdentity(); $('auth-dialog').close(); success = true;
    } catch (e) {
      state.ready = false; clearResults(); setIdentity();
      $('auth-message').textContent = '接続を確認できませんでした。\n' + e.message; $('auth-message').className = 'form-message error';
      if (!$('auth-dialog').open) $('auth-dialog').showModal();
      $('auth-cancel').hidden = true;
    } finally { busy(false); }
    if (success) await loadInitial();
  }
  function updateTabs() {
    document.querySelectorAll('[data-kind]').forEach(tab => {
      const active = state.kind === tab.dataset.kind;
      tab.setAttribute('aria-selected', String(active)); tab.tabIndex = active ? 0 : -1;
      const data = state.lists[tab.dataset.kind];
      tab.querySelector('.tab-count').textContent = data?.ok ? data.totalCount.toLocaleString() : '—';
    });
    $('results').setAttribute('aria-labelledby', 'tab-' + state.kind);
    const synonym = state.kind === 'synonym';
    $('physical-label').textContent = kinds[state.kind].name;
    $('secondary-label').textContent = synonym ? '参照先オブジェクト名' : '日本語名称';
    $('physical').placeholder = synonym ? '例：S_KYF1940' : '例：KYF1940';
    $('japanese').placeholder = synonym ? '例：KYF1940' : '例：顧客';
  }
  function showQuery(query) {
    $('physical').value = query.object_name;
    $('japanese').value = state.kind === 'synonym' ? query.target_object_name : query.description;
  }
  async function loadInitial() {
    if (state.busy || !state.ready) return;
    clearResults(); busy(true, 'テーブル・インデックス・シノニム・ビューの一覧を\n各50件ずつ取得しています。');
    message('一覧を取得しています。');
    try {
      const result = await post('initial', context());
      state.lists = result.lists; state.selectedId = ''; showQuery(blankQuery()); renderList();
      saveStored(PREF, selected());
      const warnings = [...result.warnings, ...(state.storageWarning ? [state.storageWarning] : [])];
      if (warnings.length) message(warnings.join('\n'), 'warning');
    } catch (e) { handleError(e); } finally { busy(false); }
  }
  async function loadPage(page = 1, query = currentResult()?.query || blankQuery()) {
    if (state.busy || !state.ready) return;
    busy(true, '検索条件に一致する一覧をRPSから取得しています。');
    message('一覧を検索しています。');
    try {
      const result = await post('search', { ...context(), kind: state.kind, page: String(page), ...query });
      state.lists[state.kind] = result; state.selectedId = ''; renderList();
    } catch (e) { handleError(e); } finally { busy(false); }
  }
  function beginSearch(mode) {
    const query = blankQuery();
    query.TYPE = mode; query.object_name = $('physical').value.trim();
    query[state.kind === 'synonym' ? 'target_object_name' : 'description'] = $('japanese').value.trim();
    loadPage(1, query);
  }
  function textCell(row, text, tag = 'td') {
    const cell = document.createElement(tag); cell.textContent = text ?? ''; row.append(cell); return cell;
  }
  function button(text, action, className) {
    const b = document.createElement('button'); b.type = 'button'; b.textContent = text; b.className = className;
    b.onclick = action; return b;
  }
  function renderList() {
    updateTabs();
    const result = currentResult(), meta = kinds[state.kind], table = $('objects');
    table.tHead.replaceChildren(); table.tBodies[0].replaceChildren();
    $('list-title').textContent = meta.title + '一覧';
    const good = !!result?.ok;
    $('page').value = good ? result.page : 1; $('page').max = good ? result.totalPages : 1;
    $('pages').textContent = good ? result.totalPages.toLocaleString() : '1';
    $('summary').textContent = good ? '全 ' + result.totalCount.toLocaleString() + ' 件 / このページ ' + result.rows.length + ' 件' : '接続先と検索条件を選んで一覧を取得します。';
    $('page-label').textContent = good ? result.page + ' / ' + result.totalPages.toLocaleString() + ' ページ · 50件ずつ' : '—';
    const query = result?.query || blankQuery(), conditions = [];
    if (query.object_name) conditions.push(meta.name + '：' + query.object_name);
    const secondary = state.kind === 'synonym' ? query.target_object_name : query.description;
    if (secondary) conditions.push((state.kind === 'synonym' ? '参照先：' : '日本語名称：') + secondary);
    $('query-summary').textContent = conditions.length ? (query.TYPE === 'contains' ? '曖昧検索' : '前方一致') + ' / ' + conditions.join(' / ') : 'すべての' + meta.title;
    $('empty').hidden = good && result.rows.length > 0;
    $('empty-title').textContent = result?.ok === false ? '一覧を取得できませんでした。' : good ? '一致する' + meta.title + 'がありません。' : 'データと定義を、ひとつの場所に。';
    $('empty-description').textContent = result?.ok === false ? result.error : good ? '検索条件を変更するか、条件クリアで検索し直してください。' : state.ready ? '一覧を取得すると、ここに表示されます。' : 'ログインすると、接続先を選んでテーブルを検索できます。';
    if (good) {
      const full = $('all-columns').checked, head = document.createElement('tr');
      ['No.', ...(full ? result.headers : [meta.name, '日本語名称', 'DBTYPE', 'スキーマ', 'Ver', '最終更新日']), '操作'].forEach(v => textCell(head, v, 'th'));
      table.tHead.append(head);
      const fragment = document.createDocumentFragment();
      result.rows.forEach((record, index) => {
        const tr = document.createElement('tr'); tr.setAttribute('data-record-id', record.recordId);
        tr.classList.toggle('selected', record.recordId === state.selectedId);
        textCell(tr, (result.page - 1) * result.pageSize + index + 1);
        const open = tab => openDetail(record, tab);
        if (full) {
          result.headers.forEach((label, i) => {
            const td = textCell(tr, '');
            if (i === 1) td.append(button(record.name, () => open(state.kind === 'table' ? 'definition' : 'ddl'), 'name-button'));
            else if (label === 'DDL') td.append(button('DDL', () => open('ddl'), 'row-button'));
            else td.textContent = record.cells[i] || '';
          });
        } else {
          textCell(tr, '').append(button(record.name, () => open(state.kind === 'table' ? 'definition' : 'ddl'), 'name-button'));
          const jp = textCell(tr, record.description); jp.className = 'jp-cell'; jp.title = record.description;
          textCell(tr, record.dbtype); textCell(tr, record.schema);
          textCell(tr, record.version).className = 'version-cell';
          textCell(tr, record.cells[meta.updated] || '');
        }
        textCell(tr, '').append(button(state.kind === 'table' ? '定義・データ' : 'DDLを表示', () => open(state.kind === 'table' ? 'data' : 'ddl'), 'row-button'));
        fragment.append(tr);
      });
      table.tBodies[0].append(fragment); $('list-scroll').scrollTop = 0;
      message(result.rows.length ? '名前または操作ボタンから詳細を開けます。' : '検索が完了しました。');
      if (result.warnings?.length) message(result.warnings.join('\n'), 'warning');
    } else if (result?.error) message(result.error, 'error');
    syncControls();
  }
  async function openDetail(record, tab) {
    if (state.busy || !state.ready) return;
    state.detail = null; state.detailTab = tab; state.window = ''; state.selectedId = record.recordId;
    $('objects').querySelectorAll('tbody tr').forEach(tr => tr.classList.toggle('selected', tr.dataset.recordId === record.recordId));
    $('detail-title').textContent = record.name;
    $('detail-context').textContent = [record.description, record.dbtype, record.schema, 'Ver ' + record.version].filter(Boolean).join(' / ');
    $('detail-label').textContent = record.kind === 'table' ? 'TABLE DETAIL' : kinds[record.kind].title;
    $('data-count').textContent = $('definition-count').textContent = '';
    $('detail-status').textContent = ''; $('detail-status').className = 'detail-status';
    $('detail-warning').hidden = true; $('detail-dialog').classList.remove('has-warning');
    for (const id of ['data-table', 'definition-table']) { $(id).tHead.replaceChildren(); $(id).tBodies[0].replaceChildren(); }
    $('ddl-text').textContent = ''; $('data-scroll').scrollTop = $('data-scroll').scrollLeft = 0;
    $('detail-dialog').showModal();
    busy(true, record.kind === 'table' ? 'RPSのテーブル定義・DDLと、\nOracleのDBデータを最大5,000件取得しています。' : 'RPSからDDLを取得しています。');
    try {
      const result = await post('detail', {
        recordId: record.recordId, connectionId: record.connectionId, schema: record.schema, dbtype: record.dbtype,
        kind: record.kind, object_name: record.name, version: record.version
      });
      state.detail = result;
      if (result.definition?.ok) renderDefinition(result.definition);
      if (result.data?.ok) renderDataHeader(result.data.columns);
      $('ddl-text').textContent = result.ddl?.ok ? result.ddl.text : '';
      $('data-count').textContent = result.data?.ok ? result.data.rowCount.toLocaleString() + ' 件' : '';
      $('definition-count').textContent = result.definition?.ok ? result.definition.rows.length + ' 項目' : '';
      $('detail-warning').textContent = result.warnings.join('\n');
      $('detail-warning').hidden = !result.partial; $('detail-dialog').classList.toggle('has-warning', result.partial);
      switchDetail(tab);
    } catch (e) { handleError(e, true); } finally { busy(false); }
  }
  function switchDetail(tab) {
    const result = state.detail;
    if (!result) return;
    if (result.kind !== 'table') tab = 'ddl';
    state.detailTab = tab;
    document.querySelectorAll('[data-detail]').forEach(b => {
      b.hidden = result.kind !== 'table' && b.dataset.detail !== 'ddl';
      b.setAttribute('aria-selected', String(b.dataset.detail === tab)); b.tabIndex = b.dataset.detail === tab ? 0 : -1;
    });
    ['data', 'definition', 'ddl'].forEach(name => { $(name + '-panel').hidden = name !== tab; });
    const part = result[tab];
    $('detail-status').className = 'detail-status' + (part?.ok ? '' : ' error');
    if (!part?.ok) $('detail-status').textContent = part?.error || 'この情報は対象外です。';
    else if (tab === 'data') {
      $('detail-status').textContent = part.rowCount.toLocaleString() + ' 件取得 / 最大 ' + part.limit.toLocaleString() + ' 件'
        + (part.limitReached ? ' · 5,000件に達しました。続きの有無は確認していません。' : '')
        + (part.responseLimited ? ' · 応答サイズの上限で終了しました。' : '')
        + (part.truncatedCells ? ' · 長い値 ' + part.truncatedCells + ' セルを省略しました。' : '')
        + (part.rowCount === 0 ? ' · このテーブルには表示するデータがありません。' : '');
      state.window = ''; renderWindow();
    } else if (tab === 'definition') $('detail-status').textContent = 'RPSに登録されたテーブル定義 / ' + part.rows.length + ' 項目';
    else $('detail-status').textContent = 'RPSに登録されたDDL / Ver ' + result.version;
    syncControls();
  }
  function renderDefinition(definition) {
    const table = $('definition-table'), head = document.createElement('tr');
    definition.headers.forEach(v => textCell(head, v, 'th')); table.tHead.append(head);
    const fragment = document.createDocumentFragment();
    definition.rows.forEach(values => { const tr = document.createElement('tr'); values.forEach(v => textCell(tr, v)); fragment.append(tr); });
    table.tBodies[0].append(fragment);
  }
  function renderDataHeader(columns) {
    const table = $('data-table'), head = document.createElement('tr'), group = table.querySelector('colgroup');
    group.replaceChildren(); const no = document.createElement('col'); no.style.width = '65px'; group.append(no);
    textCell(head, 'No.', 'th');
    columns.forEach(column => {
      const col = document.createElement('col'); col.style.width = '200px'; group.append(col);
      const th = textCell(head, column.name, 'th'), jp = document.createElement('small');
      jp.textContent = column.japaneseName || '（日本語名なし）'; th.append(jp);
      th.title = [column.name, column.japaneseName, column.type].filter(Boolean).join(' / ');
    });
    table.style.width = Math.max(65 + columns.length * 200, $('data-scroll').clientWidth || 800) + 'px';
    table.tHead.append(head);
  }
  // 固定行高＋上下の余白行で、5,000行すべてをDOMへ展開しない。
  function renderWindow() {
    const data = state.detail?.data;
    if (!data?.ok || state.detailTab !== 'data' || $('data-panel').hidden) return;
    const viewport = $('data-scroll'), height = 36;
    const start = Math.max(0, Math.floor(viewport.scrollTop / height) - 8);
    const end = Math.min(data.rows.length, start + Math.ceil(viewport.clientHeight / height) + 20);
    if (state.window === start + ':' + end) return;
    state.window = start + ':' + end;
    const fragment = document.createDocumentFragment();
    function spacer(pixels) {
      if (!pixels) return;
      const tr = document.createElement('tr'); tr.className = 'spacer'; tr.setAttribute('aria-hidden', 'true');
      const td = textCell(tr, ''); td.colSpan = data.columns.length + 1; td.style.height = pixels + 'px'; fragment.append(tr);
    }
    spacer(start * height);
    for (let i = start; i < end; i++) {
      const tr = document.createElement('tr'); tr.setAttribute('aria-rowindex', String(i + 2)); textCell(tr, i + 1);
      data.rows[i].forEach(value => {
        const td = textCell(tr, value === null ? 'NULL' : value); td.title = value === null ? 'NULL' : value;
        if (value === null) td.className = 'null';
      }); fragment.append(tr);
    }
    spacer((data.rows.length - end) * height);
    $('data-table').setAttribute('aria-rowcount', String(data.rows.length + 1));
    $('data-table').tBodies[0].replaceChildren(fragment);
  }
  function exportContent() {
    if ($('detail-dialog').open && state.detail) {
      const result = state.detail, part = result[state.detailTab];
      if (!part?.ok) return null;
      const name = result.name + '_' + result.version + '_' + state.detailTab;
      if (state.detailTab === 'ddl') return { name, text: part.text, rows: null };
      if (state.detailTab === 'definition') return { name, rows: [part.headers, ...part.rows] };
      return { name, rows: [part.columns.map(c => c.name), part.columns.map(c => c.japaneseName), ...part.rows] };
    }
    const result = currentResult();
    return result?.ok ? { name: 'DBplus_' + state.kind + '_page' + result.page, rows: [result.headers, ...result.rows.map(r => r.cells)] } : null;
  }
  async function copyCurrent() {
    const content = exportContent(); if (!content) return;
    const text = content.text ?? content.rows.map(r => r.map(v => v === null ? 'NULL' : String(v ?? '').replace(/\t/g, ' ').replace(/\r?\n/g, ' ')).join('\t')).join('\r\n');
    try {
      if (!navigator.clipboard?.writeText) throw new Error('fallback');
      await navigator.clipboard.writeText(text);
    } catch (_) {
      const area = document.createElement('textarea'); area.value = text; area.style.cssText = 'position:fixed;left:0;top:0;opacity:0';
      ($('detail-dialog').open ? $('detail-dialog') : document.body).append(area); area.select();
      const copied = document.execCommand('copy'); area.remove();
      if (!copied) { toast('コピーできませんでした。保存ボタンを利用してください。'); return; }
    }
    toast('コピーしました。');
  }
  function downloadCurrent() {
    const content = exportContent(); if (!content) return;
    const csv = value => '"' + String(value === null ? 'NULL' : value ?? '').replace(/"/g, '""') + '"';
    const text = content.text ?? '\uFEFF' + content.rows.map(r => r.map(csv).join(',')).join('\r\n');
    const url = URL.createObjectURL(new Blob([text], { type: content.rows ? 'text/csv;charset=utf-8' : 'text/plain;charset=utf-8' }));
    const a = document.createElement('a'); a.href = url; a.download = content.name.replace(/[\\/:*?"<>|]/g, '_') + (content.rows ? '.csv' : '.sql');
    document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  $('search-form').onsubmit = e => { e.preventDefault(); beginSearch('prefix'); };
  $('contains').onclick = () => beginSearch('contains');
  $('clear').onclick = () => { $('physical').value = $('japanese').value = ''; loadPage(1, blankQuery()); };
  $('home').onclick = () => { state.kind = 'table'; showQuery(blankQuery()); loadInitial(); };
  $('dbtype').onchange = () => { fillEnvironment(); loadInitial(); };
  $('environment').onchange = () => { fillSchemas(); loadInitial(); };
  $('connection').onchange = () => loadInitial();
  $('all-columns').onchange = () => renderList();
  document.querySelectorAll('[data-kind]').forEach(tab => {
    tab.onclick = () => {
      if (state.busy) return;
      state.kind = tab.dataset.kind;
      const data = currentResult(); showQuery(data?.query || blankQuery()); renderList();
      if (!data?.ok) loadPage(1, blankQuery());
    };
  });
  function tabKeys(selector) {
    document.querySelectorAll(selector).forEach(tab => tab.onkeydown = e => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
      e.preventDefault();
      const tabs = [...document.querySelectorAll(selector)].filter(t => !t.hidden && !t.disabled), i = tabs.indexOf(tab);
      const next = e.key === 'Home' ? tabs[0] : e.key === 'End' ? tabs[tabs.length - 1] : tabs[(i + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length];
      if (next) { next.click(); next.focus(); }
    });
  }
  tabKeys('[data-kind]'); tabKeys('[data-detail]');
  $('first').onclick = () => loadPage(1); $('last').onclick = () => loadPage(currentResult().totalPages);
  $('previous').onclick = $('side-previous').onclick = () => loadPage(currentResult().page - 1);
  $('next').onclick = $('side-next').onclick = () => loadPage(currentResult().page + 1);
  function go() {
    const page = Number($('page').value), result = currentResult();
    if (!Number.isInteger(page) || page < 1 || page > result.totalPages) { message('1〜' + result.totalPages + 'のページ番号を指定してください。', 'error'); return; }
    loadPage(page);
  }
  $('go').onclick = go; $('page').onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); go(); } };
  $('credentials').onclick = () => openAuth();
  $('auth-form').onsubmit = e => { e.preventDefault(); authenticate({ domain: $('domain').value.trim(), loginID: $('employee').value.trim(), loginPass: $('password').value }); };
  $('auth-cancel').onclick = () => $('auth-dialog').close();
  $('auth-dialog').addEventListener('cancel', e => { if (!state.ready || state.busy) e.preventDefault(); });
  $('wait-dialog').addEventListener('cancel', e => e.preventDefault());
  $('forget').onclick = async () => {
    if (state.busy) return;
    busy(true, 'ログイン情報を削除しています。');
    try { await post('login', { operation: 'logout' }); } catch (_) { /* 接続できなくても端末内の保存情報は削除する */ }
    finally {
      removeStored(KEY); state.ready = false; state.credentials = null; clearResults(); setIdentity();
      $('employee').value = $('password').value = ''; $('auth-cancel').hidden = true;
      $('auth-message').textContent = '保存情報を削除しました。'; $('auth-message').className = 'form-message'; busy(false);
    }
  };
  $('detail-close').onclick = () => $('detail-dialog').close();
  $('detail-dialog').addEventListener('cancel', e => { if (state.busy) e.preventDefault(); });
  $('detail-dialog').addEventListener('close', () => { state.detail = null; state.window = ''; syncControls(); });
  document.querySelectorAll('[data-detail]').forEach(tab => { tab.onclick = () => switchDetail(tab.dataset.detail); });
  $('data-scroll').addEventListener('scroll', () => {
    if (!scrollFrame) scrollFrame = requestAnimationFrame(() => { scrollFrame = 0; renderWindow(); });
  });
  window.addEventListener('resize', () => {
    state.window = '';
    if (state.detail?.data?.ok) {
      $('data-table').style.width = Math.max(65 + state.detail.data.columns.length * 200, $('data-scroll').clientWidth) + 'px';
      renderWindow();
    }
  });
  $('copy').onclick = $('detail-copy').onclick = copyCurrent;
  $('download').onclick = $('detail-download').onclick = downloadCurrent;
  renderList(); syncControls();
  const stored = credentialsFrom(readStored(KEY));
  if (stored?.domain && stored?.loginID && stored?.loginPass) { state.credentials = stored; authenticate(stored); }
  else openAuth();
})();
