@echo off
setlocal
cd /d "%~dp0"
if exist build\classes rmdir /s /q build\classes
mkdir build\classes
if not exist dist mkdir dist
(for /r src\main\java %%F in (*.java) do @echo "%%F") > build\sources.txt
javac -encoding UTF-8 -source 8 -target 8 -cp build-tools\servlet-api.jar -d build\classes @build\sources.txt
if errorlevel 1 exit /b 1
if exist build\war rmdir /s /q build\war
mkdir build\war
xcopy src\main\webapp build\war\ /E /I /Y >nul
xcopy build\classes build\war\WEB-INF\classes\ /E /I /Y >nul
jar cf dist\dbplus.war -C build\war .
if errorlevel 1 exit /b 1
echo Completed: dist\dbplus.war
endlocal
