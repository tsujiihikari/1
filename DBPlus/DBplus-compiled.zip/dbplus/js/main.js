const panels = ['data', 'definition', 'indexes', 'synonyms'];
const keyOf = (ref) => JSON.stringify([ref.connectionId, ref.schemaName, ref.tableName]);
const byId = (id) => { const node = document.getElementById(id); if (!node)
    throw new Error(`画面要素がありません: ${id}`); return node; };
const escapeHtml = (value) => value.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const isObject = (v) => typeof v === 'object' && v !== null && !Array.isArray(v);
const validName = (v) => typeof v === 'string' && v.length > 0 && v.length <= 512 && !/[\u0000-\u001f]/.test(v);
const validRef = (v) => isObject(v) && validName(v.connectionId) && validName(v.schemaName) && validName(v.tableName);
const validTime = (v) => typeof v === 'string' && /T.*(?:Z|[+-]\d{2}:\d{2})$/.test(v) && Number.isFinite(Date.parse(v));
function isReady(v) { return v.status === 'ready' || v.status === 'empty'; }
function notify(text) { const n = byId('appNotification'); n.textContent = text; n.hidden = false; }
function setStatus(id, message, error = false) { const n = byId(id); n.textContent = message; n.classList.toggle('is-error', error); }
function errorMessage(e) { return e instanceof Error ? e.message : '処理に失敗しました。'; }
/** 通信は同一オリジン・context path相対。認証画面HTMLを成功結果として扱わない。 */
class ApiClient {
    constructor(base) {
        this.base = base;
    }
    async get(path, params = {}, signal) {
        const url = new URL(path, this.base);
        Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
        const ctrl = new AbortController();
        const abort = () => ctrl.abort();
        signal?.addEventListener('abort', abort, { once: true });
        if (signal?.aborted)
            ctrl.abort();
        let expired = false;
        const timeout = window.setTimeout(() => { expired = true; ctrl.abort(); }, 35000);
        try {
            const res = await fetch(url, { signal: ctrl.signal, credentials: 'same-origin', cache: 'no-store', headers: { 'Accept': 'application/json' } });
            if (!(res.headers.get('Content-Type') || '').includes('application/json'))
                throw new Error(`JSON以外の応答です（HTTP ${res.status}）。認証・API設定を確認してください。`);
            const body = await res.json();
            if (!isObject(body) || body.protocolVersion !== 1 || typeof body.requestId !== 'string')
                throw new Error('API応答の形式が不正です。');
            if (!res.ok) {
                const e = isObject(body.error) ? body.error : {};
                throw new Error(`${typeof e.message === 'string' ? e.message : '通信に失敗しました。'} [${body.requestId}]`);
            }
            return body;
        }
        catch (e) {
            if (expired)
                throw new Error('通信が35秒の待機期限を超えました。再取得してください。');
            throw e;
        }
        finally {
            clearTimeout(timeout);
            signal?.removeEventListener('abort', abort);
        }
    }
}
/** 文字列配列を全件DOM化せず、可視行＋前後8行だけを生成する共通仮想表。 */
class VirtualGrid {
    constructor(viewport, table, body) {
        this.viewport = viewport;
        this.table = table;
        this.body = body;
        this.frame = 0;
        this.start = -1;
        this.end = -1;
        this.count = 0;
        this.columns = 1;
        this.renderRow = () => '';
        this.schedule = () => { if (!this.frame)
            this.frame = requestAnimationFrame(() => { this.frame = 0; this.draw(); }); };
        viewport.addEventListener('scroll', this.schedule, { passive: true });
        this.observer = new ResizeObserver(this.schedule);
        this.observer.observe(viewport);
    }
    set(count, columns, row, top = 0, left = 0) {
        this.count = count;
        this.columns = Math.max(1, columns);
        this.renderRow = row;
        this.start = this.end = -1;
        this.table.setAttribute('aria-rowcount', String(count + 1));
        this.body.replaceChildren();
        this.draw();
        // 初回のスペーサーを作成した後に、保存位置を範囲内へ戻す。
        this.viewport.scrollTop = Math.max(0, Math.min(top, this.viewport.scrollHeight - this.viewport.clientHeight));
        this.viewport.scrollLeft = Math.max(0, Math.min(left, this.viewport.scrollWidth - this.viewport.clientWidth));
        this.draw();
        this.schedule();
    }
    clear() { this.count = 0; this.start = this.end = -1; this.body.replaceChildren(); this.table.setAttribute('aria-rowcount', '1'); }
    refresh() { this.start = this.end = -1; this.schedule(); }
    spacer(height) {
        const tr = document.createElement('tr');
        tr.className = 'dbp-spacer';
        tr.setAttribute('aria-hidden', 'true');
        const td = document.createElement('td');
        td.colSpan = this.columns;
        const div = document.createElement('div');
        div.style.height = `${height}px`;
        td.append(div);
        tr.append(td);
        return tr;
    }
    draw() {
        const h = this.viewport.clientHeight - (this.table.tHead?.getBoundingClientRect().height || 40);
        if (h <= 0)
            return;
        const top = this.viewport.scrollTop;
        const start = Math.max(0, Math.min(this.count, Math.floor(top / 32) - 8));
        const end = Math.min(this.count, Math.ceil((top + h) / 32) + 8);
        if (start === this.start && end === this.end)
            return;
        // 一覧buttonのフォーカスを保持。画面外へ動いたときはviewportへ戻す。
        const focused = document.activeElement instanceof HTMLElement ? document.activeElement.closest('tr[data-list-index]') : null;
        const focusIndex = focused && this.body.contains(focused) ? Number(focused.dataset.listIndex) : null;
        this.start = start;
        this.end = end;
        this.body.innerHTML = Array.from({ length: end - start }, (_, n) => this.renderRow(start + n)).join('');
        this.body.prepend(this.spacer(start * 32));
        this.body.append(this.spacer((this.count - end) * 32));
        this.table.dataset.renderedRows = String(end - start);
        if (focusIndex !== null) {
            const btn = this.body.querySelector(`tr[data-list-index="${focusIndex}"] button`);
            (btn || this.viewport).focus({ preventScroll: true });
        }
    }
    destroy() { cancelAnimationFrame(this.frame); this.viewport.removeEventListener('scroll', this.schedule); this.observer.disconnect(); }
}
/** localStorageは軽量な参照履歴のみ。破損・保存不可でも閲覧処理を続ける。 */
class HistoryStore {
    constructor(storageKey) {
        this.storageKey = storageKey;
        this.items = [];
        this.merge(this.read());
    }
    parse(raw) {
        try {
            const data = JSON.parse(raw || '{}');
            if (!isObject(data) || data.version !== 1 || !Array.isArray(data.items))
                return [];
            return data.items.slice(0, 1000).filter((v) => validRef(v) && isObject(v) && validTime(v.lastViewedAt)).map(v => ({ connectionId: v.connectionId, schemaName: v.schemaName, tableName: v.tableName, lastViewedAt: v.lastViewedAt }));
        }
        catch {
            return [];
        }
    }
    read() { try {
        return this.parse(localStorage.getItem(this.storageKey));
    }
    catch {
        return [];
    } }
    merge(items) {
        const map = new Map();
        [...this.items, ...items].forEach(i => { const old = map.get(keyOf(i)); if (!old || Date.parse(i.lastViewedAt) > Date.parse(old.lastViewedAt))
            map.set(keyOf(i), i); });
        this.items = [...map.values()].sort((a, b) => Date.parse(b.lastViewedAt) - Date.parse(a.lastViewedAt)).slice(0, 100);
    }
    touch(ref) {
        this.merge(this.read());
        this.merge([{ connectionId: ref.connectionId, schemaName: ref.schemaName, tableName: ref.tableName, lastViewedAt: new Date().toISOString() }]);
        try {
            localStorage.setItem(this.storageKey, JSON.stringify({ version: 1, items: this.items }));
        }
        catch {
            notify('この環境では閲覧履歴を保存できません。閲覧は継続できます。');
        }
    }
    sync(raw) { this.merge(this.parse(raw)); }
}
/** 最近2件・60秒・UTF-16概算16MiB。大きなアクティブ1件は表示のため保持する。 */
class DetailCache {
    constructor() {
        this.entries = new Map();
    }
    get(key) { const e = this.entries.get(key); if (!e)
        return; if (e.expires < Date.now()) {
        this.entries.delete(key);
        return;
    } this.entries.delete(key); this.entries.set(key, e); return e.value; }
    set(key, value) { this.entries.delete(key); this.entries.set(key, { value, expires: Date.now() + 60000, size: JSON.stringify(value).length * 2 }); while (this.entries.size > 1 && (this.entries.size > 2 || [...this.entries.values()].reduce((n, e) => n + e.size, 0) > 16 * 1024 * 1024))
        this.entries.delete(this.entries.keys().next().value); }
    delete(key) { this.entries.delete(key); }
}
function validateDetail(d, ref) {
    if (!validRef(d.ref) || keyOf(d.ref) !== keyOf(ref) || !validTime(d.fetchedAt) || typeof d.connectionLabel !== 'string' || typeof d.logicalName !== 'string')
        throw new Error('取得対象または取得時刻が一致しません。');
    for (const name of panels) {
        const p = d[name];
        if (!isObject(p) || !['ready', 'empty', 'unsupported', 'unavailable', 'forbidden', 'error'].includes(p.status) || !Array.isArray(p.warnings) || !p.warnings.every(x => typeof x === 'string'))
            throw new Error('詳細タブの応答形式が不正です。');
    }
    const p = d.data;
    if (isReady(p)) {
        if (!Array.isArray(p.rowsHtml) || !p.rowsHtml.every(x => typeof x === 'string' && /^<tr(?:\s|>)/.test(x)) || !Array.isArray(p.columns) || p.columnCount !== p.columns.length || p.columnCount < 1 || p.columnCount > 2000 || typeof p.theadHtml !== 'string' || !Number.isInteger(p.maxRows) || p.maxRows > 3000 || p.maxRows < 1 || p.returnedRows !== p.rowsHtml.length || p.rowsHtml.length > p.maxRows || (p.status === 'empty') !== (p.rowsHtml.length === 0) || ![true, false, null].includes(p.hasMore))
            throw new Error('データ行数・列情報・上限の応答契約が不正です。');
        if (!p.columns.every(c => isObject(c) && typeof c.name === 'string' && Number.isFinite(c.widthPx) && c.widthPx >= 48 && c.widthPx <= 1000))
            throw new Error('列幅の応答が不正です。');
    }
    for (const name of ['definition', 'indexes', 'synonyms'])
        if (isReady(d[name]) && (typeof d[name].html !== 'string' || !Number.isInteger(d[name].recordCount) || d[name].recordCount < 0 || (d[name].status === 'empty') !== (d[name].recordCount === 0)))
            throw new Error('定義HTMLの応答形式が不正です。');
}
class AppController {
    constructor(api, config) {
        this.api = api;
        this.config = config;
        this.connections = [];
        this.schemaGeneration = 0;
        this.listGeneration = 0;
        this.detailGeneration = 0;
        this.listHasMore = false;
        this.listMax = 4000;
        this.tables = [];
        this.filtered = [];
        this.tabs = new Map();
        this.serial = 0;
        this.cache = new DetailCache();
        this.connection = byId('connectionSelect');
        this.schema = byId('schemaSelect');
        this.history = new HistoryStore(`dbplus.history.tables.v1:${config.deploymentId}:${location.pathname.replace(/[^/]*$/, '')}`);
        this.listGrid = new VirtualGrid(byId('tableListViewport'), byId('tableListTable'), byId('tableListBody'));
        this.dataGrid = new VirtualGrid(byId('dataGridViewport'), byId('dataGridTable'), byId('dataGridBody'));
        this.bind();
        this.renderLinks();
    }
    async init() {
        try {
            const response = await this.api.get('connections');
            if (!Array.isArray(response.items) || !response.items.every(c => isObject(c) && validName(c.connectionId) && typeof c.label === 'string'))
                throw new Error('接続先応答が不正です。');
            this.connections = response.items;
            if (this.connections.some(c => c.dbProduct === 'DEMO'))
                byId('environmentBadge').textContent = 'DEMO · 架空データ';
            this.fillSelect(this.connection, this.connections.map(c => [c.connectionId, c.label]));
            this.connection.disabled = !this.connections.length;
            const allowed = new Set(this.connections.map(c => c.connectionId));
            this.history.items.filter(x => allowed.has(x.connectionId)).forEach(i => this.addTab(i, false));
            this.renderTabs();
            if (this.connections.length)
                await this.loadSchemas();
            else
                setStatus('tableListStatus', '利用可能な接続先が設定されていません。');
        }
        catch (e) {
            this.connection.replaceChildren(new Option('接続先を取得できません', ''));
            setStatus('tableListStatus', errorMessage(e), true);
        }
    }
    fillSelect(select, options) { select.replaceChildren(...options.map(([value, label]) => new Option(label, value))); }
    bind() {
        this.connection.addEventListener('change', () => { void this.loadSchemas(); });
        this.schema.addEventListener('change', () => this.resetList());
        byId('tableSearchForm').addEventListener('submit', e => { e.preventDefault(); void this.loadTables(); });
        byId('tableFilterInput').addEventListener('input', () => this.filterList());
        byId('tableListBody').addEventListener('click', e => { const row = e.target.closest('tr[data-list-index]'); if (row) {
            const item = this.filtered[Number(row.dataset.listIndex)];
            if (item)
                void this.open({ ...item, connectionId: this.connection.value });
        } });
        byId('tableListViewport').addEventListener('keydown', e => this.listKeys(e));
        byId('dbplusHomeBtn').addEventListener('click', () => this.home());
        byId('homeTabBtn').addEventListener('click', () => this.home());
        byId('tableTabList').addEventListener('click', e => { const b = e.target.closest('[data-table-key]'); const tab = b && this.tabs.get(b.dataset.tableKey || ''); if (tab)
            void this.open(tab.ref); });
        byId('mainTabBar').addEventListener('keydown', e => this.tabKeys(e, byId('mainTabBar')));
        byId('detailTabBar').addEventListener('keydown', e => this.tabKeys(e, byId('detailTabBar')));
        byId('detailTabBar').addEventListener('click', e => { const b = e.target.closest('[data-panel]'); if (b && this.active) {
            this.saveScroll();
            this.tabs.get(this.active).panel = b.dataset.panel;
            this.showPanel();
        } });
        byId('reloadDetailBtn').addEventListener('click', () => { if (this.active)
            void this.open(this.tabs.get(this.active).ref, true); });
        byId('linksTriggerBtn').addEventListener('click', () => this.toggleLinks());
        byId('linksCloseBtn').addEventListener('click', () => this.toggleLinks(false));
        document.addEventListener('keydown', e => { if (e.key === 'Escape' && !byId('linksPanel').hidden)
            this.toggleLinks(false); });
        document.addEventListener('click', e => { const target = e.target; if (!byId('linksPanel').hidden && !byId('linksPanel').contains(target) && !byId('linksTriggerBtn').contains(target))
            this.toggleLinks(false); });
        byId('dataGridBody').addEventListener('click', e => {
            const td = e.target.closest('td');
            const cell = td?.querySelector('.dbp-cell');
            if (!cell)
                return;
            byId('cellDetailValue').textContent = cell.textContent;
            byId('cellDetailNote').textContent = cell.classList.contains('dbp-null') ? 'SQL NULL' : cell.dataset.truncated === 'true' ? `先頭${(this.current && isReady(this.current.data) ? this.current.data.previewMaxChars : 2048)}文字までのプレビューです。` : 'サーバから取得済みの値を表示しています。';
            byId('cellDetailDialog').showModal();
        });
        byId('cellDetailCloseBtn').addEventListener('click', () => byId('cellDetailDialog').close());
        window.addEventListener('storage', e => { if (e.key === this.history.storageKey) {
            this.history.sync(e.newValue);
            const allowed = new Set(this.connections.map(c => c.connectionId));
            this.history.items.filter(i => allowed.has(i.connectionId)).forEach(i => this.addTab(i, false));
            this.renderTabs();
        } });
        window.addEventListener('pagehide', () => { this.schemaAbort?.abort(); this.listAbort?.abort(); this.detailAbort?.abort(); this.listGrid.destroy(); this.dataGrid.destroy(); });
    }
    tabKeys(e, bar) {
        if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key) || !(e.target instanceof HTMLElement) || e.target.getAttribute('role') !== 'tab')
            return;
        const buttons = [...bar.querySelectorAll('[role="tab"]')];
        const index = buttons.indexOf(e.target);
        if (index < 0)
            return;
        e.preventDefault();
        const next = e.key === 'Home' ? 0 : e.key === 'End' ? buttons.length - 1 : (index + (e.key === 'ArrowRight' ? 1 : -1) + buttons.length) % buttons.length;
        buttons[next].focus();
        buttons[next].click();
    }
    listKeys(e) {
        const row = e.target.closest('[data-list-index]');
        if (!row || !['ArrowDown', 'ArrowUp'].includes(e.key))
            return;
        const next = Math.max(0, Math.min(this.filtered.length - 1, Number(row.dataset.listIndex) + (e.key === 'ArrowDown' ? 1 : -1)));
        e.preventDefault();
        const vp = byId('tableListViewport');
        if (next * 32 < vp.scrollTop)
            vp.scrollTop = next * 32;
        else if ((next + 1) * 32 > vp.scrollTop + vp.clientHeight - 40)
            vp.scrollTop = (next + 1) * 32 - vp.clientHeight + 40;
        this.listGrid.refresh();
        requestAnimationFrame(() => byId('tableListBody').querySelector(`[data-list-index="${next}"] button`)?.focus({ preventScroll: true }));
    }
    resetList() {
        this.listAbort?.abort();
        this.listGeneration++;
        this.tables = [];
        this.filtered = [];
        this.listHasMore = false;
        this.listGrid.clear();
        byId('tableCount').textContent = '—';
        byId('tableListContext').textContent = this.schema.value ? `${this.connection.selectedOptions[0]?.textContent} / ${this.schema.value}` : 'スキーマを選択してください';
        setStatus('tableListStatus', '一覧を取得してください。');
        byId('loadTablesBtn').disabled = !this.schema.value;
        byId('tableListViewport').setAttribute('aria-busy', 'false');
    }
    async loadSchemas() {
        const gen = ++this.schemaGeneration;
        this.schemaAbort?.abort();
        const ctrl = this.schemaAbort = new AbortController();
        const connectionId = this.connection.value;
        this.schema.disabled = true;
        this.schema.replaceChildren(new Option('読込中…', ''));
        this.resetList();
        try {
            const res = await this.api.get('schemas', { connectionId }, ctrl.signal);
            if (gen !== this.schemaGeneration)
                return;
            if (res.connectionId !== connectionId || !Array.isArray(res.items) || !res.items.every(s => isObject(s) && validName(s.schemaName) && typeof s.label === 'string'))
                throw new Error('スキーマ応答が不正です。');
            this.fillSelect(this.schema, res.items.map(s => [s.schemaName, s.label]));
            this.schema.disabled = !res.items.length;
            this.resetList();
            if (!res.items.length)
                setStatus('tableListStatus', '利用可能なスキーマがありません。');
        }
        catch (e) {
            if (!ctrl.signal.aborted && gen === this.schemaGeneration) {
                this.schema.replaceChildren(new Option('取得できません', ''));
                setStatus('tableListStatus', errorMessage(e), true);
            }
        }
    }
    async loadTables() {
        if (!this.schema.value)
            return;
        this.resetList();
        const gen = ++this.listGeneration;
        const ctrl = this.listAbort = new AbortController();
        const connectionId = this.connection.value;
        const schemaName = this.schema.value;
        setStatus('tableListStatus', 'テーブル一覧を取得しています…');
        byId('tableListViewport').setAttribute('aria-busy', 'true');
        byId('loadTablesBtn').disabled = true;
        try {
            const res = await this.api.get('tables', { connectionId, schemaName }, ctrl.signal);
            if (gen !== this.listGeneration)
                return;
            if (res.connectionId !== connectionId || res.schemaName !== schemaName || !Array.isArray(res.items) || res.items.length > 4000 || res.returnedTables !== res.items.length || !res.items.every(t => validName(t.tableName) && t.schemaName === schemaName && typeof t.logicalName === 'string') || res.maxTables < 1 || res.maxTables > 4000)
                throw new Error('一覧の対象・件数が不正です。');
            this.listHasMore = res.hasMore;
            this.listMax = res.maxTables;
            this.tables = res.items;
            this.filterList();
            if (res.hasMore)
                setStatus('tableListStatus', `一覧は上限${res.maxTables.toLocaleString()}件まで取得しています。完全な一覧ではありません。`);
        }
        catch (e) {
            if (!ctrl.signal.aborted && gen === this.listGeneration)
                setStatus('tableListStatus', errorMessage(e), true);
        }
        finally {
            if (gen === this.listGeneration) {
                byId('tableListViewport').setAttribute('aria-busy', 'false');
                byId('loadTablesBtn').disabled = !this.schema.value;
            }
        }
    }
    filterList() {
        const q = byId('tableFilterInput').value.trim().toLocaleLowerCase();
        this.filtered = this.tables.filter(t => `${t.tableName}\n${t.logicalName}`.toLocaleLowerCase().includes(q));
        byId('tableCount').textContent = `${this.filtered.length.toLocaleString()} / ${this.tables.length.toLocaleString()} 件`;
        setStatus('tableListStatus', `${this.filtered.length ? 'テーブル名または行を選択して開きます。' : '該当するテーブルがありません。'}${this.listHasMore ? `\n一覧は上限${this.listMax}件です。完全な一覧ではありません。` : ''}`);
        this.listGrid.set(this.filtered.length, 4, i => { const t = this.filtered[i]; return `<tr data-list-index="${i}" aria-rowindex="${i + 2}"><td>${i + 1}</td><td><button type="button" class="dbp-table-link">${escapeHtml(t.tableName)}</button></td><td><span class="dbp-cell">${escapeHtml(t.logicalName)}</span></td><td><span class="dbp-cell">${escapeHtml(t.schemaName)}</span></td></tr>`; });
    }
    addTab(ref, prepend = true) {
        const key = keyOf(ref);
        const old = this.tabs.get(key);
        if (old)
            return old;
        const tab = { ref: { connectionId: ref.connectionId, schemaName: ref.schemaName, tableName: ref.tableName }, domId: `tableTab-${++this.serial}`, panel: 'data', scroll: { data: { top: 0, left: 0 }, definition: { top: 0, left: 0 }, indexes: { top: 0, left: 0 }, synonyms: { top: 0, left: 0 } } };
        if (prepend)
            this.tabs = new Map([[key, tab], ...this.tabs]);
        else
            this.tabs.set(key, tab);
        while (this.tabs.size > 100) {
            const victim = [...this.tabs.keys()].reverse().find(k => k !== this.active && k !== key);
            if (!victim)
                break;
            this.tabs.delete(victim);
            this.cache.delete(victim);
        }
        return tab;
    }
    renderTabs() {
        const focusedId = document.activeElement?.id;
        const area = byId('tableTabList');
        const fragment = document.createDocumentFragment();
        this.tabs.forEach((t, key) => {
            const b = document.createElement('button');
            b.id = t.domId;
            b.type = 'button';
            b.className = `dbp-main-tab${this.active === key ? ' is-active' : ''}`;
            b.setAttribute('role', 'tab');
            b.setAttribute('aria-controls', 'tableWorkspaceView');
            b.setAttribute('aria-selected', String(this.active === key));
            b.tabIndex = this.active === key ? 0 : -1;
            b.dataset.tableKey = key;
            b.title = `${this.connections.find(c => c.connectionId === t.ref.connectionId)?.label || t.ref.connectionId} / ${t.ref.schemaName} / ${t.ref.tableName}`;
            const schema = document.createElement('span');
            schema.className = 'dbp-tab-schema';
            schema.textContent = t.ref.schemaName;
            const name = document.createElement('span');
            name.className = 'dbp-tab-name';
            name.textContent = t.ref.tableName;
            b.append(schema, name);
            fragment.append(b);
        });
        area.replaceChildren(fragment);
        const home = byId('homeTabBtn');
        home.classList.toggle('is-active', !this.active);
        home.setAttribute('aria-selected', String(!this.active));
        home.tabIndex = this.active ? -1 : 0;
        if (focusedId && document.getElementById(focusedId))
            byId(focusedId).focus({ preventScroll: true });
    }
    saveScroll() { if (!this.active)
        return; const t = this.tabs.get(this.active); if (!t)
        return; const v = t.panel === 'data' ? byId('dataGridViewport') : byId(`${t.panel}Content`).querySelector('.tableInfoTableWrap'); if (v)
        t.scroll[t.panel] = { top: v.scrollTop, left: v.scrollLeft }; }
    home() {
        this.saveScroll();
        this.detailAbort?.abort();
        this.detailGeneration++;
        this.pending = undefined;
        this.active = undefined;
        this.current = undefined;
        this.dataGrid.clear();
        for (const p of ['definition', 'indexes', 'synonyms'])
            byId(`${p}Content`).replaceChildren();
        byId('homeView').hidden = false;
        byId('tableWorkspaceView').hidden = true;
        this.renderTabs();
        this.listGrid.refresh();
    }
    async open(ref, force = false) {
        const key = keyOf(ref);
        if (key === this.active && this.pending?.key === key && !force)
            return this.pending.promise;
        this.saveScroll();
        if (this.active !== key || force) {
            this.detailAbort?.abort();
            this.detailGeneration++;
            this.pending = undefined;
        }
        this.active = key;
        const tab = this.addTab(ref);
        this.renderTabs();
        byId('homeView').hidden = true;
        byId('tableWorkspaceView').hidden = false;
        byId('tableWorkspaceView').setAttribute('aria-labelledby', tab.domId);
        byId('tableWorkspaceName').textContent = ref.tableName;
        byId('tableWorkspaceContext').textContent = `${this.connections.find(c => c.connectionId === ref.connectionId)?.label || ref.connectionId} / ${ref.schemaName}`;
        byId('tableWorkspaceLogicalName').textContent = '';
        if (force)
            this.cache.delete(key);
        const cached = this.cache.get(key);
        if (cached) {
            byId('tableWorkspaceView').setAttribute('aria-busy', 'false');
            this.current = cached;
            this.history.touch(ref);
            this.renderDetail(cached);
            return;
        }
        this.current = undefined;
        this.dataGrid.clear();
        byId('dataGridHead').replaceChildren();
        byId('dataGridCols').replaceChildren();
        for (const p of ['definition', 'indexes', 'synonyms']) {
            byId(`${p}Content`).replaceChildren();
            setStatus(`${p}Status`, '');
        }
        setStatus('dataStatus', '');
        this.showPanel();
        setStatus('detailStatus', '4タブの情報を取得しています…');
        byId('tableWorkspaceView').setAttribute('aria-busy', 'true');
        const gen = ++this.detailGeneration;
        const ctrl = this.detailAbort = new AbortController();
        const promise = (async () => {
            try {
                const detail = await this.api.get('table-detail', { connectionId: ref.connectionId, schemaName: ref.schemaName, tableName: ref.tableName }, ctrl.signal);
                if (gen !== this.detailGeneration || ctrl.signal.aborted)
                    return;
                validateDetail(detail, ref);
                this.cache.set(key, detail);
                if (this.active !== key)
                    return;
                this.current = detail;
                this.history.touch(ref);
                this.renderDetail(detail);
            }
            catch (e) {
                if (!ctrl.signal.aborted && this.active === key && gen === this.detailGeneration)
                    setStatus('detailStatus', errorMessage(e), true);
            }
            finally {
                if (gen === this.detailGeneration) {
                    this.pending = undefined;
                    byId('tableWorkspaceView').setAttribute('aria-busy', 'false');
                }
            }
        })();
        this.pending = { key, promise };
        return promise;
    }
    renderDetail(d) {
        byId('tableWorkspaceLogicalName').textContent = d.logicalName;
        const time = new Date(d.fetchedAt).toLocaleString('ja-JP');
        setStatus('detailStatus', `取得時刻：${time}　${d.partial ? '一部の情報を取得できません。各タブを確認してください。' : '4タブの情報を取得しました。'}　[${d.requestId}]`);
        const p = d.data;
        if (isReady(p)) {
            const cols = p.columns;
            byId('dataGridCols').replaceChildren(...cols.map(c => { const col = document.createElement('col'); col.style.width = `${c.widthPx}px`; return col; }));
            byId('dataGridTable').style.width = `${cols.reduce((s, c) => s + c.widthPx, 0)}px`;
            byId('dataGridHead').innerHTML = p.theadHtml;
            setStatus('dataStatus', `${p.returnedRows.toLocaleString()}件を取得${p.hasMore ? ` · 上限${p.maxRows}件まで表示しています（総件数は未取得）` : p.hasMore === null && p.returnedRows === p.maxRows ? ' · 上限に到達しています（超過未確認）' : ''}${!p.returnedRows ? ' · データがありません' : ''}${!p.orderGuaranteed ? ' · 取得順序は未保証です' : ''}${p.previewTruncatedCells ? ` · ${p.previewTruncatedCells}セルの長文を省略` : ''}${p.warnings.length ? '\n' + p.warnings.join('\n') : ''}`);
        }
        else {
            byId('dataGridHead').replaceChildren();
            this.resultStatus('dataStatus', p);
        }
        for (const name of ['definition', 'indexes', 'synonyms']) {
            const p = d[name];
            if (isReady(p)) {
                byId(`${name}Content`).innerHTML = p.html;
                setStatus(`${name}Status`, `${p.recordCount}件${name === 'definition' ? ` · 取得元：${p.source || '未指定'}${p.definitionVersion ? ` · 定義版：${p.definitionVersion}` : ''}` : ''}${p.warnings.length ? '\n' + p.warnings.join('\n') : ''}`);
            }
            else {
                byId(`${name}Content`).replaceChildren();
                this.resultStatus(`${name}Status`, p);
            }
        }
        this.showPanel();
    }
    resultStatus(id, p) { const message = 'message' in p ? p.message : `${p.error.message} [${p.error.code}]`; setStatus(id, `${message}${p.warnings.length ? '\n' + p.warnings.join('\n') : ''}`, p.status === 'error' || p.status === 'forbidden'); }
    showPanel() {
        if (!this.active)
            return;
        const t = this.tabs.get(this.active);
        panels.forEach(p => { byId(`${p}Panel`).hidden = p !== t.panel; const b = byId(`${p}TabBtn`); b.setAttribute('aria-selected', String(p === t.panel)); b.tabIndex = p === t.panel ? 0 : -1; });
        const scroll = t.scroll[t.panel];
        if (t.panel === 'data') {
            const p = this.current?.data;
            if (p && isReady(p)) {
                this.dataGrid.set(p.rowsHtml.length, p.columnCount, i => p.rowsHtml[i], scroll.top, scroll.left);
            }
            else
                this.dataGrid.clear();
        }
        else {
            const vp = byId(`${t.panel}Content`).querySelector('.tableInfoTableWrap');
            if (vp) {
                vp.scrollTop = Math.max(0, Math.min(scroll.top, vp.scrollHeight - vp.clientHeight));
                vp.scrollLeft = Math.max(0, Math.min(scroll.left, vp.scrollWidth - vp.clientWidth));
            }
        }
    }
    toggleLinks(open = byId('linksPanel').hidden) { byId('linksPanel').hidden = !open; byId('linksTriggerBtn').setAttribute('aria-expanded', String(open)); if (!open)
        byId('linksTriggerBtn').focus({ preventScroll: true }); }
    renderLinks() {
        const area = byId('linksContent');
        this.config.links.forEach(item => { try {
            const url = new URL(item.url, location.href);
            if (!['http:', 'https:'].includes(url.protocol))
                return;
            const a = document.createElement('a');
            a.textContent = item.label;
            a.href = url.href;
            a.target = '_blank';
            a.rel = 'noopener noreferrer';
            area.append(a);
        }
        catch { /* 不正な設定URLは表示しない。 */ } });
        if (!area.children.length) {
            const p = document.createElement('p');
            p.className = 'dbp-links-empty';
            p.textContent = 'リンクが未設定です。';
            area.append(p);
        }
    }
}
async function bootstrap() {
    try {
        const response = await fetch('config/ui.json', { cache: 'no-store' });
        if (!response.ok)
            throw new Error('config/ui.jsonを取得できません。HTTPサーバ経由で開いてください。');
        const config = await response.json();
        if (typeof config.apiBase !== 'string' || !validName(config.deploymentId) || !Array.isArray(config.links) || !config.links.every(x => isObject(x) && typeof x.label === 'string' && typeof x.url === 'string'))
            throw new Error('画面設定が不正です。');
        const base = new URL(config.apiBase, location.href);
        if (base.origin !== location.origin || !['http:', 'https:'].includes(base.protocol) || !base.pathname.endsWith('/'))
            throw new Error('APIベースは同一オリジンの末尾 / 付きURLを指定してください。');
        const app = new AppController(new ApiClient(base), config);
        await app.init();
    }
    catch (e) {
        setStatus('tableListStatus', errorMessage(e), true);
    }
}
void bootstrap();
export {};
