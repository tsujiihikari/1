# API仕様

すべてPOST、Content-Type: application/x-www-form-urlencoded;charset=UTF-8、
X-DBPlus-Request: 1 を付けます。クライアントは同一WARから相対URLで呼び出します。
応答はUTF-8のJSON、Cache-Control: no-store です。

## 共通パラメーター

| 名前 | 用途 |
| --- | --- |
| domain | RPSログインドメイン |
| loginID | RPSログインID。RPS側のshain_cdへ変換 |
| loginPass | RPSパスワード。前後空白を変更しない |
| connectionId | login応答の接続先ID |
| schema | 選択したRPSスキーマ・Oracle所有者 |
| dbtype | 選択したDBTYPE |

loginは最初の3項目、initial/search/detailは6項目すべてを送ります。
先にloginを成功させ、同じHttpSession Cookieで以降の要求を送ってください。
login以外の要求でも認証3項目を照合しますが、毎回RPSへログインし直すことはありません。

## POST /api/login

認証3項目でRPSログインを検証します。

成功例：

~~~json
{
  "ok": true,
  "status": "接続OK",
  "connections": [
    {"connectionId":"connection-2","type":"JH","dbtype":"SAMPLEDB","schema":"SAMPLEOWNER","label":"JH / SAMPLEDB / SAMPLEOWNER / sample (db.example)"}
  ]
}
~~~

認証失敗はHTTP 401、ok:false, status:"失敗", code:"AUTH_REQUIRED", error を返します。
ネットワーク障害はHTTP 502です。DB接続先一覧にDBのユーザー名・パスワードは含めません。

同じURLへ operation=logout だけを送るとRPS状態を破棄します。

## POST /api/initial

共通6項目を指定します。ページ番号や検索条件は受け取らず、空条件で4種類を必ずpage=1から取得します。

~~~json
{
  "ok": true,
  "lists": {
    "table": {"ok":true,"kind":"table","headers":[],"rows":[],"page":1,"pageSize":50,"totalCount":0,"totalPages":1,"query":{"object_name":"","description":"","target_object_name":"","TYPE":"prefix"},"warnings":[]},
    "index": {"ok":true},
    "view": {"ok":true},
    "synonym": {"ok":true}
  },
  "partial": false,
  "warnings": []
}
~~~

上記のindex/view/synonymも実応答ではtableと同じ一覧構造です。
一部の一覧だけ失敗した場合、その一覧に ok:false, error を設定し、全体の partial:true とwarningsを返します。
認証切れは全体をHTTP 401とします。

## POST /api/search

共通6項目に加え、次を指定します。

| 名前 | 値 |
| --- | --- |
| kind | table, index, synonym, view |
| page | 1以上のページ番号 |
| TYPE | prefix（前方一致）または contains（曖昧検索） |
| object_name | 物理名。省略可 |
| description | 日本語名称。table/index/viewで使用、省略可 |
| target_object_name | シノニムの参照先名。synonymで使用、省略可 |

TYPEは大文字小文字を区別せず受け、応答では小文字に正規化します。
シノニムでdescriptionを指定した場合は、RPSに対応検索がないためHTTP 400になります。
検索結果はinitialのlists内と同じ一覧構造です。0件でも ok:true と空配列、totalPages:1 を返します。

一覧行の例：

~~~json
{
  "recordId":"サーバー発行UUID",
  "connectionId":"connection-2",
  "schema":"SAMPLEOWNER",
  "dbtype":"SAMPLEDB",
  "kind":"table",
  "name":"SAMPLE_TABLE",
  "owner":"SAMPLEOWNER",
  "version":"2.4",
  "description":"顧客情報",
  "cells":["SAMPLEDB","SAMPLE_TABLE","2.4","","顧客情報"]
}
~~~

cells は実際にはRPSの全ヘッダー列に対応します。オブジェクト種別ごとに列数が異なります。
クライアントは列ヘッダーとcellsを同じ応答から使用します。

## POST /api/detail

共通6項目と、一覧行から得た次の4項目を送ります。

| 名前 | 値 |
| --- | --- |
| recordId | 一覧でサーバーが発行したID |
| kind | 行の種別 |
| object_name | 行のname |
| version | 行のversion |

RPSの説明文はサーバー側で保持したものを使います。

~~~json
{
  "ok":true,
  "kind":"table",
  "name":"SAMPLE_TABLE",
  "schema":"SAMPLEOWNER",
  "dbtype":"SAMPLEDB",
  "connectionId":"connection-2",
  "version":"2.4",
  "description":"顧客情報",
  "definition":{"ok":true,"headers":["項目名","日本語名称"],"rows":[["ID","顧客番号"]]},
  "ddl":{"ok":true,"text":"CREATE TABLE ..."},
  "data":{
    "ok":true,
    "columns":[{"name":"ID","japaneseName":"顧客番号","type":"NUMBER"}],
    "rows":[["9007199254740993"]],
    "rowCount":1,
    "limit":5000,
    "limitReached":false,
    "truncatedCells":0,
    "responseLimited":false
  },
  "partial":false,
  "warnings":[]
}
~~~

- definition, ddl, data は個別に ok を持ちます。失敗した部位は { "ok":false, "error":"説明" } です。
- 一部または全部が取得失敗でも、識別情報が正しければ詳細のHTTP応答は200で、partial:true とwarningsで状態を明示します。クライアントは各部位のokを判定します。
- table以外は definition:null, data:null でDDLだけを取得します。ビューやシノニムからのデータSELECTは行いません。
- limitReached:true は返却件数が5,000件という意味です。5,001件目の有無は意味しません。
- responseLimited:true は概算応答サイズ上限による打切りです。
- truncatedCells は1セルの長さ上限で省略したセル数です。
- RPSのバージョンは定義に使用します。Oracleデータは現在の接続先のデータです。

## HTTPステータス

| ステータス | 内容 |
| --- | --- |
| 200 | 操作の応答。部分取得の失敗は各部位のok・partial・warningsで判定 |
| 400 | 未指定、不正な種別/ページ/TYPE、接続先不一致、行IDまたはバージョン不一致 |
| 401 | RPS認証失敗・セッション失効・認証情報変更。再ログインが必要 |
| 403 | 画面用リクエストヘッダーがない |
| 405 | GETなどPOST以外 |
| 502 | 接続先への通信・応答形式などの取得失敗 |

例外メッセージへRPSパスワード、Oracleユーザー/パスワード、SQL全文は含めません。
